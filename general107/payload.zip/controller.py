"""Serial fresh ABI3 groups inside the qualified private mount namespace."""
from pathlib import Path
import importlib.util
import json
import math
import os
import shlex
import signal
import subprocess
import sys
import time
from operations import ROOT,CANN,gate,integrity,require,run,save,sha


def group_alive(pid):
    try:os.killpg(pid,0);return True
    except ProcessLookupError:return False


def finish(processes, directory):
    for sig,seconds in ((signal.SIGTERM,5),(signal.SIGKILL,5)):
        for p in processes:
            p.poll()
            if group_alive(p.pid):
                try:os.killpg(p.pid,sig)
                except ProcessLookupError:pass
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            for p in processes:p.poll()
            if not any(group_alive(p.pid) for p in processes):break
            time.sleep(.05)
    rows=[{'pid':p.pid,'exit_code':p.poll(),'group_remaining':group_alive(p.pid)} for p in processes]
    save(directory/'process-exits.json',rows)
    require(all(r['exit_code'] is not None and not r['group_remaining'] for r in rows),'Own process state unknown')


def build_integrity():
    result=json.loads((ROOT/'build-summary.json').read_text())
    require(result['status']=='PASS' and result['candidate']=='64ed582898e1321a0e93a2c4e0e78a6deb2f4868','Build prerequisite')
    for name,digest in result['artifacts'].items():require(sha(ROOT/name)==digest,'Built artifact changed')
    for name,digest in json.loads((ROOT/'payload-manifest.json').read_text())['files'].items():
        require(sha(ROOT/name)==digest,'Experiment input changed: '+name)
    integrity(private=True)
    return result


def one_group(phase,index,directory,build):
    directory.mkdir(exist_ok=False)
    base=27000+index*64;host=29400+index*3
    before=gate(directory/'before',ports=[*range(base,base+32),host,host+1,host+2])
    build_integrity()
    profile=phase=='capture';env=os.environ.copy()
    require(not any(env.get(k) for k in ('ASCEND_VISIBLE_DEVICES','ASCEND_RT_VISIBLE_DEVICES','LD_PRELOAD')),'Unexpected overrides')
    env.update(HCCL_IF_BASE_PORT=str(base),TILEXR_COMM_ID='127.0.0.1:'+str(host+1),TILEXR_UDMA_ATTACH_EXISTING_RA='1')
    processes=[];logs=[];commands=[];success=False
    save(directory/'launch-intent.json',{'devices':[0,1],'profile':profile,'index':index,'hccl_base_port':base,'host_ports':[host,host+1,host+2]})
    try:
        for rank in range(2):
            out=directory/('rank'+str(rank));out.mkdir()
            command=[build['runner'],str(rank),str(rank),str(host),str(host+2),str(ROOT/'fixture'/('rank'+str(rank))),str(out),build['raw_elf'],build['profile_elf'] if profile else 'none','20']
            if profile:
                command=[str(CANN/'tools/profiler/bin/msprof'),'--application='+shlex.join(command),'--output='+str(directory/('prof-rank'+str(rank))),'--task-time=on']
            log=(directory/('rank'+str(rank)+'.log')).open('xb');logs.append(log)
            p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
            processes.append(p);commands.append({'rank':rank,'pid':p.pid,'argv':command})
            save(directory/'commands.json',commands)
        deadline=time.monotonic()+240
        while any(p.poll() is None for p in processes):
            require(not any(p.poll() not in (None,0) for p in processes),'Rank/profiler failed; stop group')
            require(time.monotonic()<deadline,'Group timeout; do not replay')
            time.sleep(.1)
        require(all(p.returncode==0 for p in processes),'Rank/profiler nonzero')
        success=True
    finally:
        finish(processes,directory)
        for log in logs:log.close()
    require(success,'Group incomplete')
    ranks=[]
    if profile:
        sys.path.insert(0,str(ROOT/'source/tools/tilelang_runtime_experiment'))
        from analyze import analyze_rank
    for rank in range(2):
        summary=json.loads((directory/('rank'+str(rank))/'summary.json').read_text())
        require(summary['status']=='PASS' and summary['verified_iterations']==21 and summary['allreduce_values_checked']==22 and summary['flags_cleared'],'Business/flags/AR failed')
        log=(directory/('rank'+str(rank)+'.log')).read_text(errors='replace')
        require('TileXR UDMA attaching to existing RA initialization' in log and 'InitUDMA success' in log,'Explicit RA attachment absent')
        if profile:
            row=analyze_rank(directory/('rank'+str(rank)),directory/('prof-rank'+str(rank)),rank)
            save(directory/('analysis-rank'+str(rank)+'.json'),row)
        ranks.append(summary)
    after=gate(directory/'after')
    build_integrity()
    summary={'status':'PASS','index':index,'phase':phase,'ranks':ranks,'before':before,'after':after,'clock':'NOT_VERIFIED'}
    save(directory/'summary.json',summary);return {'index':index,'status':'PASS','summary_sha256':sha(directory/'summary.json')}


def main():
    phase=sys.argv[1];require(phase in ('correctness','capture'),'Unknown phase')
    directory=ROOT/phase;directory.mkdir(exist_ok=False)
    result={'schema':'tilelang_general_107_phase.v1','phase':phase,'status':'FAIL_OR_UNVERIFIED','groups':[],'npu_launch':False,'clock':'NOT_VERIFIED'}
    try:
        build=build_integrity()
        if phase=='capture':
            previous=json.loads((ROOT/'correctness/summary.json').read_text())
            require(previous['status']=='PASS' and len(previous['groups'])==3,'Three correctness groups required before capture')
            for g in previous['groups']:require(sha(ROOT/'correctness'/('g'+str(g['index']).zfill(3))/'summary.json')==g['summary_sha256'],'Prior correctness changed')
        for index in (range(3) if phase=='correctness' else range(3,13)):
            result['current_group']=index;save(directory/'progress.json',result)
            g=directory/('g'+str(index).zfill(3))
            try:row=one_group(phase,index,g,build)
            finally:
                if (g/'launch-intent.json').exists():result['npu_launch']=True
            result['groups'].append(row);save(directory/'progress.json',result)
        result.pop('current_group',None);result['status']='PASS'
    except Exception as e:result.update(error_type=type(e).__name__,error_detail=str(e)[:350])
    save(directory/'summary.json',result)
    print(json.dumps(result,separators=(',',':')))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
