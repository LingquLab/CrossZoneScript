"""CPU boundaries only: strict business/tail acceptance and ABI3 Host signatures."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from examples.tilelang_dispatch.tests.test_runtime_session import ACL, HCCL, RUNTIME_STUB


class FrontendTests(unittest.TestCase):
    def test_exact_golden_and_tail_rejections(self):
        with tempfile.TemporaryDirectory() as d:
            directory = Path(d)
            cpp = directory / 'test.cpp'
            cpp.write_text(r'''
#include "golden.h"
using namespace runtime_experiment;
int main() {
 std::vector<unsigned char> expected{0, 0xff, 0xa5}, actual{0, 0xff, 0xa5, 0xa5};
 CheckBytes(actual,expected,true,"valid");
 int rejected=0;
 actual[1]=0xfe; try{CheckBytes(actual,expected,true,"bad data");}catch(const std::runtime_error&){++rejected;}
 actual[1]=0xff;actual[3]=0;try{CheckBytes(actual,expected,true,"bad tail");}catch(const std::runtime_error&){++rejected;}
 actual[3]=0xa5;try{CheckBytes(actual,expected,false,"bad size");}catch(const std::runtime_error&){++rejected;}
 actual.resize(2);try{CheckBytes(actual,expected,true,"truncated");}catch(const std::runtime_error&){++rejected;}
 return rejected==4?0:1;
}
''')
            subprocess.run(['g++', '-std=c++14', '-Wall', '-Wextra', '-Werror',
                            '-I' + str(Path(__file__).parent), str(cpp), '-o', str(directory / 'test')], check=True)
            subprocess.run([str(directory / 'test')], check=True)

    def test_runner_real_tilexr_headers_with_cann_signature_stubs(self):
        with tempfile.TemporaryDirectory() as d:
            directory = Path(d)
            acl = ACL + '\nusing aclrtContext=void*; extern int aclrtGetCurrentContext(aclrtContext*); extern int aclInit(const char*); extern int aclrtSetDevice(int); extern int aclrtCreateStream(aclrtStream*); extern int aclrtDestroyStream(aclrtStream); extern int aclFinalize();\n'
            for name, source in {'acl/acl.h': acl, 'hccl/hccl.h': HCCL,
                                 'hccl/hccl_comm.h': '#include "hccl.h"\n',
                                 'runtime/kernel.h': RUNTIME_STUB,
                                 'runtime/rt.h': '#include "kernel.h"\n'}.items():
                p = directory / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(source)
            subprocess.run(['g++', '-std=c++14', '-Wall', '-Wextra', '-Werror',
                            '-Wno-misleading-indentation', '-fsyntax-only',
                            '-DTL_PRE_ALLREDUCE_SUPPORT=1', '-D_GLIBCXX_USE_CXX11_ABI=0',
                            '-I' + d, '-I' + str(ROOT / 'examples/tilelang_dispatch'),
                            '-I' + str(ROOT / 'src/include'), str(Path(__file__).with_name('runner.cpp'))], check=True)


if __name__ == '__main__':
    unittest.main()
