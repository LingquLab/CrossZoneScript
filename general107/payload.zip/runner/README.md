# ABI3 Dispatch experiment frontend

Build `CMakeLists.txt` with the frozen raw/profile export directories, matching
CANN and an ABI0 TileXR prefix. The runner takes rank, physical device, root
exchange port, barrier port, fixture directory, existing output directory, raw
ELF, profile ELF (or `none`), and warmup count. This acceptance frontend covers
P2/E4/T256/H256/K2 BF16 on physical devices0/1, with 20+1 Dispatch and 22 SUM2
checks per rank. It compares TL039 business bytes exactly and checks unused
output/assist capacity remains `0xA5`.

An external bounded controller must provide device gates, isolated qualified
topology, ports, fresh directories and whole-group failure handling. On failure
the runner exits without unwinding device owners; it never resets a device or
destroys communication while another rank may still run. On success it uses the
session's TileXR-before-HCCL destruction order.

Capture allocation precedes every session ready/barrier. The profile launch is
the final measured iteration only. `analyze.py` requires exactly20 raw tasks
and1 profile task and composes intervals on the same core before aggregating.
Receiver membership comes from actual `received_records`; absent F8/F9 is
`NOT_EXECUTED`, not a measured zero. ABI3 has no separate final-fence marker.

Signature stubs check C++ integration only. Real CANN compilation, hardware
correctness and timing remain separate acceptance steps.
