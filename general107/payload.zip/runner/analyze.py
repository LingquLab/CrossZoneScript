"""ABI3 capture analysis: same-core composition, actual workload cohorts, raw ticks."""
import csv
import hashlib
import json
import math
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'examples'))
from tilelang_dispatch.runtime_profile import STAGES, summarize_lanes


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stat(pairs):
    if not pairs:
        return {'status': 'NOT_EXECUTED', 'participants': 0, 'mean_ticks': None, 'max_ticks': None, 'slowest_cores': []}
    maximum = max(v for _, v in pairs)
    return {'status': 'EXECUTED', 'participants': len(pairs),
            'mean_ticks': sum(v for _, v in pairs) / len(pairs), 'max_ticks': maximum,
            'slowest_cores': [c for c, v in pairs if v == maximum],
            'participant_mask': format(sum(1 << c for c, _ in pairs), '016x')}


def analyze_rank(directory, profiler_directory, rank):
    directory, profiler_directory = Path(directory), Path(profiler_directory)
    summary = json.loads((directory / 'summary.json').read_text())
    if summary['status'] != 'PASS' or summary['rank'] != rank or summary['verified_iterations'] != 21:
        raise ValueError('Rank acceptance missing')
    lanes = json.loads((directory / 'lanes.json').read_text())
    if sorted(lane['core'] for lane in lanes) != list(range(64)):
        raise ValueError('Capture must have exactly cores0-63')
    # Public parser validates pairs, IDs and enclosure. Keep per-core values to
    # compose before any cross-core aggregation.
    result = summarize_lanes(lanes)
    diag = struct.unpack('<1024i', (directory / 'round20.diagnostics.bin').read_bytes())
    workloads = {c: dict(zip(('error', 'count_polls', 'gate_polls', 'payload_polls',
                             'route_ids_read', 'sent_records', 'reserved6', 'received_records',
                             'reserved8', 'sent_wire_bytes', 'received_wire_bytes'), diag[c * 16:c * 16 + 11]))
                 for c in range(64)}
    receivers = {c for c in range(64) if workloads[c]['received_records'] > 0}
    if receivers != set(range(4)) or any(workloads[c]['received_records'] != 128 for c in receivers):
        raise ValueError('Actual received_records differs from core0-3/128 per receiver')
    components = {
        'F0': ('F0.send_layout',), 'F1': ('F1.route_read',), 'F2': ('F2.expert_count',),
        'F3': ('F3.count_publish',), 'F4': ('F4.pack_send',), 'F5': ('F5.wait_count',),
        'F6': ('F6.prefix_publish',), 'F7': ('F7.layout_wait', 'F7.receive_plan'),
        'F8': ('F8.payload_loop',), 'F9': ('F9.payload_clear',),
        'F8+F9': ('F8.payload_loop', 'F9.payload_clear'),
        'module.receive_output': ('F7.layout_wait', 'F7.receive_plan', 'F8.payload_loop', 'F9.payload_clear')}
    by_core = {}
    for lane in lanes:
        c = lane['core']; values = dict(zip(lane['event_ids'], lane['timestamps']))
        stages = {name: values[end] - values[begin] for begin, (name, end) in STAGES.items() if begin in values}
        if ('F8.payload_loop' in stages) != (c in receivers) or ('F9.payload_clear' in stages) != (c in receivers):
            raise ValueError('Workload/marker participation differs')
        by_core[c] = stages
    for name, parts in components.items():
        for cohort, cores in (('all', set(range(64))), ('receiver', receivers), ('non_receiver', set(range(64)) - receivers)):
            pairs = [(c, sum(by_core[c].get(part, 0) for part in parts)) for c in sorted(cores)
                     if any(part in by_core[c] for part in parts)]
            result[name + '.' + cohort] = stat(pairs)
    csvs = list(profiler_directory.rglob('op_summary*.csv'))
    if len(csvs) != 1:
        raise ValueError('Expected one msprof op_summary')
    with csvs[0].open(newline='') as f:
        tasks = list(csv.DictReader(f))
    raw = [r for r in tasks if r['Op Name'] == 'tilexr_tl_dispatch_runtime_c64']
    measured = [r for r in tasks if r['Op Name'] == 'tilexr_tl_dispatch_runtime_c64_profile']
    if len(raw) != 20 or len(measured) != 1:
        raise ValueError('msprof must show 20 raw warmups and one profile task')
    starts = [float(r['Task Start Time(us)']) for r in raw]
    duration = float(measured[0]['Task Duration(us)'])
    if not math.isfinite(duration) or duration <= 0 or max(starts) > float(measured[0]['Task Start Time(us)']):
        raise ValueError('Invalid measured task duration/order')
    summary['msprof_dispatch_us'] = duration
    return {'rank': rank, 'summary': summary, 'statistics': result, 'per_core': by_core,
            'workload': workloads, 'sources': {str(p): sha(p) for p in
                (directory / 'dispatch.records', directory / 'lanes.json', directory / 'round20.diagnostics.bin', csvs[0])},
            'clock': 'NOT_VERIFIED', 'units': 'raw ticks; no calibrated/global timeline',
            'boundaries': 'ABI3: count READY clear belongs to F7; output drain belongs to F8; F9 runs only receiver cores; no separate final_fence marker'}
