// Bounded experiment frontend. Production ABI3/session and device algorithms are reused unchanged.
#include "runtime_session_cann.h"
#include <tilexr/profiling/acl.h>
#include "golden.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <sstream>

namespace rt = tilexr::tilelang_dispatch;
namespace prof = TileXR::Profiling;
using runtime_experiment::Require;
using runtime_experiment::Read;
using runtime_experiment::Write;
using runtime_experiment::CheckBytes;

static void Acl(aclError code, const char* name) {
    Require(code == ACL_SUCCESS, std::string(name) + ": " + std::to_string(code));
}
static void CaptureStatus(const prof::Status& status) { Require(bool(status), status.message); }
static void Json(const std::string& path, const std::string& text) { Write(path, text.data(), text.size()); }
template<class T> static std::vector<T> Typed(const std::string& path) {
    const auto bytes = Read(path);
    Require(bytes.size() % sizeof(T) == 0, "Misaligned fixture " + path);
    std::vector<T> values(bytes.size() / sizeof(T));
    std::memcpy(values.data(), bytes.data(), bytes.size()); return values;
}

int main(int argc, char** argv) {
    // Objects that may own submitted work deliberately outlive exceptions. The
    // external controller stops the whole owned process group after any failure.
    std::string output;
    try {
        Require(argc == 10, "usage: runner rank device root-port barrier-port fixture-dir output-dir raw-elf profile-elf-or-none warmup");
        rt::RuntimeConfig config; rt::RuntimeLimits limits;
        config.rank = std::stoull(argv[1]); const int device = std::stoi(argv[2]);
        const int root_port = std::stoi(argv[3]), barrier_port = std::stoi(argv[4]);
        const std::string fixture = argv[5]; output = argv[6];
        const bool profile = std::string(argv[8]) != "none";
        rt::RuntimeSessionOptions options; options.warmup = std::stoull(argv[9]);
        Require(config.rank < 2 && device == int(config.rank) && options.warmup == 20,
                "This acceptance frontend requires P2 physical0/1 and 20+1");
        const auto layout = rt::MakeRuntimeLayout(config, limits);
        const auto strategy = rt::MakeRuntimeStrategy(config, limits);
        rt::RuntimeFixture inputs;
        inputs.x = Typed<std::uint16_t>(fixture + "/x.bin");
        inputs.ids = Typed<std::int32_t>(fixture + "/ids.bin");
        const std::map<std::string, std::vector<unsigned char>> golden{
            {"output", Read(fixture + "/expected_output.bin")},
            {"assist", Read(fixture + "/expected_assist.bin")},
            {"counts", Read(fixture + "/expected_counts.bin")},
            {"expert_nums", Read(fixture + "/expected_expert_nums.bin")}};
        Require(golden.at("output").size() == 512 * 512 && golden.at("assist").size() == 512 * 12 &&
                golden.at("counts").size() == 16 && golden.at("expert_nums").size() == 16,
                "TL039 golden shape mismatch");
        Acl(aclInit(nullptr), "aclInit"); Acl(aclrtSetDevice(device), "aclrtSetDevice");
        aclrtStream stream = nullptr; Acl(aclrtCreateStream(&stream), "aclrtCreateStream");
        auto* raw = new rt::RuntimeKernelLaunch(Read(argv[7]), "tilexr_tl_dispatch_runtime_c64", limits, 64, false);
        auto* instrumented = profile ? new rt::RuntimeKernelLaunch(Read(argv[8]), "tilexr_tl_dispatch_runtime_c64_profile", limits, 64, true) : nullptr;
        auto* ops = new rt::RuntimeCannOps(stream, *raw, instrumented, device, root_port, barrier_port);
        auto* capture = new prof::AclCapture;
        if (profile) {
            prof::CaptureConfig c; c.rank = config.rank; c.logicalStreamCount = 64; c.recordsPerStream = 32;
            // Before all session ready/barriers, never in a measured window.
            CaptureStatus(capture->Initialize(c, stream));
        }
        auto* session = new rt::RuntimeCannSession(*ops, config, limits, options);
        session->Initialize(inputs); session->Prepare();
        std::size_t validated = 0;
        auto validate = [&](const rt::RuntimeRound& round) {
            struct Buffer { const char* name; void* address; std::size_t bytes; bool tail; };
            const Buffer buffers[] = {
                {"output", round.args.output, std::size_t(layout.output_capacity_rows * layout.feature_bytes), true},
                {"assist", round.args.assist, std::size_t(layout.output_capacity_rows * 12), true},
                {"counts", round.args.counts, 16, false}, {"expert_nums", round.args.expert_nums, 16, false}};
            for (const auto& buffer : buffers) {
                std::vector<unsigned char> actual(buffer.bytes); ops->Read(buffer.address, actual.data(), actual.size());
                // Preserve a failing or measured output before checking it.
                if (round.measured) Write(output + "/" + buffer.name + ".bin", actual.data(), actual.size());
                try { CheckBytes(actual, golden.at(buffer.name), buffer.tail, buffer.name); }
                catch (...) { Write(output + "/failed-" + std::to_string(round.iteration) + "-" + buffer.name + ".bin", actual.data(), actual.size()); throw; }
            }
            std::vector<std::int32_t> diag(64 * 16); ops->Read(round.args.diagnostics, diag.data(), diag.size() * 4);
            std::int64_t received = 0, sent = 0, recv_bytes = 0, sent_bytes = 0;
            for (std::size_t core = 0; core < 64; ++core) {
                const auto* d = &diag[core * 16];
                Require(d[0] == 0, "Device diagnostic failure");
                Require(d[7] == (core < 4 ? 128 : 0), "Actual receiver workload mask/count mismatch");
                received += d[7]; sent += d[5]; recv_bytes += d[10]; sent_bytes += d[9];
            }
            Require(received == 512 && sent == 512 && recv_bytes == 524288 && sent_bytes == 524288,
                    "Per-round record/wire totals mismatch");
            Write(output + "/round" + std::to_string(round.iteration) + ".diagnostics.bin", diag.data(), diag.size() * 4);
            ++validated;
        };
        const auto timing = session->Run(validate, profile ? capture->DeviceArgs() : nullptr);
        if (profile) {
            CaptureStatus(capture->Save(output + "/dispatch.records"));
            const auto* snapshot = capture->Snapshot();
            Require(snapshot && snapshot->streams.size() == 64, "Capture lane count mismatch");
            std::ostringstream lanes; lanes << "[";
            const std::set<unsigned> allowed{1,2,10,11,100,101,200,201,300,301,400,401,500,501,600,601,700,701,702,703,800,801,900,901};
            for (std::size_t core = 0; core < 64; ++core) {
                const auto& lane = snapshot->streams[core];
                Require(lane.id == (config.rank << 16 | core) && lane.complete && lane.dropped == 0 &&
                        lane.records.size() >= 2 && lane.records.size() <= 24, "Capture incomplete/overflow/lane identity");
                Require(lane.records.front().eventId == 1 && lane.records.back().eventId == 2, "Capture whole envelope missing");
                std::set<unsigned> seen; std::uint64_t last = 0;
                if (core) lanes << ',';
                lanes << "{\"core\":" << core << ",\"timestamps\":[";
                for (std::size_t i = 0; i < lane.records.size(); ++i) {
                    const auto& rec = lane.records[i];
                    Require(allowed.count(rec.eventId) && seen.insert(rec.eventId).second && rec.timestamp > 0 && rec.timestamp >= last,
                            "Invalid/duplicate/unordered marker");
                    if (i) lanes << ','; lanes << rec.timestamp; last = rec.timestamp;
                }
                lanes << "],\"event_ids\":[";
                for (std::size_t i = 0; i < lane.records.size(); ++i) { if (i) lanes << ','; lanes << lane.records[i].eventId; }
                lanes << "]}";
            }
            lanes << "]\n"; Json(output + "/lanes.json", lanes.str());
            CaptureStatus(capture->Close());
        }
        session->Close(); raw->Close(); if (instrumented) instrumented->Close();
        Acl(aclrtDestroyStream(stream), "aclrtDestroyStream"); Acl(aclFinalize(), "aclFinalize");
        Require(validated == 21, "Not all 20+1 iterations validated");
        std::ostringstream report; report.precision(17);
        report << "{\"schema\":\"tilelang_abi3_rank.v1\",\"status\":\"PASS\",\"rank\":" << config.rank
               << ",\"verified_iterations\":21,\"allreduce_values_checked\":22,\"flags_cleared\":true,\"profiling\":" << (profile ? "true" : "false")
               << ",\"actual_batch_capacity\":" << strategy.actual_batch_capacity
               << ",\"dispatch_acl_us\":" << timing.dispatch_acl_us << ",\"pre_dispatch_event_us\":" << timing.pre_dispatch_acl_us
               << ",\"segment_event_us\":" << timing.segment_acl_us << ",\"host_launch_sync_us\":" << timing.host_launch_sync_us
               << ",\"magic\":" << timing.magic << ",\"clock\":\"NOT_VERIFIED\"}\n";
        Json(output + "/summary.json", report.str()); std::puts("ABI3_RANK_PASS"); return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "ABI3_RANK_FAIL: %s\n", error.what()); std::fflush(nullptr);
        // No device reset, communicator destruction or unsafe destructor on a failed group.
        std::_Exit(1);
    }
}
