#pragma once
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

namespace runtime_experiment {
inline void Require(bool ok, const std::string& message) {
    if (!ok) throw std::runtime_error(message);
}
inline std::vector<unsigned char> Read(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    Require(bool(file), "Cannot open " + path);
    return {std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
}
inline void Write(const std::string& path, const void* data, std::size_t bytes) {
    std::ofstream file(path, std::ios::binary | std::ios::trunc);
    Require(bool(file), "Cannot create " + path);
    file.write(static_cast<const char*>(data), bytes);
    Require(bool(file), "Cannot write " + path);
}
// Compare valid business bytes exactly, then verify every unused allocation byte.
inline void CheckBytes(const std::vector<unsigned char>& actual,
                       const std::vector<unsigned char>& expected, bool sentinel_tail,
                       const std::string& label) {
    Require(actual.size() >= expected.size(), label + " truncated");
    Require(sentinel_tail || actual.size() == expected.size(), label + " length mismatch");
    for (std::size_t i = 0; i < expected.size(); ++i)
        if (actual[i] != expected[i]) throw std::runtime_error(label + " byte mismatch at " + std::to_string(i));
    for (std::size_t i = expected.size(); i < actual.size(); ++i)
        if (actual[i] != 0xA5) throw std::runtime_error(label + " tail modified at " + std::to_string(i));
}
}
