# [AI] ABI3运行时Dispatch：代码与验收边界

本入口是非量化MoE的ABI3运行时实现及性能优化候选；完整替代尚未完成。
性能机制、UB寿命和验收边界见[GENERAL_PERFORMANCE.zh-CN.md](GENERAL_PERFORMANCE.zh-CN.md)。
核心设备算法仍在`kernel.py`，一次launch执行全部五模块；旧`make_kernel`、
旧ABI2 runner及历史打点保留。ABI3没有借原生kernel执行业务，也没有运行时Python/JIT调用。

## 能力与验证

|内容|本候选状态|
|---|---|
|P/E/T/H/K/rank来自运行时描述符|已实现；真实lower及同一个CPU编译产物多形状验收|
|FP16/BF16、token mask、expertTokenNums count/prefix|已实现；位模式/golden、部分/全mask验收|
|480B有效块＋32B READY、任意合法尾部H|已实现；奇数H、1/2/3等不同块数导出及CPU验收|
|接收A/B批量跨步、向量READY全等、F8内排空、新F9|复用02候选思路并泛化块数；三批以上复用CPU验收，硬件事件未验证|
|Host描述符|独立C++14/Python逐字段一致、溢出/容量门禁、CMake编译/安装通过|
|设备源码|真实TileLang导出及纯AIV适配；实际UB不重叠/预算检查|
|多个prefix核|运行时最多8个producer；32B对齐切片、独立carry、每消费者/producer独立gate；CPU覆盖E32/E33|
|共享专家、分轮大规模调度|未实现；共享模式显式拒绝|
|MXFP8 quantMode=4|未实现；已复现固定A5后端类型/向量lower缺口，见REPLACEMENT.md|
|公共TileXRMoeEpDispatchMemory API、Combine、生产窗口接入|未实现；目前仅独立设备/Host ABI候选|
|CANN目标编译、NPU、性能、跨核/跨rank时钟|均未执行/未验证|

无硬件证据时，CPU分阶段执行不能证明并发可见性、事件合法性或性能。容量档位由导出调用者明确给定，
提供Python `select_capacity`与C++14 `SelectRuntimeCapacity`，从调用方已经编译的容量清单中自动选择；
不运行Python/JIT，也没有覆盖全部原生合法尺寸的预编译包。超档、UB/DMA或窗口超限必须拒绝，不能静默回落原生。
无共享MoE专家数需能被P整除。K可以大于E，无效专家ID被跳过；同token重复有效专家的原生行为存在歧义，
本候选没有声明该输入的等价性，详见REPLACEMENT.md。

## 入口与参数

- `make_runtime_kernel(limits, cores, poll_limit=100000)`：构造一个PrimFunc。`limits`为静态容量上限，
  `cores`为该设备产物实际启动AIV数（2–200），不是rank数。UB、模板上限及张量容量在导出时固定。
- `RuntimeConfig.words(limits)`：Python Host验证有效形状并构造32个uint64参数。
- `runtime_abi.h`中的`MakeRuntimeDescriptor`/`ValidateRuntimeDescriptor`：C++14独立实现同一格式，
  调用方必须在复制描述符和launch之前验证。该头不分配窗口、不注册kernel、不初始化通信、不做AllReduce。

`params`为GM上的256B描述符，字段如下；整数下标从0起。

|字段|内容/单位|作用|
|---|---|---|
|0–6|T、H、K、E、P、当前rank、实际启动核数|动态循环、地址与任务划分；均需在对应容量内|
|7|magic|真实NextMagic轮次身份；runtime_session按magic选择bank，生产公共接口仍未接入|
|8–9|参考地址常量、2GiB容量|保留布局参考字段；实际映射来自peers，kernel不将常量当可访问指针|
|10–11|T×P、ABI=3|等长rank输入及格式身份|
|12|0无mask/1使用mask|mask长度T，uint8非零为有效token|
|13|0累计prefix/1每专家count|`expert_nums`的输出模式|
|14|0 BF16/1 FP16|uint16位模式，不做数值转换|
|15|align(H×2,32)/4，uint32 word数|feature对齐长度，同时为紧凑payload的assist起点|
|16|ceil((align(H×2,32)+32)/480)|每条记录的有效块/READY块数量|
|17–31|0|保留，Host严格校验|

字段15/16由Host生成且device校验；避免固定后端把嵌套动态ceil表达式错误折叠成不等价的有符号除法。
描述符虽有device形状守卫，仍不能替代Host检查窗口、容量和保留字段。

前缀workspace以`uint32`存储，接收端按`int32`计算。两者不能直接交给要求同类型的
`T.copy`模板；使用显式`ReinterpretCast<uint32_t>()`搬运原语保持位模式，stride按八个word
补齐，并保留S→MTE2→S等待。Host语义测试和真实导出只验证位布局、边界及调用保留，
不能代替目标CANN编译与NPU正确性验收。

一次kernel的参数顺序：

|参数|格式/有效形状|用途|
|---|---|---|
|params|uint64[32]|上述运行时描述符|
|x|uint16[T×H]|本rank的连续FP16/BF16位模式输入；不使用maxH行距|
|ids|int32[T×K]|本rank逐token的目标专家ID；连续K行距|
|mask|uint8[T]|有mask时读取；无mask时不读取，可传空指针|
|peers|uint64[2×P]|第2r项为rank r的state地址，第2r+1项为其Dispatch payload地址|
|state|uint32[1MiB/4]|本rank状态/计数/workspace/gate映射|
|payload|uint32[E×T×blocks×128]|本rank接收窗口；每512B块包含480B有效字节及32B READY|
|output|uint16[E×T×H]容量|只写实际有效记录，按本地专家→source rank→token/choice排列|
|assist|int32[E×T×3]容量|有效记录的[source rank, 原token下标, choice]|
|counts|int32[E]|按本地专家/source rank的累计记录数|
|expert_nums|int64[E/P]有效项|本地专家count或prefix|
|diagnostics|int32[cores×16]|逐核错误、poll和工作量；不是时间打点|
|fftsAddr|uint64，0|导出工具的保留启动参数，本纯AIV入口不使用|

GM张量在PrimFunc中声明容量上限；当前kernel仅按有效形状访问GM：输入为T×H/T×K，
output为E×T×H容量、assist为E×T×3容量、counts为E、expert_nums为E/P、diagnostics为cores×16。
Host可按这些逻辑足迹分配，也可按编译容量超额分配；行距始终取有效H/K，不使用maxH/maxK行距。
同rank state/payload需和peers中本rank条目一致。peers需预先绑定当前bank并包含Combine reserve后的
Dispatch起点；`runtime_session.h`已实现该绑定，实际通信来自`runtime_session_cann.h`的TileXR peer映射。
完整生产API接入尚未实现。不得把临时CPU窗口或合成地址拿到设备上使用。
launch参数在64位Host为104B，但**不是旧ABI2的104B**：旧版无mask且有profileGM，严禁混用。

## 五模块实现

1. `runtime_send` F0/F1一次加载、归一化路由；无mask时不读/填active。F2按专家区间
   `Compares + And + GatherMask`筛选，单次标量直方图；F3按目标rank跨步发布连续计数记录，组尾完成。
   零计数同样发布READY。小T分配全核计数，大T分配末尾至多8核。
2. 同宏F4通过等值比较/GatherMask求当前route的同专家前缀位置，保留逐route前缀查询，未变为全局预计算。
   feature读入紧凑record，两次向量Copy将480B有效区插入512B步长；A区最多两槽发送环，
   槽复用/阶段末才等待MTE3。奇数H保护及原始FP16/BF16位模式不变。
3. `runtime_prefix` F5等待计数。F6按E和core数选择1～8个producer，各自扫描必要的计数carry，
   仅写自己32B对齐的prefix切片；借用已排空的A区构造连续副本，跨步批量发布workspace，
   完成后发布每消费者/producer独立32B gate。它没有实现原生跨核partial-sum交换协议。
4. `runtime_receive` F7每核等待并清理自己的全部producer gate；core0在全producer完成读计数后
   清计数READY。接收核读取prefix并构造非空槽列表。F8某槽未就绪时查看下一槽；
   实际H决定批容量，A/B全局批次跨槽连续交替，直接跨步输出feature/assist。
   每槽当前批有独立poll上限；最终及失败退出的输出排空仍在F8。
5. F9按实际消费量初始化一份足够大的零源，多个槽/批共享，提交全部跨步清READY后统一完成；
   失败批不输出、不清理。零源在MTE3完成前不再写入。

C++桥接仅执行DMA、向量Copy/筛选/Min/Max等单原语，集中于`RUNTIME_COPY_SOURCE`。
业务路由、数量、循环、槽映射和同步调度仍写在TileLang宏中。固定后端只保留特定copy命名的extern，
导出验收检查实际调用以及UB偏移。没有调用原生完整Dispatch业务函数。

## 本地构建/导出

使用匹配的固定TileLang解释器和PYTHONPATH，不能直接改为不匹配的pip版本。
在仓库根目录执行（输出目录必须不存在）：

```bash
python -m examples.tilelang_dispatch.export --runtime --cores 64 \
  --max-tokens 256 --max-hidden 1024 --max-top-k 4 --max-experts 16 --max-world-size 8 \
  --output /tmp/dispatch-runtime-raw
python -m examples.tilelang_dispatch.runtime_device --source /tmp/dispatch-runtime-raw \
  --output /tmp/dispatch-runtime-device
cmake -S examples/tilelang_dispatch -B /tmp/dispatch-runtime-host -DTL_RUNTIME_ABI_ONLY=ON
cmake --build /tmp/dispatch-runtime-host
ctest --test-dir /tmp/dispatch-runtime-host --output-on-failure
```

`runtime_device.py`只按SHA锁定raw处理纯AIV外壳，移除未使用Cube缓冲和Host三尖括号包装，
保留实际UB偏移并将TPipe销毁移至尾部。它不实现F0–F9业务，不插入TileXR打点，不编译CANN。
旧`profile.py`和104B runner会明确拒绝ABI3，避免生成看似可运行的错误产物。
`runtime_launch.h`提供纯AIV注册/104B raw或112B profile提交封装，调用方仍须持有GM、通信窗口和stream。
`runtime_session.h`/`runtime_session_cann.h`负责HCCL-first初始化、实际形状GM、NextMagic/bank、
连续预热与AR→Dispatch事件顺序及验证/销毁；外部控制器、业务Validator、capture和msprof仍由调用方接入。
`runtime_profile.py`从TL显式边界生成24槽打点及逐核/模块/接收核统计；原始ticks不建立公共时钟。
raw与profile使用不同ELF/入口，不可混用；Recorder对目标寄存器/stack/UB的影响尚待目标编译。
CMake的ABI_ONLY模式只验Host描述符，不证明CANN或设备launch成功。目标运行接入边界见性能说明。
