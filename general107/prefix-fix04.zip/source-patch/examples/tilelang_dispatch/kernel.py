"""每rank一个集成Dispatch kernel；旧ABI2专化入口与新ABI3运行时入口并存。

[AI] make_kernel保留H256/K2 BF16、T=4/16/64/256的历史路径。
make_runtime_kernel在容量上限内接受运行时P/E/T/H/K/rank、mask及FP16/BF16位模式。
新入口的合同、参数格式和未覆盖项见docs/RUNTIME.zh-CN.md，不代表已完整替代原生。

默认 TL v2（variant=3 / p1p2）：workspace 批量完成，gate 逐核32B提交后组尾等待。
小batch全部核、大batch末核计数分工；末核前缀和与发送核并行；每核由自己的gate进入接收。
只有核内流水依赖，无全核barrier。参数/路由留在UB，不输出中间描述符。

阅读顺序（F编号对应profile_recipe.json中的观测片段，不是独立kernel）：
① prepare：F0计算窗口地址与本核任务范围；F1将expertIds读入本核UB。
② count_publish：F2统计专家路由数；F3将计数与READY标志发给目标rank。
③ pack_send：F4按路由打包BF16特征、来源信息及READY标志并发送。
④ count_prefix：F5等齐并消费计数；F6计算前缀和，发布workspace及gate。
⑤ receive_output：F7等待布局并规划输出；F8接收特征；F9清理已消费标志。
发送路径与末核的前缀和路径并行；所有核随后等待各自的gate进入接收。
"""
import tilelang.language as T
from tilelang.language.ascend_tile import fill_experiment
from tvm import tir
from .contract import (F, READY, CUMSUM_WORD, GATE_WORD, STATE_WORDS,
                       workspace_stride_words, validate_dispatch_config)

# [AI] A5接收UB逻辑预算采用与原生相同的保守190KiB；不是整机内存或每rank输入大小。
# 本TL版本另保留显式分配的共用UB，不能直接照搬原生97条容量。
RECEIVE_UB_BYTES = 190 * 1024


def receive_ub_plan(tokens, cores, world_size=2, experts=4):
    """[AI] 每核保守UB预算。E=P*L，prefix每核副本按32B补齐。

    公共缓冲与F6发布区逐块对齐相加；不依赖跨阶段UB复用。A/B每条
    各960B数据，另共用64B READY，实际1984B/条；容量仍用基线2048B/条，
    防止把扩大批量混入F8优化。READY另留224B尾部保护和两个32B归约结果；
    950整数Min/Max无需scratch，实际占用须连同这288B一起核验。
    至少容纳一条，实际导出还须检查UB末地址。P不限定为偶数。
    """
    validate_dispatch_config(world_size=world_size, experts=experts, rank=0,
                             cores=cores, tokens=tokens)
    stride = workspace_stride_words(experts)
    align = lambda size: (size + 31) // 32 * 32
    common_sizes = (128, 512, tokens * 8, experts * 4, 1024, 512,
                    experts * 32, stride * 4, stride * 4,
                    (experts // world_size) * 8, 64,
                    cores * stride * 4, experts * 4)
    common_bytes = sum(align(size) for size in common_sizes)
    bytes_per_record = 2048
    capacity = (RECEIVE_UB_BYTES - common_bytes) // bytes_per_record
    planned_bytes = common_bytes + capacity * (bytes_per_record - 64) + 288
    if capacity < 1 or capacity * 2 > 4095 or planned_bytes > RECEIVE_UB_BYTES:
        raise ValueError('TL UB/DMA row capacity exceeded')
    return {'ub_budget_bytes': RECEIVE_UB_BYTES, 'common_bytes': common_bytes,
            'bytes_per_record': bytes_per_record, 'batch_capacity': capacity,
            'planned_bytes': planned_bytes,
            'capacity_policy_bytes': common_bytes + capacity * bytes_per_record,
            'data_buffers': 2, 'data_bytes_per_record': 960,
            'assist_bytes_per_record_per_buffer': 0, 'flag_bytes_per_record': 64,
            'ready_guard_bytes': 224, 'ready_result_bytes': 64, 'ready_scratch_bytes': 0}


# [AI] 固定后端只生成tl::ascend::copy*外部调用；通用GM→UB模板会补零并等待MTE3。
# 通过TileLang已有import_source接口提供此最小适配：对齐DMA只搬有效行，不写未用尾部。
# 形状/地址/事件由下面TL宏传入；不依赖C++生成变量名，不修改后端或导出后的文件。
RECEIVE_COPY_SOURCE = r"""
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] 9.1/950整数归约：每repeat只比较32B槽首；Min和Max都为READY才全等。
// flags后的56个uint32保护区由TL初始化，末次repeat的整个256B读取范围均已分配。
// 两个结果独立32B对齐；950无需sharedTmpBuffer，按该版本文档传src。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    constexpr uint32_t result = Capacity * 16 + 56;
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows), 1,
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// [AI] assist保留uint32来源的全部位；GM输出仍是int32，不能用异型Tensor实例化同T模板。
template <uint32_t Capacity>
__aicore__ inline void copy_ub_to_gm_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t dstPitch, uint32_t rows,
    uint32_t width) {
    auto signedSrc = src.ReinterpretCast<int32_t>();
    // import_source位于common.h之前；直接提交DMA，不依赖尚未声明的后端模板。
    AscendC::DataCopyExtParams params{static_cast<uint16_t>(rows), width * 4,
        (240 * 4 - width * 4) / 32, dstPitch * 4 - width * 4, 0};
    AscendC::DataCopyPad(dst, signedSrc, params);
}
// [AI] peer表是在本进程设备地址空间内有效的uint64地址，不是另一进程的裸指针。
// CopyCodegen把真实GM表作为dst、真实UB作为src传入；此桥接只绑定目标地址并提交对齐DMA。
__aicore__ inline void copy_ub_to_gm_peer(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint32_t slot, uint32_t wordOffset,
    uint32_t words) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue(slot)));
    AscendC::DataCopy(dst[wordOffset], src, words);
}
} }
"""


@T.macro
def copy_peer_words(src, peers, target, kind, src_offset, dst_offset, size, world_size, cpu):
    # [AI] kind=0计数窗口、kind=1数据窗口；所有offset/size以uint32为单位。
    # 设备peers是GM uint64[2*P]。CPU串行测试使用等宽虚拟窗口，不解引用设备地址。
    if cpu:
        for i in T.serial(size):
            peers[(target * 2 + kind) * (peers.shape[0] // (2 * world_size)) + dst_offset + i] = src[src_offset + i]
    else:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_peer',
                      src.access_ptr('r', offset=src_offset), peers.access_ptr('r'),
                      target * 2 + kind, dst_offset, size)
        T.set_flag('MTE3', 'S', 0)
        T.wait_flag('MTE3', 'S', 0)


@T.macro
def read_receive_rows(src, dst, src_offset, width, rows, capacity, cpu):
    # [AI] GM→UB跨步读：src为uint32 GM，dst为uint32 UB；offset/width以uint32为单位。
    # GM行距固定128 words=512B，UB紧排width words；rows是本批有效行数，capacity是UB行容量。
    # READY读取width=8（32B）；数据读取width=120（480B），均跳过各自GM行的剩余部分。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[row * width + col] = src[src_offset + row * 128 + col]
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        # [AI] 全部地址/width均32B对齐，DataCopyParams单位为32B块。
        # 只搬有效rows，不调用会在尾批Duplicate并等待MTE3的通用补零模板。
        # 未搬行不被读取；从而上一批MTE3写出可与本次MTE2读取重叠。
        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, {width}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w'),
                      128, rows, width, T.uint32(0))
        T.set_flag('MTE2', 'S', 0)
        T.wait_flag('MTE2', 'S', 0)


@T.macro
def initialize_receive_flags(flags, capacity, cpu):
    # [AI] 全容量槽及224B保护区每来源槽初始化一次；掩码外即使发生物理读取也无未初始化值。
    # 归约只依赖2*N个槽首，不把保护值算入结果；初始化计入F8。
    words = capacity * 16 + 56
    if cpu:
        for i in T.serial(words):
            flags[i] = T.uint32(0)
    else:
        T.set_flag('S', 'V', 0)
        T.wait_flag('S', 'V', 0)
        fill_experiment(flags, T.uint32(0), [T.bitwise_not(T.uint64(0))], words // 64, 1, 8)
        T.call_intrin('handle', tir.op.Op.get('tl.ascend_fill_experiment'),
                      'Fill_experiment<uint32_t>', flags.access_ptr('w', offset=(words // 64) * 64),
                      T.uint32(0), (T.uint64(1) << (words % 64)) - T.uint64(1), 1, 1, 8)
        T.set_flag('V', 'MTE2', 0)
        T.wait_flag('V', 'MTE2', 0)


@T.macro
def write_receive_rows(src, dst, src_offset, dst_offset, src_pitch, dst_pitch,
                       width, rows, capacity, cpu):
    # [AI] UB→GM批量跨步提交；offset/pitch/width均以src/dst的32位元素为单位。
    # src_pitch必须是8 words（32B）的整数倍；dst_pitch可为3 words，使assist紧排为12B/条。
    # 此宏只提交DMA。调用者须先S→MTE3，并在整组提交后MTE3→S，期间不得改写src。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[dst_offset + row * dst_pitch + col] = src[src_offset + row * src_pitch + col]
    else:
        T.call_extern('handle', f'tl::ascend::copy_ub_to_gm<{src.dtype}_t, {src_pitch}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w', offset=dst_offset),
                      dst_pitch, rows, width)


@T.macro
def copy_words(src, dst, src_offset, dst_offset, size, cpu):
    # offset/size以缓冲区元素为单位。GM→UB使用MTE2，UB→GM使用MTE3；
    # copy返回前等待搬运完成，后面的scalar代码才可读结果或改写同一UB。
    if cpu:
        for i in T.serial(size):
            dst[dst_offset + i] = src[src_offset + i]
    else:
        if src.scope() == 'global':
            T.set_flag('S', 'MTE2', 0)
            T.wait_flag('S', 'MTE2', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE2', 'S', 0)
            T.wait_flag('MTE2', 'S', 0)
        else:
            T.set_flag('S', 'MTE3', 0)
            T.wait_flag('S', 'MTE3', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE3', 'S', 0)
            T.wait_flag('MTE3', 'S', 0)


@T.macro
def fence(cpu):
    if not cpu:
        # 所有copy已建立scalar完成依赖；本地MTE3排序，不是跨核/rank barrier。
        T.pipe_barrier('MTE3')


@T.macro
def send_round(p, o):
    # F0.send_round：无共享专家版本的CalSendRound；不消费F1路由结果。
    o[F["send_rounds"]] = 1
    # [AI] 通用peer直接写路径一次覆盖全部路由，不套用原生特殊组网两轮调度。


@T.macro
def count_split(p, o, core):
    # F0.count_split：小batch全部核；大batch仅末尾count/cumsum核调用。
    o[F["count_begin"]] = 0
    o[F["count_end"]] = 0
    o[F["count_tasks"]] = 0
    if p[0] < 48 or T.cast(core, "uint64") >= o[F["send_cores"]]:
        worker = T.alloc_var("uint64")
        worker = T.cast(core, "uint64")
        if p[0] >= 48:
            worker = worker - o[F["send_cores"]]
        n = T.alloc_var("uint64")
        n = p[3]
        b = T.alloc_var("uint64")
        b = o[F["count_workers"]]
        begin = T.alloc_var("uint64")
        begin = n // b * worker + T.min(worker, n % b)
        size = T.alloc_var("uint64")
        size = n // b + T.cast(worker < n % b, "uint64")
        o[F["count_begin"]] = begin
        o[F["count_end"]] = begin + size
        o[F["count_tasks"]] = size


@T.macro
def status_split(p, o, core):
    # F0.status_split：输入是接收状态槽数量，不是接收token数量。
    worker = T.alloc_var("uint64")
    worker = T.cast(core, "uint64") - o[F["send_cores"]]
    n = T.alloc_var("uint64")
    n = o[F["receive_states"]]
    b = T.alloc_var("uint64")
    b = o[F["cumsum_cores"]]
    begin = T.alloc_var("uint64")
    begin = n // b * worker + T.min(worker, n % b)
    size = T.alloc_var("uint64")
    size = n // b + T.cast(worker < n % b, "uint64")
    o[F["status_begin"]] = begin
    o[F["status_end"]] = begin + size
    o[F["status_tasks"]] = size


@T.macro
def receive_split(p, o, core):
    """
    给 解包核分配接收地址槽位，起始地址、结束地址等
    p:在本核 UB 中,用于记录token数量、隐藏维度、top-k、专家数、rank 数量及编号、启动核数、轮次编号、通信窗口地址和容量等
    o:在本核 UB 中，用于存储布局和任务信息
    core: 本核编号
    """
    # worker 获取当前的核编号
    worker = T.alloc_var("uint64")
    worker = T.cast(core, "uint64")
    # 表示有n个接收的槽位，槽位 = 某个rank的某个专家gm存储空间
    n = T.alloc_var("uint64")
    n = o[F["receive_states"]]
    # b可以被分配任务的核数, p[6] 表示本rank的核数
    b = T.alloc_var("uint64")
    b = p[6]
    # 以下开始对本核要计算的gm槽位地址进行分配，计算本核负责的接收任务的起点和终点
    begin = T.alloc_var("uint64")
    begin = n // b * worker + T.min(worker, n % b)
    #  计算接收的槽位地址信息
    size = T.alloc_var("uint64")
    size = n // b + T.cast(worker < n % b, "uint64")
    o[F["receive_begin"]] = begin
    o[F["receive_end"]] = begin + size
    o[F["receive_tasks"]] = size


@T.macro
def layout(p, o):
    # 固定BF16用例；保留真实被后续地址/任务计算使用的布局，不构造独立测试描述符。
    # F0.layout：p是Host传入的uint64[16]参数，o是本核使用的字段表，F提供字段索引。
    # [AI] p[3]=E、p[4]=P、p[6]=本rank核数；本TL策略固定一个末核做prefix。
    experts = T.alloc_var('uint64')
    experts = p[3]
    cores = T.alloc_var('uint64')
    cores = p[6]
    cumsum = T.alloc_var('uint64')
    cumsum = 1
    feature = T.alloc_var('uint64')
    feature = p[1] * 2
    blocks = T.alloc_var('uint64')
    blocks = (((feature + 31) // 32 * 32) + 32 + 479) // 480
    record_bytes = T.alloc_var('uint64')
    record_bytes = blocks * 512
    workspace = T.alloc_var('uint64')
    workspace = cores * ((experts + 7) // 8 * 8) * 4
    state_address = T.alloc_var('uint64')
    state_address = p[8] + (p[7] % 2) * T.uint64(1073741824) + 2097152
    o[F['receive_states']] = experts
    o[F['cumsum_cores']] = cumsum
    o[F['send_cores']] = cores - cumsum
    o[F['count_workers']] = cores
    if p[0] >= 48:
        o[F['count_workers']] = cumsum
    o[F['record_bytes']] = record_bytes
    o[F['expert_window_bytes']] = (p[10] // p[4]) * record_bytes
    o[F['state_address']] = state_address
    o[F['workspace_address']] = state_address + 786432 - workspace


# ② F2＋F3：每核读取完整route[2*T]。T<48由前4核各计一个专家，
# [AI] T>=48由末核统计全部E个专家；先完成本核计数，再逐专家发布32B READY槽。
# 分开两个循环使F2/F3各有一个完整观测区间，不能在循环内覆盖同一Recorder槽。
@T.macro
def count_publish(route, peers, rank, small, amounts, diag, o, route_count, cpu, world_size, experts):
    if o[F['count_tasks']] > T.uint64(0):
        # F2.expert_count：统计本核负责的全部专家；4项amounts是核内UB，不跨核。
        for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
            amount = T.alloc_var('uint32')
            amount = T.uint32(0)
            for i in T.serial(route_count):
                if route[i] == expert:
                    amount = amount + T.uint32(1)
            amounts[expert] = amount
        diag[4] = T.cast(o[F['count_tasks']], 'int32')
        # F3.count_publish：即使计数为0也发布READY；copy完成后才重用small。
        for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
            for i in T.serial(8):
                small[i] = T.uint32(0)
            small[0] = T.uint32(READY)
            small[1] = amounts[expert]
            offset = T.alloc_var('int32')
            offset = ((expert % (experts // world_size)) * world_size + rank) * 8
            copy_peer_words(small, peers, expert // (experts // world_size), 0,
                            0, offset, 8, world_size, cpu)
            fence(cpu)


# ③ F4：发送核按core, core+send_cores,...覆盖2*T条路由，末核不发送。
# 每条1024B记录包含512B BF16特征、来源三元组和两个32B READY尾槽。
# 在整段循环外打一次F4点；不把单条的耗时当作整核发送耗时。
@T.macro
def pack_send(x, route, peers, record, feature, core, rank, diag, o, route_count, cpu, world_size, experts):
    # [AI] 直接peer地址表路径send_rounds=1，按全局专家映射任意目标rank。
    if core < route_count and o[F['send_rounds']] == T.uint64(1):
        for task in T.serial((route_count + T.cast(o[F['send_cores']], 'int32') - 1) // T.cast(o[F['send_cores']], 'int32')):
            route_index = T.alloc_var('int32')
            route_index = core + task * T.cast(o[F['send_cores']], 'int32')
            if route_index < route_count:
                expert = T.alloc_var('int32')
                expert = route[route_index]
                if expert >= 0 and expert < experts:
                    position = T.alloc_var('int32')
                    position = 0
                    for i in T.serial(route_index):
                        if route[i] == expert:
                            position = position + 1
                    copy_words(x, feature, (route_index // 2) * 128, 0, 128, cpu)
                    for i in T.serial(256):
                        record[i] = T.uint32(0)
                    for i in T.serial(128):
                        record[(i // 120) * 128 + i % 120] = feature[i]
                    record[136] = T.uint32(rank)
                    record[137] = T.cast(route_index // 2, 'uint32')
                    record[138] = T.cast(route_index % 2, 'uint32')
                    for block in T.serial(2):
                        for i in T.serial(8):
                            record[block * 128 + 120 + i] = T.uint32(READY)
                    target = T.alloc_var('int32')
                    target = expert // (experts // world_size)
                    bucket = T.alloc_var('int32')
                    bucket = ((rank + target) % world_size) * (experts // world_size) + expert % (experts // world_size)
                    offset = T.alloc_var('int32')
                    offset = bucket * T.cast(o[F["expert_window_bytes"]] // 4, "int32") + position * T.cast(o[F["record_bytes"]] // 4, "int32")
                    copy_peer_words(record, peers, target, 1, 0, offset, 256, world_size, cpu)
                    fence(cpu)
                    diag[5] = diag[5] + 1
                    diag[9] = diag[9] + T.cast(o[F["record_bytes"]], "int32")
                else:
                    diag[0] = 6


@T.macro
def count_prefix(state, counts, core, cores, poll_limit, records, prefix, small, diag, o, cpu, variant, experts, stride):
    # ④ F5＋F6：仅本rank末核执行，rank0为核55、rank1为核63。
    # [AI] state为本rank GM状态窗口；records接收E个32B计数槽，prefix保存E项累计计数。
    if core == cores - 1:
        ready = T.alloc_var('int32')
        ready = 0
        attempts = T.alloc_var('int32')
        attempts = 0
        # [AI] F5.wait_count：等齐P个来源rank×L个本地专家的全部E槽，0计数也须READY。
        while ready == 0 and attempts < poll_limit:
            copy_words(state, records, 0, 0, experts * 8, cpu)
            ready = 1
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                if records[q * 8] != T.uint32(READY):
                    ready = 0
            attempts = attempts + 1
        diag[1] = attempts
        diag[6] = T.cast(o[F["status_tasks"]], "int32")
        if ready == 0:
            diag[0] = 1  # 计数未就绪：不构造/发布虚假输出布局。
        else:
            # F5.consume_clear：汇总本核负责的计数并清READY，保留计数值供F6使用。
            total = T.alloc_var('uint32')
            total = 0
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                total = total + records[q * 8 + 1]
                records[q * 8] = T.uint32(0)
            copy_words(records, state, 0, 0, experts * 8, cpu)
            fence(cpu)
            # F6.prefix_publish / F6.prepare：发布并回读局部汇总槽，计算inclusive prefix。
            # 当前只有一个cumsum核，保留其32B局部汇总槽的发布/消费/清理。
            for i in T.serial(8):
                small[i] = T.uint32(0)
            small[0] = total
            small[1] = T.uint32(READY)
            copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
            fence(cpu)
            copy_words(state, small, CUMSUM_WORD, 0, 8, cpu)
            if small[1] != T.uint32(READY):
                diag[0] = 4
            else:
                for q in T.serial(stride):
                    prefix[q] = 0
                running = T.alloc_var('uint32')
                running = 0
                for q in T.serial(experts):
                    running = running + records[q * 8 + 1]
                    prefix[q] = T.cast(running, 'int32')
                # 均衡输入得到[T/2,T,3*T/2,2*T]，每项是对应接收槽的输出结束位置。
                for i in T.serial(8):
                    small[i] = T.uint32(0)
                copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
                copy_words(prefix, counts, 0, 0, experts, cpu)
                #  分配计数槽位，用于记录rank 给某专家的token数量 等信息 [READY标志，token数量，预留空间……]
                # workspace为每个接收核保留同一份4项prefix；gate为每核独立的32B通知槽。
                # 必须先完成workspace发布再通知gate；复用small前也必须完成其前一批搬运。
                if variant == 0:
                    # baseline：workspace、gate均逐核搬运，每次copy都等待完成。
                    for q in T.serial(stride):
                        small[q] = T.cast(prefix[q], 'uint32')
                    for c in T.serial(cores):
                        copy_words(small, state, 0, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + c * stride, stride, cpu)
                    fence(cpu)
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    for c in T.serial(cores):
                        copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    fence(cpu)
                elif variant == 2 or variant == 3:
                    # F6.workspace_publish（P2）：在连续UB中排列cores份prefix，一次写GM。
                    # 每份内容和目标地址与baseline一致，减少小块copy次数，未减少数据量。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    publish_buf = T.alloc_ub((cores * stride,), 'uint32')
                    for c in T.serial(cores):
                        for q in T.serial(stride):
                            publish_buf[c * stride + q] = T.uint32(0)
                            if q < experts:
                                publish_buf[c * stride + q] = T.cast(prefix[q], 'uint32')
                    copy_words(publish_buf, state, 0, workspace_word, cores * stride, cpu)
                    fence(cpu)
                    # P2-safe-gate：workspace仍批量发布；gate恢复独立32B槽及逐次完成等待。
                    # 保留原publish_buf容量，避免同时改变UB布局；接收核仍只清自己的槽。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    # F6.gate_publish：P2-safe-gate逐核等待；默认P1+P2只在整组末尾等待。
                    if variant == 2 or cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        # P1+P2：P2 workspace已完成；gate采用P1组尾完成等待。
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                else:
                    # P1：保留逐核小块copy，workspace组和gate组各等待一次完成。
                    # [AI] workspace每核align(E,8)个int32；保持32B行距及逐核地址覆盖。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    for q in T.serial(stride):
                        small[q] = T.cast(prefix[q], 'uint32')
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, workspace_word + c * stride, stride, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:stride], state[workspace_word + c * stride:workspace_word + c * stride + stride])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                    # gate是8个int32(1)，区别于计数/payload的float(1)位模式。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)

@T.macro
def read_receive_payload(src, dst, offset, rows, capacity, event_id, cpu):
    # [AI] payload无scalar消费者：S准备参数，MTE2完成直接交MTE3；不等待MTE2→S。
    # 调用前已消费本A/B旧输出的MTE3→S事件；该完成依赖经S→MTE2保护第三批复用。
    if cpu:
        read_receive_rows(src, dst, offset, 120, rows, capacity * 2, cpu)
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, {capacity * 2}>',
                      src.access_ptr('r', offset=offset), dst.access_ptr('w'),
                      128, rows, 120, T.uint32(0))
        T.set_flag('MTE2', 'MTE3', event_id)
        T.wait_flag('MTE2', 'MTE3', event_id)


@T.macro
def receive_batch_output(payload, output, assist, offset, destination, batch_count,
                         batch_data, capacity, event_id, cpu):
    # [AI] 当前A/B槽已空闲。直接从960B压紧记录分别跨步输出512B特征与12B assist。
    # 两次输出共用MTE3→S完成事件，复用/退出前必须消费，不复制assist到中间UB。
    read_receive_payload(payload, batch_data, offset, batch_count * 2, capacity, event_id, cpu)
    if not cpu:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
    write_receive_rows(batch_data, output, 0, destination * 128,
                       240, 128, 128, batch_count, capacity, cpu)
    if cpu:
        for row in T.serial(batch_count):
            for col in T.serial(3):
                assist[(destination + row) * 3 + col] = T.reinterpret(
                    'int32', batch_data[row * 240 + 128 + col])
    else:
        T.call_extern('handle', f'tl::ascend::copy_ub_to_gm_assist<{capacity}>',
                      batch_data.access_ptr('r', offset=128),
                      assist.access_ptr('w', offset=destination * 3), 3, batch_count, 3)
    if not cpu:
        T.set_flag('MTE3', 'S', event_id)


@T.macro
def receive_output(state, payload, output, assist, expert_nums, core, rank, cores,
                   poll_limit, small, prefix, nums, diag, o, cpu, capacity, world_size, experts, stride):
    # [AI] ⑤ F7/F8/F9：全核等自己的gate；按receive_begin/end分到槽的核搬运payload。
    # [AI] 入参：state/payload是本rank GM通信窗口；output为uint32承载的BF16[T*4,256]容量，
    # assist为int32[T*4,3]容量；实际有效行由prefix决定。expert_nums为int64[2]专家计数。
    # small/prefix/nums/diag/o均为本核UB；poll_limit限制每批READY轮询，cpu仅用于串行行为验证。
    # 每条GM记录=2*(480B数据+32B READY)；压紧UB记录=960B，特征占前512B，随后12B来源信息。
    # [AI] A/B数据独立占用UB；READY缓冲可在两批间复用，assist与特征共用本批数据源。
    batch_data_a = T.alloc_ub((capacity * 240,), 'uint32')
    batch_data_b = T.alloc_ub((capacity * 240,), 'uint32')
    batch_flags = T.alloc_ub((capacity * 2 * 8 + 72,), 'uint32')
    ready = T.alloc_var('int32')
    ready = 0
    attempts = T.alloc_var('int32')
    attempts = 0
    # F7.layout_wait：检查本核gate的8个uint32均为1；Host提交不代表这里已开始。
    while ready == 0 and attempts < poll_limit:
        copy_words(state, small, GATE_WORD + core * 8, 0, 8, cpu)
        ready = 1
        for i in T.serial(8):
            if small[i] != T.uint32(1):
                ready = 0
        attempts = attempts + 1
    diag[2] = attempts
    if ready == 0:
        if diag[0] == 0:
            diag[0] = 2
    else:
        # F7.gate_clear：每核只清自己的32B gate，供下一轮复用。
        for i in T.serial(8):
            small[i] = T.uint32(0)
        copy_words(small, state, 0, GATE_WORD + core * 8, 8, cpu)
        if o[F["receive_tasks"]] > T.uint64(0):
            # F7.receive_plan：读取本核的prefix副本，确定输出起点/条数和payload桶。
            # core0还将四项prefix归并为两个本地专家的总接收数。
            diag[8] = T.cast(o[F["receive_tasks"]], "int32")
            copy_words(state, small, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + core * stride, 0, stride, cpu)
            for i in T.serial(stride):
                prefix[i] = T.cast(small[i], "int32")
            if core == 0:
                for local in T.serial(experts // world_size):
                    before_local = T.alloc_var('int32')
                    before_local = prefix[T.max(local * world_size - 1, 0)]
                    if local == 0:
                        before_local = 0
                    nums[local] = T.cast(prefix[(local + 1) * world_size - 1], 'int64') - T.cast(before_local, 'int64')
                copy_words(nums, expert_nums, 0, 0, experts // world_size, cpu)
            consumed_slots = T.alloc_ub((experts,), 'int32')
            for q in T.serial(experts):
                consumed_slots[q] = 0
            # [AI] F7.receive_plan：核可分到多个槽；先验证整段prefix，防止越界。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                previous = T.alloc_var('int32')
                previous = prefix[T.max(q - 1, 0)]
                if q == 0:
                    previous = 0
                if prefix[q] < previous or prefix[q] - previous > T.cast(o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32') or previous < 0 or prefix[q] > experts * T.cast(o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32'):
                    if diag[0] == 0:
                        diag[0] = 5
            # [AI] F8.payload_loop：按local_expert×source槽循环，不能假定core就是槽编号。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                begin = T.alloc_var('int32')
                begin = prefix[T.max(q - 1, 0)]
                if q == 0:
                    begin = 0
                size = T.alloc_var('int32')
                size = prefix[q] - begin
                if size > 0 and diag[0] == 0:
                    initialize_receive_flags(batch_flags, capacity, cpu)
                bucket = T.alloc_var('int32')
                bucket = ((q % world_size + rank) % world_size) * (experts // world_size) + q // world_size
                consumed = T.alloc_var('int32')
                consumed = 0
                # [AI] F8.payload_loop：容量由UB预算决定；A/B交替，尾批仅处理有效条数。
                # pending表示本槽已提交且尚未消费MTE3→S事件；空桶/失败前未用槽不等待。
                batch_index = T.alloc_var('int32')
                pending_a = T.alloc_var('int32')
                pending_b = T.alloc_var('int32')
                batch_index = 0
                pending_a = 0
                pending_b = 0
                while consumed < size and diag[0] == 0:
                    batch_count = T.alloc_var('int32')
                    batch_count = T.min(capacity, size - consumed)
                    offset = T.alloc_var('int32')
                    offset = bucket * T.cast(o[F["expert_window_bytes"]] // 4, "int32") + consumed * T.cast(o[F["record_bytes"]] // 4, "int32")
                    arrived = T.alloc_var('int32')
                    arrived = 0
                    polls = T.alloc_var('int32')
                    polls = 0
                    while arrived == 0 and polls < poll_limit:
                        if cpu:
                            read_receive_rows(payload, batch_flags, offset + 120, 8,
                                              batch_count * 2, capacity * 2, cpu)
                            arrived = 1
                            for row in T.serial(batch_count * 2):
                                if batch_flags[row * 8] != T.uint32(READY):
                                    arrived = 0
                        else:
                            T.set_flag('S', 'MTE2', 0)
                            T.wait_flag('S', 'MTE2', 0)
                            T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_ready<{capacity}>',
                                          payload.access_ptr('r', offset=offset + 120),
                                          batch_flags.access_ptr('w'), 128, batch_count * 2, 8, T.uint32(0))
                            arrived = T.cast(batch_flags[capacity * 16 + 56] == T.uint32(READY)
                                             and batch_flags[capacity * 16 + 64] == T.uint32(READY), 'int32')
                        polls = polls + 1
                    # [AI] 保留payload_polls的逐条检查口径：一次批轮询检查batch_count条的两槽。
                    diag[3] = diag[3] + polls * batch_count
                    if arrived == 0:
                        diag[0] = 3
                    else:
                        if batch_index % 2 == 0:
                            if not cpu:
                                if pending_a != 0:
                                    T.wait_flag('MTE3', 'S', 2)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_a,
                                                 capacity, 2, cpu)
                            pending_a = 1
                        else:
                            if not cpu:
                                if pending_b != 0:
                                    T.wait_flag('MTE3', 'S', 3)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_b,
                                                 capacity, 3, cpu)
                            pending_b = 1
                        batch_index = batch_index + 1
                        consumed = consumed + batch_count
                # [AI] 包括READY超限退出：排空先前已提交的A/B，再计成功消费/清flag。
                # 等待属于F8，不能将完成成本转移到F9制造计时改善。
                if not cpu:
                    if pending_a != 0:
                        T.wait_flag('MTE3', 'S', 2)
                    if pending_b != 0:
                        T.wait_flag('MTE3', 'S', 3)
                consumed_slots[q] = consumed
                diag[7] = diag[7] + consumed
                diag[10] = diag[10] + consumed * T.cast(o[F["record_bytes"]], "int32")
            # [AI] F9.payload_clear：F8排空之后才清所有已消费槽；失败槽原样保留。
            # [AI] 先求本核最大清理批。consumed_slots是F8已完成输出的条数，
            # 不是prefix中的预期条数；空桶/失败批不会扩大清理范围。
            max_clean_records = T.alloc_var('int32')
            max_clean_records = 0
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                slot_records = T.alloc_var('int32')
                slot_records = consumed_slots[q]
                max_clean_records = T.max(max_clean_records, T.min(capacity, slot_records))
            clean_words = T.alloc_var('int32')
            clean_words = max_clean_records * 2 * 8
            if clean_words > 0:
                # [AI] READY缓冲已结束F8读取；只填DMA会读取的最大有效前缀。
                # CPU分支验证业务内容；设备用固定后端已有的Fill_experiment/ Duplicate。
                # uint32每repeat为64元素：完整repeat一次提交，末尾16/32/48元素另用掩码。
                # S→V保证数量/前序读取完成，V→MTE3保证零数据可供清理DMA读取。
                if cpu:
                    for i in T.serial(clean_words):
                        batch_flags[i] = T.uint32(0)
                else:
                    T.set_flag('S', 'V', 0)
                    T.wait_flag('S', 'V', 0)
                    if clean_words // 64 > 0:
                        fill_experiment(batch_flags, T.uint32(0), [T.bitwise_not(T.uint64(0))],
                                        clean_words // 64, 1, 8)
                    if clean_words % 64 > 0:
                        T.call_intrin('handle', tir.op.Op.get('tl.ascend_fill_experiment'),
                                      'Fill_experiment<uint32_t>',
                                      batch_flags.access_ptr('w', offset=(clean_words // 64) * 64),
                                      T.uint32(0), (T.uint64(1) << (clean_words % 64)) - T.uint64(1),
                                      1, 1, 8)
                    T.set_flag('V', 'MTE3', 0)
                    T.wait_flag('V', 'MTE3', 0)
            # [AI] 所有槽共用这份只读零缓冲，清理容量和逐批MTE3完成等待保持不变。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                bucket = T.alloc_var('int32')
                bucket = ((q % world_size + rank) % world_size) * (experts // world_size) + q // world_size
                # [AI] F9.payload_clear：每批跨步清2*N个32B尾槽，GM目的行距512B。
                # 仅清已完成输出的记录；失败批不消费/不清理，保留诊断现场。
                # [AI] 每槽从UB取一次成功条数，内层循环仅使用scalar，避免反复GetValue。
                slot_records = T.alloc_var('int32')
                slot_records = consumed_slots[q]
                cleared = T.alloc_var('int32')
                cleared = 0
                while cleared < slot_records:
                    clear_count = T.alloc_var('int32')
                    clear_count = T.min(capacity, slot_records - cleared)
                    if not cpu:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                    write_receive_rows(batch_flags, payload, 0,
                                       bucket * T.cast(o[F['expert_window_bytes']] // 4, 'int32')
                                       + cleared * T.cast(o[F['record_bytes']] // 4, 'int32') + 120,
                                       8, 128, 8, clear_count * 2, capacity * 2, cpu)
                    if not cpu:
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    cleared = cleared + clear_count
        # F9.final_fence：本核收尾的MTE3排序，不是跨核/rank完成屏障。
        fence(cpu)

@T.macro
def dispatch_body(params, x, ids, peers, local_state, local_data, output, assist,
                  counts, expert_nums, diagnostics, core, rank, cores, poll_limit,
                  variant, tokens, receive_capacity, world_size, experts, stride):
    # [AI] peers=GM uint64[2*P]：state/data交错。地址由本rank Host通信映射提供。
    # 每核独立UB。P/E/T是本次编译的shape参数，不是固定rank名单。
    p = T.alloc_ub((16,), 'uint64')
    o = T.alloc_ub((64,), 'uint64')
    route = T.alloc_ub((tokens * 2,), 'int32')
    amounts = T.alloc_ub((experts,), 'uint32')
    record = T.alloc_ub((256,), 'uint32')
    feature = T.alloc_ub((128,), 'uint32')
    records = T.alloc_ub((experts * 8,), 'uint32')
    prefix = T.alloc_ub((stride,), 'int32')
    small = T.alloc_ub((stride,), 'uint32')
    nums = T.alloc_ub((experts // world_size,), 'int64')
    diag = T.alloc_ub((16,), 'int32')
    for i in T.serial(16):
        diag[i] = 0
    copy_words(params, p, 0, 0, 16, False)
    layout(p, o)
    copy_words(ids, route, 0, 0, tokens * 2, False)
    send_round(p, o)
    count_split(p, o, core)
    count_publish(route, peers, rank, small, amounts, diag, o, tokens * 2, False, world_size, experts)
    if T.cast(core, 'uint64') < o[F['send_cores']]:
        pack_send(x, route, peers, record, feature, core, rank, diag, o, tokens * 2, False, world_size, experts)
    else:
        status_split(p, o, core)
        count_prefix(local_state, counts, core, cores, poll_limit, records, prefix, small, diag, o,
                     False, variant, experts, stride)
    T.pipe_barrier('ALL')
    receive_split(p, o, core)
    receive_output(local_state, local_data, output, assist, expert_nums, core, rank, cores,
                   poll_limit, small, prefix, nums, diag, o, False, receive_capacity,
                   world_size, experts, stride)
    copy_words(diag, diagnostics, 0, core * 16, 16, False)


def make_kernel(rank, cores, *, poll_limit=100000, variant=3, tokens=4, world_size=2, experts=4):
    """[AI] 构造一个rank的单Dispatch PrimFunc，P由配置传入；不在设备端跨进程解引用裸指针。

    params:uint64[16]为本轮布局/magic；x:uint32[T*128]承载BF16[T,256]；
    ids:int32[T,2]为全局专家ID；peers:uint64[2*P]为本进程可访问的GM映射；
    local_state/local_data为本rank窗口；output/assist容量E*T、实际长度由counts决定；
    counts:int32[E]为inclusive prefix；expert_nums:int64[E/P]；diagnostics:int32[cores,16]。
    """
    validate_dispatch_config(world_size=world_size, experts=experts, rank=rank, cores=cores, tokens=tokens)
    if isinstance(poll_limit, bool) or not isinstance(poll_limit, int) or not 1 <= poll_limit <= 10000000:
        raise ValueError('poll_limit must be an integer in [1,10000000]')
    if type(variant) is not int or variant not in (0, 1, 2, 3):
        raise ValueError('variant must be baseline/P1/P2-safe-gate/P1+P2')
    if type(tokens) is not int or tokens not in (4, 16, 64, 256):
        raise ValueError('tokens must be 4, 16, 64, or 256')
    stride = workspace_stride_words(experts)
    receive_capacity = receive_ub_plan(tokens, cores, world_size, experts)['batch_capacity']
    @T.prim_func
    def dispatch(
        params: T.Tensor((16,), 'uint64'), x: T.Tensor((tokens * 128,), 'uint32'),
        ids: T.Tensor((tokens * 2,), 'int32'), peers: T.Tensor((world_size * 2,), 'uint64'),
        local_state: T.Tensor((STATE_WORDS,), 'uint32'),
        local_data: T.Tensor((experts * tokens * 256,), 'uint32'),
        output: T.Tensor((experts * tokens * 128,), 'uint32'),
        assist: T.Tensor((experts * tokens * 3,), 'int32'),
        counts: T.Tensor((experts,), 'int32'), expert_nums: T.Tensor((experts // world_size,), 'int64'),
        diagnostics: T.Tensor((cores * 16,), 'int32')):
        with T.Kernel(cores, threads=1, is_npu=True) as core:
            T.import_source(RECEIVE_COPY_SOURCE)
            with T.Scope('V'):
                dispatch_body(params, x, ids, peers, local_state, local_data,
                              output, assist, counts, expert_nums, diagnostics,
                              core, rank, cores, poll_limit, variant, tokens, receive_capacity,
                              world_size, experts, stride)
    return dispatch


# [AI] 通用入口与旧专化入口并存，便于同一提交逐项回归；业务仍集中在本kernel文件。
# 这条路径的H/K/T/P/E/rank取自运行时参数，静态上限仅决定分配容量。
RUNTIME_COPY_SOURCE = r"""
namespace tl { namespace ascend {
__aicore__ inline void copy_gm_to_ub_runtime_prefix(AscendC::LocalTensor<int32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t words) {
    // [AI] workspace stores uint32 words; prefix arithmetic uses their int32 view.
    // Runtime stride is padded to eight words, so this copies complete 32B blocks.
    AscendC::DataCopyParams p{1, static_cast<uint16_t>(words / 8), 0, 0};
    AscendC::DataCopy(dst.ReinterpretCast<uint32_t>(), src, p);
}
__aicore__ inline void copy_gm_to_ub_runtime_feature(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint16_t> src, uint32_t count) {
    AscendC::DataCopyExtParams p{1, count * 2, 0, 0, 0};
    AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(dst.ReinterpretCast<uint16_t>(), src, p, pad);
}
__aicore__ inline void copy_ub_to_gm_runtime_feature(AscendC::GlobalTensor<uint16_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t pitch, uint32_t rows, uint32_t hidden) {
    AscendC::DataCopyExtParams p{static_cast<uint16_t>(rows), hidden * 2,
        (pitch * 4 - hidden * 2) / 32, 0, 0};
    AscendC::DataCopyPad(dst, src.ReinterpretCast<uint16_t>(), p);
}
__aicore__ inline void copy_ub_to_gm_runtime_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t pitch, uint32_t rows) {
    AscendC::DataCopyExtParams p{static_cast<uint16_t>(rows), 12,
        (pitch * 4 - 12) / 32, 0, 0};
    AscendC::DataCopyPad(dst, src.ReinterpretCast<int32_t>(), p);
}
template <uint32_t MaxRows>
__aicore__ inline void copy_gm_to_ub_runtime_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t rows) {
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), 1, 15, 0};
    AscendC::DataCopy(dst, src, p);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    constexpr uint32_t result = MaxRows * 8 + 56;
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}

__aicore__ inline void copy_ub_to_ub_runtime_boundary(AscendC::LocalTensor<int32_t> dst,
    AscendC::LocalTensor<int32_t> src, uint32_t id) {
    // [AI] profile0编译为空；独立ABI3插桩器只替换调用，不修改算法或事件。
    (void)dst; (void)src; (void)id;
}
// [AI] 单个向量/搬运原语；业务循环、路由顺序和事件寿命仍由TL宏管理。
__aicore__ inline void copy_ub_to_ub_runtime_fill(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> unused, uint32_t words, uint32_t value) {
    AscendC::Duplicate<uint32_t>(dst, value, words);
}
__aicore__ inline void copy_ub_to_ub_runtime_pack(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t blocks) {
    auto in = src.ReinterpretCast<int32_t>();
    auto out = dst.ReinterpretCast<int32_t>();
    // [AI] 每480B有效区扩成512B行距，READY的32B不被Copy覆盖；repeat分段防uint8溢出。
    for (uint32_t first = 0; first < blocks; first += 255) {
        uint8_t n = static_cast<uint8_t>(blocks - first > 255 ? 255 : blocks - first);
        AscendC::Copy(out[first * 128], in[first * 120], uint64_t(64), n, {1,1,16,15});
        AscendC::Copy(out[first * 128 + 64], in[first * 120 + 64], uint64_t(56), n, {1,1,16,15});
    }
}
template <uint32_t MaxRoutes>
__aicore__ inline void copy_ub_to_ub_runtime_range(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> routes, uint32_t count, int32_t lo, int32_t hi) {
    constexpr uint32_t maskWords = ((MaxRoutes + 255) / 256) * 8;
    constexpr uint32_t result = 2 * maskWords + ((MaxRoutes + 7) / 8) * 8;
    if (!count) { scratch.SetValue(result, 0); return; }
    // [AI] Compares只写有效bit；And会读完整对齐mask，因此尾部先初始化。
    AscendC::Duplicate<uint32_t>(scratch, 0, maskWords * 2);
    AscendC::PipeBarrier<PIPE_V>();
    auto lower = scratch.ReinterpretCast<uint8_t>();
    auto upper = scratch[maskWords].ReinterpretCast<uint8_t>();
    AscendC::Compares(lower, routes, lo, AscendC::CMPMODE::GE, count);
    AscendC::Compares(upper, routes, hi, AscendC::CMPMODE::LT, count);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::And(lower.ReinterpretCast<uint16_t>(), lower.ReinterpretCast<uint16_t>(),
        upper.ReinterpretCast<uint16_t>(), static_cast<int32_t>(maskWords * 2));
    AscendC::PipeBarrier<PIPE_V>();
    uint64_t selected = 0;
    AscendC::GatherMask(scratch[maskWords * 2].ReinterpretCast<int32_t>(), routes, scratch,
        true, count, {1,1,0,0}, selected);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
    scratch.SetValue(result, static_cast<uint32_t>(selected));
}
template <uint32_t MaxRoutes>
__aicore__ inline void copy_ub_to_ub_runtime_equal(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> routes, uint32_t count, int32_t expert) {
    constexpr uint32_t maskWords = ((MaxRoutes + 255) / 256) * 8;
    constexpr uint32_t result = maskWords + ((MaxRoutes + 7) / 8) * 8;
    if (!count) { scratch.SetValue(result, 0); return; }
    AscendC::Compares(scratch.ReinterpretCast<uint8_t>(), routes, expert, AscendC::CMPMODE::EQ, count);
    AscendC::PipeBarrier<PIPE_V>();
    uint64_t selected = 0;
    AscendC::GatherMask(scratch[maskWords].ReinterpretCast<int32_t>(), routes, scratch,
        true, count, {1,1,0,0}, selected);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
    scratch.SetValue(result, static_cast<uint32_t>(selected));
}
__aicore__ inline void copy_ub_to_gm_runtime_workspace(AscendC::GlobalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t rows, uint32_t width, uint32_t pitch) {
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), static_cast<uint16_t>(width / 8),
        0, static_cast<uint16_t>((pitch - width) / 8)};
    AscendC::DataCopy(dst, src, p);
}
__aicore__ inline void copy_ub_to_gm_runtime_counts(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint64_t address, uint32_t rows, uint32_t world) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t*>(peers.GetValue(address >> 32)));
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), 1, 0, static_cast<uint16_t>(world - 1)};
    AscendC::DataCopy(dst[static_cast<uint32_t>(address)], src, p);
}
} }
"""


@T.macro
def runtime_marker(diag, event, cpu):
    if not cpu:
        T.call_extern('handle', 'tl::ascend::copy_ub_to_ub_runtime_boundary',
                      diag.access_ptr('r'), diag.access_ptr('w'), event)


@T.macro
def runtime_fill(buf, offset, words, value, cpu):
    # [AI] uint32原语，无TL视图别名；offset/words均为32位元素，不是字节。
    if cpu:
        for j in T.serial(words):
            buf[offset + j] = value
    else:
        T.set_flag('S', 'V', 0)
        T.wait_flag('S', 'V', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_ub_runtime_fill',
                      buf.access_ptr('r', offset=offset), buf.access_ptr('w', offset=offset), words, value)
        T.set_flag('V', 'S', 0)
        T.wait_flag('V', 'S', 0)


@T.macro
def runtime_finish(cpu):
    if not cpu:
        T.set_flag('MTE3', 'S', 0)
        T.wait_flag('MTE3', 'S', 0)


@T.macro
def runtime_send(p, x, ids, mask, peers, core, route, active, record,
                 diag, arena, scratch, records, window_words, cpu):
    runtime_marker(diag, 10, cpu)
    # [AI] F0/F1：仅有mask时读取active。一次归一化后，计数和发送共用同一有效路由。
    count = T.cast(p[0] * p[2], 'int32')
    experts = T.cast(p[3], 'int32')
    world = T.cast(p[4], 'int32')
    rank = T.cast(p[5], 'int32')
    cores = T.cast(p[6], 'int32')
    hidden = T.cast(p[1], 'int32')
    local = experts // world
    assist_word = T.cast(p[15], 'int32')
    blocks = T.cast(p[16], 'int32')
    runtime_marker(diag, 11, cpu)
    runtime_marker(diag, 100, cpu)
    copy_words(ids, route, 0, 0, count, cpu)
    if p[12] != T.uint64(0):
        copy_words(mask, active, 0, 0, T.cast(p[0], 'int32'), cpu)
    for i in T.serial(count):
        if route[i] < 0 or route[i] >= experts:
            route[i] = -1
        if p[12] != T.uint64(0):
            if active[i // T.cast(p[2], 'int32')] == T.uint8(0):
                route[i] = -1
    runtime_marker(diag, 101, cpu)
    # [AI] F2：每工作核一次路由直方图，替代每专家重扫；记录按专家连续存放。
    workers = T.alloc_var('int32')
    workers = cores
    worker = T.alloc_var('int32')
    worker = core
    if p[0] >= T.uint64(48):
        workers = T.min(8, T.min((experts + 15) // 16, cores // 2))
        worker = core - (cores - workers)
    if p[0] < T.uint64(48) or core >= cores - T.min(8, T.min((experts + 15) // 16, cores // 2)):
        begin = experts // workers * worker + T.min(worker, experts % workers)
        end = begin + experts // workers + T.cast(worker < experts % workers, 'int32')
        if begin < end:
            runtime_marker(diag, 200, cpu)
            runtime_fill(records, 0, experts * 8, T.uint32(0), cpu)
            for expert in T.serial(begin, end):
                records[expert * 8] = T.uint32(READY)
            if cpu:
                for i in T.serial(count):
                    expert = route[i]
                    if expert >= begin and expert < end:
                        records[expert * 8 + 1] = records[expert * 8 + 1] + T.uint32(1)
            else:
                T.set_flag('S', 'V', 0)
                T.wait_flag('S', 'V', 0)
                T.call_extern('handle', f'tl::ascend::copy_ub_to_ub_runtime_range<{route.shape[0]}>',
                              route.access_ptr('r'), scratch.access_ptr('w'), count, begin, end)
                selected_at = ((route.shape[0] + 255) // 256) * 16
                result_at = selected_at + ((route.shape[0] + 7) // 8) * 8
                for i in T.serial(T.cast(scratch[result_at], 'int32')):
                    expert = T.cast(scratch[selected_at + i], 'int32')
                    records[expert * 8 + 1] = records[expert * 8 + 1] + T.uint32(1)
            runtime_marker(diag, 201, cpu)
            runtime_marker(diag, 300, cpu)
            # [AI] F3：同目的rank的连续专家一次跨步DMA；零计数也发布READY。
            for target in T.serial(world):
                lo = T.max(begin, target * local)
                hi = T.min(end, (target + 1) * local)
                if lo < hi:
                    offset = ((lo % local) * world + rank) * 8
                    if cpu:
                        for e in T.serial(lo, hi):
                            for j in T.serial(8):
                                peers[target * 2 * window_words + ((e % local) * world + rank) * 8 + j] = records[e * 8 + j]
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        address = T.shift_left(T.cast(target * 2, 'uint64'), 32) + T.cast(offset, 'uint64')
                        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_runtime_counts',
                                      records.access_ptr('r', offset=lo * 8), peers.access_ptr('r'), address, hi - lo, world)
                    diag[4] = diag[4] + hi - lo
            runtime_finish(cpu)
            runtime_marker(diag, 301, cpu)
    # [AI] F4：未来接收A区在此作为发送环；未来B区作为精确向量计数scratch。
    # 两区在发送排空后才被F6/接收复用，不创建不可靠的TL别名。
    if core < cores - 1:
        runtime_marker(diag, 400, cpu)
        slots = T.min(2, arena.shape[0] // (blocks * 128))
        runtime_fill(arena, 0, slots * blocks * 128, T.uint32(READY), cpu)
        runtime_fill(record, 0, blocks * 120, T.uint32(0), cpu)
        issued = T.alloc_var('int32')
        issued = 0
        for task in T.serial((count + cores - 2) // (cores - 1)):
            i = core + task * (cores - 1)
            if i < count:
                token = i // T.cast(p[2], 'int32')
                expert = route[i]
                if expert >= 0:
                    position = T.alloc_var('int32')
                    position = 0
                    if cpu:
                        for j in T.serial(i):
                            if route[j] == expert:
                                position = position + 1
                    else:
                        T.set_flag('S', 'V', 0)
                        T.wait_flag('S', 'V', 0)
                        T.call_extern('handle', f'tl::ascend::copy_ub_to_ub_runtime_equal<{route.shape[0]}>',
                                      route.access_ptr('r'), scratch.access_ptr('w'), i, expert)
                        result = ((route.shape[0] + 255) // 256) * 8 + ((route.shape[0] + 7) // 8) * 8
                        position = T.cast(scratch[result], 'int32')
                    if position >= T.cast(p[0], 'int32'):
                        diag[0] = 7
                    else:
                        slot = issued % slots
                        if not cpu:
                            if issued >= slots:
                                T.wait_flag('MTE3', 'S', slot + 2)
                        if cpu:
                            for j in T.serial((hidden + 1) // 2):
                                value = T.alloc_var('uint32')
                                value = T.cast(x[token * hidden + j * 2], 'uint32')
                                if j * 2 + 1 < hidden:
                                    value = T.bitwise_or(value, T.shift_left(T.cast(x[token * hidden + j * 2 + 1], 'uint32'), 16))
                                record[j] = value
                        else:
                            T.set_flag('S', 'MTE2', 0)
                            T.wait_flag('S', 'MTE2', 0)
                            T.call_extern('handle', 'tl::ascend::copy_gm_to_ub_runtime_feature',
                                          x.access_ptr('r', offset=token * hidden), record.access_ptr('w'), hidden)
                            T.set_flag('MTE2', 'S', 0)
                            T.wait_flag('MTE2', 'S', 0)
                        # [AI] DataCopyPad尾字节不作为业务值；奇数H的高半字和对齐间隙显式为零。
                        if hidden % 2 != 0:
                            record[hidden // 2] = T.bitwise_and(record[hidden // 2], T.uint32(65535))
                        for j in T.serial((hidden + 1) // 2, assist_word):
                            record[j] = T.uint32(0)
                        # [AI] assist在紧排480B源中写入；READY从不提前独立发布。
                        record[assist_word] = T.cast(rank, 'uint32')
                        record[assist_word + 1] = T.cast(token, 'uint32')
                        record[assist_word + 2] = T.cast(i % T.cast(p[2], 'int32'), 'uint32')
                        if cpu:
                            for j in T.serial(blocks * 120):
                                arena[slot * blocks * 128 + (j // 120) * 128 + j % 120] = record[j]
                        else:
                            T.set_flag('S', 'V', 0)
                            T.wait_flag('S', 'V', 0)
                            T.call_extern('handle', 'tl::ascend::copy_ub_to_ub_runtime_pack',
                                          record.access_ptr('r'), arena.access_ptr('w', offset=slot * blocks * 128), blocks)
                            T.set_flag('V', 'MTE3', 0)
                            T.wait_flag('V', 'MTE3', 0)
                        target = expert // local
                        bucket = ((rank + target) % world) * local + expert % local
                        offset = (bucket * T.cast(p[0], 'int32') + position) * blocks * 128
                        if cpu:
                            for j in T.serial(blocks * 128):
                                peers[(target * 2 + 1) * window_words + offset + j] = arena[slot * blocks * 128 + j]
                        else:
                            T.set_flag('S', 'MTE3', 0)
                            T.wait_flag('S', 'MTE3', 0)
                            T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_peer',
                                          arena.access_ptr('r', offset=slot * blocks * 128), peers.access_ptr('r'),
                                          target * 2 + 1, offset, blocks * 128)
                            T.set_flag('MTE3', 'S', slot + 2)
                            # [AI] pack已消费compact源后才允许下一token覆盖record。
                            T.set_flag('V', 'S', 0)
                            T.wait_flag('V', 'S', 0)
                        issued = issued + 1
                        diag[5] = diag[5] + 1
                        diag[9] = diag[9] + blocks * 512
        if not cpu:
            for slot in T.serial(slots):
                if issued > slot:
                    T.wait_flag('MTE3', 'S', slot + 2)
        runtime_marker(diag, 401, cpu)


@T.macro
def runtime_publish_rows(src, dst, src_offset, dst_offset, rows, width, pitch, cpu):
    # [AI] 单次跨步DMA，源紧排width、目的pitch；均以uint32为单位且32B对齐。
    if cpu:
        for row in T.serial(rows):
            for j in T.serial(width):
                dst[dst_offset + row * pitch + j] = src[src_offset + row * width + j]
    else:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_runtime_workspace',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w', offset=dst_offset),
                      rows, width, pitch)


@T.macro
def runtime_prefix(p, state, counts, core, records, prefix, diag, scratch, poll_limit, cpu):
    # [AI] F5/F6：小E单producer；大E最多8个producer，分配32B对齐且不重叠的prefix片段。
    # 每producer读取完整计数，独立计算自己的carry，避免未验证的跨核partial-sum协议。
    experts = T.cast(p[3], 'int32')
    cores = T.cast(p[6], 'int32')
    producers = T.alloc_var('int32')
    producers = T.min(8, T.min((experts + 15) // 16, cores // 2))
    stride = (experts + 7) // 8 * 8
    workspace = 196608 - cores * stride
    if core >= cores - producers:
        worker = core - (cores - producers)
        chunks = stride // 8
        begin = (chunks // producers * worker + T.min(worker, chunks % producers)) * 8
        stop = begin + (chunks // producers + T.cast(worker < chunks % producers, 'int32')) * 8
        end = T.min(stop, experts)
        runtime_marker(diag, 500, cpu)
        ready = T.alloc_var('int32')
        ready = 0
        polls = T.alloc_var('int32')
        polls = 0
        while ready == 0 and polls < poll_limit:
            copy_words(state, records, 0, 0, experts * 8, cpu)
            ready = 1
            for q in T.serial(experts):
                if records[q * 8] != T.uint32(READY):
                    ready = 0
            polls = polls + 1
        diag[1] = polls
        runtime_marker(diag, 501, cpu)
        if ready == 0:
            diag[0] = 1
        else:
            runtime_marker(diag, 600, cpu)
            running = T.alloc_var('uint32')
            running = 0
            for q in T.serial(begin, stop):
                prefix[q] = 0
            for q in T.serial(end):
                running = running + records[q * 8 + 1]
                if q >= begin:
                    prefix[q] = T.cast(running, 'int32')
            copy_words(prefix, counts, begin, begin, end - begin, cpu)
            width = stop - begin
            chunk = T.max(1, scratch.shape[0] // width)
            first = T.alloc_var('int32')
            first = 0
            while first < cores:
                n = T.min(chunk, cores - first)
                for c in T.serial(n):
                    for j in T.serial(width):
                        scratch[c * width + j] = T.cast(prefix[begin + j], 'uint32')
                runtime_publish_rows(scratch, state, 0, workspace + first * stride + begin,
                                     n, width, stride, cpu)
                runtime_finish(cpu)
                first = first + n
            # [AI] 各producer只写各消费者专属的32B gate，杜绝同一cacheline并发覆盖。
            gate_chunk = T.max(1, scratch.shape[0] // 8)
            runtime_fill(scratch, 0, T.min(gate_chunk, cores) * 8, T.uint32(1), cpu)
            first = 0
            while first < cores:
                n = T.min(gate_chunk, cores - first)
                runtime_publish_rows(scratch, state, 0, GATE_WORD + (first * producers + worker) * 8,
                                     n, 8, producers * 8, cpu)
                first = first + n
            runtime_finish(cpu)
            runtime_marker(diag, 601, cpu)


@T.macro
def runtime_batch_output(p, payload, output, assist, offset, destination, batch,
                         data, capacity, max_rows, event, cpu):
    # [AI] F8：运行时blocks行跨步读，直接输出实际H及12B assist。
    hidden = T.cast(p[1], 'int32')
    aw = T.cast(p[15], 'int32')
    blocks = T.cast(p[16], 'int32')
    rows = batch * blocks
    if cpu:
        read_receive_rows(payload, data, offset, 120, rows, max_rows, cpu)
        for row in T.serial(batch):
            for h in T.serial(hidden):
                word = data[row * blocks * 120 + h // 2]
                output[(destination + row) * hidden + h] = T.cast(
                    T.bitwise_and(T.shift_right(word, (h % 2) * 16), T.uint32(65535)), 'uint16')
            for j in T.serial(3):
                assist[(destination + row) * 3 + j] = T.reinterpret('int32', data[row * blocks * 120 + aw + j])
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, {max_rows}>',
                      payload.access_ptr('r', offset=offset), data.access_ptr('w'), 128, rows, 120, T.uint32(0))
        T.set_flag('MTE2', 'MTE3', event)
        T.wait_flag('MTE2', 'MTE3', event)
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_runtime_feature',
                      data.access_ptr('r'), output.access_ptr('w', offset=destination * hidden),
                      blocks * 120, batch, hidden)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_runtime_assist',
                      data.access_ptr('r', offset=aw), assist.access_ptr('w', offset=destination * 3),
                      blocks * 120, batch)
        T.set_flag('MTE3', 'S', event)


@T.macro
def runtime_receive(p, state, payload, output, assist, expert_nums, core, prefix,
                    nums, consumed_slots, records, data_a, data_b, flags, diag,
                    capacity, max_rows, poll_limit, cpu):
    runtime_marker(diag, 700, cpu)
    # [AI] F7：所有实际启动核消费自己的gate；接收任务按运行时E/P拆分。
    experts = T.cast(p[3], 'int32')
    world = T.cast(p[4], 'int32')
    rank = T.cast(p[5], 'int32')
    cores = T.cast(p[6], 'int32')
    tokens = T.cast(p[0], 'int32')
    hidden = T.cast(p[1], 'int32')
    blocks = T.cast(p[16], 'int32')
    stride = (experts + 7) // 8 * 8
    workspace = 196608 - cores * stride
    producers = T.alloc_var('int32')
    producers = T.min(8, T.min((experts + 15) // 16, cores // 2))
    ready = T.alloc_var('int32')
    ready = 0
    polls = T.alloc_var('int32')
    polls = 0
    while ready == 0 and polls < poll_limit:
        copy_words(state, records, GATE_WORD + core * producers * 8, 0, producers * 8, cpu)
        ready = 1
        for j in T.serial(producers * 8):
            if records[j] != T.uint32(1):
                ready = 0
        polls = polls + 1
    diag[2] = polls
    if ready == 0:
        diag[0] = 2
    else:
        runtime_fill(records, 0, producers * 8, T.uint32(0), cpu)
        copy_words(records, state, 0, GATE_WORD + core * producers * 8, producers * 8, cpu)
        # [AI] core0看到全部producer gate，证明它们都已读取计数，可安全清READY。
        # 其余核只读已发布workspace，不再读取这些计数槽；下一轮由正常kernel完成约束隔离。
        if core == 0:
            copy_words(state, records, 0, 0, experts * 8, cpu)
            for q in T.serial(experts):
                records[q * 8] = T.uint32(0)
            copy_words(records, state, 0, 0, experts * 8, cpu)
        runtime_marker(diag, 701, cpu)
        begin_slot = experts // cores * core + T.min(core, experts % cores)
        end_slot = begin_slot + experts // cores + T.cast(core < experts % cores, 'int32')
        if begin_slot < end_slot:
            runtime_marker(diag, 702, cpu)
            if cpu:
                copy_words(state, prefix, workspace + core * stride, 0, stride, cpu)
            else:
                T.set_flag('S', 'MTE2', 0)
                T.wait_flag('S', 'MTE2', 0)
                T.call_extern('handle', 'tl::ascend::copy_gm_to_ub_runtime_prefix',
                              state.access_ptr('r', offset=workspace + core * stride),
                              prefix.access_ptr('w'), stride)
                T.set_flag('MTE2', 'S', 0)
                T.wait_flag('MTE2', 'S', 0)
            if core == 0:
                for local in T.serial(experts // world):
                    before = T.alloc_var('int32')
                    before = 0
                    if local > 0:
                        before = prefix[local * world - 1]
                    nums[local] = T.cast(prefix[(local + 1) * world - 1], 'int64')
                    if p[13] == T.uint64(1):
                        nums[local] = nums[local] - T.cast(before, 'int64')
                copy_words(nums, expert_nums, 0, 0, experts // world, cpu)
            # [AI] table[0:E]=已消费，table[E:2E]=当前批poll数，table[2E:3E]=非空槽索引。
            # 所有槽先验证/建表，再跨槽推进；DMA输出地址仍由原prefix确定。
            valid_slots = T.alloc_var('int32')
            valid_slots = 0
            for q in T.serial(begin_slot, end_slot):
                consumed_slots[q] = 0
                consumed_slots[experts + q] = 0
                start = T.alloc_var('int32')
                start = 0
                if q > 0:
                    start = prefix[q - 1]
                size = prefix[q] - start
                if size < 0 or size > tokens or start < 0 or prefix[q] > experts * tokens:
                    diag[0] = 5
                if size > 0:
                    consumed_slots[experts * 2 + valid_slots] = q
                    valid_slots = valid_slots + 1
            runtime_marker(diag, 703, cpu)
            runtime_marker(diag, 800, cpu)
            # [AI] 实际H决定每条占用；同时受A/B、READY容量和4095行DMA/归约约束。
            actual_capacity = T.min(data_a.shape[0] // (blocks * 120),
                                    T.min(data_b.shape[0] // (blocks * 120),
                                          T.min(max_rows // blocks, 4095 // blocks)))
            if valid_slots > 0 and diag[0] == 0:
                initialize_receive_flags(flags, max_rows // 2, cpu)
            remaining = T.alloc_var('int32')
            remaining = valid_slots
            cursor = T.alloc_var('int32')
            cursor = 0
            batch_index = T.alloc_var('int32')
            batch_index = 0
            pending_a = T.alloc_var('int32')
            pending_a = 0
            pending_b = T.alloc_var('int32')
            pending_b = 0
            while remaining > 0 and diag[0] == 0:
                q = consumed_slots[experts * 2 + cursor]
                start = T.alloc_var('int32')
                start = 0
                if q > 0:
                    start = prefix[q - 1]
                size = prefix[q] - start
                consumed = consumed_slots[q]
                if consumed < size:
                    batch = T.min(actual_capacity, size - consumed)
                    bucket = ((q % world + rank) % world) * (experts // world) + q // world
                    offset = (bucket * tokens + consumed) * blocks * 128
                    arrived = T.alloc_var('int32')
                    arrived = 0
                    if cpu:
                        read_receive_rows(payload, flags, offset + 120, 8, batch * blocks, max_rows, cpu)
                        arrived = 1
                        for j in T.serial(batch * blocks):
                            if flags[j * 8] != T.uint32(READY):
                                arrived = 0
                    else:
                        T.set_flag('S', 'MTE2', 0)
                        T.wait_flag('S', 'MTE2', 0)
                        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_runtime_ready<{max_rows}>',
                                      payload.access_ptr('r', offset=offset + 120), flags.access_ptr('w'), batch * blocks)
                        arrived = T.cast(flags[max_rows * 8 + 56] == T.uint32(READY) and
                                         flags[max_rows * 8 + 64] == T.uint32(READY), 'int32')
                    consumed_slots[experts + q] = consumed_slots[experts + q] + 1
                    diag[3] = diag[3] + batch
                    if arrived != 0:
                        if batch_index % 2 == 0:
                            if not cpu:
                                if pending_a != 0:
                                    T.wait_flag('MTE3', 'S', 2)
                            runtime_batch_output(p, payload, output, assist, offset, start + consumed,
                                                 batch, data_a, capacity, max_rows, 2, cpu)
                            pending_a = 1
                        else:
                            if not cpu:
                                if pending_b != 0:
                                    T.wait_flag('MTE3', 'S', 3)
                            runtime_batch_output(p, payload, output, assist, offset, start + consumed,
                                                 batch, data_b, capacity, max_rows, 3, cpu)
                            pending_b = 1
                        batch_index = batch_index + 1
                        consumed_slots[q] = consumed + batch
                        consumed_slots[experts + q] = 0
                        diag[7] = diag[7] + batch
                        diag[10] = diag[10] + batch * blocks * 512
                        if consumed + batch == size:
                            remaining = remaining - 1
                            cursor = (cursor + 1) % T.max(valid_slots, 1)
                    else:
                        # [AI] 不就绪转下一槽；每槽当前批预算不随轮转重置，避免无限等待。
                        if consumed_slots[experts + q] >= poll_limit:
                            diag[0] = 3
                        cursor = (cursor + 1) % T.max(valid_slots, 1)
                else:
                    cursor = (cursor + 1) % T.max(valid_slots, 1)
            # [AI] A/B跨槽持续使用；最终输出排空仍属于F8，错误退出也必须排空。
            if not cpu:
                if pending_a != 0:
                    T.wait_flag('MTE3', 'S', 2)
                if pending_b != 0:
                    T.wait_flag('MTE3', 'S', 3)
            runtime_marker(diag, 801, cpu)
            runtime_marker(diag, 900, cpu)
            # [AI] F9：只初始化实际DMA会读到的零源范围，所有清理共享该不变源。
            clean_rows = T.alloc_var('int32')
            clean_rows = 0
            for q in T.serial(begin_slot, end_slot):
                clean_rows = T.max(clean_rows, T.min(actual_capacity, consumed_slots[q]) * blocks)
            if clean_rows > 0:
                runtime_fill(flags, 0, clean_rows * 8, T.uint32(0), cpu)
                if not cpu:
                    T.set_flag('V', 'MTE3', 0)
                    T.wait_flag('V', 'MTE3', 0)
                    T.set_flag('S', 'MTE3', 0)
                    T.wait_flag('S', 'MTE3', 0)
                for q in T.serial(begin_slot, end_slot):
                    bucket = ((q % world + rank) % world) * (experts // world) + q // world
                    cleared = T.alloc_var('int32')
                    cleared = 0
                    while cleared < consumed_slots[q]:
                        n = T.min(actual_capacity, consumed_slots[q] - cleared)
                        offset = (bucket * tokens + cleared) * blocks * 128 + 120
                        write_receive_rows(flags, payload, 0, offset, 8, 128, 8, n * blocks, max_rows, cpu)
                        cleared = cleared + n
                runtime_finish(cpu)
            runtime_marker(diag, 901, cpu)


def make_runtime_kernel(limits, cores=64, *, poll_limit=100000):
    """[AI] 一个容量档位一个PrimFunc；P/E/T/H/K/rank及mask均来自params。

    x/output:uint16位模式，BF16/FP16都不做数值转换。核数是启动档位，容量和
    UB在导出时固定；同一产物可处理多种合法运行时形状，不调用旧make_kernel。
    """
    from .runtime_contract import PARAM_WORDS, RUNTIME_ABI
    if type(poll_limit) is not int or not 1 <= poll_limit <= 10000000:
        raise ValueError('poll_limit must be an integer in [1,10000000]')
    plan = limits.ub_plan(cores)
    max_tokens, max_hidden, max_top_k = limits.max_tokens, limits.max_hidden, limits.max_top_k
    max_experts, max_world = limits.max_experts, limits.max_world_size
    record_words, max_blocks = limits.record_words, limits.record_blocks
    payload_words, window_words = limits.payload_words, limits.cpu_window_words
    capacity = plan['batch_capacity']
    max_rows = plan['max_ready_rows']
    # [AI] 初始化helper要求偶数行容量；实际有效READY行可以是奇数。
    max_rows = (max_rows + 1) // 2 * 2
    max_stride = (limits.max_experts + 7) // 8 * 8
    @T.prim_func
    def dispatch_runtime(params: T.Tensor((PARAM_WORDS,), 'uint64'),
                         x: T.Tensor((max_tokens * max_hidden,), 'uint16'),
                         ids: T.Tensor((max_tokens * max_top_k,), 'int32'),
                         mask: T.Tensor((max_tokens,), 'uint8'),
                         peers: T.Tensor((max_world * 2,), 'uint64'),
                         state: T.Tensor((STATE_WORDS,), 'uint32'),
                         payload: T.Tensor((payload_words,), 'uint32'),
                         output: T.Tensor((max_experts * max_tokens * max_hidden,), 'uint16'),
                         assist: T.Tensor((max_experts * max_tokens * 3,), 'int32'),
                         counts: T.Tensor((max_experts,), 'int32'),
                         expert_nums: T.Tensor((max_experts,), 'int64'),
                         diagnostics: T.Tensor((cores * 16,), 'int32')):
        with T.Kernel(cores, threads=1, is_npu=True) as core:
            T.import_source(RECEIVE_COPY_SOURCE + RUNTIME_COPY_SOURCE)
            with T.Scope('V'):
                p = T.alloc_ub((PARAM_WORDS,), 'uint64')
                route = T.alloc_ub((max_tokens * max_top_k,), 'int32')
                active = T.alloc_ub((max_tokens,), 'uint8')
                record = T.alloc_ub((record_words,), 'uint32')
                records = T.alloc_ub((max_experts * 8,), 'uint32')
                prefix = T.alloc_ub((max_stride,), 'int32')
                consumed_slots = T.alloc_ub((max_experts * 3,), 'int32')
                nums = T.alloc_ub((max_experts,), 'int64')
                diag = T.alloc_ub((16,), 'int32')
                data_a = T.alloc_ub((capacity * max_blocks * 120,), 'uint32')
                data_b = T.alloc_ub((capacity * max_blocks * 120,), 'uint32')
                flags = T.alloc_ub((max_rows * 8 + 72,), 'uint32')
                for i in T.serial(16):
                    diag[i] = 0
                runtime_marker(diag, 1, False)
                copy_words(params, p, 0, 0, PARAM_WORDS, False)
                if (p[11] != T.uint64(RUNTIME_ABI) or p[6] != T.uint64(cores) or
                    p[0] == T.uint64(0) or p[0] > T.uint64(max_tokens) or
                    p[1] == T.uint64(0) or p[1] > T.uint64(max_hidden) or
                    p[2] == T.uint64(0) or p[2] > T.uint64(max_top_k) or
                    p[3] == T.uint64(0) or p[3] > T.uint64(max_experts) or
                    p[4] == T.uint64(0) or p[4] > T.uint64(max_world) or
                    p[5] >= p[4] or p[3] % T.max(p[4], T.uint64(1)) != T.uint64(0) or
                    p[12] > T.uint64(1) or p[13] > T.uint64(1) or
                    p[14] > T.uint64(1) or p[15] != (p[1] * T.uint64(2) + T.uint64(31)) // T.uint64(32) * T.uint64(8) or
                    p[16] != (p[15] * T.uint64(4) + T.uint64(511)) // T.uint64(480)):
                    diag[0] = 8
                else:
                    runtime_send(p, x, ids, mask, peers, core, route, active, record,
                                 diag, data_a, data_b, records, window_words, False)
                    runtime_prefix(p, state, counts, core, records, prefix, diag, data_a, poll_limit, False)
                    T.pipe_barrier('ALL')
                    runtime_receive(p, state, payload, output, assist, expert_nums, core, prefix,
                                    nums, consumed_slots, records, data_a, data_b, flags, diag,
                                    capacity, max_rows, poll_limit, False)
                copy_words(diag, diagnostics, 0, core * 16, 16, False)
                runtime_marker(diag, 2, False)
    return dispatch_runtime
