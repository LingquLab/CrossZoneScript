"""[AI] Execute production primitive C++ against explicit Host semantic stubs.

These tests check bit layout, selection, bounds and helper arithmetic. They do
not establish CANN overload availability, target instructions or event ordering.
"""
import ast
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


STUB = r'''
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#define __aicore__
#define __gm__
constexpr int PIPE_V=0;
namespace AscendC {
template<class T> struct Tensor {
    uint8_t* p=nullptr; size_t bytes=0;
    Tensor()=default;
    Tensor(T* q,size_t n):p(reinterpret_cast<uint8_t*>(q)),bytes(n*sizeof(T)){}
    Tensor operator[](size_t n) const {
        if(n*sizeof(T)>bytes)throw std::runtime_error("tensor offset");
        Tensor t;t.p=p+n*sizeof(T);t.bytes=bytes-n*sizeof(T);return t;
    }
    T GetValue(size_t n)const {
        if((n+1)*sizeof(T)>bytes)throw std::runtime_error("tensor read");
        T x;std::memcpy(&x,p+n*sizeof(T),sizeof(T));return x;
    }
    void SetValue(size_t n,T x)const {
        if((n+1)*sizeof(T)>bytes)throw std::runtime_error("tensor write");
        std::memcpy(p+n*sizeof(T),&x,sizeof(T));
    }
    template<class U> Tensor<U> ReinterpretCast()const {
        Tensor<U> t;t.p=p;t.bytes=bytes;return t;
    }
    void SetGlobalBuffer(T* q){p=reinterpret_cast<uint8_t*>(q);bytes=1ULL<<32;}
};
template<class T>using LocalTensor=Tensor<T>;
template<class T>using GlobalTensor=Tensor<T>;
struct DataCopyExtParams{uint16_t blockCount;uint32_t blockLen,srcStride,dstStride,rsv;};
struct DataCopyParams{uint16_t blockCount,blockLen,srcStride,dstStride;};
template<class T>struct DataCopyPadExtParams{bool pad;uint8_t left,right;T value;};
enum class HardEvent{MTE2_V,V_S};
enum class CMPMODE{EQ,GE,LT};
struct CopyRepeatParams{uint16_t dstBlkStride,srcBlkStride,dstRepStride,srcRepStride;};
struct GatherMaskParams{uint16_t src0BlockStride,repeatTimes,src0RepeatStride,src1RepeatStride;};
template<HardEvent E>void SetFlag(int){}
template<HardEvent E>void WaitFlag(int){}
template<int P>void PipeBarrier(){}
// Unused movement/reduction APIs compile the complete production source block;
// tested Copy, Compares, And and GatherMask have explicit scalar semantics below.
template<class... A>void DataCopyPad(A...){}
template<class T>void DataCopy(Tensor<T> dst,Tensor<T> src,DataCopyParams p){
    const uint32_t perBlock=32/sizeof(T);
    for(uint32_t r=0;r<p.blockCount;++r)for(uint32_t i=0;i<p.blockLen*perBlock;++i)
        dst.SetValue(r*(p.blockLen+p.dstStride)*perBlock+i,
                     src.GetValue(r*(p.blockLen+p.srcStride)*perBlock+i));
}
template<class T,class... A>void ReduceMin(A...){}
template<class T,class... A>void ReduceMax(A...){}
template<class T>void Duplicate(Tensor<T> dst,T value,uint32_t count){
    for(uint32_t i=0;i<count;++i)dst.SetValue(i,value);
}
template<class T>void Copy(Tensor<T> dst,Tensor<T> src,uint64_t mask,uint8_t repeats,CopyRepeatParams p){
    constexpr uint32_t perBlock=32/sizeof(T);
    for(uint32_t r=0;r<repeats;++r)for(uint32_t i=0;i<mask;++i){
        const auto si=r*p.srcRepStride*perBlock+(i/perBlock)*p.srcBlkStride*perBlock+i%perBlock;
        const auto di=r*p.dstRepStride*perBlock+(i/perBlock)*p.dstBlkStride*perBlock+i%perBlock;
        dst.SetValue(di,src.GetValue(si));
    }
}
template<class T>void Compares(Tensor<uint8_t> dst,Tensor<T> src,T scalar,CMPMODE mode,uint32_t count){
    for(uint32_t i=0;i<count;++i){
        const T v=src.GetValue(i);
        const bool match=mode==CMPMODE::EQ?v==scalar:mode==CMPMODE::GE?v>=scalar:v<scalar;
        uint8_t b=dst.GetValue(i/8),bit=static_cast<uint8_t>(1U<<(i%8));
        dst.SetValue(i/8,match?static_cast<uint8_t>(b|bit):static_cast<uint8_t>(b&~bit));
    }
}
void And(Tensor<uint16_t> dst,Tensor<uint16_t> a,Tensor<uint16_t> b,int32_t count){
    for(int32_t i=0;i<count;++i)dst.SetValue(i,a.GetValue(i)&b.GetValue(i));
}
template<class T>void GatherMask(Tensor<T> dst,Tensor<T> src,Tensor<uint32_t> mask,
    bool reduceMode,uint32_t count,GatherMaskParams p,uint64_t& selected){
    if(!reduceMode||p.src0BlockStride!=1||p.repeatTimes!=1)throw std::runtime_error("unsupported gather mode");
    auto bits=mask.template ReinterpretCast<uint8_t>();selected=0;
    for(uint32_t i=0;i<count;++i)if((bits.GetValue(i/8)>>(i%8))&1U)dst.SetValue(selected++,src.GetValue(i));
}
}
'''

HARNESS = r'''
void require(bool yes,const char* why){if(!yes)throw std::runtime_error(why);}
void prefix_copy(uint32_t words){
    constexpr uint32_t guard=0xdeadbeef;
    std::vector<uint32_t> source(words+16,guard),dest(words+16,guard);
    for(uint32_t i=0;i<words;++i)source[8+i]=0x80000000U+i*0x1234567U;
    source[8]=0;source[9]=0x7fffffff;source[10]=0x80000000;source[11]=0xffffffff;
    const auto before=source;
    AscendC::LocalTensor<uint32_t> out(dest.data(),dest.size());
    AscendC::GlobalTensor<uint32_t> in(source.data(),source.size());
    tl::ascend::copy_gm_to_ub_runtime_prefix(out[8].ReinterpretCast<int32_t>(),in[8],words);
    require(std::equal(source.begin()+8,source.begin()+8+words,dest.begin()+8),"prefix bit view mismatch");
    require(std::all_of(dest.begin(),dest.begin()+8,[](uint32_t x){return x==guard;}),"prefix left guard");
    require(std::all_of(dest.begin()+8+words,dest.end(),[](uint32_t x){return x==guard;}),"prefix right guard");
    require(source==before,"prefix mutated source");
}
void packing(uint32_t hidden,uint32_t blocks){
    const uint32_t guard=0xdeadbeef,ready=0x3f800000;
    const uint32_t aw=((hidden*2+31)/32)*8;
    require(aw+3<=blocks*120,"test compact capacity");
    std::vector<uint32_t> source(blocks*120,0),dest(blocks*128+16,guard);
    // Independently construct BF16/FP16 bit patterns, including NaN-looking and
    // signed encodings: the helper must never convert them numerically.
    std::vector<uint16_t> feature(hidden);
    for(uint32_t h=0;h<hidden;++h)feature[h]=static_cast<uint16_t>(0x7f81U+h*313U);
    std::memcpy(source.data(),feature.data(),hidden*2);
    source[aw]=3;source[aw+1]=71;source[aw+2]=2;
    for(uint32_t b=0;b<blocks;++b)for(uint32_t j=120;j<128;++j)dest[b*128+j]=ready;
    const auto before=source;
    tl::ascend::copy_ub_to_ub_runtime_pack({dest.data(),dest.size()},{source.data(),source.size()},blocks);
    for(uint32_t b=0;b<blocks;++b)for(uint32_t j=0;j<128;++j){
        const uint32_t expected=j<120?source[b*120+j]:ready;
        require(dest[b*128+j]==expected,"packed payload/READY mismatch");
    }
    require(std::all_of(dest.begin()+blocks*128,dest.end(),[&](uint32_t x){return x==guard;}),"pack guard overwritten");
    require(source==before,"pack mutated source");
    if(hidden%2)require((source[hidden/2]>>16)==0,"odd H padding uninitialized");
}
void selecting(uint32_t count,int32_t lo,int32_t hi,bool normalize){
    constexpr uint32_t max=1031,maskWords=((max+255)/256)*8,aligned=((max+7)/8)*8;
    require(count<=max,"route count");
    std::vector<int32_t> route(max,-1);
    for(uint32_t i=0;i<count;++i){
        route[i]=static_cast<int32_t>((i*17+i/5)%37)-3;
        if(normalize&&(i%4==0||route[i]>=32))route[i]=-1;
    }
    const auto original=route;
    const uint32_t guard=0xdecafbad;
    for(bool range:{false,true}){
        std::vector<uint32_t> scratch(2*maskWords+aligned+8+16,guard);
        std::vector<int32_t> expected;
        for(uint32_t i=0;i<count;++i)if(range?(route[i]>=lo&&route[i]<hi):route[i]==lo)expected.push_back(route[i]);
        const uint32_t selectedStart=(range?2:1)*maskWords;
        const uint32_t result=selectedStart+aligned;
        if(range)tl::ascend::copy_ub_to_ub_runtime_range<max>({scratch.data(),scratch.size()},{route.data(),route.size()},count,lo,hi);
        else tl::ascend::copy_ub_to_ub_runtime_equal<max>({scratch.data(),scratch.size()},{route.data(),route.size()},count,lo);
        require(scratch[result]==expected.size(),"selected count mismatch");
        for(uint32_t i=0;i<expected.size();++i)require(static_cast<int32_t>(scratch[selectedStart+i])==expected[i],"selected order mismatch");
        for(uint32_t i=result+1;i<scratch.size();++i)require(scratch[i]==guard,"selection result guard overwritten");
        require(route==original,"selection mutated routes");
    }
}
int main(int argc,char** argv){
    try{
        if(argc==3&&std::string(argv[1])=="prefix")prefix_copy(std::stoul(argv[2]));
        else if(argc==4&&std::string(argv[1])=="pack")packing(std::stoul(argv[2]),std::stoul(argv[3]));
        else if(argc==6&&std::string(argv[1])=="select")selecting(std::stoul(argv[2]),std::stoi(argv[3]),std::stoi(argv[4]),std::stoi(argv[5])!=0);
        else return 2;
        std::cout<<"PASS\n";return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
'''


@unittest.skipUnless(shutil.which('g++'), 'Requires C++14 Host compiler')
class RuntimePrimitiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tree = ast.parse((Path(__file__).resolve().parents[1] / 'kernel.py').read_text())
        assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(target, ast.Name) and target.id == 'RUNTIME_COPY_SOURCE'
                                  for target in node.targets))
        production_source = ast.literal_eval(assignment.value)
        cls.directory = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.directory.cleanup)
        source = Path(cls.directory.name) / 'runtime_primitives.cpp'
        source.write_text(STUB + production_source + HARNESS)
        cls.executable = Path(cls.directory.name) / 'runtime_primitives'
        subprocess.run(['g++', '-std=c++14', '-Wall', '-Wextra', '-pedantic',
                        str(source), '-o', str(cls.executable)], check=True,
                       capture_output=True, text=True, timeout=30)

    def run_case(self, *args):
        result = subprocess.run([str(self.executable), *map(str, args)],
                                capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(result.stdout.strip(), 'PASS')

    def test_bit_preserving_pack_odd_h_and_ready(self):
        for hidden in (1, 17, 239, 240, 255, 256, 513, 1024):
            with self.subTest(hidden=hidden):
                blocks = (((hidden * 2 + 31) // 32 * 32) + 32 + 479) // 480
                self.run_case('pack', hidden, blocks)

    def test_prefix_dma_preserves_unsigned_bits_and_bounds(self):
        for words in (8, 16, 24, 64, 256):
            with self.subTest(words=words):
                self.run_case('prefix', words)

    def test_pack_repeat_segmentation(self):
        # [AI] Exercise the helper's own uint8 split, independent of the current
        # Host contract that rejects >255 blocks per native-compatible record.
        self.run_case('pack', 17, 256)
        self.run_case('pack', 17, 511)

    def test_exact_equal_and_range_tail_selection(self):
        for count in (0, 1, 7, 8, 31, 32, 33, 255, 256, 257, 1024, 1031):
            for normalize in (0, 1):
                for lo, hi in ((0, 8), (7, 19), (31, 32), (40, 41)):
                    with self.subTest(count=count, normalize=normalize, lo=lo, hi=hi):
                        self.run_case('select', count, lo, hi, normalize)
