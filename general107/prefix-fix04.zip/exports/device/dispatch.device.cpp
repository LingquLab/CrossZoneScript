
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] 9.1/950整数归约：每repeat只比较32B槽首；Min和Max都为READY才全等。
// flags后的56个uint32保护区由TL初始化，末次repeat的整个256B读取范围均已分配。
// 两个结果独立32B对齐；950无需sharedTmpBuffer，按该版本文档传src。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    constexpr uint32_t result = Capacity * 16 + 56;
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows), 1,
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// [AI] assist保留uint32来源的全部位；GM输出仍是int32，不能用异型Tensor实例化同T模板。
template <uint32_t Capacity>
__aicore__ inline void copy_ub_to_gm_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t dstPitch, uint32_t rows,
    uint32_t width) {
    auto signedSrc = src.ReinterpretCast<int32_t>();
    // import_source位于common.h之前；直接提交DMA，不依赖尚未声明的后端模板。
    AscendC::DataCopyExtParams params{static_cast<uint16_t>(rows), width * 4,
        (240 * 4 - width * 4) / 32, dstPitch * 4 - width * 4, 0};
    AscendC::DataCopyPad(dst, signedSrc, params);
}
// [AI] peer表是在本进程设备地址空间内有效的uint64地址，不是另一进程的裸指针。
// CopyCodegen把真实GM表作为dst、真实UB作为src传入；此桥接只绑定目标地址并提交对齐DMA。
__aicore__ inline void copy_ub_to_gm_peer(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint32_t slot, uint32_t wordOffset,
    uint32_t words) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue(slot)));
    AscendC::DataCopy(dst[wordOffset], src, words);
}
} }

namespace tl { namespace ascend {
__aicore__ inline void copy_gm_to_ub_runtime_prefix(AscendC::LocalTensor<int32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t words) {
    // [AI] workspace stores uint32 words; prefix arithmetic uses their int32 view.
    // Runtime stride is padded to eight words, so this copies complete 32B blocks.
    AscendC::DataCopyParams p{1, static_cast<uint16_t>(words / 8), 0, 0};
    AscendC::DataCopy(dst.ReinterpretCast<uint32_t>(), src, p);
}
__aicore__ inline void copy_gm_to_ub_runtime_feature(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint16_t> src, uint32_t count) {
    AscendC::DataCopyExtParams p{1, count * 2, 0, 0, 0};
    AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(dst.ReinterpretCast<uint16_t>(), src, p, pad);
}
__aicore__ inline void copy_ub_to_gm_runtime_feature(AscendC::GlobalTensor<uint16_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t pitch, uint32_t rows, uint32_t hidden) {
    AscendC::DataCopyExtParams p{static_cast<uint16_t>(rows), hidden * 2,
        (pitch * 4 - hidden * 2) / 32, 0, 0};
    AscendC::DataCopyPad(dst, src.ReinterpretCast<uint16_t>(), p);
}
__aicore__ inline void copy_ub_to_gm_runtime_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t pitch, uint32_t rows) {
    AscendC::DataCopyExtParams p{static_cast<uint16_t>(rows), 12,
        (pitch * 4 - 12) / 32, 0, 0};
    AscendC::DataCopyPad(dst, src.ReinterpretCast<int32_t>(), p);
}
template <uint32_t MaxRows>
__aicore__ inline void copy_gm_to_ub_runtime_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t rows) {
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), 1, 15, 0};
    AscendC::DataCopy(dst, src, p);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    constexpr uint32_t result = MaxRows * 8 + 56;
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}

__aicore__ inline void copy_ub_to_ub_runtime_boundary(AscendC::LocalTensor<int32_t> dst,
    AscendC::LocalTensor<int32_t> src, uint32_t id) {
    // [AI] profile0编译为空；独立ABI3插桩器只替换调用，不修改算法或事件。
    (void)dst; (void)src; (void)id;
}
// [AI] 单个向量/搬运原语；业务循环、路由顺序和事件寿命仍由TL宏管理。
__aicore__ inline void copy_ub_to_ub_runtime_fill(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> unused, uint32_t words, uint32_t value) {
    AscendC::Duplicate<uint32_t>(dst, value, words);
}
__aicore__ inline void copy_ub_to_ub_runtime_pack(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t blocks) {
    auto in = src.ReinterpretCast<int32_t>();
    auto out = dst.ReinterpretCast<int32_t>();
    // [AI] 每480B有效区扩成512B行距，READY的32B不被Copy覆盖；repeat分段防uint8溢出。
    for (uint32_t first = 0; first < blocks; first += 255) {
        uint8_t n = static_cast<uint8_t>(blocks - first > 255 ? 255 : blocks - first);
        AscendC::Copy(out[first * 128], in[first * 120], uint64_t(64), n, {1,1,16,15});
        AscendC::Copy(out[first * 128 + 64], in[first * 120 + 64], uint64_t(56), n, {1,1,16,15});
    }
}
template <uint32_t MaxRoutes>
__aicore__ inline void copy_ub_to_ub_runtime_range(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> routes, uint32_t count, int32_t lo, int32_t hi) {
    constexpr uint32_t maskWords = ((MaxRoutes + 255) / 256) * 8;
    constexpr uint32_t result = 2 * maskWords + ((MaxRoutes + 7) / 8) * 8;
    if (!count) { scratch.SetValue(result, 0); return; }
    // [AI] Compares只写有效bit；And会读完整对齐mask，因此尾部先初始化。
    AscendC::Duplicate<uint32_t>(scratch, 0, maskWords * 2);
    AscendC::PipeBarrier<PIPE_V>();
    auto lower = scratch.ReinterpretCast<uint8_t>();
    auto upper = scratch[maskWords].ReinterpretCast<uint8_t>();
    AscendC::Compares(lower, routes, lo, AscendC::CMPMODE::GE, count);
    AscendC::Compares(upper, routes, hi, AscendC::CMPMODE::LT, count);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::And(lower.ReinterpretCast<uint16_t>(), lower.ReinterpretCast<uint16_t>(),
        upper.ReinterpretCast<uint16_t>(), static_cast<int32_t>(maskWords * 2));
    AscendC::PipeBarrier<PIPE_V>();
    uint64_t selected = 0;
    AscendC::GatherMask(scratch[maskWords * 2].ReinterpretCast<int32_t>(), routes, scratch,
        true, count, {1,1,0,0}, selected);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
    scratch.SetValue(result, static_cast<uint32_t>(selected));
}
template <uint32_t MaxRoutes>
__aicore__ inline void copy_ub_to_ub_runtime_equal(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> routes, uint32_t count, int32_t expert) {
    constexpr uint32_t maskWords = ((MaxRoutes + 255) / 256) * 8;
    constexpr uint32_t result = maskWords + ((MaxRoutes + 7) / 8) * 8;
    if (!count) { scratch.SetValue(result, 0); return; }
    AscendC::Compares(scratch.ReinterpretCast<uint8_t>(), routes, expert, AscendC::CMPMODE::EQ, count);
    AscendC::PipeBarrier<PIPE_V>();
    uint64_t selected = 0;
    AscendC::GatherMask(scratch[maskWords].ReinterpretCast<int32_t>(), routes, scratch,
        true, count, {1,1,0,0}, selected);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
    scratch.SetValue(result, static_cast<uint32_t>(selected));
}
__aicore__ inline void copy_ub_to_gm_runtime_workspace(AscendC::GlobalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t rows, uint32_t width, uint32_t pitch) {
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), static_cast<uint16_t>(width / 8),
        0, static_cast<uint16_t>((pitch - width) / 8)};
    AscendC::DataCopy(dst, src, p);
}
__aicore__ inline void copy_ub_to_gm_runtime_counts(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint64_t address, uint32_t rows, uint32_t world) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t*>(peers.GetValue(address >> 32)));
    AscendC::DataCopyParams p{static_cast<uint16_t>(rows), 1, 0, static_cast<uint16_t>(world - 1)};
    AscendC::DataCopy(dst[static_cast<uint32_t>(address)], src, p);
}
} }
#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void tilexr_tl_dispatch_runtime_c64( GM_ADDR params_handle,  GM_ADDR x_handle,  GM_ADDR ids_handle,  GM_ADDR mask_handle,  GM_ADDR peers_handle,  GM_ADDR state_handle,  GM_ADDR payload_handle,  GM_ADDR output_handle,  GM_ADDR assist_handle,  GM_ADDR counts_handle,  GM_ADDR expert_nums_handle,  GM_ADDR diagnostics_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<uint64_t> params;
  params.SetGlobalBuffer((__gm__ uint64_t*)params_handle);
  AscendC::GlobalTensor<uint16_t> x;
  x.SetGlobalBuffer((__gm__ uint16_t*)x_handle);
  AscendC::GlobalTensor<int> ids;
  ids.SetGlobalBuffer((__gm__ int*)ids_handle);
  AscendC::GlobalTensor<uint8_t> mask;
  mask.SetGlobalBuffer((__gm__ uint8_t*)mask_handle);
  AscendC::GlobalTensor<uint64_t> peers;
  peers.SetGlobalBuffer((__gm__ uint64_t*)peers_handle);
  AscendC::GlobalTensor<uint32_t> state;
  state.SetGlobalBuffer((__gm__ uint32_t*)state_handle);
  AscendC::GlobalTensor<uint32_t> payload;
  payload.SetGlobalBuffer((__gm__ uint32_t*)payload_handle);
  AscendC::GlobalTensor<uint16_t> output;
  output.SetGlobalBuffer((__gm__ uint16_t*)output_handle);
  AscendC::GlobalTensor<int> assist;
  assist.SetGlobalBuffer((__gm__ int*)assist_handle);
  AscendC::GlobalTensor<int> counts;
  counts.SetGlobalBuffer((__gm__ int*)counts_handle);
  AscendC::GlobalTensor<int64_t> expert_nums;
  expert_nums.SetGlobalBuffer((__gm__ int64_t*)expert_nums_handle);
  AscendC::GlobalTensor<int> diagnostics;
  diagnostics.SetGlobalBuffer((__gm__ int*)diagnostics_handle);

  // [AI] 纯AIV仅分配实际UB，全部搬运完成后销毁。
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;
  pipe.InitBuffer(ascend_ub, 191968);
  auto core = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    }
  auto diag = ascend_ub.GetWithOffset<int>(16, 0);
  auto p = ascend_ub.GetWithOffset<uint64_t>(32, 64);
  auto route = ascend_ub.GetWithOffset<int>(1024, 320);
  auto active = ascend_ub.GetWithOffset<uint8_t>(256, 4416);
  int workers = 0;
  int worker = 0;
  auto records = ascend_ub.GetWithOffset<uint32_t>(128, 4672);
  auto data_b = ascend_ub.GetWithOffset<uint32_t>(22200, 5184);
  auto data_a = ascend_ub.GetWithOffset<uint32_t>(22200, 93984);
  auto record = ascend_ub.GetWithOffset<uint32_t>(640, 182784);
  int issued = 0;
  int producers = 0;
  int ready = 0;
  int polls = 0;
  uint32_t running = (uint32_t)0;
  auto prefix = ascend_ub.GetWithOffset<int>(16, 185344);
  int first = 0;
  int producers_1 = 0;
  int ready_1 = 0;
  int polls_1 = 0;
  auto nums = ascend_ub.GetWithOffset<int64_t>(16, 185408);
  int valid_slots = 0;
  auto consumed_slots = ascend_ub.GetWithOffset<int>(48, 185536);
  auto flags = ascend_ub.GetWithOffset<uint32_t>(1560, 185728);
  int remaining = 0;
  int cursor = 0;
  int batch_index = 0;
  int pending_a = 0;
  int pending_b = 0;
  int start = 0;
  int arrived = 0;
  int clean_rows = 0;
  int position = 0;
  int before = 0;
  int start_1 = 0;
  int cleared = 0;
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    if ASCEND_IS_AIV {
      for (int32_t i = 0; i < 16; ++i) {
        diag.SetValue(i, 0);
      }
      tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 1);
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<uint64_t, 32>(p[0], params[0], 32, 1, 32, (uint64_t)0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      if (((((((((((((((((((p.GetValue(11) != (uint64_t)3) || (p.GetValue(6) != (uint64_t)64)) || (p.GetValue(0) == (uint64_t)0)) || ((uint64_t)256 < p.GetValue(0))) || (p.GetValue(1) == (uint64_t)0)) || ((uint64_t)1024 < p.GetValue(1))) || (p.GetValue(2) == (uint64_t)0)) || ((uint64_t)4 < p.GetValue(2))) || (p.GetValue(3) == (uint64_t)0)) || ((uint64_t)16 < p.GetValue(3))) || (p.GetValue(4) == (uint64_t)0)) || ((uint64_t)8 < p.GetValue(4))) || (p.GetValue(4) <= p.GetValue(5))) || ((p.GetValue(3) % (p.GetValue(4) > (uint64_t)1 ? p.GetValue(4) : (uint64_t)1)) != (uint64_t)0)) || ((uint64_t)1 < p.GetValue(12))) || ((uint64_t)1 < p.GetValue(13))) || ((uint64_t)1 < p.GetValue(14))) || (p.GetValue(15) != (((p.GetValue(1) + (uint64_t)15) / (uint64_t)16) * (uint64_t)8))) || (p.GetValue(16) != ((p.GetValue(15) + (uint64_t)127) / (uint64_t)120))) {
        diag.SetValue(0, 8);
      } else {
        tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 10);
        int32_t count = ((int32_t)(p.GetValue(0) * p.GetValue(2)));
        int32_t experts = ((int32_t)p.GetValue(3));
        int32_t world = ((int32_t)p.GetValue(4));
        int32_t rank = ((int32_t)p.GetValue(5));
        int32_t cores = ((int32_t)p.GetValue(6));
        int32_t hidden = ((int32_t)p.GetValue(1));
        int32_t assist_word = ((int32_t)p.GetValue(15));
        int32_t blocks = ((int32_t)p.GetValue(16));
        tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 11);
        tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 100);
        AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
        tl::ascend::copy_gm_to_ub<int, 1024>(route[0], ids[0], 1024, 1, ((count <= 1024) ? count : 1024), 0);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        if (p.GetValue(12) != (uint64_t)0) {
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval;
          if (((int32_t)p.GetValue(0)) <= 256) {
            condval = ((int32_t)p.GetValue(0));
          } else {
            condval = 256;
          }
          tl::ascend::copy_gm_to_ub<uint8_t, 256>(active[0], mask[0], 256, 1, condval, (uchar)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        }
        for (int32_t i_1 = 0; i_1 < count; ++i_1) {
          if ((route.GetValue(i_1) < 0) || (experts <= route.GetValue(i_1))) {
            route.SetValue(i_1, -1);
          }
          if (p.GetValue(12) != (uint64_t)0) {
            if (active.GetValue((i_1 / ((int32_t)p.GetValue(2)))) == (uchar)0) {
              route.SetValue(i_1, -1);
            }
          }
        }
        tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 101);
        workers = cores;
        worker = core;
        if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
          workers = (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)));
          worker = ((core + workers) - cores);
        }
        if (((p.GetValue(0) / (uint64_t)48) < (uint64_t)1) || ((cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))) <= core)) {
          int32_t begin = ((worker < (experts % workers) ? worker : (experts % workers)) + ((experts / workers) * worker));
          int32_t end = ((begin + (experts / workers)) + ((int32_t)(worker < (experts % workers))));
          if (begin < end) {
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 200);
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::copy_ub_to_ub_runtime_fill(records[0], records[0], (experts * 8), (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            for (int32_t expert = begin; expert < end; ++expert) {
              records.SetValue((((int64_t)expert) * (int64_t)8), (uint32_t)1065353216);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::copy_ub_to_ub_runtime_range<1024>(data_b[0], route[0], count, begin, end);
            for (int32_t i_2 = 0; i_2 < ((int32_t)data_b.GetValue(1088)); ++i_2) {
              int32_t expert_1 = ((int32_t)data_b.GetValue((((int64_t)i_2) + (int64_t)64)));
              records.SetValue(((((int64_t)expert_1) * (int64_t)8) + (int64_t)1), (records.GetValue(((((int64_t)expert_1) * (int64_t)8) + (int64_t)1)) + (uint32_t)1));
            }
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 201);
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 300);
            for (int32_t target = 0; target < world; ++target) {
              if (((begin < ((target + 1) * (experts / world))) && ((target * (experts / world)) < end)) && ((target * (experts / world)) < ((target + 1) * (experts / world)))) {
                AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                uint64_t address = ((((uint64_t)(target * 2)) << (uint64_t)32) + ((uint64_t)(((((begin > (target * (experts / world)) ? begin : (target * (experts / world))) % (experts / world)) * world) * 8) + (rank * 8))));
                tl::ascend::copy_ub_to_gm_runtime_counts(peers[0], records[((begin > (target * (experts / world)) ? begin : (target * (experts / world))) * 8)], address, ((end < ((target + 1) * (experts / world)) ? end : ((target + 1) * (experts / world))) - (begin > (target * (experts / world)) ? begin : (target * (experts / world)))), world);
                diag.SetValue(4, (((end < ((target + 1) * (experts / world)) ? end : ((target + 1) * (experts / world))) + diag.GetValue(4)) - (begin > (target * (experts / world)) ? begin : (target * (experts / world)))));
              }
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 301);
          }
        }
        if ((core + 1) < cores) {
          tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 400);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::copy_ub_to_ub_runtime_fill(data_a[0], data_a[0], (((2 < (2775 / (blocks * 16)) ? 2 : (2775 / (blocks * 16))) * blocks) * 128), (uint32_t)1065353216);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::copy_ub_to_ub_runtime_fill(record[0], record[0], (blocks * 120), (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          issued = 0;
          for (int32_t task = 0; task < (((count + cores) - 2) / (cores - 1)); ++task) {
            if ((core + (task * (cores - 1))) < count) {
              int32_t token = ((core + (task * (cores - 1))) / ((int32_t)p.GetValue(2)));
              int32_t expert_2 = route.GetValue((((int64_t)core) + (((int64_t)task) * (((int64_t)cores) - (int64_t)1))));
              if (0 <= expert_2) {
                position = 0;
                AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                tl::ascend::copy_ub_to_ub_runtime_equal<1024>(data_b[0], route[0], (core + (task * (cores - 1))), expert_2);
                position = ((int32_t)data_b.GetValue(1056));
                if (((int32_t)p.GetValue(0)) <= position) {
                  diag.SetValue(0, 7);
                } else {
                  int32_t slot = (issued % (2 < (2775 / (blocks * 16)) ? 2 : (2775 / (blocks * 16))));
                  if ((2 <= issued) || ((2775 / (blocks * 16)) <= issued)) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>((slot + 2));
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_runtime_feature(record[0], x[(token * hidden)], hidden);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  if (0 < (hidden % 2)) {
                    record.SetValue((hidden / 2), (record.GetValue((hidden / 2)) & (uint32_t)65535));
                  }
                  for (int32_t j = ((hidden + 1) / 2); j < assist_word; ++j) {
                    record.SetValue(((int64_t)j), (uint32_t)0);
                  }
                  record.SetValue(((int64_t)assist_word), ((uint32_t)rank));
                  record.SetValue((((int64_t)assist_word) + (int64_t)1), ((uint32_t)token));
                  record.SetValue((((int64_t)assist_word) + (int64_t)2), ((uint32_t)((core + (task * (cores - 1))) % ((int32_t)p.GetValue(2)))));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::copy_ub_to_ub_runtime_pack(data_a[((slot * blocks) * 128)], record[0], blocks);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  int32_t offset = ((((((((rank + (expert_2 / (experts / world))) % world) * (experts / world)) + (expert_2 % (experts / world))) * ((int32_t)p.GetValue(0))) + position) * blocks) * 128);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm_peer(peers[0], data_a[((slot * blocks) * 128)], (((expert_2 / (experts / world)) * 2) + 1), offset, (blocks * 128));
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>((slot + 2));
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                  issued = (issued + 1);
                  diag.SetValue(5, (diag.GetValue(5) + 1));
                  diag.SetValue(9, ((blocks * 512) + diag.GetValue(9)));
                }
              }
            }
          }
          for (int32_t slot_1 = 0; slot_1 < (2 < (2775 / (blocks * 16)) ? 2 : (2775 / (blocks * 16))); ++slot_1) {
            if (slot_1 < issued) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>((slot_1 + 2));
            }
          }
          tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 401);
        }
        int32_t experts_1 = ((int32_t)p.GetValue(3));
        int32_t cores_1 = ((int32_t)p.GetValue(6));
        producers = (8 < (((experts_1 + 15) / 16) < (cores_1 / 2) ? ((experts_1 + 15) / 16) : (cores_1 / 2)) ? 8 : (((experts_1 + 15) / 16) < (cores_1 / 2) ? ((experts_1 + 15) / 16) : (cores_1 / 2)));
        if ((cores_1 - producers) <= core) {
          int32_t worker_1 = ((core + producers) - cores_1);
          int32_t begin_1 = (((worker_1 < (((experts_1 + 7) / 8) % producers) ? worker_1 : (((experts_1 + 7) / 8) % producers)) * 8) + (((((experts_1 + 7) / 8) / producers) * worker_1) * 8));
          int32_t stop = ((((((experts_1 + 7) / 8) / producers) * 8) + (((int32_t)(worker_1 < (((experts_1 + 7) / 8) % producers))) * 8)) + begin_1);
          tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 500);
          ready = 0;
          polls = 0;
          while (1) {
            if (!(((ready == 0) && (polls < 100000)))) { break; }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 128>(records[0], state[0], 262144, 1, ((experts_1 <= 32768) ? (experts_1 * 8) : 262144), (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            ready = 1;
            for (int32_t q = 0; q < experts_1; ++q) {
              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {
                ready = 0;
              }
            }
            polls = (polls + 1);
          }
          diag.SetValue(1, polls);
          tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 501);
          if (ready == 0) {
            diag.SetValue(0, 1);
          } else {
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 600);
            running = (uint32_t)0;
            for (int32_t q_1 = begin_1; q_1 < stop; ++q_1) {
              prefix.SetValue(((int64_t)q_1), 0);
            }
            for (int32_t q_2 = 0; q_2 < (stop < experts_1 ? stop : experts_1); ++q_2) {
              running = (running + records.GetValue(((((int64_t)q_2) * (int64_t)8) + (int64_t)1)));
              if (begin_1 <= q_2) {
                prefix.SetValue(q_2, ((int32_t)running));
              }
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int, 16>(counts[begin_1], prefix[begin_1], 16, 1, (((stop <= 16) || (experts_1 <= 16)) ? ((stop < experts_1 ? stop : experts_1) - begin_1) : ((begin_1 < 16) ? (16 - begin_1) : 0)));
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            first = 0;
            while (1) {
              if (!((first < cores_1))) { break; }
              int32_t n = ((1 > (22200 / (stop - begin_1)) ? 1 : (22200 / (stop - begin_1))) < (cores_1 - first) ? (1 > (22200 / (stop - begin_1)) ? 1 : (22200 / (stop - begin_1))) : (cores_1 - first));
              for (int32_t c = 0; c < n; ++c) {
                for (int32_t j_1 = 0; j_1 < (stop - begin_1); ++j_1) {
                  data_a.SetValue(((((int64_t)c) * (((int64_t)stop) - ((int64_t)begin_1))) + ((int64_t)j_1)), ((uint32_t)prefix.GetValue((((int64_t)begin_1) + ((int64_t)j_1)))));
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm_runtime_workspace(state[(((((first * ((experts_1 + 7) / 8)) * 8) + begin_1) + 196608) - ((cores_1 * ((experts_1 + 7) / 8)) * 8))], data_a[0], n, (stop - begin_1), (((experts_1 + 7) / 8) * 8));
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              first = (first + n);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::copy_ub_to_ub_runtime_fill(data_a[0], data_a[0], ((2775 < cores_1 ? 2775 : cores_1) * 8), (uint32_t)1);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            first = 0;
            while (1) {
              if (!((first < cores_1))) { break; }
              int32_t n_1 = (2775 < (cores_1 - first) ? 2775 : (cores_1 - first));
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm_runtime_workspace(state[((((first * producers) * 8) + (worker_1 * 8)) + 224256)], data_a[0], n_1, 8, (producers * 8));
              first = (first + n_1);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 601);
          }
        }
        AscendC::PipeBarrier<PIPE_ALL>();
        tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 700);
        int32_t experts_2 = ((int32_t)p.GetValue(3));
        int32_t world_1 = ((int32_t)p.GetValue(4));
        int32_t rank_1 = ((int32_t)p.GetValue(5));
        int32_t cores_2 = ((int32_t)p.GetValue(6));
        int32_t tokens = ((int32_t)p.GetValue(0));
        int32_t blocks_1 = ((int32_t)p.GetValue(16));
        producers_1 = (8 < (((experts_2 + 15) / 16) < (cores_2 / 2) ? ((experts_2 + 15) / 16) : (cores_2 / 2)) ? 8 : (((experts_2 + 15) / 16) < (cores_2 / 2) ? ((experts_2 + 15) / 16) : (cores_2 / 2)));
        ready_1 = 0;
        polls_1 = 0;
        while (1) {
          if (!(((ready_1 == 0) && (polls_1 < 100000)))) { break; }
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval_1;
          if (0 <= ((4736 - producers_1) - (core * producers_1))) {
            condval_1 = (producers_1 * 8);
          } else {
            int32_t condval_2;
            if ((core * producers_1) < 4736) {
              condval_2 = (37888 - ((core * producers_1) * 8));
            } else {
              condval_2 = 0;
            }
            condval_1 = condval_2;
          }
          tl::ascend::copy_gm_to_ub<uint32_t, 128>(records[0], state[(((core * producers_1) * 8) + 224256)], 262144, 1, condval_1, (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
          ready_1 = 1;
          for (int32_t j_2 = 0; j_2 < (producers_1 * 8); ++j_2) {
            if (records.GetValue(((int64_t)j_2)) != (uint32_t)1) {
              ready_1 = 0;
            }
          }
          polls_1 = (polls_1 + 1);
        }
        diag.SetValue(2, polls_1);
        if (ready_1 == 0) {
          diag.SetValue(0, 2);
        } else {
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::copy_ub_to_ub_runtime_fill(records[0], records[0], (producers_1 * 8), (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
          int32_t condval_3;
          if (0 <= ((4736 - producers_1) - (core * producers_1))) {
            condval_3 = (producers_1 * 8);
          } else {
            int32_t condval_4;
            if ((core * producers_1) < 4736) {
              condval_4 = (37888 - ((core * producers_1) * 8));
            } else {
              condval_4 = 0;
            }
            condval_3 = condval_4;
          }
          tl::ascend::copy_ub_to_gm<uint32_t, 128>(state[(((core * producers_1) * 8) + 224256)], records[0], 262144, 1, condval_3);
          AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          if (core == 0) {
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 128>(records[0], state[0], 262144, 1, ((experts_2 <= 32768) ? (experts_2 * 8) : 262144), (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            for (int32_t q_3 = 0; q_3 < experts_2; ++q_3) {
              records.SetValue((((int64_t)q_3) * (int64_t)8), (uint32_t)0);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 128>(state[0], records[0], 262144, 1, ((experts_2 <= 32768) ? (experts_2 * 8) : 262144));
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 701);
          if (((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)) < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2))))) {
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 702);
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub_runtime_prefix(prefix[0], state[(((((experts_2 + 7) / 8) * (core - cores_2)) * 8) + 196608)], (((experts_2 + 7) / 8) * 8));
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            if (core == 0) {
              for (int32_t local = 0; local < (experts_2 / world_1); ++local) {
                before = 0;
                if (0 < local) {
                  before = prefix.GetValue(((((int64_t)local) * ((int64_t)world_1)) - (int64_t)1));
                }
                nums.SetValue(((int64_t)local), ((int64_t)prefix.GetValue((((((int64_t)local) + (int64_t)1) * ((int64_t)world_1)) - (int64_t)1))));
                if (p.GetValue(13) == (uint64_t)1) {
                  nums.SetValue(((int64_t)local), (nums.GetValue(((int64_t)local)) - ((int64_t)before)));
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<int64_t, 16>(expert_nums[0], nums[0], 16, 1, (((experts_2 / world_1) <= 16) ? (experts_2 / world_1) : 16));
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            }
            valid_slots = 0;
            for (int32_t q_4 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_4 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_4) {
              consumed_slots.SetValue(((int64_t)q_4), 0);
              consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_4)), 0);
              start_1 = 0;
              if (0 < q_4) {
                start_1 = prefix.GetValue((((int64_t)q_4) - (int64_t)1));
              }
              int32_t size = (prefix.GetValue(((int64_t)q_4)) - start_1);
              if ((((size < 0) || (tokens < size)) || (start_1 < 0)) || ((experts_2 * tokens) < prefix.GetValue(((int64_t)q_4)))) {
                diag.SetValue(0, 5);
              }
              if (0 < size) {
                consumed_slots.SetValue(((((int64_t)experts_2) * (int64_t)2) + ((int64_t)valid_slots)), q_4);
                valid_slots = (valid_slots + 1);
              }
            }
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 703);
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 800);
            if ((0 < valid_slots) && (diag.GetValue(0) == 0)) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill_experiment<uint32_t>(flags[0], (uint32_t)0, (~(uint64_t)0), 24, 1, 8);
              tl::ascend::Fill_experiment<uint32_t>(flags[1536], (uint32_t)0, (((uint64_t)1 << (uint64_t)8) - (uint64_t)1), 1, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
            }
            remaining = valid_slots;
            cursor = 0;
            batch_index = 0;
            pending_a = 0;
            pending_b = 0;
            while (1) {
              if (!(((0 < remaining) && (diag.GetValue(0) == 0)))) { break; }
              int32_t q_5 = consumed_slots.GetValue(((((int64_t)experts_2) * (int64_t)2) + ((int64_t)cursor)));
              start = 0;
              if (0 < q_5) {
                start = prefix.GetValue((q_5 - 1));
              }
              int32_t size_1 = (prefix.GetValue(((int64_t)q_5)) - start);
              int32_t consumed = consumed_slots.GetValue(((int64_t)q_5));
              if (consumed < size_1) {
                arrived = 0;
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                tl::ascend::copy_gm_to_ub_runtime_ready<186>(flags[0], payload[((((((((((q_5 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_5 / world_1)) * tokens) + consumed) * blocks_1) * 128) + 120)], ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) * blocks_1));
                arrived = ((int32_t)((flags.GetValue(1544) == (uint32_t)1065353216) && (flags.GetValue(1552) == (uint32_t)1065353216)));
                consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_5)), (consumed_slots.GetValue((((int64_t)experts_2) + ((int64_t)q_5))) + 1));
                diag.SetValue(3, ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) + diag.GetValue(3)));
                if (arrived != 0) {
                  if ((batch_index % 2) == 0) {
                    if (pending_a != 0) {
                      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                    }
                    int32_t hidden_1 = ((int32_t)p.GetValue(1));
                    int32_t aw = ((int32_t)p.GetValue(15));
                    int32_t blocks_2 = ((int32_t)p.GetValue(16));
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                    tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 186>(data_a[0], payload[(((((((((q_5 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_5 / world_1)) * tokens) + consumed) * blocks_1) * 128)], 128, ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) * blocks_2), 120, (uint32_t)0);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                    tl::ascend::copy_ub_to_gm_runtime_feature(output[((start + consumed) * hidden_1)], data_a[0], (blocks_2 * 120), (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)), hidden_1);
                    tl::ascend::copy_ub_to_gm_runtime_assist(assist[((start * 3) + (consumed * 3))], data_a[aw], (blocks_2 * 120), (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)));
                    AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                    pending_a = 1;
                  } else {
                    if (pending_b != 0) {
                      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                    }
                    int32_t hidden_2 = ((int32_t)p.GetValue(1));
                    int32_t aw_1 = ((int32_t)p.GetValue(15));
                    int32_t blocks_3 = ((int32_t)p.GetValue(16));
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                    tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 186>(data_b[0], payload[(((((((((q_5 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_5 / world_1)) * tokens) + consumed) * blocks_1) * 128)], 128, ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) * blocks_3), 120, (uint32_t)0);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                    tl::ascend::copy_ub_to_gm_runtime_feature(output[((start + consumed) * hidden_2)], data_b[0], (blocks_3 * 120), (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)), hidden_2);
                    tl::ascend::copy_ub_to_gm_runtime_assist(assist[((start * 3) + (consumed * 3))], data_b[aw_1], (blocks_3 * 120), (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)));
                    AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                    pending_b = 1;
                  }
                  batch_index = (batch_index + 1);
                  consumed_slots.SetValue(((int64_t)q_5), ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) + consumed) < size_1 ? (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) + consumed) : size_1));
                  consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_5)), 0);
                  diag.SetValue(7, ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) + diag.GetValue(7)));
                  diag.SetValue(10, ((((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (size_1 - consumed) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (size_1 - consumed)) * blocks_1) * 512) + diag.GetValue(10)));
                  if (((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) + consumed) < size_1 ? (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) + consumed) : size_1) == size_1) {
                    remaining = (remaining - 1);
                    cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
                  }
                } else {
                  if (100000 <= consumed_slots.GetValue((((int64_t)experts_2) + ((int64_t)q_5)))) {
                    diag.SetValue(0, 3);
                  }
                  cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
                }
              } else {
                cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
              }
            }
            if (pending_a != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
            }
            if (pending_b != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
            }
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 801);
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 900);
            clean_rows = 0;
            for (int32_t q_6 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_6 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_6) {
              clean_rows = (clean_rows > ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < consumed_slots.GetValue(((int64_t)q_6)) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : consumed_slots.GetValue(((int64_t)q_6))) * blocks_1) ? clean_rows : ((((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < consumed_slots.GetValue(((int64_t)q_6)) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : consumed_slots.GetValue(((int64_t)q_6))) * blocks_1));
            }
            if (0 < clean_rows) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::copy_ub_to_ub_runtime_fill(flags[0], flags[0], (clean_rows * 8), (uint32_t)0);
              AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              for (int32_t q_7 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_7 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_7) {
                cleared = 0;
                while (1) {
                  if (!((cleared < consumed_slots.GetValue(((int64_t)q_7))))) { break; }
                  int32_t n_2 = (((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) < (consumed_slots.GetValue(((int64_t)q_7)) - cleared) ? ((185 / blocks_1) < ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1)) ? (185 / blocks_1) : ((186 / blocks_1) < (4095 / blocks_1) ? (186 / blocks_1) : (4095 / blocks_1))) : (consumed_slots.GetValue(((int64_t)q_7)) - cleared));
                  int32_t offset_1 = ((((((((((q_7 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_7 / world_1)) * tokens) + cleared) * blocks_1) * 128) + 120);
                  tl::ascend::copy_ub_to_gm<uint32_t, 8, 186>(payload[offset_1], flags[0], 128, (n_2 * blocks_1), 8);
                  cleared = (cleared + n_2);
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            }
            tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 901);
          }
        }
      }
      AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
      tl::ascend::copy_ub_to_gm<int, 16>(diagnostics[(core * 16)], diag[0], 1024, 1, 16);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
      tl::ascend::copy_ub_to_ub_runtime_boundary(diag[0], diag[0], 2);
    }
  }
  pipe.Destroy();
}
