"""Independent CANN/ABI0 build of frozen64ed plus reviewed experiment frontend."""
from pathlib import Path, PurePosixPath
import json
import shutil
import stat
import sys
import zipfile
from operations import ROOT, CANN, sha, save, require, run, integrity, gate

REV='64ed582898e1321a0e93a2c4e0e78a6deb2f4868'
OLD=Path('/root/tilelang-107-multirank-e28d87de-20261116-run01')

def extract(path, destination, expected_sha=None):
    if expected_sha:require(sha(path)==expected_sha,'Archive SHA mismatch')
    with zipfile.ZipFile(path) as z:
        names=z.namelist();require(len(names)==len(set(names)) and z.testzip() is None,'Archive duplicate/CRC')
        require(sum(i.file_size for i in z.infolist())<180*1024**2,'Archive size')
        for i in z.infolist():
            p=PurePosixPath(i.filename)
            require(not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(i.external_attr>>16),'Unsafe archive')
        z.extractall(destination)


def main():
    result={'schema':'tilelang_general_107_build.v1','candidate':REV,'status':'FAIL_OR_UNVERIFIED','npu_launch':False,'clock':'NOT_VERIFIED','directory':str(ROOT)}
    try:
        require(not (ROOT/'build-started.json').exists(),'Saved build exists; audit before retry')
        save(ROOT/'build-started.json',{'candidate':REV})
        result['integrity']=integrity()
        ports=[p for i in range(13) for p in [*range(27000+64*i,27032+64*i),*range(29400+3*i,29403+3*i)]]
        result['idle_gate']=gate(ROOT/'build-gate',all_devices=True,ports=ports)
        # Existing source-only dependency archive, verified before extraction; no old ELF reused.
        transfer=json.loads((OLD/'transfer.json').read_text())
        deps=OLD/'dependencies.zip';require(sha(deps)==transfer['dependency_zip_sha256'],'Dependency archive changed')
        with zipfile.ZipFile(deps) as z:
            manifest=json.loads(z.read('dependency-manifest.json'))
            require(manifest['revision']=='e28d87deb1e141e23ace5900594218ff47ab2525','Dependency provenance')
            for name,digest in manifest['files'].items():
                raw=z.read(name);require(__import__('hashlib').sha256(raw).hexdigest()==digest,'Dependency member changed')
        extract(deps,ROOT/'deps')
        require(sha(ROOT/'deps/backend/src/tl_templates/ascend/common.h')=='d6355337873e5f7368c3ec7cb1f22ef0494663e133152120fee20265f03a1780','Backend template changed')
        source=ROOT/'source';source.mkdir()
        extract(ROOT/'general-64ed5828-source.zip',source,'7f5ce28f4a494db6353d965083ada7f8e26532042b52ce20832106718abd87de')
        # Git archives omit gitlink contents. Supply the exact frozen submodule source.
        extract(ROOT/'spdlog-source.zip',source/'3rdparty/spdlog','f4f3d720e250a93844723eecc68cddd06925994e7bc48dce305f17e91af625e6')
        require((source/'3rdparty/spdlog/include/spdlog/spdlog.h').is_file(),'Frozen spdlog headers missing')
        shutil.copytree(ROOT/'runner',source/'tools/tilelang_runtime_experiment')
        extract(ROOT/'general-64ed5828-ascendc-profile.zip',ROOT/'exports','d915be8100decfb33c265a9e1d41ff1b8f250b85429325bfc4f352c2b257393c')
        (ROOT/'query.cpp').write_text('#include <acl/acl.h>\n#include <cstdio>\nint main(){if(aclInit(nullptr))return 1;bool good=true;for(unsigned d=0;d<2;++d){int64_t n=0;int e=aclrtGetDeviceInfo(d,ACL_DEV_ATTR_VECTOR_CORE_NUM,&n);printf("%u %d %lld\\n",d,e,(long long)n);good=good&&e==0&&n==64;}return aclFinalize()==0&&good?0:2;}\n')
        run(ROOT,'query-compile',['g++',ROOT/'query.cpp','-I'+str(CANN/'include'),'-L'+str(CANN/'lib64'),'-Wl,-rpath,'+str(CANN/'lib64'),'-lascendcl','-o',ROOT/'query'],30)
        run(ROOT,'query',[ROOT/'query'],30)
        require((ROOT/'query.log').read_text().splitlines()==['0 0 64','1 0 64'],'Actual AIV core counts differ')
        run(ROOT,'toolchain',['bash','-c','command -v g++; g++ --version; cmake --version; command -v bisheng; bisheng --version; uname -m'],30)
        core=ROOT/'core-install'
        run(ROOT,'core-configure',['cmake','-S',source,'-B',ROOT/'core-build','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_FLAGS=-D_GLIBCXX_USE_CXX11_ABI=0','-DCMAKE_INSTALL_PREFIX='+str(core),'-DCMAKE_INSTALL_LIBDIR=lib64','-DBUILD_TESTING=OFF','-DTILEXR_BUILD_TESTS=OFF','-DTILEXR_BUILD_COLLECTIVES=OFF','-DTILEXR_BUILD_EP=OFF','-DTILEXR_BUILD_CHECKER=OFF'],60)
        run(ROOT,'core-build',['cmake','--build',ROOT/'core-build','--verbose','-j4'],240)
        run(ROOT,'core-install',['cmake','--install',ROOT/'core-build'],30)
        install=ROOT/'install'
        run(ROOT,'runner-configure',['cmake','-S',source/'tools/tilelang_runtime_experiment','-B',ROOT/'build','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_INSTALL_PREFIX='+str(install),'-DCMAKE_INSTALL_LIBDIR=lib64','-DTL_CANN_ROOT='+str(CANN),'-DTL_COMM_PREFIX='+str(core),'-DTL_BACKEND_ROOT='+str(ROOT/'deps/backend'),'-DTL_RUNTIME_RAW_DIR='+str(ROOT/'exports/device'),'-DTL_RUNTIME_PROFILE_DIR='+str(ROOT/'exports/profile'),'-DCMAKE_INSTALL_RPATH='+str(core/'lib64')+';'+str(CANN/'lib64')],60)
        run(ROOT,'runner-build',['cmake','--build',ROOT/'build','--verbose','-j4'],240)
        run(ROOT,'runner-install',['cmake','--install',ROOT/'build'],30)
        runner=install/'bin/tilelang_runtime_runner'
        run(ROOT,'runner-ldd',['ldd',runner],15)
        require(b'not found' not in (ROOT/'runner-ldd.log').read_bytes() and b'devlib' not in (ROOT/'runner-ldd.log').read_bytes(),'Bad library resolution')
        raw=list((install/'lib64/tilexr/kernels').glob('*_raw.o'));profile=list((install/'lib64/tilexr/kernels').glob('*_profile.o'))
        require(len(raw)==len(profile)==1,'ELF counts mismatch')
        artifacts=[runner,core/'lib64/libtile-comm.so',*raw,*profile,*list((ROOT/'build').rglob('*_rel.o'))]
        require(len(artifacts)==6,'Expected Host/core/2 linked/2 relocatable artifacts')
        for p in artifacts:
            b=p.read_bytes();require(b[:4]==b'\x7fELF' and b[5]==1,'Invalid ELF')
            if p.suffix=='.o':require(int.from_bytes(b[16:18],'little')==(1 if p.name.endswith('_rel.o') else 2),'Device ELF type')
            else:require(int.from_bytes(b[18:20],'little')==183,'Host aarch64 ELF type')
        hashes={str(p.relative_to(ROOT)):sha(p) for p in artifacts};save(ROOT/'artifact-hashes.json',hashes)
        result.update(status='PASS',cores=[64,64],core_cxx11_abi=0,artifacts=hashes,raw_elf=str(raw[0]),profile_elf=str(profile[0]),runner=str(runner),dependency_zip_sha256=sha(deps),runtime_validation='NOT_RUN',compiled_capacity=json.loads((ROOT/'exports/device/runtime-device.json').read_text())['capacity_limits'],qualification_reused=True)
        result['integrity_after']=integrity()
    except Exception as e:
        result.update(error_type=type(e).__name__,error_detail=str(e)[:350])
    save(ROOT/'build-summary.json',result)
    print(json.dumps(result,separators=(',',':')))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
