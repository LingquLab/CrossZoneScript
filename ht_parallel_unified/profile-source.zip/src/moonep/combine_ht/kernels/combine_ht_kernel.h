/* Copyright (c) 2026 TileXR Project. */
/* Implements local URMA send and gateway reduction for combine_ht.cpp. Send owns
 * one fullmesh queue per gateway; reduction owns its UB and completion slot.
 * The simulator Send loads Host templates, patches their queue word in UB and
 * accesses four-byte GM counters with private MTE read/write buffers.
 * Arithmetic and metadata caching retain the upstream server-dedup contract.
 * Detailed native profiling samples one WQE; reduction drains each token's output.
 * CQ markers retain the sender's asynchronous submission order.
 * The optional test snapshot copies built WQEs from UB before SQ publication.
 * DeepEP-derived portions: Copyright (c) 2026, Lu Lu; see ../LICENSE. */
#ifndef TILEXR_MOONEP_COMBINE_HT_KERNEL_H
#define TILEXR_MOONEP_COMBINE_HT_KERNEL_H

#include "combine_ht_prefill.h"
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
#include "combine_ht_queue_state.h"
#endif
#include "kernel_operator.h"
#include "simt_api/device_functions.h"
#include <tilexr/comm/udma/device/api.h>
#include <tilexr/comm/device/sync.h>
#include <tilexr/ep/inter_server_send_types.h>
#include <tilexr/profiling/device/sst_buffered_writer.h>
using namespace AscendC;
namespace {
using namespace TileXRCombineHT;
constexpr uint32_t kAttachedWaitIterations = 1000000;
__aicore__ inline void Mark(TileXR::Profiling::SstBufferedWriter &writer, uint32_t event)
{
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
    writer.RecordAt(event, GetSystemCycle());
#else
    (void)writer;
    (void)event;
#endif
}
#if defined(TILEXR_COMBINE_HT_SST_FP32) && TILEXR_COMBINE_HT_SST_FP32 == 1
using ReduceRow = float;
#else
using ReduceRow = bfloat16_t;
#endif

struct ReduceView {
    GM_ADDR workspace;
    GM_ADDR input;
    GM_ADDR forward;
    GM_ADDR ranges;
    GM_ADDR masks;
    TileXRCombineHTConfig config;
    TileXRCombineHTLayout layout;
    uint32_t groupSources, totalStages, reducer;
    GM_ADDR partial;
    GM_ADDR sharedReady;
    int64_t readyMagic;
    uint32_t partialRows;
};
struct LocalSendView {
    GM_ADDR workspace;
    GM_ADDR input;
    GM_ADDR backward;
    GM_ADDR ranges;
    GM_ADDR snapshot;
    __gm__ TileXR::UDMAInfo *info;
    __gm__ TileXR::TileXRUDMARegistry *registry;
    TileXRCombineHTConfig config;
    TileXRCombineHTLayout layout;
    uint32_t gateway, peer;
    GM_ADDR prefill;
    uint64_t localOffset;
};
template <typename T>
__aicore__ inline void NativeLoad(LocalTensor<T> ub, __gm__ T* source, uint32_t count)
{
    GlobalTensor<T> gm;
    gm.SetGlobalBuffer(source);
    SetFlag<HardEvent::S_MTE2>(EVENT_ID2);
    WaitFlag<HardEvent::S_MTE2>(EVENT_ID2);
    DataCopyPad(ub, gm, DataCopyExtParams(1, count * sizeof(T), 0, 0, 0), DataCopyPadExtParams<T>{false, 0, 0, 0});
    SetFlag<HardEvent::MTE2_S>(EVENT_ID2);
    WaitFlag<HardEvent::MTE2_S>(EVENT_ID2);
}
template <typename T>
__aicore__ inline void NativeStore(__gm__ T* destination, LocalTensor<T> ub, uint32_t count)
{
    GlobalTensor<T> gm;
    gm.SetGlobalBuffer(destination);
    SetFlag<HardEvent::S_MTE3>(EVENT_ID3);
    WaitFlag<HardEvent::S_MTE3>(EVENT_ID3);
    DataCopyPad(gm, ub, DataCopyExtParams(1, count * sizeof(T), 0, 0, 0));
    SetFlag<HardEvent::MTE3_S>(EVENT_ID3);
    WaitFlag<HardEvent::MTE3_S>(EVENT_ID3);
}

__aicore__ inline void AddBf16(__gm__ bfloat16_t* source_address, uint32_t element_num,
                               LocalTensor<bfloat16_t> bf16_input_ub, LocalTensor<float> fp32_input_ub,
                               LocalTensor<float> fp32_accumulator_ub)
{
    GlobalTensor<bfloat16_t> input_gm;
    input_gm.SetGlobalBuffer(source_address);
    DataCopy(bf16_input_ub, input_gm, element_num);
    SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
    WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
    Cast(fp32_input_ub, bf16_input_ub, RoundMode::CAST_NONE, element_num);
    PipeBarrier<PIPE_V>();
    Add(fp32_accumulator_ub, fp32_accumulator_ub, fp32_input_ub, element_num);
    PipeBarrier<PIPE_V>();
    SetFlag<HardEvent::V_MTE2>(EVENT_ID0);
    WaitFlag<HardEvent::V_MTE2>(EVENT_ID0);
}
// Small shapes retain the full resident table. Large shapes cache eight chunks
// across all sources; page replacement occurs only after all groups consumed it.
__simt_vf__ __aicore__ LAUNCH_BOUND(kBuilderThreads) inline void LoadGatewayPageVf(__ubuf__ int32_t* output, __gm__ int32_t* ranges,
                                                                 __gm__ int32_t* masks, uint32_t world, uint32_t groups,
                                                                 uint32_t chunks, uint32_t page, uint32_t begin,
                                                                 uint32_t mask_offset)
{
    for (uint32_t i = threadIdx.x; i < world * page * kRangeFields; i += kBuilderThreads) {
        const uint32_t chunk = begin + i / kRangeFields % page;
        output[i] = chunk < chunks ? asc_ldcg(ranges + (uint64_t(i / (page * kRangeFields)) * chunks + chunk) * kRangeFields + i % kRangeFields) : 0;
    }
    for (uint32_t i = threadIdx.x; i < groups * page; i += kBuilderThreads) {
        const uint32_t chunk = begin + i % page;
        output[mask_offset + i] = chunk < chunks ? asc_ldcg(masks + i / page * chunks + chunk) : 0;
    }
    asc_threadfence();
}
__aicore__ inline void LoadGatewayControls(LocalTensor<int32_t> controls_ub, GM_ADDR chunk_ranges, GM_ADDR chunk_masks,
                                           const ReduceView& view, uint32_t begin = 0U)
{
    const uint32_t page = ControlChunks(view.config, view.layout);
    if (page == view.layout.chunks) {
        NativeLoad(controls_ub, reinterpret_cast<__gm__ int32_t*>(chunk_ranges), view.config.world * page * kRangeFields);
        NativeLoad(controls_ub[MaskOffset(view.config, view.layout)], reinterpret_cast<__gm__ int32_t*>(chunk_masks),
                   view.totalStages);
    } else {
        SetFlag<HardEvent::S_V>(EVENT_ID2);
        WaitFlag<HardEvent::S_V>(EVENT_ID2);
        Simt::VF_CALL<LoadGatewayPageVf>(Simt::Dim3{kBuilderThreads, 1, 1}, reinterpret_cast<__ubuf__ int32_t*>(controls_ub.GetPhyAddr()),
                                       reinterpret_cast<__gm__ int32_t*>(chunk_ranges),
                                       reinterpret_cast<__gm__ int32_t*>(chunk_masks), view.config.world,
                                       view.config.world / view.groupSources, view.layout.chunks, page, begin,
                                       MaskOffset(view.config, view.layout));
        SetFlag<HardEvent::V_S>(EVENT_ID2);
        WaitFlag<HardEvent::V_S>(EVENT_ID2);
    }
}
// Forward pages are relative to THIS core's task slice, not globally aligned
// 64-row pages. Only a predecessor row and token-tail lookahead may lie outside
// the owned slice. Lookahead loads one row rather than a neighbour core's page.
static_assert(kMetadataWords * sizeof(int32_t) % kUbAlign == 0U, "forward banks must be DMA aligned");
static_assert(kMetadataSlots * kMetadataWords * sizeof(int32_t) <= kScratchBytes,
              "forward metadata must not overwrite resident controls");
static_assert(kLocalRanks * kSlotBytes <= kScratchBytes,
              "gather flag polling must not overwrite resident controls");
struct GatewayTaskCache {
    GlobalTensor<int32_t>& tasks_gm;
    LocalTensor<int32_t> tasks_ub;
    uint64_t begin_word, end_word, chunk_end_word;
    uint64_t page_begin[kMetadataSlots]{};
    uint32_t page_words[kMetadataSlots]{};
    bool load_pending[kMetadataSlots]{};
    uint32_t current_slot = 0;

    __aicore__ inline GatewayTaskCache(GlobalTensor<int32_t>& gm, LocalTensor<int32_t> ub, uint64_t begin, uint64_t end,
                                       uint64_t chunk_end)
        : tasks_gm(gm), tasks_ub(ub), begin_word(begin), end_word(end), chunk_end_word(chunk_end)
    {
    }

    __aicore__ inline bool Contains(uint32_t slot, uint64_t word) const
    {
        return word >= page_begin[slot] && word < page_begin[slot] + page_words[slot];
    }
    __aicore__ inline void Wait(uint32_t slot)
    {
        if (load_pending[slot]) {
            const auto event = slot == 0U ? EVENT_ID4 : EVENT_ID5;
            WaitFlag<HardEvent::MTE2_S>(event);
            load_pending[slot] = false;
        }
    }
    __aicore__ inline void Load(uint32_t slot, uint64_t word)
    {
        // Consume even an unused prefetch before reusing its event and bank.
        Wait(slot);
#if defined(TILEXR_COMBINE_HT_SST_FP32) && TILEXR_COMBINE_HT_SST_FP32 == 1
        // SST reads an aligned page even when a token crosses the worker slice.
        // The full table has a multiple of eight words because world is a multiple of eight.
        constexpr uint64_t wordsPerBlock = kUbAlign / sizeof(int32_t);
        page_begin[slot] = word / kMetadataWords * kMetadataWords;
        const uint64_t end = (chunk_end_word + wordsPerBlock - 1) / wordsPerBlock * wordsPerBlock;
        const uint64_t available = end - page_begin[slot];
        page_words[slot] = available < kMetadataWords ? uint32_t(available) : kMetadataWords;
#else
        if (word >= end_word) {
            page_begin[slot] = word / kForwardFields * kForwardFields;
            page_words[slot] =
                chunk_end_word - page_begin[slot] < kForwardFields ? static_cast<uint32_t>(chunk_end_word - page_begin[slot]) : kForwardFields;
        } else {
            page_begin[slot] = begin_word + (word - begin_word) / kMetadataWords * kMetadataWords;
            page_words[slot] = end_word - page_begin[slot] < kMetadataWords
                                   ? static_cast<uint32_t>(end_word - page_begin[slot])
                                   : kMetadataWords;
        }
#endif
        const auto event = slot == 0U ? EVENT_ID4 : EVENT_ID5;
        // Scalar reads of the old page must finish before MTE2 overwrites it.
        SetFlag<HardEvent::S_MTE2>(event);
        WaitFlag<HardEvent::S_MTE2>(event);
        DataCopyPad(tasks_ub[slot * kMetadataWords], tasks_gm[page_begin[slot]],
                    DataCopyExtParams(1, page_words[slot] * sizeof(int32_t), 0, 0, 0),
                    DataCopyPadExtParams<int32_t>{false, 0, 0, 0});
        SetFlag<HardEvent::MTE2_S>(event);
        load_pending[slot] = true;
    }
    __aicore__ inline uint32_t Select(uint64_t word)
    {
        if (!Contains(current_slot, word)) {
            current_slot ^= 1U;
            if (!Contains(current_slot, word)) {
                Load(current_slot, word);
            }
        }
        return current_slot;
    }
    __aicore__ inline void PrefetchNext(uint64_t word)
    {
        const uint32_t slot = Select(word);
        const uint64_t next_word = page_begin[slot] + page_words[slot];
        // Prefetch only owned rows. Tail lookahead remains a demand-only row
        // load, so small slices never fetch a neighbour core's entire page.
        if (next_word < end_word && !Contains(slot ^ 1U, next_word)) {
            Load(slot ^ 1U, next_word);
        }
    }
    __aicore__ inline int32_t GetValue(uint64_t word)
    {
        const uint32_t slot = Select(word);
        Wait(slot);
        return tasks_ub.GetValue(slot * kMetadataWords + word - page_begin[slot]);
    }
    __aicore__ inline void Finish()
    {
        for (uint32_t slot = 0; slot < kMetadataSlots; ++slot) {
            Wait(slot);
        }
    }
};
template <typename TaskReader>
__aicore__ inline uint32_t AlignTaskToTokenBoundary(TaskReader& tasks, uint64_t source_task_base,
                                                    uint32_t chunk_task_begin, uint32_t task_index)
{
    if (task_index == chunk_task_begin) {
        return task_index;
    }
    // At a boundary the predecessor ends here; inside a run it ends after here.
    return tasks.GetValue((source_task_base + task_index - 1U) * kForwardFields);
}
__aicore__ inline bool ReduceGateway(GM_ADDR workspace, GM_ADDR input, GlobalTensor<int32_t>& forward_list_gm,
                                     LocalTensor<int32_t> chunk_ranges_ub, const ReduceView& view,
                                     uint32_t group_index, uint32_t chunk_index, uint32_t reduce_core_index,
                                     uint32_t reduce_core_num, LocalTensor<ReduceRow> row_input_ub,
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
                                     LocalTensor<float> fp32_input_ub, LocalTensor<ReduceRow> row_output_ub,
#endif
                                     LocalTensor<float> fp32_accumulator_ub, LocalTensor<int32_t> metadata_ub,
                                     TileXR::Profiling::SstBufferedWriter &writer, bool detailed, bool &first_token)
{
    bool validPartialRows = true;
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
    // 槽 A/B 分别使用 EVENT_ID1/2，仅在实际写回后产生 MTE3_V 事件。
    uint32_t output_slot = 0;
    bool output_store_pending[kReduceOutputSlots]{};
#endif
    // Preserve the source group and peer order used by the original forward table.
    for (uint32_t source_index = 0; source_index < view.groupSources; ++source_index) {
        const uint32_t source_rank_id = SourcePeer(view.config, group_index, source_index);
        const uint32_t page = ControlChunks(view.config, view.layout);
        const uint64_t range_index = (uint64_t(source_rank_id) * page + chunk_index % page) * kRangeFields;
        const uint32_t chunk_task_begin = chunk_ranges_ub.GetValue(range_index);
        const uint32_t chunk_task_end = chunk_ranges_ub.GetValue(range_index + 1U);
        const uint32_t task_num = chunk_task_end - chunk_task_begin;
        const uint64_t source_task_base = uint64_t(source_rank_id) * view.layout.forward_capacity;
        // Rotate the statically sliced partition across source ranks. This
        // keeps the existing disjoint ranges and token-boundary handling, but
        // spreads the q/q+1 slices caused by integer division over all reduce
        // cores instead of assigning the same remainder pattern to each one.
        const uint32_t partition_index = (reduce_core_index + source_index) % reduce_core_num;
        uint32_t task_index = chunk_task_begin + uint64_t(task_num) * partition_index / reduce_core_num;
        const uint32_t worker_task_end =
            chunk_task_begin + uint64_t(task_num) * (partition_index + 1U) / reduce_core_num;
        if (task_index == worker_task_end) {
            continue;
        }
        const uint32_t metadata_begin = task_index > chunk_task_begin ? task_index - 1U : task_index;
        GatewayTaskCache tasks{forward_list_gm, metadata_ub, (source_task_base + metadata_begin) * kForwardFields,
                               (source_task_base + worker_task_end) * kForwardFields, (source_task_base + chunk_task_end) * kForwardFields};
        // 仅当 token 的首条任务落在本核原始分工区间内时，才由本核负责该 token。
        task_index = AlignTaskToTokenBoundary(tasks, source_task_base, chunk_task_begin, task_index);
        while (task_index < worker_task_end) {
            const uint32_t token_task_end = tasks.GetValue((source_task_base + task_index) * kForwardFields);
            const int32_t first_contributor_rank = tasks.GetValue((source_task_base + task_index) * kForwardFields + kContributor);
            // The stage's gather dependency has completed before this token is
            // selected. DIRECT tokens are ready too, but require no reduction.
            if (first_token) {
                Mark(writer, FirstTokenReady);
                first_token = false;
            }
            Mark(writer, TokenReady);
            if (first_contributor_rank < 0) {
                // Direct-only tokens have no vector work; overlap the next
                // page load with subsequent scalar token processing instead.
                tasks.PrefetchNext((source_task_base + task_index) * kForwardFields);
                Mark(writer, TokenReduced);
                task_index = token_task_end;
                continue;
            }
            const uint32_t primary_row = tasks.GetValue((source_task_base + task_index) * kForwardFields + kPrimaryRow);
            if (view.sharedReady && (primary_row >= view.partialRows || primary_row >= view.config.input_rows)) {
                validPartialRows = false;
                task_index = token_task_end;
                continue;
            }
            Mark(writer, Tokens);
            for (uint32_t hidden_offset = 0; hidden_offset < view.config.hidden; hidden_offset += kReduceTileElements) {
                const uint32_t element_num = view.config.hidden - hidden_offset < kReduceTileElements
                                                 ? view.config.hidden - hidden_offset
                                                 : kReduceTileElements;
#if defined(TILEXR_COMBINE_HT_SST_FP32) && TILEXR_COMBINE_HT_SST_FP32 == 1
                Duplicate(fp32_accumulator_ub, 0.0F, element_num);
                PipeBarrier<PIPE_V>();
                for (uint32_t part = task_index; part <= token_task_end; ++part) {
                    GM_ADDR region = input;
                    uint32_t row = primary_row;
                    if (part != task_index) {
                        const uint32_t index = part - 1;
                        const uint64_t entry = (source_task_base + index) * kForwardFields;
                        const bool local = uint32_t(tasks.GetValue(entry + kContributor)) == view.config.rank;
                        row = tasks.GetValue(entry + (local ? kInputRow : kGatherRow));
                        region = local ? input : workspace + view.layout.gather_offset;
                        if (!hidden_offset) Mark(writer, Contributions);
                    }
                    GlobalTensor<float> gm;
                    gm.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(region) +
                        uint64_t(row) * view.config.hidden + hidden_offset);
                    gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
                    DataCopy(row_input_ub, gm, element_num);
                    SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
                    WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
                    Add(fp32_accumulator_ub, fp32_accumulator_ub, row_input_ub, element_num);
                    SetFlag<HardEvent::V_MTE2>(EVENT_ID0);
                    WaitFlag<HardEvent::V_MTE2>(EVENT_ID0);
                }
                GlobalTensor<float> output;
                output.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(view.partial) +
                    uint64_t(primary_row) * view.config.hidden + hidden_offset);
                SetFlag<HardEvent::V_MTE3>(EVENT_ID1);
                WaitFlag<HardEvent::V_MTE3>(EVENT_ID1);
                DataCopy(output, fp32_accumulator_ub, element_num);
                SetFlag<HardEvent::MTE3_V>(EVENT_ID1);
                WaitFlag<HardEvent::MTE3_V>(EVENT_ID1);
#else
                // 首份贡献直接初始化累加器，省去清零和首次加法。
                GlobalTensor<bfloat16_t> primary_input_gm;
                primary_input_gm.SetGlobalBuffer(reinterpret_cast<__gm__ bfloat16_t*>(input) +
                                                 uint64_t(primary_row) * view.config.hidden + hidden_offset);
                DataCopy(row_input_ub, primary_input_gm, element_num);
                SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
                WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
                Cast(fp32_accumulator_ub, row_input_ub, RoundMode::CAST_NONE, element_num);
                // Enqueue metadata AFTER this token's first payload DMA, so
                // the prefetch can overlap its Cast rather than delaying the
                // payload at the head of the shared MTE2 queue. Keep both
                // banks through contributor scans and hidden-tile replays.
                if (!hidden_offset) {
                    tasks.PrefetchNext((source_task_base + task_index) * kForwardFields);
                }
                PipeBarrier<PIPE_V>();
                SetFlag<HardEvent::V_MTE2>(EVENT_ID0);
                WaitFlag<HardEvent::V_MTE2>(EVENT_ID0);
                for (uint32_t contributor_task_index = task_index; contributor_task_index < token_task_end;
                     ++contributor_task_index) {
                    // Reuse classification across hidden tiles; reduced runs contain only secondary rows.
                    const int32_t contributor_rank =
                        contributor_task_index == task_index
                            ? first_contributor_rank
                            : tasks.GetValue((source_task_base + contributor_task_index) * kForwardFields + kContributor);

                    const bool is_local_contribution = uint32_t(contributor_rank) == view.config.rank;
                    if (!hidden_offset) Mark(writer, Contributions);
                    const uint32_t contributor_row = tasks.GetValue((source_task_base + contributor_task_index) * kForwardFields +
                                                                    (is_local_contribution ? kInputRow : kGatherRow));
                    AddBf16(reinterpret_cast<__gm__ bfloat16_t*>(
                                (is_local_contribution ? input : workspace + view.layout.gather_offset)) +
                                uint64_t(contributor_row) * view.config.hidden + hidden_offset,
                            element_num, row_input_ub, fp32_input_ub, fp32_accumulator_ub);
                }
                // server 内先用 FP32 完成累加，再将 partial 舍入为 BF16 后写回并发送。
                // 只等待即将复用的槽，另一个槽可继续写回；按实际 token/tile 写出次数轮转。
                const auto output_event_id = output_slot == 0U ? EVENT_ID1 : EVENT_ID2;
                auto bf16_output_slot_ub = row_output_ub[output_slot * kReduceTileElements];
                if (output_store_pending[output_slot]) {
                    WaitFlag<HardEvent::MTE3_V>(output_event_id);
                    output_store_pending[output_slot] = false;
                }
                Cast(bf16_output_slot_ub, fp32_accumulator_ub, RoundMode::CAST_RINT, element_num);
                // 当前 Cast 读完累加器后，下一条 token/tile 才能重新初始化它。
                PipeBarrier<PIPE_V>();
                GlobalTensor<bfloat16_t> partial_output_gm;
                partial_output_gm.SetGlobalBuffer(
                    reinterpret_cast<__gm__ bfloat16_t*>(view.partial) +
                    uint64_t(primary_row) * view.config.hidden + hidden_offset);
                SetFlag<HardEvent::V_MTE3>(output_event_id);
                WaitFlag<HardEvent::V_MTE3>(output_event_id);
                DataCopy(partial_output_gm, bf16_output_slot_ub, element_num);
                SetFlag<HardEvent::MTE3_V>(output_event_id);
                output_store_pending[output_slot] = true;
                output_slot ^= 1U;
#endif
            }
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
            if (detailed) {
                // DataCopy only issues MTE3. Timestamp completion after the
                // final hidden tile reaches partial GM, including both banks.
                SetFlag<HardEvent::MTE3_S>(EVENT_ID3);
                WaitFlag<HardEvent::MTE3_S>(EVENT_ID3);
            }
#endif
            Mark(writer, TokenReduced);
            task_index = token_task_end;
        }
        // A skipped/direct-only token may leave a prefetch unread. Drain it
        // before the next source or chunk reuses metadata UB/event IDs 4/5.
        tasks.Finish();
    }
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
    // 返回后会发布本 chunk 的 reduce_done；两个输出槽都必须排空。
    // 空任务核、只写出一条的核，不等待未产生的事件。
    for (uint32_t slot = 0; slot < kReduceOutputSlots; ++slot) {
        if (output_store_pending[slot]) {
            const auto output_event_id = slot == 0U ? EVENT_ID1 : EVENT_ID2;
            WaitFlag<HardEvent::MTE3_V>(output_event_id);
        }
    }
#endif
    return validPartialRows;
}

__aicore__ inline bool WaitGatherDone(const ReduceView &view, uint32_t stage, uint32_t mask,
    LocalTensor<uint64_t> snapshot)
{
    if (!mask) return true;
    constexpr uint32_t words = kSlotBytes / sizeof(uint64_t);
    GlobalTensor<uint64_t> flags;
    flags.SetGlobalBuffer(reinterpret_cast<__gm__ uint64_t *>(view.workspace +
        uint64_t(GatherSlot(view.config, stage, 0)) * kSlotBytes));
    flags.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
    uint32_t attempts = 0;
    while (!view.sharedReady || attempts++ < kAttachedWaitIterations) {
        SetFlag<HardEvent::S_MTE2>(EVENT_ID2);
        WaitFlag<HardEvent::S_MTE2>(EVENT_ID2);
        DataCopy(snapshot, flags, kLocalRanks * words);
        SetFlag<HardEvent::MTE2_S>(EVENT_ID2);
        WaitFlag<HardEvent::MTE2_S>(EVENT_ID2);
#if defined(TILEXR_COMBINE_HT_SST_FP32) && TILEXR_COMBINE_HT_SST_FP32 == 1
        uint32_t pending = 0;
#pragma unroll
        for (uint32_t local = 0; local < kLocalRanks; ++local) {
            if ((mask & (1U << local)) && snapshot.GetValue(local * words) == 0) pending |= 1U << local;
        }
        if (!pending) return true;
#else
        bool ready = true;
#pragma unroll
        for (uint32_t local = 0; local < kLocalRanks; ++local) {
            ready = (!(mask & (1U << local)) || snapshot.GetValue(local * words) != 0) && ready;
        }
        if (ready) return true;
#endif
    }
    return false;
}

struct GatewayReduce {
    __aicore__ inline static uint32_t Run(const ReduceView &view, TileXR::Profiling::SstBufferedWriter &writer, bool detailed)
    {
        bool first_token = true;
        TPipe pipe;
        TBuf<QuePosition::VECCALC> input, accumulator, controls, signal;
        pipe.InitBuffer(input, kReduceTileElements * sizeof(ReduceRow));
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
        TBuf<QuePosition::VECCALC> cast, output;
        pipe.InitBuffer(cast, kReduceTileElements * sizeof(float));
#endif
        pipe.InitBuffer(accumulator, kReduceTileElements * sizeof(float));
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
        pipe.InitBuffer(output, kReduceOutputSlots * kReduceTileElements * sizeof(ReduceRow));
#endif
        pipe.InitBuffer(controls, kScratchBytes + kControlBytes);
        pipe.InitBuffer(signal, kUbAlign);
        writer.Bind(pipe);
        Mark(writer, ReduceBegin);
        auto metadata = controls.Get<int32_t>();
        auto resident = metadata[kScratchBytes / sizeof(int32_t)];
        GlobalTensor<int32_t> forward;
        forward.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(view.forward));
        const uint32_t page = ControlChunks(view.config, view.layout);
        LoadGatewayControls(resident, view.ranges, view.masks, view);
        auto *progress = reinterpret_cast<__gm__ int32_t *>(view.workspace +
            uint64_t(ReduceSlot(view.config, view.layout, view.reducer)) * kSlotBytes);
        for (uint32_t chunk = 0; chunk < view.layout.chunks; ++chunk) {
            if (chunk && chunk % page == 0) LoadGatewayControls(resident, view.ranges, view.masks, view, chunk);
            for (uint32_t group = 0; group < view.layout.groups; ++group) {
                const uint32_t stage = group * view.layout.chunks + chunk;
                const uint32_t mask = view.config.wait_policy == TILEXR_COMBINE_HT_ALL_LOCAL ?
                    ((1U << kLocalRanks) - 1) & ~(1U << (view.config.rank % kLocalRanks)) :
                    resident.GetValue(MaskOffset(view.config, view.layout) + group * page + chunk % page);
                Mark(writer, StageBegin);
                if (!WaitGatherDone(view, stage, mask, controls.Get<uint64_t>())) {
                    return TILEXR_COMBINE_HT_GATHER_TIMEOUT;
                }
                Mark(writer, StageReady);
                const bool valid = ReduceGateway(view.workspace, view.input, forward, resident, view, group, chunk,
                    view.reducer, view.config.reduce_core_count, input.Get<ReduceRow>(),
#if !defined(TILEXR_COMBINE_HT_SST_FP32) || TILEXR_COMBINE_HT_SST_FP32 != 1
                    cast.Get<float>(), output.Get<ReduceRow>(),
#endif
                    accumulator.Get<float>(), metadata, writer, detailed, first_token);
                if (!valid) {
                    return TILEXR_COMBINE_HT_INVALID_PARTIAL_ROW;
                }
                // ReduceGateway drains both output slots before publishing the
                // original chunk-major monotonic progress, even on empty cores.
                SetFlag<HardEvent::MTE3_S>(EVENT_ID3);
                WaitFlag<HardEvent::MTE3_S>(EVENT_ID3);
                const int32_t epoch = static_cast<int32_t>(TileXREpHt::ReduceEpoch(chunk, group, view.layout.groups));
                writer.Mark(4200, chunk);
                if (view.sharedReady) {
                    // Publish the round and epoch together in the shared slot.
                    auto value = signal.Get<uint64_t>();
                    value.SetValue(0, static_cast<uint64_t>(view.readyMagic));
                    auto fields = value.ReinterpretCast<int32_t>();
                    fields.SetValue(offsetof(TileXREpHt::ReadyValue, epoch) / sizeof(int32_t), epoch);
                    fields.SetValue(offsetof(TileXREpHt::ReadyValue, reserved) / sizeof(int32_t), 0);
                    auto *slot = reinterpret_cast<__gm__ uint64_t *>(
                        view.sharedReady + uint64_t(view.reducer) * TileXREpHt::kSlotBytes);
                    NativeStore(slot, value, sizeof(TileXREpHt::ReadyValue) / sizeof(uint64_t));
                } else {
                    auto value = signal.Get<int32_t>();
                    value.SetValue(0, epoch);
                    NativeStore(progress, value, 1);
                }
                writer.Mark(4201, chunk);
                Mark(writer, WorkEnd);
            }
        }
        return 0;
    }
};

constexpr uint32_t kWqeBytes = TileXR::TILEXR_UDMA_WQE_BB_BYTES;

#if !defined(TILEXR_COMBINE_HT_SIM_SEND) || TILEXR_COMBINE_HT_SIM_SEND != 1
constexpr uint32_t kWqeWords = kWqeBytes / sizeof(uint64_t);

// Reuse the LocalPutBatch 128-row quantum, caching the immutable peer header
// once. SIMT builds all payload descriptors from the existing UB backward page;
// no per-row scalar descriptor preparation or GM WQE stores are needed.
template <bool Signal>
__simt_vf__ __aicore__ LAUNCH_BOUND(kBuilderThreads) inline void BuildPutWqesVf(
    __ubuf__ uint64_t *output, __ubuf__ const uint64_t *header,
    __ubuf__ const int64_t *records, uint32_t count, uint32_t head,
    uint64_t input, uint64_t remote, uint32_t bytes,
    uint32_t row_begin, uint32_t row_end)
{
    const uint32_t row = row_begin + threadIdx.x;
    if (row >= count || row >= row_end) return;
    __ubuf__ uint64_t *wqe = output + uint64_t(row) * kWqeWords;
#pragma unroll
    for (uint32_t word = 0; word < kWqeWords; ++word) wqe[word] = header[word];
    auto *sqe = reinterpret_cast<__ubuf__ TileXR::UDMASqeCtx *>(wqe);
    const uint32_t absolute = head + row;
    sqe->sqeBbIdx = absolute % TileXR::TILEXR_UDMA_SQ_BB_COUNT;
    sqe->owner = (absolute & TileXR::TILEXR_UDMA_SQ_BB_COUNT) == 0;
    sqe->flag = row + 1 == count ? TileXR::TILEXR_UDMA_SQE_FLAG_COMPLETION : 0;
    uint64_t src = input, dst = remote;
    if constexpr (Signal) {
        sqe->flag = TileXR::TILEXR_UDMA_SQE_FLAG_ORDERED_COMPLETION;
    } else {
        src += uint64_t(records[row * kBackwardFields + kSendRow]) * bytes;
        dst += uint64_t(uint32_t(uint64_t(records[row * kBackwardFields + kPackedRow]))) * bytes;
    }
    sqe->rmtAddrLOrTokenId = uint32_t(dst);
    sqe->rmtAddrHOrTokenValue = dst >> kPackedShift;
    auto *sge = reinterpret_cast<__ubuf__ TileXR::UDMASgeCtx *>(
        reinterpret_cast<__ubuf__ uint8_t *>(wqe) + sizeof(TileXR::UDMASqeCtx));
    sge->va = src;
    sge->len = bytes;
}

template <bool Signal, bool Sample = false>
__aicore__ inline void BuildPutWqes(LocalTensor<uint8_t> wqes, LocalTensor<uint8_t> header,
    LocalTensor<int64_t> records, uint32_t count, uint32_t head,
    uint64_t input, uint64_t remote, uint32_t bytes, uint32_t rowBegin, uint32_t rowEnd)
{
    Simt::VF_CALL<BuildPutWqesVf<Signal>>(
        Simt::Dim3{Sample ? 1U : kBuilderThreads, 1, 1},
        reinterpret_cast<__ubuf__ uint64_t *>(wqes.GetPhyAddr()),
        reinterpret_cast<__ubuf__ uint64_t *>(header.GetPhyAddr()),
        reinterpret_cast<__ubuf__ int64_t *>(records.GetPhyAddr()),
        count, head, input, remote, bytes, rowBegin, rowEnd);
}
#endif

#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
using LocalQueueState = TileXRCombineHT::MteQueueState;
#else
using LocalQueueState = TileXR::UDMADeviceQueueState;
#endif

struct LocalPutBatch {
    __gm__ TileXR::UDMAInfo *info;
    __gm__ TileXR::UDMAWQCtx *sq;
    LocalTensor<uint8_t> wqes, header;
    GM_ADDR snapshot;
    uint32_t peer, qp, head, completions;
    TileXR::Profiling::SstBufferedWriter &writer;
    bool detailed;
    LocalQueueState &state;
    // entryIdx identifies the final BB of the completed batch. Its event pair
    // cannot be reused while that SQ entry is outstanding, including SQ wrap.
    __aicore__ inline void Completed(uint32_t tail)
    {
        Mark(writer, CqReceivedBase + 2 * ((tail - 1) % TileXR::TILEXR_UDMA_SQ_BB_COUNT));
    }
    __aicore__ inline uint32_t Quiet()
    {
        return TileXR::UDMAPollCQUntilSqTail(info, peer, qp, head, *this, state);
    }
    template <bool Signal>
    __aicore__ inline uint32_t Flush(LocalTensor<int64_t> records, uint32_t count,
        uint64_t input, uint64_t remote, uint32_t bytes, uint64_t snapshotRow, GM_ADDR templates = nullptr)
    {
        const uint32_t tail = state.Load(sq->tailAddr);
        if (head - tail + count >= sq->depth) {
            const uint32_t status = Quiet();
            if (status != TileXR::TILEXR_UDMA_STATUS_SUCCESS) return status;
        }
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
        (void)records; (void)input; (void)remote; (void)bytes;
        GlobalTensor<uint8_t> source;
        source.SetGlobalBuffer(templates);
        Mark(writer, PrefillLoadBegin);
        DataCopy(wqes, source, count * kWqeBytes);
        SetFlag<HardEvent::MTE2_S>(EVENT_ID0);
        WaitFlag<HardEvent::MTE2_S>(EVENT_ID0);
        Mark(writer, PrefillLoadEnd);
        Mark(writer, PrefillPatchBegin);
        auto words = wqes.ReinterpretCast<uint32_t>();
        for (uint32_t row = 0; row < count; ++row) {
            const uint32_t flag = Signal ? TileXR::TILEXR_UDMA_SQE_FLAG_ORDERED_COMPLETION :
                TileXR::TILEXR_UDMA_SQE_FLAG_COMPLETION;
            const uint32_t word = row * (kWqeBytes / sizeof(uint32_t));
            words.SetValue(word, PrefillQueueWord(words.GetValue(word), head + row, flag));
        }
        Mark(writer, PrefillPatchEnd);
#else
        (void)templates;
        SetFlag<HardEvent::S_V>(EVENT_ID0);
        WaitFlag<HardEvent::S_V>(EVENT_ID0);
        Mark(writer, WqeBuildBegin);
        uint32_t row_begin = 0;
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
        if (detailed) {
            // Build the real first descriptor once, retaining the original
            // count for the tail completion flag. Native sampling includes
            // the VF launch and V->S synchronization.
            Mark(writer, SingleWqeBegin);
            BuildPutWqes<Signal, true>(wqes, header, records, count, head, input, remote, bytes, 0, 1);
            SetFlag<HardEvent::V_S>(EVENT_ID0);
            WaitFlag<HardEvent::V_S>(EVENT_ID0);
            Mark(writer, SingleWqeEnd);
            row_begin = 1;
        }
#endif
        if (row_begin < count) {
            BuildPutWqes<Signal>(wqes, header, records, count, head, input, remote, bytes, row_begin, count);
        }
        SetFlag<HardEvent::V_MTE3>(EVENT_ID0);
        WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
        if (detailed) {
            SetFlag<HardEvent::V_S>(EVENT_ID0);
            WaitFlag<HardEvent::V_S>(EVENT_ID0);
        }
#endif
        Mark(writer, WqeBuildEnd);
#endif
        // Existing TileXR MTE3 publication handles the SQ wrap in two DMAs.
        Mark(writer, SqSubmitBegin);
        if (snapshot) {
            // The existing MTE3 completion in UDMAPublishWqe drains both copies.
            TileXR::UDMAMte3CopyToSq(wqes, 0U, snapshot + snapshotRow * kWqeBytes, count * kWqeBytes);
        }
        TileXR::UDMAPublishWqe(wqes, sq, head, count);
        head += count;
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
        completions += count;
#else
        ++completions;
#endif
        state.Store(sq->headAddr, head);
        state.Store(sq->wqeCntAddr, completions);
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
        const uint64_t doorbell_cycle = GetSystemCycle();
#endif
        TileXR::UDMARingDoorbell(head, sq);
#if defined(TILEXR_ENABLE_PROFILING) && TILEXR_ENABLE_PROFILING == 1
        writer.RecordAt(DoorbellBeginBase + 2 * ((head - 1) % TileXR::TILEXR_UDMA_SQ_BB_COUNT), doorbell_cycle);
#endif
        Mark(writer, SqSubmitEnd);
        return TileXR::TILEXR_UDMA_STATUS_SUCCESS;
    }
};

struct LocalUrmaSend {
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
    __aicore__ inline static uint32_t RunPrefilled(const LocalSendView &view,
        TileXR::Profiling::SstBufferedWriter &writer, bool detailed)
    {
        TPipe pipe;
        TBuf<QuePosition::VECCALC> wqes, directory, stateRead, stateWrite;
        pipe.InitBuffer(wqes, kBatchRows * kWqeBytes);
        pipe.InitBuffer(directory, sizeof(PrefillStage));
        pipe.InitBuffer(stateRead, 64);
        pipe.InitBuffer(stateWrite, 64);
        writer.Bind(pipe);
        LocalQueueState state(stateRead.Get<uint32_t>(), stateWrite.Get<uint32_t>());
        auto *sq = TileXR::UDMAGetWQCtx(view.info, view.peer, view.gateway);
        const uint32_t head = state.Load(sq->headAddr);
        GM_ADDR snapshot = view.snapshot ? view.snapshot + uint64_t(view.gateway) *
            PrefillSnapshotRowsPerGateway(view.config, view.layout) * kWqeBytes : nullptr;
        LocalPutBatch batch{view.info, sq, wqes.Get<uint8_t>(), wqes.Get<uint8_t>(), snapshot,
            view.peer, view.gateway, head,
            state.Load(sq->wqeCntAddr), writer, detailed, state};
        const uint64_t stages = uint64_t(view.layout.groups) * view.layout.chunks;
        uint64_t payloadRow = 0;
        bool issued = false;
        for (uint32_t chunk = 0; chunk < view.layout.chunks; ++chunk) {
            Mark(writer, ChunkSendBegin);
            for (uint32_t group = 0; group < view.layout.groups; ++group) {
                const uint64_t stage = uint64_t(group) * view.layout.chunks + chunk;
                NativeLoad(directory.Get<uint64_t>(), reinterpret_cast<__gm__ uint64_t *>(view.prefill + kPrefillAlign +
                    (uint64_t(view.gateway) * stages + stage) * sizeof(PrefillStage)), sizeof(PrefillStage) / sizeof(uint64_t));
                const auto fields = directory.Get<uint64_t>();
                const uint64_t payload = fields.GetValue(0), count = fields.GetValue(1), signal = fields.GetValue(2);
                Mark(writer, StageBegin);
                for (uint64_t offset = 0; offset < count; offset += kBatchRows) {
                    const uint32_t batchCount = count - offset < kBatchRows ? uint32_t(count - offset) : kBatchRows;
                    const uint32_t status = batch.Flush<false>(LocalTensor<int64_t>{}, batchCount, 0, 0, 0,
                        payloadRow + offset, view.prefill + payload + offset * kWqeBytes);
                    if (status) return status;
                    issued = true;
                    Mark(writer, Batches);
                }
                payloadRow += count;
                Mark(writer, WorkEnd);
                if (fields.GetValue(3) != 0) {
                    const uint64_t signalRow = PrefillSnapshotRowsPerGateway(view.config, view.layout) - stages + stage;
                    const uint32_t status = batch.Flush<true>(LocalTensor<int64_t>{}, 1, 0, 0, 0,
                        signalRow, view.prefill + signal);
                    if (status) return status;
                    issued = true;
                    Mark(writer, SoSubmit);
                }
            }
            Mark(writer, ChunkSendEnd);
        }
        if (!issued) return TileXR::TILEXR_UDMA_STATUS_SUCCESS;
        Mark(writer, QuietBegin);
        const uint32_t status = batch.Quiet();
        Mark(writer, QuietEnd);
        return status;
    }
#endif
    __aicore__ inline static uint32_t Run(const LocalSendView &view, TileXR::Profiling::SstBufferedWriter &writer, bool detailed)
    {
        if (view.gateway == view.config.rank % kLocalRanks) return TileXR::TILEXR_UDMA_STATUS_SUCCESS;
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
        return RunPrefilled(view, writer, detailed);
#else
        const uint32_t peer = view.peer;
        TPipe pipe;
        TBuf<QuePosition::VECCALC> wqes, header, metadata, ranges;
        pipe.InitBuffer(wqes, kBatchRows * kWqeBytes);
        pipe.InitBuffer(header, kWqeBytes);
        pipe.InitBuffer(metadata, kBatchRows * kBackwardFields * sizeof(int64_t));
        // Ranges are paged by chunk together with the metadata batch; no UB
        // allocation grows with arbitrary token/chunk counts.
        pipe.InitBuffer(ranges, kUbAlign);
        LocalQueueState state;
        auto *sq = TileXR::UDMAGetWQCtx(view.info, peer, view.gateway);
        const uint32_t head = state.Load(sq->headAddr);
        GM_ADDR snapshot = view.snapshot ?
            view.snapshot + view.gateway * SnapshotRowsPerGateway(view.layout) * kWqeBytes : nullptr;
        LocalPutBatch batch{view.info, sq, wqes.Get<uint8_t>(), header.Get<uint8_t>(), snapshot, peer, view.gateway, head,
            state.Load(sq->wqeCntAddr), writer, detailed, state};
        auto *base = reinterpret_cast<__gm__ uint8_t *>(view.registry->regions[peer].base) + view.localOffset;
        auto *headerPtr = reinterpret_cast<__ubuf__ TileXR::UDMASqeCtx *>(batch.header.GetPhyAddr());
        Duplicate(header.Get<uint32_t>(), uint32_t(0), kWqeBytes / sizeof(uint32_t));
        SetFlag<HardEvent::V_S>(EVENT_ID0);
        WaitFlag<HardEvent::V_S>(EVENT_ID0);
        TileXR::UDMAFillSqeCtx<TileXR::UDMAOpcode::WRITE>(headerPtr, base,
            TileXR::UDMAGetRemoteMemInfo(view.info, peer, view.gateway), head, 0);
        TileXR::UDMAFillSgeCtx(reinterpret_cast<__ubuf__ TileXR::UDMASgeCtx *>(
            batch.header.GetPhyAddr() + sizeof(TileXR::UDMASqeCtx)), 0, nullptr, 0);
        const uint64_t recordBase = uint64_t(view.gateway) * view.layout.backward_capacity * kBackwardFields;
        const uint32_t stages = view.layout.groups * view.layout.chunks;
        uint32_t status = 0;
        bool issued = false;
        for (uint32_t chunk = 0; chunk < view.layout.chunks; ++chunk) {
            Mark(writer, ChunkSendBegin);
            for (uint32_t group = 0; group < view.layout.groups; ++group) {
                const uint32_t stage = group * view.layout.chunks + chunk;
                const uint64_t range = (uint64_t(view.gateway) * stages + stage) * kRangeFields;
                NativeLoad(ranges.Get<int32_t>(), reinterpret_cast<__gm__ int32_t *>(view.ranges) + range, kRangeFields);
                const uint32_t begin = ranges.Get<int32_t>().GetValue(0), end = ranges.Get<int32_t>().GetValue(1);
                Mark(writer, StageBegin);
                for (uint32_t offset = begin; offset < end; offset += kBatchRows) {
                    const uint32_t count = end - offset < kBatchRows ? end - offset : kBatchRows;
                    NativeLoad(metadata.Get<int64_t>(), reinterpret_cast<__gm__ int64_t *>(view.backward) +
                        recordBase + uint64_t(offset) * kBackwardFields, count * kBackwardFields);
                    status = batch.Flush<false>(metadata.Get<int64_t>(), count, reinterpret_cast<uint64_t>(view.input),
                        reinterpret_cast<uint64_t>(base) + view.layout.gather_offset, view.config.hidden * kBf16Bytes, offset);
                    if (status) return status;
                    issued = true;
                    Mark(writer, Batches);
                }
                Mark(writer, WorkEnd);
                if (begin != end || view.config.wait_policy == TILEXR_COMBINE_HT_ALL_LOCAL) {
                    const uint64_t source = reinterpret_cast<uint64_t>(view.workspace) +
                        uint64_t(kControlWorlds * view.config.world + view.gateway) * kSlotBytes;
                    const uint64_t destination = reinterpret_cast<uint64_t>(base) +
                        uint64_t(GatherSlot(view.config, stage, view.config.rank % kLocalRanks)) * kSlotBytes;
                    status = batch.Flush<true>(metadata.Get<int64_t>(), 1, source, destination, sizeof(uint64_t),
                        uint64_t(view.layout.backward_capacity) + stage);
                    if (status) return status;
                    issued = true;
                    Mark(writer, SoSubmit);
                }
            }
            Mark(writer, ChunkSendEnd);
        }
        if (issued) {
            Mark(writer, QuietBegin);
            status = batch.Quiet();
            Mark(writer, QuietEnd);
        }
        return status;
#endif
    }
};

__simt_vf__ __aicore__ LAUNCH_BOUND(kBuilderThreads) inline void PrepareControlsVf(
    __gm__ uint64_t *workspace, uint32_t slots, uint32_t sourceBegin, uint32_t core)
{
    constexpr uint32_t words = kSlotBytes / sizeof(uint64_t);
    for (uint32_t slot = core * kBuilderThreads + threadIdx.x; slot < slots; slot += kCores * kBuilderThreads) {
        asc_stcg(workspace + uint64_t(slot) * words, uint64_t(slot >= sourceBegin && slot < sourceBegin + kCores));
    }
    asc_threadfence();
}

__aicore__ inline __gm__ uint64_t *AttachedEntryFlag(const TileXRCombineHT::KernelArgs &args)
{
    return reinterpret_cast<__gm__ uint64_t *>(
        args.workspace + uint64_t(ReduceSlot(args.config, args.layout, 0)) * kSlotBytes);
}

__aicore__ inline void PublishAttachedStatus(GM_ADDR status, uint32_t core, uint32_t value)
{
    TPipe pipe;
    TBuf<QuePosition::VECCALC> buffer;
    pipe.InitBuffer(buffer, kUbAlign);
    auto local = buffer.Get<uint32_t>();
    local.SetValue(0, value);
    NativeStore(reinterpret_cast<__gm__ uint32_t *>(status) + core, local, 1);
}

__aicore__ inline bool AttachedEntryReady(const TileXRCombineHT::KernelArgs &args, int64_t magic)
{
    TPipe pipe;
    TBuf<QuePosition::VECCALC> buffer;
    pipe.InitBuffer(buffer, kUbAlign);
    auto value = buffer.Get<uint64_t>();
    NativeLoad(value, AttachedEntryFlag(args), 1);
    return value.GetValue(0) == static_cast<uint64_t>(magic);
}

__aicore__ inline void RunCombineHT(const TileXRCombineHT::KernelArgs &args, uint64_t localOffset = 0,
    GM_ADDR partial = nullptr, GM_ADDR sharedReady = nullptr, int64_t readyMagic = 0, uint32_t partialRows = 0,
    bool requireBarrier = false)
{
    using namespace TileXRCombineHT;
    const uint32_t core = GetBlockIdx();
    const bool send = (args.config.run_mask & TILEXR_COMBINE_HT_SEND_ONLY) && core < kLocalRanks;
    const bool reduce = (args.config.run_mask & TILEXR_COMBINE_HT_REDUCE_ONLY) &&
        core >= args.config.reduce_core_begin && core - args.config.reduce_core_begin < args.config.reduce_core_count;
    if (requireBarrier && (send || reduce) && !AttachedEntryReady(args, readyMagic)) {
        PublishAttachedStatus(args.status, core, TILEXR_COMBINE_HT_LOCAL_BARRIER_TIMEOUT);
        return;
    }
    TileXR::Profiling::SstBufferedWriter writer;
    writer.Initialize(args.profiling, core);
    Mark(writer, Begin);
    if (send) {
        LocalSendView view{args.workspace, args.input, args.backward, args.backward_ranges, args.wqe_snapshot,
            reinterpret_cast<__gm__ TileXR::UDMAInfo *>(args.fullmesh_info),
            reinterpret_cast<__gm__ TileXR::TileXRUDMARegistry *>(args.registry), args.config, args.layout,
            core, args.comm_peer_begin + core, args.prefill, localOffset};
        const uint32_t status = LocalUrmaSend::Run(view, writer, args.profiling != nullptr);
#if defined(TILEXR_COMBINE_HT_SIM_SEND) && TILEXR_COMBINE_HT_SIM_SEND == 1
        TPipe pipe;
        TBuf<QuePosition::VECCALC> statusBuffer;
        pipe.InitBuffer(statusBuffer, kUbAlign);
        auto value = statusBuffer.Get<uint32_t>();
        value.SetValue(0, status);
        NativeStore(reinterpret_cast<__gm__ uint32_t *>(args.status) + core, value, 1);
#else
        reinterpret_cast<__gm__ uint32_t *>(args.status)[core] = status;
#endif
    } else if (reduce) {
        ReduceView view{args.workspace, args.input, args.forward, args.ranges, args.masks, args.config, args.layout,
            args.config.world < kGroupSources ? args.config.world : kGroupSources,
            args.layout.groups * args.layout.chunks, core - args.config.reduce_core_begin,
            partial ? partial : args.workspace + args.layout.partial_offset, sharedReady, readyMagic, partialRows};
        const uint32_t status = GatewayReduce::Run(view, writer, args.profiling != nullptr);
        if (sharedReady) {
            PublishAttachedStatus(args.status, core, status);
        }
    }
    if (!writer.IsBound()) {
        TPipe pipe;
        writer.Bind(pipe);
        Mark(writer, End);
        writer.Publish();
    } else {
        Mark(writer, End);
        writer.Publish();
    }
}

__aicore__ inline void PrepareCombineHT(const TileXRCombineHT::KernelArgs &args)
{
    Simt::VF_CALL<PrepareControlsVf>(Simt::Dim3{TileXRCombineHT::kBuilderThreads, 1, 1},
        reinterpret_cast<__gm__ uint64_t *>(args.workspace), args.layout.control_slots,
        TileXRCombineHT::kControlWorlds * args.config.world, uint32_t(GetBlockIdx()));
    SetFlag<HardEvent::V_S>(EVENT_ID0);
    WaitFlag<HardEvent::V_S>(EVENT_ID0);
}

__aicore__ inline void BarrierCombineHT(const TileXRCombineHT::KernelArgs &args)
{
    // Outer lifecycle only: the compute kernel has no inter-core/global barrier.
    TPipe pipe;
    TBuf<QuePosition::VECCALC> buffer;
    pipe.InitBuffer(buffer, TileXRCombineHT::kUbAlign);
    auto *comm = reinterpret_cast<__gm__ TileXR::CommArgs *>(args.comm);
    using TileXRCombineHT::kLocalRanks;
    GM_ADDR peers[kLocalRanks];
#pragma unroll
    for (uint32_t local = 0; local < kLocalRanks; ++local) peers[local] = comm->peerMems[args.comm_peer_begin + local];
    SyncCollectives sync;
    const uint32_t localRank = args.config.rank % kLocalRanks;
    sync.Init(localRank, kLocalRanks, peers, buffer);
#pragma unroll
    for (uint32_t local = 0; local < kLocalRanks; ++local) sync.SetSyncFlag(args.magic, 1, localRank, local);
#pragma unroll
    // A faster peer may already publish the next boundary to the same slot.
    for (uint32_t local = 0; local < kLocalRanks; ++local) sync.WaitSyncGreaterFlag(args.magic, 1, local);
}

__aicore__ inline void BarrierAttachedCombineHT(const TileXRCombineHT::AttachedKernelArgs &args, bool finishing)
{
    TPipe pipe;
    TBuf<QuePosition::VECCALC> buffer;
    pipe.InitBuffer(buffer, kLocalRanks * SYNC_UNIT_SIZE);
    auto values = buffer.Get<uint64_t>();
    const auto &local = args.local;
    auto *comm = reinterpret_cast<__gm__ TileXR::CommArgs *>(local.comm);
    const uint32_t localRank = local.config.rank % kLocalRanks;
    const uint64_t marker = static_cast<uint64_t>(args.ready_magic) * 2 + uint64_t(finishing);
    values.SetValue(0, marker);
    for (uint32_t peer = 0; peer < kLocalRanks; ++peer) {
        auto *destination = reinterpret_cast<__gm__ uint64_t *>(comm->peerMems[local.comm_peer_begin + peer]);
        NativeStore(destination + localRank * FLAG_UNIT_INT_NUM, values, 1);
    }

    GlobalTensor<uint64_t> flags;
    flags.SetGlobalBuffer(reinterpret_cast<__gm__ uint64_t *>(comm->peerMems[local.comm_peer_begin + localRank]));
    flags.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
    bool ready = false;
    for (uint32_t attempt = 0; attempt < kAttachedWaitIterations; ++attempt) {
        SetFlag<HardEvent::S_MTE2>(EVENT_ID2);
        WaitFlag<HardEvent::S_MTE2>(EVENT_ID2);
        DataCopy(values, flags, kLocalRanks * FLAG_UNIT_INT_NUM);
        SetFlag<HardEvent::MTE2_S>(EVENT_ID2);
        WaitFlag<HardEvent::MTE2_S>(EVENT_ID2);
        ready = true;
        for (uint32_t peer = 0; peer < kLocalRanks; ++peer) {
            const uint64_t observed = values.GetValue(peer * FLAG_UNIT_INT_NUM);
            ready = ready && (observed == marker || (!finishing && observed == marker + 1));
        }
        if (ready) break;
    }
    if (!finishing) {
        values.SetValue(0, ready ? static_cast<uint64_t>(args.ready_magic) : uint64_t{0});
        NativeStore(AttachedEntryFlag(local), values, 1);
    } else if (!ready) {
        auto status = buffer.Get<uint32_t>();
        status.SetValue(0, TILEXR_COMBINE_HT_LOCAL_BARRIER_TIMEOUT);
        NativeStore(reinterpret_cast<__gm__ uint32_t *>(local.status) + localRank, status, 1);
    }
}

} // namespace

#endif // TILEXR_MOONEP_COMBINE_HT_KERNEL_H
