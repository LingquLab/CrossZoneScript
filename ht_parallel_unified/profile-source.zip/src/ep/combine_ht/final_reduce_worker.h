/*
 * Copyright (c) 2026 TileXR Project.
 * Reduce the returned partials after all gateways publish their completion flags.
 */
#pragma once

#include "final_reduce_schedule.h"
#include "kernel_operator.h"
#include <tilexr/profiling/device/sst_buffered_writer.h>

using namespace AscendC;
using namespace TileXREpHt;

namespace TileXREpHt::FinalReduceDevice {
using TileXR::Profiling::SstBufferedWriter;
using TileXR::Profiling::SstStageScope;
constexpr uint32_t kWordsPerBlock = 32 / sizeof(uint64_t);
constexpr uint32_t kMaskBatch = 32;
constexpr uint32_t kBankAlignment = 256;
constexpr uint32_t kBankMask = 1;

#if !defined(ASCENDC_CPU_DEBUG) && !defined(TILEXR_EP_HT_FINAL_REDUCE_SST_FP32)
namespace Reg = AscendC::MicroAPI;
constexpr Reg::CastTrait kToFloat = {
    Reg::RegLayout::ZERO, Reg::SatMode::NO_SAT, Reg::MaskMergeMode::ZEROING, RoundMode::UNKNOWN};
constexpr Reg::CastTrait kToBf16 = {
    Reg::RegLayout::ZERO, Reg::SatMode::NO_SAT, Reg::MaskMergeMode::ZEROING, RoundMode::CAST_RINT};

template <bool First, bool Last>
__simd_vf__ void AccumulateRow(
    __ubuf__ bfloat16_t *input, __ubuf__ float *sum, __ubuf__ bfloat16_t *output, uint32_t hidden)
{
    uint32_t remaining = hidden;
    for (uint32_t offset = 0; offset < hidden; offset += 64) {
        auto mask = Reg::UpdateMask<float>(remaining);
        Reg::RegTensor<bfloat16_t> payload;
        Reg::RegTensor<float> value;
        Reg::LoadAlign<bfloat16_t, Reg::LoadDist::DIST_UNPACK_B16>(payload, input + offset);
        Reg::Cast<float, bfloat16_t, kToFloat>(value, payload, mask);
        if constexpr (!First) {
            Reg::RegTensor<float> prior;
            Reg::LoadAlign(prior, sum + offset);
            Reg::Add(value, prior, value, mask);
        }
        if constexpr (Last) {
            Reg::Cast<bfloat16_t, float, kToBf16>(payload, value, mask);
            Reg::StoreAlign<bfloat16_t, Reg::StoreDist::DIST_PACK_B32>(output + offset, payload, mask);
        } else {
            Reg::StoreAlign(sum + offset, value, mask);
        }
    }
}
#endif

#ifdef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
using RowElement = float;
#else
using RowElement = bfloat16_t;
#endif

template <HardEvent event>
__aicore__ inline void Sync()
{
    SetFlag<event>(EVENT_ID0);
    WaitFlag<event>(EVENT_ID0);
}

class FinalReduceWorker {
public:
    __aicore__ FinalReduceWorker(GM_ADDR workspace, GM_ADDR serverMask, GM_ADDR localReady, GM_ADDR output,
        const SendConfig &config, TPipe &pipe, SstBufferedWriter &trace)
        : trace_(trace), workspace_(workspace), serverMask_(serverMask), localReady_(localReady), output_(output), config_(config)
    {
        const uint32_t rowBytes = config.hidden * sizeof(RowElement);
        bankElements_ = ((rowBytes + kBankAlignment - 1) & ~(kBankAlignment - 1)) / sizeof(RowElement);
        tokenStride_ = ReturnSlots(config.topk) * config.hidden;
        hidden_ = config.hidden;
        auto *returned = reinterpret_cast<__gm__ RowElement *>(workspace + config.returnOffset);
        returnedGm_.SetGlobalBuffer(returned);
        returnedGm_.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
        outputGm_.SetGlobalBuffer(reinterpret_cast<__gm__ RowElement *>(output_));
        pipe.InitBuffer(metadata_, kMaskBatch * sizeof(uint64_t));
        pipe.InitBuffer(notifications_, 5 * kWorld * 32);
        notificationGap_ = config_.chunks * kLanes * kSlotBytes - sizeof(uint64_t);
#ifdef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
        pipe.InitBuffer(row_, rowBytes);
        pipe.InitBuffer(outRow_, rowBytes);
#else
        pipe.InitBuffer(row_, 2 * bankElements_ * sizeof(RowElement));
        pipe.InitBuffer(outRow_, 2 * bankElements_ * sizeof(RowElement));
#endif
#if defined(ASCENDC_CPU_DEBUG) && !defined(TILEXR_EP_HT_FINAL_REDUCE_SST_FP32)
        pipe.InitBuffer(converted_, config.hidden * sizeof(float));
#endif
#ifndef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
        pipe.InitBuffer(sum_, config.hidden * sizeof(float));
#endif
    }

    __aicore__ bool WaitWindow(uint32_t window, uint32_t first, uint32_t last)
    {
        SstStageScope timing(trace_, 4402, window);
        const uint32_t serverBegin = config_.rank / kRanksPerServer * kRanksPerServer;
        const uint64_t remote = ~(uint64_t {(1U << kRanksPerServer) - 1} << serverBegin);
        uint64_t previous = 0;
        if (first != last && LogicalChunk(config_, last - 1) != LogicalChunk(config_, last)) {
            for (uint64_t pending = remote; pending; pending &= pending - 1) {
                const uint32_t gateway = __builtin_ctzll(pending);
                if (NeedsPreviousNotify(config_, gateway, first, last)) {
                    previous |= uint64_t {1} << gateway;
                }
            }
        }

        // Each plane is a single strided DMA. Queue all required planes before
        // synchronizing Scalar once, and reread only planes with missing SOs.
        uint64_t pending[] = {(1U << kRanksPerServer) - 1, remote, remote, previous, previous};
        GM_ADDR const addresses[] = {localReady_ + LocalReturnReadyOffset(0, window),
            workspace_ + CompletionOffset(config_, 0, last, 0), workspace_ + CompletionOffset(config_, 0, last, 1),
            workspace_ + CompletionOffset(config_, 0, last - (last != 0), 0),
            workspace_ + CompletionOffset(config_, 0, last - (last != 0), 1)};
        auto flags = notifications_.Get<uint64_t>();
        const uint64_t magic = uint64_t(config_.magic);
        for (uint64_t attempt = 0; attempt < config_.waitIterations; ++attempt) {
            for (uint32_t group = 0; group < 5; ++group) {
                if (pending[group]) {
                    CopyMetadata(flags[group * kFlagPlaneWords], addresses[group],
                        group == 0 ? kRanksPerServer : kWorld, sizeof(uint64_t),
                        group == 0 ? kSlotBytes - sizeof(uint64_t) : notificationGap_);
                }
            }
            Sync<HardEvent::MTE2_S>();
            uint64_t missing = 0;
            for (uint32_t group = 0; group < 5; ++group) {
                auto plane = flags[group * kFlagPlaneWords];
                for (uint64_t remaining = pending[group]; remaining; remaining &= remaining - 1) {
                    const uint32_t slot = __builtin_ctzll(remaining);
                    if (plane.GetValue(slot * kWordsPerBlock) == magic) {
                        pending[group] &= ~(uint64_t {1} << slot);
                    }
                }
                missing |= pending[group];
            }
            if (missing == 0) {
                return true;
            }
        }
        return false;
    }

    __aicore__ uint32_t ReduceTokens(uint32_t begin, uint32_t end)
    {
#ifndef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
        uint64_t rowOffset = uint64_t(begin) * tokenStride_;
#endif
        for (uint32_t token = begin; token < end;) {
            const uint32_t count = end - token < kMaskBatch ? end - token : kMaskBatch;
            auto masks = ReadMetadata(serverMask_ + uint64_t(token) * sizeof(uint64_t), count * sizeof(uint64_t));
#ifdef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
            for (uint32_t index = 0; index < count; ++index, ++token) {
                const uint64_t mask = masks.GetValue(index);
                if (mask >> kServerCount) {
                    return FinalReduceInvalidMask;
                }
                ReduceFp32Token(token, mask);
            }
#else
            uint64_t mask = masks.GetValue(0);
            if (mask >> kServerCount) {
                return FinalReduceInvalidMask;
            }
            if (mask) {
                Prefetch(rowOffset, mask, inputBank_);
            }
            for (uint32_t index = 0; index < count; ++index, ++token) {
                const uint64_t nextMask = index + 1 < count ? masks.GetValue(index + 1) : 0;
                ReduceToken(token, rowOffset, mask, nextMask >> kServerCount ? 0 : nextMask);
                if (nextMask >> kServerCount) {
                    return FinalReduceInvalidMask;
                }
                mask = nextMask;
                rowOffset += tokenStride_;
            }
#endif
        }
        return FinalReduceSuccess;
    }

    __aicore__ void Drain()
    {
#ifndef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
        for (uint32_t bank = 0; bank < 2; ++bank) {
            WaitOutput(bank);
            if (inputPending_[bank]) {
                WaitFlag<HardEvent::V_MTE2>(EVENT_ID0 + bank);
            }
        }
#endif
    }

private:
    static constexpr uint32_t kFlagPlaneWords = kWorld * kWordsPerBlock;

    __aicore__ void CopyMetadata(
        LocalTensor<uint64_t> local, GM_ADDR source, uint16_t blocks, uint32_t blockBytes, uint32_t gap)
    {
        GlobalTensor<uint64_t> gm;
        gm.SetGlobalBuffer(reinterpret_cast<__gm__ uint64_t *>(source));
        gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
        DataCopyPad(local, gm, DataCopyExtParams(blocks, blockBytes, gap, 0, 0),
            DataCopyPadExtParams<uint64_t> {false, 0, 0, 0});
    }

    __aicore__ LocalTensor<uint64_t> ReadMetadata(GM_ADDR source, uint32_t bytes)
    {
        auto local = metadata_.Get<uint64_t>();
        CopyMetadata(local, source, 1, bytes, 0);
        Sync<HardEvent::MTE2_S>();
        return local;
    }

    __aicore__ void WaitOutput(uint32_t bank)
    {
        if (outputPending_[bank]) {
            WaitFlag<HardEvent::MTE3_V>(EVENT_ID2 + bank);
            outputPending_[bank] = false;
        }
    }

    __aicore__ void WriteOutput(uint32_t token, uint32_t bank, LocalTensor<RowElement> output)
    {
        SetFlag<HardEvent::V_MTE3>(EVENT_ID2 + bank);
        WaitFlag<HardEvent::V_MTE3>(EVENT_ID2 + bank);
        DataCopy(outputGm_[uint64_t(token) * hidden_], output, hidden_);
        SetFlag<HardEvent::MTE3_V>(EVENT_ID2 + bank);
        outputPending_[bank] = true;
    }

#ifdef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
    __aicore__ void ReduceFp32Token(uint32_t token, uint64_t mask)
    {
        SstStageScope timing(trace_, 4404, token);
        auto row = row_.Get<float>();
        auto output = outRow_.Get<float>();
        const uint32_t hidden = config_.hidden;
        bool first = true;
        for (; mask; mask &= mask - 1) {
            const uint32_t server = __builtin_ctzll(mask);
            GlobalTensor<float> returned;
            returned.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                workspace_ + ReturnOffset(config_, token, server * kRanksPerServer, sizeof(float))));
            returned.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
            if (first) {
                // Start the SST accumulator with this token's first returned row.
                {
                    SstStageScope timing(trace_, 4406, (token << 8) | server);
                    DataCopy(output, returned, hidden);
                    Sync<HardEvent::MTE2_V>();
                }
                first = false;
                continue;
            }
            {
                SstStageScope timing(trace_, 4406, (token << 8) | server);
                DataCopy(row, returned, hidden);
                Sync<HardEvent::MTE2_V>();
            }
            {
                SstStageScope timing(trace_, 4408, (token << 8) | server);
                Add(output, output, row, hidden);
                Sync<HardEvent::V_MTE2>();
            }
        }
        if (first) {
            for (uint32_t h = 0; h < hidden; ++h) {
                output.SetValue(h, 0.0F);
            }
            Sync<HardEvent::S_MTE3>();
        }
        Sync<HardEvent::V_MTE3>();
        GlobalTensor<float> result;
        result.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(output_) + uint64_t(token) * hidden);
        {
            SstStageScope timing(trace_, 4410, token);
            DataCopy(result, output, hidden);
            Sync<HardEvent::MTE3_V>();
        }
    }
#else
    __aicore__ void Prefetch(uint64_t rowOffset, uint64_t mask, uint32_t bank)
    {
        if (inputPending_[bank]) {
            WaitFlag<HardEvent::V_MTE2>(EVENT_ID0 + bank);
            inputPending_[bank] = false;
        }
        const uint32_t server = __builtin_ctzll(mask);
        DataCopy(row_.Get<RowElement>()[bank * bankElements_],
            returnedGm_[rowOffset + uint64_t(server) * config_.hidden], config_.hidden);
        SetFlag<HardEvent::MTE2_V>(EVENT_ID0 + bank);
    }

    template <bool First, bool Last>
    __aicore__ void Compute(LocalTensor<RowElement> input, LocalTensor<RowElement> output)
    {
        auto sum = sum_.Get<float>();
#if defined(ASCENDC_CPU_DEBUG)
        auto converted = converted_.Get<float>();
        if constexpr (First) {
            Cast(sum, input, RoundMode::CAST_NONE, config_.hidden);
        } else {
            Cast(converted, input, RoundMode::CAST_NONE, config_.hidden);
            PipeBarrier<PIPE_V>();
            Add(sum, sum, converted, config_.hidden);
        }
        if constexpr (Last) {
            PipeBarrier<PIPE_V>();
            Cast(output, sum, RoundMode::CAST_RINT, config_.hidden);
        }
#else
        asc_vf_call<AccumulateRow<First, Last>>(reinterpret_cast<__ubuf__ bfloat16_t *>(input.GetPhyAddr()),
            reinterpret_cast<__ubuf__ float *>(sum.GetPhyAddr()),
            reinterpret_cast<__ubuf__ bfloat16_t *>(output.GetPhyAddr()), config_.hidden);
#endif
    }

    __aicore__ void ReduceToken(uint32_t token, uint64_t rowOffset, uint64_t mask, uint64_t nextMask)
    {
        const uint32_t outBank = token & kBankMask;
        auto output = outRow_.Get<RowElement>()[outBank * bankElements_];
        if (mask == 0) {
            if (nextMask) {
                Prefetch(rowOffset + tokenStride_, nextMask, inputBank_);
            }
            WaitOutput(outBank);
            Duplicate(output, static_cast<RowElement>(0.0F), config_.hidden);
        }
        bool first = true;
        while (mask) {
            const uint32_t bank = inputBank_;
            inputBank_ ^= kBankMask;
            mask &= mask - 1;
            if (mask) {
                Prefetch(rowOffset, mask, inputBank_);
            } else if (nextMask) {
                Prefetch(rowOffset + tokenStride_, nextMask, inputBank_);
            }
            WaitFlag<HardEvent::MTE2_V>(EVENT_ID0 + bank);
            if (mask == 0) {
                WaitOutput(outBank);
            }
            auto input = row_.Get<RowElement>()[bank * bankElements_];
            if (first) {
                if (mask) {
                    Compute<true, false>(input, output);
                } else {
                    Compute<true, true>(input, output);
                }
                first = false;
            } else if (mask) {
                Compute<false, false>(input, output);
            } else {
                Compute<false, true>(input, output);
            }
            if (mask) {
                PipeBarrier<PIPE_V>();
            }
            SetFlag<HardEvent::V_MTE2>(EVENT_ID0 + bank);
            inputPending_[bank] = true;
        }
        WriteOutput(token, outBank, output);
    }
#endif

    SstBufferedWriter &trace_;
    GM_ADDR workspace_;
    GM_ADDR serverMask_;
    GM_ADDR localReady_;
    GM_ADDR output_;
    const SendConfig &config_;
    GlobalTensor<RowElement> returnedGm_, outputGm_;
    uint32_t bankElements_, tokenStride_, hidden_, notificationGap_;
    bool outputPending_[2] = {};
    TBuf<TPosition::VECCALC> metadata_, notifications_, row_, outRow_;
#ifndef TILEXR_EP_HT_FINAL_REDUCE_SST_FP32
    uint32_t inputBank_ = 0;
    bool inputPending_[2] = {};
    TBuf<TPosition::VECCALC> sum_;
#endif
#if defined(ASCENDC_CPU_DEBUG) && !defined(TILEXR_EP_HT_FINAL_REDUCE_SST_FP32)
    TBuf<TPosition::VECCALC> converted_;
#endif
};
__aicore__ inline void Run(GM_ADDR workspace, GM_ADDR serverMask, GM_ADDR localReady, GM_ADDR output, GM_ADDR status, SendConfig config, uint32_t block, uint32_t blocks, GM_ADDR profile)
{
    SstBufferedWriter trace;
    trace.Initialize(profile, GetBlockIdx());
    trace.Mark(4400);
    TPipe pipe;
    FinalReduceWorker worker(workspace, serverMask, localReady, output, config, pipe, trace);
    trace.Bind(pipe);
    const uint32_t result = ReduceWindows(config, block, blocks, worker);
    worker.Drain();

    TBuf<TPosition::VECCALC> statusBuffer;
    pipe.InitBuffer(statusBuffer, 32);
    auto local = statusBuffer.Get<uint32_t>();
    local.SetValue(0, result);
    GlobalTensor<uint32_t> resultGm;
    resultGm.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(status) + block * kFinalReduceStatusStride);
    Sync<HardEvent::S_MTE3>();
    DataCopyPad(resultGm, local, DataCopyExtParams(1, sizeof(uint32_t), 0, 0, 0));
    Sync<HardEvent::MTE3_S>();
    trace.Mark(4401);
    trace.Publish();
}

} // namespace TileXREpHt::FinalReduceDevice
