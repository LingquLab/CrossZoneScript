/*
 * Copyright (c) 2026 TileXR Project.
 * 调用共享调度器，将已注册工作区中的 BF16 partial 写回源 rank，并发送 magic 完成通知。
 * 每个 AIV 独占一个 owner 的双 lane；工作区和通信资源由调用方保持到 kernel 完成。
 */
#pragma once

#include "kernel_operator.h"
#include <tilexr/profiling/device/sst_buffered_writer.h>
#include "ready.h"
#include <tilexr/comm/udma/device/api.h>

using namespace AscendC;
namespace TileXREpHt::InterServerSendDevice {
using namespace TileXREpHt;
using TileXR::Profiling::SstBufferedWriter;
using TileXR::Profiling::SstStageScope;
class DeviceTransport {
public:
    __aicore__ DeviceTransport(GM_ADDR comm, GM_ADDR workspace, GM_ADDR forward, GM_ADDR counts, GM_ADDR ranges,
        const SendConfig &config, uint32_t owner, TPipe &pipe, SstBufferedWriter &trace)
        : args_(reinterpret_cast<__gm__ TileXR::CommArgs *>(comm)), workspace_(workspace), forward_(forward),
          counts_(counts), ranges_(ranges), c_(config), owner_(owner), trace_(trace)
    {
        pipe.InitBuffer(metadata_, 512);
        pipe.InitBuffer(rangesCache_, kMaxPeersPerOwner * RangeCacheStride() * sizeof(int32_t));
        pipe.InitBuffer(ready_, c_.reducerCount * kReadyUbStride);
        pipe.InitBuffer(forwardCache_, kMaxPeersPerOwner * kForwardPageRows * kUbBlockBytes);
        pipe.InitBuffer(wqe_, kBatchRows * TileXR::TILEXR_UDMA_WQE_BB_BYTES);
        auto source = metadata_.Get<int64_t>();
        source.SetValue(0, c_.magic);
        GlobalTensor<int64_t> gm;
        gm.SetGlobalBuffer(
            reinterpret_cast<__gm__ int64_t *>(workspace_ + c_.signalOffset + uint64_t(owner_) * kSlotBytes));
        SetFlag<HardEvent::S_MTE3>(EVENT_ID1);
        WaitFlag<HardEvent::S_MTE3>(EVENT_ID1);
        DataCopyPad(gm, source, DataCopyExtParams(1, 8, 0, 0, 0));
        SetFlag<HardEvent::MTE3_S>(EVENT_ID1);
        WaitFlag<HardEvent::MTE3_S>(EVENT_ID1);
    }
    template <class T>
    __aicore__ LocalTensor<T> Load(GM_ADDR address, uint32_t count, LocalTensor<T> ub)
    {
        GlobalTensor<T> gm;
        gm.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(address));
        gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
        SetFlag<HardEvent::S_MTE2>(EVENT_ID0);
        WaitFlag<HardEvent::S_MTE2>(EVENT_ID0);
        DataCopyPad(ub, gm, DataCopyExtParams(1, count * sizeof(T), 0, 0, 0), DataCopyPadExtParams<T> {false, 0, 0, 0});
        SetFlag<HardEvent::MTE2_S>(EVENT_ID0);
        WaitFlag<HardEvent::MTE2_S>(EVENT_ID0);
        return ub;
    }
    __aicore__ uint32_t RangeCacheStride() const
    {
        constexpr uint32_t wordsPerBlock = kUbBlockBytes / sizeof(int32_t);
        return (c_.chunks * 2 + wordsPerBlock - 1) / wordsPerBlock * wordsPerBlock;
    }
    __aicore__ Range LoadRange(uint32_t peer, uint32_t slot, uint32_t chunk)
    {
        cachePeer_[slot] = peer;
        auto ranges = rangesCache_.Get<int32_t>()[slot * RangeCacheStride()];
        const uint32_t mask = uint32_t(1) << slot;
        if (!(loadedRanges_ & mask)) {
            Load<int32_t>(ranges_ + uint64_t(peer) * c_.chunks * 8, c_.chunks * 2, ranges);
            loadedRanges_ |= mask;
        }
        return {ranges.GetValue(chunk * 2), ranges.GetValue(chunk * 2 + 1)};
    }
    __aicore__ uint32_t CacheSlot(uint32_t peer) const
    {
        for (uint32_t slot = 0; slot < kMaxPeersPerOwner; ++slot) {
            if (cachePeer_[slot] == peer) {
                return slot;
            }
        }
        return kMaxPeersPerOwner;
    }
    __aicore__ int32_t LoadCount(uint32_t peer)
    {
        const int32_t count = Load<int32_t>(counts_ + peer * 4, 1, metadata_.Get<int32_t>()).GetValue(0);
        const uint32_t slot = CacheSlot(peer);
        if (slot < kMaxPeersPerOwner) {
            validRows_[slot] = count;
        }
        return count;
    }
    __aicore__ Record LoadRecord(uint32_t peer, uint32_t row)
    {
        const uint32_t slot = CacheSlot(peer);
        const uint32_t first = row / kForwardPageRows * kForwardPageRows;
        auto page = forwardCache_.Get<int32_t>()[slot * kForwardPageRows * kUbBlockBytes / sizeof(int32_t)];
        if (!pageLoaded_[slot] || pageBegin_[slot] != first) {
            const uint32_t remaining = uint32_t(validRows_[slot]) - first;
            const uint32_t rows = remaining < kForwardPageRows ? remaining : kForwardPageRows;
            GlobalTensor<int32_t> gm;
            gm.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(
                forward_ + (uint64_t(peer) * c_.forwardCapacity + first) * kUbBlockBytes));
            gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
            SetFlag<HardEvent::S_MTE2>(EVENT_ID0);
            WaitFlag<HardEvent::S_MTE2>(EVENT_ID0);
            // The public records remain packed 24B. Each independent source
            // block is padded to a 32B UB row, including the bounded last page.
            DataCopyPad(page, gm, DataCopyExtParams(rows, kUbBlockBytes, 0, 0, 0),
                DataCopyPadExtParams<int32_t> {false, 0, 0, 0});
            SetFlag<HardEvent::MTE2_S>(EVENT_ID0);
            WaitFlag<HardEvent::MTE2_S>(EVENT_ID0);
            pageBegin_[slot] = first;
            pageLoaded_[slot] = true;
        }
        const uint32_t at = (row - first) * kUbBlockBytes / sizeof(int32_t);
        return {page.GetValue(at), page.GetValue(at + 1), page.GetValue(at + 2), page.GetValue(at + 3),
            page.GetValue(at + 4), page.GetValue(at + 5)};
    }
    __aicore__ uint32_t WaitReady(uint32_t chunk)
    {
        SstStageScope timing(trace_, 4302, chunk);
        return WaitForReducedChunk(workspace_, c_, chunk, ready_.Get<int64_t>(), readyThrough_);
    }
    __aicore__ uint32_t Add(uint32_t peer, uint32_t lane, const Record &record)
    {
        const uint64_t base = record.contributor < 0 ? c_.inputOffset : c_.partialOffset;
        batch_[lane][pending_[lane]++] = {
            base + uint64_t(record.primary) * RowBytes(), ReturnOffset(c_, record.token, c_.rank), peer};
        return pending_[lane] == kBatchRows ? FlushLane(lane) : uint32_t(Success);
    }
    __aicore__ uint32_t Flush()
    {
        for (uint32_t lane = 0; lane < kLanes; ++lane) {
            const uint32_t result = FlushLane(lane);
            if (result != Success) {
                return result;
            }
        }
        return Success;
    }
    __aicore__ uint32_t Notify(uint32_t peer, uint32_t lane, uint32_t chunk)
    {
        SstStageScope timing(trace_, 4308, (peer << 16) | (lane << 8) | chunk);
        const uint32_t qp = kLanes * owner_ + lane;
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        if (WaitSqStripe(peer, qp) != Success) {
            return TransportError;
        }
#endif
        auto source = reinterpret_cast<__gm__ uint64_t *>(workspace_ + c_.signalOffset + uint64_t(owner_) * kSlotBytes);
        const uint32_t ret = TileXR::UDMAPutNbiOnQp<uint64_t>(
            args_, wqe_.Get<uint8_t>(), peer, qp, source, CompletionOffset(c_, c_.rank, chunk, lane), 8);
        touched_[lane] |= PeerBit(peer);
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        if (ret == TileXR::TILEXR_UDMA_STATUS_SUCCESS) {
            SstStageScope timing(trace_, 4310, (peer << 16) | (lane << 8) | chunk);
            if (TileXR::UDMAQuietStatusOnQp(args_, peer, qp)) {
                return TransportError;
            }
        }
#endif
        return ret == TileXR::TILEXR_UDMA_STATUS_SUCCESS ? uint32_t(Success) : uint32_t(TransportError);
    }
    __aicore__ uint32_t Drain()
    {
        SstStageScope timing(trace_, 4312);
        uint32_t result = Success;
        for (uint32_t lane = 0; lane < kLanes; ++lane) {
            for (uint64_t peers = touched_[lane]; peers; peers &= peers - 1) {
                const uint32_t peer = __builtin_ctzll(peers);
                const uint32_t qp = kLanes * owner_ + lane;
                const uint32_t flush =
                    (unpublished_[lane] & PeerBit(peer)) ? TileXR::UDMAFlushQpDoorbell(args_, peer, qp) : 0;
                const uint32_t quiet = TileXR::UDMAQuietStatusOnQp(args_, peer, qp);
                if (flush || quiet) {
                    result = TransportError;
                }
            }
        }
        return result;
    }

private:
    static constexpr uint32_t kBatchRows = 32;
    static constexpr uint32_t kForwardPageRows = 16;
    static_assert(sizeof(Record) == 24, "Packed forward record ABI");
    static constexpr uint32_t kUbBlockBytes = 32;
    static_assert(kWorld <= 64, "Each peer occupies one bit");

    struct Descriptor {
        uint64_t sourceOffset, targetOffset;
        uint32_t peer;
    };

    __aicore__ static uint64_t PeerBit(uint32_t peer)
    {
        return uint64_t(1) << peer;
    }
    __aicore__ uint64_t RowBytes() const
    {
        return uint64_t(c_.hidden) * sizeof(uint16_t);
    }

#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
    static constexpr uint32_t kSqStripeBbs = kSlotBytes / TileXR::TILEXR_UDMA_WQE_BB_BYTES;

    __aicore__ uint32_t WaitSqStripe(uint32_t peer, uint32_t qp, __gm__ TileXR::UDMAInfo *info,
        __gm__ TileXR::UDMAWQCtx *context, uint32_t head)
    {
        if (head == 0 || head % kSqStripeBbs != 0 ||
            head == TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->tailAddr))) {
            return Success;
        }
        // Do not let SST combine unconsumed WQEs from two physical SQ stripes.
        TileXR::UDMARingDoorbell(head, context);
        return TileXR::UDMAPollCQUntilSqTail(info, peer, qp, head) ? uint32_t(TransportError) : uint32_t(Success);
    }

    __aicore__ uint32_t WaitSqStripe(uint32_t peer, uint32_t qp)
    {
        if (!TileXR::UDMAQueueOperationValid(args_, peer, qp)) {
            return TransportError;
        }
        auto info = TileXR::GetUDMAInfo(args_);
        auto context = TileXR::UDMAGetWQCtx(info, peer, qp);
        if (!context || !context->headAddr || !context->tailAddr || context->bufAddr % kSlotBytes != 0) {
            return TransportError;
        }
        const uint32_t stripeHead = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->headAddr));
        return WaitSqStripe(peer, qp, info, context, stripeHead);
    }
#endif

    __aicore__ uint32_t PostWrite(const Descriptor &d, uint32_t qp, uint64_t offset, uint64_t bytes)
    {
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        if (WaitSqStripe(d.peer, qp) != Success) {
            return TransportError;
        }
#endif
        auto source = reinterpret_cast<__gm__ uint8_t *>(workspace_ + d.sourceOffset + offset);
        auto scratch = wqe_.Get<uint8_t>();
        constexpr uint32_t completion = TileXR::TILEXR_UDMA_SQE_FLAG_COMPLETION;
        uint32_t ret = TileXR::UDMAPutNbiOnQpWithFlagDeferred<uint8_t>(
            args_, scratch, d.peer, qp, source, d.targetOffset + offset, bytes, completion);
        if (ret == TileXR::TILEXR_UDMA_STATUS_SQ_FULL) {
            if (TileXR::UDMAFlushQpDoorbell(args_, d.peer, qp) || TileXR::UDMAQuietStatusOnQp(args_, d.peer, qp)) {
                return TransportError;
            }
            ret = TileXR::UDMAPutNbiOnQpWithFlagDeferred<uint8_t>(
                args_, scratch, d.peer, qp, source, d.targetOffset + offset, bytes, completion);
        }
        return ret == TileXR::TILEXR_UDMA_STATUS_SUCCESS ? uint32_t(Success) : uint32_t(TransportError);
    }

    __aicore__ uint32_t PostRow(const Descriptor &d, uint32_t qp, uint64_t bytes)
    {
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        // SST striping requires each WRITE to stay within both 512B address stripes.
        for (uint64_t offset = 0; offset < bytes;) {
            uint64_t length = bytes - offset;
            const uint64_t sourceTail = kSlotBytes - (d.sourceOffset + offset) % kSlotBytes;
            const uint64_t targetTail = kSlotBytes - (d.targetOffset + offset) % kSlotBytes;
            length = length < sourceTail ? length : sourceTail;
            length = length < targetTail ? length : targetTail;
            const uint32_t result = PostWrite(d, qp, offset, length);
            if (result != Success) {
                return result;
            }
            offset += length;
        }
        return Success;
#else
        return PostWrite(d, qp, 0, bytes);
#endif
    }

    __aicore__ uint32_t PostPeerBatch(uint32_t peer, uint32_t lane, uint32_t rows)
    {
        SstStageScope timing(trace_, 4304, (peer << 16) | (lane << 8) | rows);
        const uint32_t qp = kLanes * owner_ + lane;
        if (!TileXR::UDMAQueueOperationValid(args_, peer, qp)) {
            return TransportError;
        }
        auto info = TileXR::GetUDMAInfo(args_);
        auto context = TileXR::UDMAGetWQCtx(info, peer, qp);
        auto memory = TileXR::UDMAGetRemoteMemInfo(info, peer, qp);
        if (!context || !memory || !context->headAddr || !context->tailAddr || !context->wqeCntAddr ||
            context->depth != TileXR::TILEXR_UDMA_SQ_BB_COUNT || !memory->eidAddr) {
            return TransportError;
        }
        uint32_t head = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->headAddr));
        uint32_t tail = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->tailAddr));
        const uint32_t depth = context->depth;
        if (head - tail > depth) {
            return TransportError;
        }
        // Reserve one BB for a following completion SO. Every payload has a
        // CQE, so the exact minimum tail watermark is always reclaimable.
        const uint32_t required = rows + 1;
        if (required > depth - (head - tail)) {
            TileXR::UDMARingDoorbell(head, context);
            const uint32_t target = head + required - depth;
            if (TileXR::UDMAPollCQUntilSqTail(info, peer, qp, target)) {
                return TransportError;
            }
        }
        auto scratch = wqe_.Get<uint8_t>();
        auto bytes = reinterpret_cast<__ubuf__ uint8_t *>(scratch.GetPhyAddr());
        uint32_t count = 0;
        for (uint32_t i = 0; i < pending_[lane]; ++i) {
            const Descriptor &d = batch_[lane][i];
            if (d.peer != peer) {
                continue;
            }
            auto source = reinterpret_cast<__gm__ uint8_t *>(workspace_ + d.sourceOffset);
            if (!TileXR::UDMARegisteredOperationValid(args_, peer, qp, d.targetOffset, RowBytes())) {
                return TransportError;
            }
            auto target = TileXR::UDMARegisteredRemoteAddr(TileXR::GetUDMARegistry(args_), peer, d.targetOffset);
            const uint32_t validated = TileXR::UDMAValidatePostSend<TileXR::UDMAOpcode::WRITE>(
                info, target, source, qp, RowBytes(), TileXR::TILEXR_UDMA_SQE_FLAG_COMPLETION, context);
            if (validated != TileXR::TILEXR_UDMA_STATUS_SUCCESS) {
                return TransportError;
            }
            auto wqe = bytes + count * TileXR::TILEXR_UDMA_WQE_BB_BYTES;
            TileXR::UDMAClearWqeScratch(wqe, TileXR::TILEXR_UDMA_WQE_BB_BYTES);
            TileXR::UDMAFillSqeCtx<TileXR::UDMAOpcode::WRITE>(reinterpret_cast<__ubuf__ TileXR::UDMASqeCtx *>(wqe),
                target, memory, head + count, TileXR::TILEXR_UDMA_SQE_FLAG_COMPLETION);
            TileXR::UDMAFillSgeCtx(reinterpret_cast<__ubuf__ TileXR::UDMASgeCtx *>(wqe + sizeof(TileXR::UDMASqeCtx)),
                RowBytes(), source, context->localTokenId);
            ++count;
        }
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        if (context->bufAddr % kSlotBytes != 0) {
            return TransportError;
        }
        const uint32_t wqeCount = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->wqeCntAddr));
        for (uint32_t published = 0; published < count;) {
            const uint32_t stripeHead = head + published;
            const uint32_t room = kSqStripeBbs - stripeHead % kSqStripeBbs;
            const uint32_t remaining = count - published;
            const uint32_t piece = remaining < room ? remaining : room;
            TileXR::UDMAPublishWqe(
                scratch[published * TileXR::TILEXR_UDMA_WQE_BB_BYTES], context, stripeHead, piece);
            published += piece;
            PublishBatchHead(peer, lane, context, head + published, wqeCount + published);
            // Use the same per-QP completion count as the SST drain path.
            {
                SstStageScope timing(trace_, 4306, (peer << 16) | (lane << 8) | piece);
                if (TileXR::UDMAQuietStatusOnQpUntil(args_, peer, qp, wqeCount + published)) {
                    return TransportError;
                }
            }
        }
#else
        // Publish the contiguous UB batch in one MTE3 copy, or two at wrap.
        TileXR::UDMAPublishWqe(scratch, context, head, count);
        const uint32_t wqeCount = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(context->wqeCntAddr));
        PublishBatchHead(peer, lane, context, head + count, wqeCount + count);
#endif
        return Success;
    }

    __aicore__ inline void PublishBatchHead(uint32_t peer, uint32_t lane, __gm__ TileXR::UDMAWQCtx *context,
        uint32_t publishedHead, uint32_t publishedWqes)
    {
        TileXR::UDMASstStoreState(reinterpret_cast<__gm__ uint32_t *>(context->headAddr), publishedHead);
        TileXR::UDMASstStoreState(reinterpret_cast<__gm__ uint32_t *>(context->wqeCntAddr), publishedWqes);
        touched_[lane] |= PeerBit(peer);
        TileXR::UDMARingDoorbell(publishedHead, context);
    }

#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
    __aicore__ uint32_t FlushSplitLane(uint32_t lane)
    {
        auto &dirtyPeers = unpublished_[lane];
        const uint32_t qp = kLanes * owner_ + lane;
        const uint64_t rowBytes = RowBytes();
        for (uint32_t i = 0; i < pending_[lane]; ++i) {
            const Descriptor &d = batch_[lane][i];
            const uint64_t peer = PeerBit(d.peer);
            touched_[lane] |= peer;
            dirtyPeers |= peer;
            const uint32_t result = PostRow(d, qp, rowBytes);
            if (result != Success) {
                return result;
            }
        }
        for (; dirtyPeers; dirtyPeers &= dirtyPeers - 1) {
            if (TileXR::UDMAFlushQpDoorbell(args_, __builtin_ctzll(dirtyPeers), qp)) {
                return TransportError;
            }
        }
        pending_[lane] = 0;
        return Success;
    }
#endif
    __aicore__ uint32_t FlushLane(uint32_t lane)
    {
#ifdef TILEXR_EP_HT_SST_SPLIT_WRITES
        // Retain native batching when each payload already fits both SST
        // stripes (including the T4/H256 fixture). Only split incompatible rows.
        for (uint32_t i = 0; i < pending_[lane]; ++i) {
            const Descriptor &d = batch_[lane][i];
            if (RowBytes() > kSlotBytes - d.sourceOffset % kSlotBytes ||
                RowBytes() > kSlotBytes - d.targetOffset % kSlotBytes) {
                return FlushSplitLane(lane);
            }
        }
#endif
        uint64_t peers = 0;
        for (uint32_t i = 0; i < pending_[lane]; ++i) {
            peers |= PeerBit(batch_[lane][i].peer);
        }
        for (; peers; peers &= peers - 1) {
            const uint32_t peer = __builtin_ctzll(peers);
            uint32_t rows = 0;
            for (uint32_t i = 0; i < pending_[lane]; ++i) {
                rows += batch_[lane][i].peer == peer;
            }
            const uint32_t result = PostPeerBatch(peer, lane, rows);
            if (result != Success) {
                return result;
            }
        }
        pending_[lane] = 0;
        return Success;
    }
    __gm__ TileXR::CommArgs *args_;
    GM_ADDR workspace_;
    GM_ADDR forward_;
    GM_ADDR counts_;
    GM_ADDR ranges_;
    const SendConfig &c_;
    uint32_t owner_;
    SstBufferedWriter &trace_;
    int32_t readyThrough_ = 0;
    uint32_t loadedRanges_ = 0;
    uint32_t cachePeer_[kMaxPeersPerOwner] = {kWorld, kWorld, kWorld, kWorld};
    int32_t validRows_[kMaxPeersPerOwner] = {};
    uint32_t pageBegin_[kMaxPeersPerOwner] = {};
    bool pageLoaded_[kMaxPeersPerOwner] = {};
    TBuf<QuePosition::VECCALC> forwardCache_;
    TBuf<QuePosition::VECCALC> rangesCache_;
    TBuf<QuePosition::VECCALC> metadata_;
    TBuf<QuePosition::VECCALC> ready_;
    TBuf<TPosition::VECOUT> wqe_;
    Descriptor batch_[kLanes][kBatchRows];
    uint32_t pending_[kLanes] = {};
    uint64_t touched_[kLanes] = {};
    uint64_t unpublished_[kLanes] = {};
};
__aicore__ inline void Run(GM_ADDR commArgs, GM_ADDR workspace, GM_ADDR forward, GM_ADDR counts, GM_ADDR ranges,
    GM_ADDR status, TileXREpHt::SendConfig config, uint32_t owner, GM_ADDR profile)
{
    SstBufferedWriter trace;
    trace.Initialize(profile, GetBlockIdx());
    trace.Mark(4300);
    TPipe pipe;
    TBuf<QuePosition::VECCALC> queueStateScratch;
    pipe.InitBuffer(queueStateScratch, 32);
    DeviceTransport transport(commArgs, workspace, forward, counts, ranges, config, owner, pipe, trace);
    trace.Bind(pipe);
    uint32_t result = TileXREpHt::Submit(config, owner, transport);
    const uint32_t drained = TileXREpHt::Drain(transport);
    if (result == TileXREpHt::Success) {
        result = drained;
    }
    TBuf<QuePosition::VECCALC> resultBuffer;
    pipe.InitBuffer(resultBuffer, 32);
    auto local = resultBuffer.Get<uint32_t>();
    local.SetValue(0, result);
    GlobalTensor<uint32_t> output;
    output.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(status) + owner * 8);
    SetFlag<HardEvent::S_MTE3>(EVENT_ID2);
    WaitFlag<HardEvent::S_MTE3>(EVENT_ID2);
    DataCopyPad(output, local, DataCopyExtParams(1, 4, 0, 0, 0));
    SetFlag<HardEvent::MTE3_S>(EVENT_ID2);
    WaitFlag<HardEvent::MTE3_S>(EVENT_ID2);
    trace.Mark(4301);
    trace.Publish();
}

} // namespace TileXREpHt::InterServerSendDevice
