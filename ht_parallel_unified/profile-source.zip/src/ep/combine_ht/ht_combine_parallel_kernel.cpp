/*
 * Copyright (c) 2026 TileXR Project.
 * Launches the HT Combine roles together. Each AIV executes one existing worker.
 */
#include "ht_combine_parallel.h"
#include "combine_ht_kernel.h"
#include "final_reduce_worker.h"
#include "inter_server_send_worker.h"
#include "local_return_worker.h"

extern "C" __global__ __aicore__ void tilexr_ep_ht_combine_parallel_kernel(TileXREpHt::ParallelKernelArgs args, GM_ADDR profile)
{
    const uint32_t core = AscendC::GetBlockIdx();
    auto local = args.attached.local;
    local.profiling = profile;
    const uint32_t localWorkers = TileXREpHt::kRanksPerServer + args.send.reducerCount;
    if (core < localWorkers) {
        RunCombineHT(local, args.attached.local_offset, args.attached.partial_out, args.attached.ready_base,
            args.attached.ready_magic, args.attached.partial_rows, args.attached.require_barrier != 0);
        return;
    }

    auto *returnForward = reinterpret_cast<GM_ADDR>(args.returnForward);
    const uint32_t worker = core - localWorkers;
    auto *workspace = local.workspace - args.attached.local_offset;
    if (worker < TileXREpHt::kRanksPerServer) {
        auto *comm = reinterpret_cast<__gm__ TileXR::CommArgs *>(local.comm);
        auto *info = reinterpret_cast<GM_ADDR>(TileXR::GetUDMAInfo(comm));
        TileXREpHt::LocalReturnDevice::Run(info, local.registry, workspace, returnForward, local.forward_counts,
            local.ranges, reinterpret_cast<GM_ADDR>(args.localReturnStatus), args.send, worker, args.localQpBase,
            args.localSignalOffset, profile);
    } else if (worker < TileXREpHt::kRanksPerServer + TileXREpHt::kOwners) {
        TileXREpHt::InterServerSendDevice::Run(local.comm, workspace, returnForward, local.forward_counts, local.ranges,
            reinterpret_cast<GM_ADDR>(args.crossReturnStatus), args.send, worker - TileXREpHt::kRanksPerServer, profile);
    } else {
        const uint32_t block = core - args.send.reducerCount - TileXREpHt::kParallelFixedWorkers;
        if (block < args.finalBlocks) {
            auto finalConfig = args.send;
            finalConfig.hidden = local.config.hidden;
            TileXREpHt::FinalReduceDevice::Run(workspace, reinterpret_cast<GM_ADDR>(args.serverMask),
                workspace + args.send.workspaceBytes, reinterpret_cast<GM_ADDR>(args.output),
                reinterpret_cast<GM_ADDR>(args.finalStatus), finalConfig, block, args.finalBlocks, profile);
        }
    }
}
