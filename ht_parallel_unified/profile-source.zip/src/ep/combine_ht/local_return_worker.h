/*
 * Copyright (c) 2026 TileXR Project.
 * Returns a gateway's partials to the eight source ranks on its own server.
 * Each AIV owns one destination and publishes its window flags after the rows.
 */
#pragma once

#include "kernel_operator.h"
#include <tilexr/profiling/device/sst_buffered_writer.h>
#include "ready.h"
#include <tilexr/comm/udma/device/api.h>
#include <tilexr/ep/final_reduce_types.h>

using namespace AscendC;
using namespace TileXREpHt;

namespace TileXREpHt::LocalReturnDevice {
using TileXR::Profiling::SstBufferedWriter;
using TileXR::Profiling::SstStageScope;
constexpr uint32_t kUbBlockBytes = 32;
constexpr uint32_t kForwardPageRows = 16;
constexpr uint32_t kDoorbellBatchRows = 32;

template <HardEvent event>
__aicore__ inline void Sync()
{
    SetFlag<event>(EVENT_ID0);
    WaitFlag<event>(EVENT_ID0);
}

template <typename T>
__aicore__ inline void Read(__gm__ T *address, LocalTensor<T> ub, uint32_t bytes)
{
    GlobalTensor<T> gm;
    gm.SetGlobalBuffer(address);
    gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
    Sync<HardEvent::S_MTE2>();
    DataCopyPad(ub, gm, DataCopyExtParams(1, bytes, 0, 0, 0), DataCopyPadExtParams<T> {false, 0, 0, 0});
    Sync<HardEvent::MTE2_S>();
}

template <typename T>
__aicore__ inline void Write(__gm__ T *address, LocalTensor<T> ub, uint32_t bytes)
{
    GlobalTensor<T> gm;
    gm.SetGlobalBuffer(address);
    Sync<HardEvent::S_MTE3>();
    DataCopyPad(gm, ub, DataCopyExtParams(1, bytes, 0, 0, 0));
    Sync<HardEvent::MTE3_S>();
}

class LocalReturn {
public:
    __aicore__ LocalReturn(SstBufferedWriter &trace, GM_ADDR workspace, GM_ADDR forward, GM_ADDR counts, GM_ADDR ranges,
        __gm__ TileXR::UDMAInfo *info, __gm__ TileXR::TileXRUDMARegistry *registry, const SendConfig &config,
        uint32_t worker, uint32_t qpBase, uint64_t signalOffset, TPipe &pipe)
        : trace_(trace), workspace_(workspace), config_(config), qp_(qpBase + worker),
          peer_(config.rank / kRanksPerServer * kRanksPerServer + worker), peerIsSelf_(peer_ == config.rank),
          rowBytes_(config.hidden * sizeof(uint16_t)),
          signalOffset_((signalOffset ? signalOffset : config.signalOffset) + uint64_t(worker) * kSlotBytes),
          forward_(reinterpret_cast<__gm__ int32_t *>(forward) + uint64_t(peer_) * config.forwardCapacity * (kUbBlockBytes / sizeof(int32_t))),
          remote_(reinterpret_cast<GM_ADDR>(registry->regions[peer_].base)), info_(info)
    {
        pipe.InitBuffer(meta_, kUbBlockBytes);
        pipe.InitBuffer(
            ranges_, ((config.chunks * 2 * sizeof(int32_t) + kUbBlockBytes - 1) / kUbBlockBytes) * kUbBlockBytes);
        pipe.InitBuffer(records_, kForwardPageRows * kUbBlockBytes);
        pipe.InitBuffer(ready_, config.reducerCount * kReadyUbStride);
        if (peerIsSelf_) {
            pipe.InitBuffer(row_, rowBytes_);
        } else {
            pipe.InitBuffer(wqe_, TileXR::TILEXR_UDMA_WQE_SCRATCH_BYTES);
            sq_ = TileXR::UDMAGetWQCtx(info_, peer_, qp_);
        }
        auto count = meta_.Get<int32_t>();
        Read(reinterpret_cast<__gm__ int32_t *>(counts) + peer_, count, sizeof(int32_t));
        count_ = count.GetValue(0);
        Read(reinterpret_cast<__gm__ int32_t *>(ranges) + uint64_t(peer_) * config.chunks * 2, ranges_.Get<int32_t>(),
            config.chunks * 2 * sizeof(int32_t));
    }

    __aicore__ Record LoadRecord(uint32_t, uint32_t index)
    {
        const uint32_t first = index / kForwardPageRows * kForwardPageRows;
        auto page = records_.Get<int32_t>();
        if (first != pageBegin_) {
            const uint32_t left = uint32_t(count_) - first;
            const uint16_t rows = left < kForwardPageRows ? left : kForwardPageRows;
            GlobalTensor<int32_t> gm;
            gm.SetGlobalBuffer(forward_ + uint64_t(first) * (kUbBlockBytes / sizeof(int32_t)));
            gm.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
            Sync<HardEvent::S_MTE2>();
            DataCopyPad(page, gm, DataCopyExtParams(rows, kUbBlockBytes, 0, 0, 0),
                DataCopyPadExtParams<int32_t> {false, 0, 0, 0});
            Sync<HardEvent::MTE2_S>();
            pageBegin_ = first;
        }
        const uint32_t at = (index - first) * kUbBlockBytes / sizeof(int32_t);
        return {page.GetValue(at), page.GetValue(at + 1), page.GetValue(at + 2), page.GetValue(at + 3),
            page.GetValue(at + 4), page.GetValue(at + 5)};
    }

    __aicore__ uint32_t Add(uint32_t, uint32_t, const Record &record)
    {
        const uint64_t source = (record.contributor < 0 ? config_.inputOffset : config_.partialOffset) +
            uint64_t(record.primary) * rowBytes_;
        const uint64_t target = ReturnOffset(config_, record.token, config_.rank);
        if (!peerIsSelf_) {
            SstStageScope timing(trace_, 4104, record.token);
            return Post(source, target, rowBytes_);
        }
        SstStageScope timing(trace_, 4106, record.token);
        auto row = row_.Get<uint8_t>();
        Read(workspace_ + source, row, rowBytes_);
        Write(workspace_ + target, row, rowBytes_);
        return Success;
    }

    __aicore__ uint32_t Run()
    {
        if (count_ < 0 || uint32_t(count_) > config_.forwardCapacity) {
            return InvalidRoute;
        }
        PeerSchedule peer {peer_, {}, 0, {}, count_};
        auto ranges = ranges_.Get<int32_t>();
        uint32_t tokenBegin = 0;
        uint32_t window = 0;
        uint32_t windowLast = WindowEnd(config_, 0);
        for (uint32_t chunk = 0; chunk < config_.chunks; ++chunk) {
            uint32_t ready;
            {
                SstStageScope timing(trace_, 4102, chunk);
                ready = WaitForReducedChunk(workspace_, config_, chunk, ready_.Get<int64_t>(), readyThrough_);
            }
            if (ready != Success) {
                return ready;
            }
            peer.range = {ranges.GetValue(chunk * 2), ranges.GetValue(chunk * 2 + 1)};
            if (peer.range.begin < 0 || peer.range.end < peer.range.begin || peer.range.end > count_) {
                return InvalidRoute;
            }
            const uint32_t tokenEnd = ChunkEnd(config_, chunk);
            while (peer.range.begin < peer.range.end) {
                const uint32_t result = SubmitPeerRows(config_, peer, tokenBegin, tokenEnd, *this);
                if (result) {
                    return result;
                }
            }
            if (chunk == windowLast) {
                const uint32_t result = PublishWindow(window++);
                if (result) {
                    return result;
                }
                windowLast = chunk + 1 < config_.chunks ? WindowEnd(config_, chunk + 1) : config_.chunks;
            }
            tokenBegin = tokenEnd;
        }
        return Success;
    }

    __aicore__ uint32_t Drain()
    {
        if (peerIsSelf_ || !outstanding_) {
            return Success;
        }
        SstStageScope timing(trace_, 4110);
        Ring();
        const uint32_t head = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(sq_->headAddr));
        const uint32_t result = TileXR::UDMAPollCQUntilSqTail(info_, peer_, qp_, head);
        outstanding_ = false;
        return result == TileXR::TILEXR_UDMA_STATUS_SUCCESS ? Success : TransportError;
    }

private:
    __aicore__ void Ring()
    {
        if (pending_) {
            const uint32_t head = TileXR::UDMASstLoadState(reinterpret_cast<__gm__ uint32_t *>(sq_->headAddr));
            TileXR::UDMARingDoorbell(head, sq_);
            pending_ = 0;
        }
    }

    __aicore__ uint32_t Post(uint64_t source, uint64_t target, uint32_t bytes)
    {
        auto scratch = wqe_.Get<uint8_t>();
        auto *dst = remote_ + target;
        auto *src = workspace_ + source;
        uint32_t result = TileXR::UDMAPostSend<TileXR::UDMAOpcode::WRITE, false>(
            info_, scratch, dst, src, peer_, qp_, bytes, nullptr, TileXR::TILEXR_UDMA_SQE_FLAG_ORDERED_COMPLETION);
        if (result == TileXR::TILEXR_UDMA_STATUS_SQ_FULL && Drain() == Success) {
            result = TileXR::UDMAPostSend<TileXR::UDMAOpcode::WRITE, false>(
                info_, scratch, dst, src, peer_, qp_, bytes, nullptr, TileXR::TILEXR_UDMA_SQE_FLAG_ORDERED_COMPLETION);
        }
        if (result != TileXR::TILEXR_UDMA_STATUS_SUCCESS) {
            return TransportError;
        }
        outstanding_ = true;
        if (++pending_ == kDoorbellBatchRows) {
            Ring();
        }
        return Success;
    }

    __aicore__ uint32_t PublishWindow(uint32_t window)
    {
        SstStageScope timing(trace_, 4108, window);
        const uint64_t target = config_.workspaceBytes + LocalReturnReadyOffset(config_.rank % kRanksPerServer, window);
        auto flag = meta_.Get<uint64_t>();
        flag.SetValue(0, uint64_t(config_.magic));
        if (peerIsSelf_) {
            Write(reinterpret_cast<__gm__ uint64_t *>(workspace_ + target), flag, sizeof(uint64_t));
            return Success;
        }
        const uint32_t drained = Drain();
        if (drained) {
            return drained;
        }
        Write(reinterpret_cast<__gm__ uint64_t *>(workspace_ + signalOffset_), flag, sizeof(uint64_t));
        const uint32_t status = Post(signalOffset_, target, sizeof(uint64_t));
        Ring();
        return status;
    }

    SstBufferedWriter &trace_;
    GM_ADDR workspace_;
    const SendConfig &config_;
    uint32_t qp_, peer_;
    bool peerIsSelf_;
    uint32_t rowBytes_;
    uint64_t signalOffset_;
    __gm__ int32_t *forward_;
    GM_ADDR remote_;
    __gm__ TileXR::UDMAInfo *info_;
    __gm__ TileXR::UDMAWQCtx *sq_ = nullptr;
    int32_t count_ = 0;
    int32_t readyThrough_ = 0;
    uint32_t pageBegin_ = UINT32_MAX;
    uint32_t pending_ = 0;
    bool outstanding_ = false;
    TBuf<QuePosition::VECCALC> meta_, ranges_, records_, ready_, row_;
    TBuf<TPosition::VECOUT> wqe_;
};
__aicore__ inline void Run(GM_ADDR info, GM_ADDR registry, GM_ADDR workspace, GM_ADDR forward, GM_ADDR counts, GM_ADDR ranges, GM_ADDR status, SendConfig config, uint32_t worker, uint32_t qpBase, uint64_t signalOffset, GM_ADDR profile)
{
    SstBufferedWriter trace;
    trace.Initialize(profile, GetBlockIdx());
    trace.Mark(4100);
    TPipe pipe;
    TBuf<QuePosition::VECCALC> queueStateScratch;
    pipe.InitBuffer(queueStateScratch, 32);
    LocalReturn run(trace, workspace, forward, counts, ranges, reinterpret_cast<__gm__ TileXR::UDMAInfo *>(info),
        reinterpret_cast<__gm__ TileXR::TileXRUDMARegistry *>(registry), config, worker, qpBase, signalOffset, pipe);
    trace.Bind(pipe);
    const uint32_t result = run.Run();
    const uint32_t drained = run.Drain();
    TBuf<QuePosition::VECCALC> resultBuffer;
    pipe.InitBuffer(resultBuffer, kUbBlockBytes);
    auto output = resultBuffer.Get<uint32_t>();
    output.SetValue(0, result == Success ? drained : result);
    Write(reinterpret_cast<__gm__ uint32_t *>(status) + worker * 8, output, sizeof(uint32_t));
    trace.Mark(4101);
    trace.Publish();
}

} // namespace TileXREpHt::LocalReturnDevice
