/* Copyright (c) 2026 TileXR Project. */
// Buffer SST profiling markers in UB and export each AIV's lane through MTE3.
#pragma once

#include "kernel_operator.h"

namespace TileXR::Profiling {
class SstBufferedWriter {
public:
    static constexpr uint32_t Bytes = 8192;
    static constexpr uint64_t Magic = 0x5458525052463332ULL;

    __aicore__ void Initialize(GM_ADDR base, uint32_t block)
    {
        target_ = base + uint64_t(block) * Bytes;
    }

    __aicore__ void Bind(AscendC::TPipe &pipe)
    {
        pipe.InitBuffer(buffer_, Bytes);
        data_ = buffer_.Get<uint64_t>();
        bound_ = true;
        if (pending_ != 0) {
            RecordAt(pending_, first_);
        }
    }

    __aicore__ bool IsBound() const { return bound_; }

    __aicore__ void RecordAt(uint32_t event, uint64_t tick, uint32_t detail = 0)
    {
        if (!bound_) {
            pending_ = event;
            first_ = tick;
            return;
        }
        if (cursor_ + 2 > Bytes / sizeof(uint64_t)) {
            ++lost_;
            return;
        }
        data_.SetValue(cursor_++, tick);
        data_.SetValue(cursor_++, uint64_t(event) | (uint64_t(detail) << 32));
    }

    __aicore__ void Mark(uint32_t event, uint32_t detail = 0)
    {
        RecordAt(event, static_cast<uint64_t>(AscendC::GetSystemCycle()), detail);
    }

    __aicore__ void Publish()
    {
        using namespace AscendC;
        data_.SetValue(0, Magic);
        data_.SetValue(1, cursor_);
        data_.SetValue(2, lost_);
        for (uint32_t i = 3; i < 8; ++i) {
            data_.SetValue(i, 0);
        }
        const uint32_t padded = (cursor_ + 3) & ~3U;
        for (uint32_t i = cursor_; i < padded; ++i) {
            data_.SetValue(i, 0);
        }
        GlobalTensor<uint64_t> target;
        target.SetGlobalBuffer(reinterpret_cast<__gm__ uint64_t *>(target_));
        SetFlag<HardEvent::S_MTE3>(EVENT_ID1);
        WaitFlag<HardEvent::S_MTE3>(EVENT_ID1);
        DataCopyPad(target, data_, DataCopyExtParams(1, padded * sizeof(uint64_t), 0, 0, 0));
        SetFlag<HardEvent::MTE3_S>(EVENT_ID1);
        WaitFlag<HardEvent::MTE3_S>(EVENT_ID1);
    }

private:
    GM_ADDR target_ = nullptr;
    AscendC::TBuf<AscendC::QuePosition::VECCALC> buffer_;
    AscendC::LocalTensor<uint64_t> data_;
    uint64_t first_ = 0;
    uint32_t pending_ = 0;
    uint32_t cursor_ = 8;
    uint32_t lost_ = 0;
    bool bound_ = false;
};

class SstStageScope {
public:
    __aicore__ SstStageScope(SstBufferedWriter &writer, uint32_t begin, uint32_t detail = 0)
        : writer_(writer), begin_(begin), detail_(detail) { writer_.Mark(begin, detail); }
    __aicore__ ~SstStageScope() { writer_.Mark(begin_ + 1, detail_); }
private:
    SstBufferedWriter &writer_;
    uint32_t begin_, detail_;
};
}
