# Copyright (c) 2026 TileXR Project.
"""Compare the addressed SST dumps with the fixture values and output guards."""
import hashlib
import json
from pathlib import Path
import struct
import sys

from exports import V310_DECODER_SHA256, reconstruct_die_output


def is_nan(bits, code, dtype):
    mask, fraction = ((0x7F800000, 0x007FFFFF) if code == "I" else
                      (0x7C00, 0x03FF) if dtype == "fp16" else (0x7F80, 0x007F))
    return (bits & mask) == mask and bool(bits & fraction)


def compare(actual, expected, code, dtype):
    counts = {"tested": 0, "bitwise_differences": 0, "mismatches": 0, "first": []}
    for position, ((got,), (want,)) in enumerate(zip(struct.iter_unpack("<" + code, actual),
                                                    struct.iter_unpack("<" + code, expected), strict=True)):
        counts["tested"] += 1
        if got == want:
            continue
        counts["bitwise_differences"] += 1
        if is_nan(want, code, dtype) and is_nan(got, code, dtype):
            continue  # NaN payload and quieting are not required to match an independent oracle.
        counts["mismatches"] += 1
        if len(counts["first"]) < 4:
            counts["first"].append([position, hex(want), hex(got)])
    return counts


def check(root, decoder):
    if hashlib.sha256(decoder.read_bytes()).hexdigest() != V310_DECODER_SHA256:
        raise ValueError("unexpected decoder")
    results = []
    for row in json.loads((root / "expected.json").read_text()):
        result = {key: row[key] for key in ("rank", "mode", "dtype")}
        for name, spec in row["references"].items():
            region = row["exports"][name]
            expected = (root / spec["golden"]).read_bytes()
            paths = [root / "bin" / f"david_{row['rank']}_die{die}_{name}.bin" for die in (1, 2)]
            try:
                data = reconstruct_die_output(paths, region["addr"] - row["base"], region["size"], decoder)
            except (OSError, ValueError) as error:
                result[name] = {"export_error": type(error).__name__, "dump_files": sum(p.is_file() for p in paths)}
                continue
            checked = compare(data[512:512 + len(expected)], expected, spec["code"], spec["dtype"])
            checked["guards_ok"] = all(byte == 0xA5 for byte in data[:512] + data[512 + len(expected):])
            result[name] = checked
        results.append(result)
    return results


if __name__ == "__main__":
    print(json.dumps(check(Path(sys.argv[1]), Path(sys.argv[2]))))
