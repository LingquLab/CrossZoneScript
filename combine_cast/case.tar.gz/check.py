# Copyright (c) 2026 TileXR Project.
"""Compare the addressed SST dumps with the fixture values and output guards."""
import hashlib
import json
from pathlib import Path
import struct
import sys

# AddrAnalyzerV310 binary used for the Die mapping below.
V310_DECODER_SHA256 = "6d4cd3b729177646ca1c43d57971e5266a946405b6f820f3d0d914114b7ccfce"


def read_addressed(path, address, size):
    if address < 0 or size <= 0:
        raise ValueError("Need a nonempty chip-local output range")
    result, seen = bytearray(size), bytearray(size)
    with Path(path).open("rb") as stream:
        while True:
            record = stream.read(520)
            if not record:
                break
            if len(record) != 520:
                raise ValueError("Truncated addressed-512 dump: " + str(path))
            base = int.from_bytes(record[:8], "little")
            left, right = max(address, base), min(address + size, base + 512)
            for current in range(left, right):
                index, value = current - address, record[8 + current - base]
                if seen[index] and result[index] != value:
                    raise ValueError("Conflicting dump records: " + str(path))
                result[index], seen[index] = value, 1
    if not all(seen):
        raise ValueError("Missing dump bytes: " + str(path))
    return bytes(result)


def reconstruct_die_output(paths, address, size):
    if len(paths) != 2 or size <= 0 or address < 0:
        raise ValueError("Need two Die dumps and a nonempty chip-local range")
    copies = [read_addressed(path, address, size) for path in paths]
    result, offset = bytearray(size), 0
    while offset < size:
        current = address + offset
        die = ((current >> 9) ^ (current >> 16) ^ (current >> 23)) & 1
        count = min(size - offset, 512 - current % 512)
        result[offset : offset + count] = copies[die][offset : offset + count]
        offset += count
    return bytes(result)


def is_nan(bits, code, dtype):
    mask, fraction = ((0x7F800000, 0x007FFFFF) if code == "I" else
                      (0x7C00, 0x03FF) if dtype == "fp16" else (0x7F80, 0x007F))
    return (bits & mask) == mask and bool(bits & fraction)


def compare(actual, expected, code, dtype):
    if len(actual) != len(expected):
        raise ValueError("Actual and expected output lengths differ")
    counts = {"tested": 0, "bitwise_differences": 0, "mismatches": 0, "first": []}
    actual_words = struct.iter_unpack("<" + code, actual)
    expected_words = struct.iter_unpack("<" + code, expected)
    for position, ((got,), (want,)) in enumerate(zip(actual_words, expected_words)):
        counts["tested"] += 1
        if got == want:
            continue
        counts["bitwise_differences"] += 1
        if is_nan(want, code, dtype) and is_nan(got, code, dtype):
            continue  # NaN payload and quieting are not required to match an independent oracle.
        counts["mismatches"] += 1
        if len(counts["first"]) < 4:
            counts["first"].append([position, hex(want), hex(got)])
    return counts


def check(root, decoder):
    if hashlib.sha256(decoder.read_bytes()).hexdigest() != V310_DECODER_SHA256:
        raise ValueError("unexpected decoder")
    results = []
    for row in json.loads((root / "expected.json").read_text()):
        result = {key: row[key] for key in ("rank", "mode", "dtype")}
        for name, spec in row["references"].items():
            region = row["exports"][name]
            expected = (root / spec["golden"]).read_bytes()
            paths = [root / "bin" / f"david_{row['rank']}_die{die}_{name}.bin" for die in (1, 2)]
            try:
                data = reconstruct_die_output(paths, region["addr"] - row["base"], region["size"])
            except (OSError, ValueError) as error:
                result[name] = {"export_error": type(error).__name__, "dump_files": sum(p.is_file() for p in paths)}
                continue
            checked = compare(data[512:512 + len(expected)], expected, spec["code"], spec["dtype"])
            checked["guards_ok"] = all(byte == 0xA5 for byte in data[:512] + data[512 + len(expected):])
            result[name] = checked
        results.append(result)
    return results


if __name__ == "__main__":
    print(json.dumps(check(Path(sys.argv[1]), Path(sys.argv[2]))))
