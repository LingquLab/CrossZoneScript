import json
from pathlib import Path
import sys

import yaml


def replace(node, keys, original):
    if isinstance(node, dict):
        for key, value in node.items():
            if key in keys:
                original.setdefault(key, []).append(value)
                node[key] = keys[key]
            else:
                replace(value, keys, original)
    elif isinstance(node, list):
        for value in node:
            replace(value, keys, original)


case = Path(sys.argv[1])
v310 = case / "v310_config"
ubus = case / "UBusSim_config"
arch = v310 / "davidV100_simulator_config.yml"
network = ubus / "UBusSim_simulator_config.yml"
network_doc = yaml.safe_load(network.read_text())
ranks = len(json.loads((case / "workload.yml").read_text())["workload_config"])
jetty_num = ranks * int(network_doc["jetty_config"]["qp_num"]) // 2
old = {}
for path in sorted(v310.glob("*.yml")) + sorted(ubus.glob("*.yml")):
    if path.name in {"workload_config.yml", "daw_config.yml"}:
        continue
    keys = ({"chip_num": ranks} if path.parent == v310 else
            {"jetty_num": jetty_num, "stat_host_range": [0, ranks-1]})
    data = yaml.safe_load(path.read_text())
    matches = {}
    replace(data, keys, matches)
    if matches:
        path.write_text(yaml.safe_dump(data, sort_keys=False))
        old[path.name] = matches
assert yaml.safe_load(arch.read_text())["architecture_config"]["chip_num"] == ranks
assert yaml.safe_load(network.read_text())["jetty_config"]["jetty_num"] == jetty_num
network_doc = yaml.safe_load(network.read_text())
switches = network_doc["simulator_info"]
assert switches["V310_flag"] is True and switches["UBusSim_flag"] is True
switches["UBusSim_flag"] = False
network.write_text(yaml.safe_dump(network_doc, sort_keys=False))
assert yaml.safe_load(network.read_text())["simulator_info"]["UBusSim_flag"] is False
print(json.dumps({"chip_num": ranks, "ubus_sim_enabled": False, "original_rank_fields": old}))
