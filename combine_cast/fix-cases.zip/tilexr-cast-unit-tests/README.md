# TileXR Cast 单测复现包

包内有三份 Ascend C 探针源码和五个已执行的 SST 用例。各用例的 `workload.yml` 固定输入文件、GM 地址、参数偏移和启动规格。输入位模式、参考输出和 guard 初始值均随包提供。每次运行读取同一份输入，`values.tsv` 按元素索引列出输入和期望位模式。

| 用例目录（`cases/` 下） | Kernel 源码（`source/` 下） | 固定参数 | 已记录的 SST 数值不匹配 |
| --- | --- | --- | --- |
| `cast-fp16` | `cast/cast_probe.cpp` | FP16（dtype 3），每个方向 65 元素 | 升精度 0/65，降精度 65/65 |
| `cast-bf16` | `cast/cast_probe.cpp` | BF16（dtype 11），每个方向 65 元素 | 升精度 11/65，降精度 65/65 |
| `aligned-fp16` | `cast/cast_aligned_probe.cpp` | FP16（dtype 3），64 个 FP32 输入 | 16 位直接写回 64/64，向量寄存器内转回 FP32 后写回 0/64 |
| `aligned-bf16` | `cast/cast_aligned_probe.cpp` | BF16（dtype 11），64 个 FP32 输入 | 16 位直接写回 64/64，向量寄存器内转回 FP32 后写回 11/64 |
| `bf16-writeback` | `bf16-writeback/probe.cpp` | BF16，16 个 FP32 输入 | UB 快照 16/16，Cast 结果搬到 GM 16/16，正确 BF16 位模式搬到 GM 的对照 0/16 |

上述五个用例均使用单 chip、单 AIV、单 SST 线程，SST 退出码为 0，输出 guard 均通过。基础探针用两组独立输入测 `CAST_NONE` 升精度和 `CAST_RINT` 降精度。对齐探针让两份输出共用降精度的向量寄存器。BF16 写回探针在 UB 中通过标量读取得到快照，并以同样的 32 B 搬运参数校验 GM 写回。

## 查看固定入参

- `workload.yml` 保存 kernel 入口、原生对象路径、GM 地址、dtype 和其他 ABI 参数。对齐探针的元素数为源码中的常量 `64`，写回探针为 `16`。
- `values.tsv` 的索引从 0 开始。基础探针前两列数据是升精度的一组输入和期望，后两列数据是降精度的另一组输入和期望。对齐和写回探针每行只有一组输入。
- `expected.json` 把导出区域对应到 `*.golden`。写回探针使用 `ub/manifest.json` 和 `ub/control.bin`。
- `cases.json` 记录每个用例的 SST 容器挂载路径、入口、原生对象 SHA-256 和原始用例归档 SHA-256。包中的原生对象由 CANN 9.1 Ascend950 构建。
- `source/cast/fixture.py` 记录基础探针输入的生成方式，`source/bf16-writeback/package.py` 保留写回探针原始打包脚本及固定向量。该打包脚本引用原测试机临时路径。直接复现时使用 `cases/` 下已经生成的文件。

例如，`cast-fp16/values.tsv` 的第 0 个降精度输入是 FP32 位模式 `0x3f800fff`，期望 FP16 输出 `0x3c00`，历史 SST 输出为 `0x0100`。写回探针的第 0 个输入是 `0x00000000`，期望 BF16 `0x0000`，UB 和 GM 的历史输出均为 `0x0100`。

## 运行参考测试

在解包后的根目录运行。

```bash
sha256sum -c SHA256SUMS
python3 -m unittest discover -s source/cast -v
```

## 复用 SST 用例

原测试使用 V310 单芯片自测模式。将选中的用例目录挂载到 `cases.json` 的 `mount` 路径，并在运行目录准备 V310 平台的 `v310_config/`、`UBusSim_config/`、`test_UBusSim.py` 、`installed_model.py` 和对应的 `environment.snapshot.json`。五个用例均使用同一模式，V310 开启，UBusSim 关闭，`chip_num` 为 1。前四个用例的 `sync_rank_config.py` 可以在复制模板后同步芯片参数并关闭 UBusSim。

从工作负载文件所在的目录运行。BF16 写回用例的运行目录是挂载目录下的 `ub/`。

```bash
cp workload.yml v310_config/workload_config.yml
source /opt/sim/sst-env.sh
/opt/sim/local/sstcore/bin/sst -n 1 ./test_UBusSim.py
```

等待两片 Die 的输出落在运行目录的 `bin/`，然后运行相应检查器。

```bash
# 基础探针或对齐探针
python3 check.py . /opt/sim/plugins/libDavinciSimulator.so

# BF16 写回探针，从 ub/ 运行
python3 ../check.py .
```

检查器使用的 V310 模型 SHA-256 为 `6d4cd3b729177646ca1c43d57971e5266a946405b6f820f3d0d914114b7ccfce`。检查器 JSON 中的 `mismatches` 或 `errors` 是实际错值数，`first` 给出元素索引、期望值和实际值。基础和对齐探针的 `bitwise_differences` 还计入仅 NaN 编码不同的项。将这些字段和 guard 检查一起判断，检查器退出码 0 表示已成功生成报告。
