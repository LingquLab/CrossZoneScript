#include "kernel_operator.h"

using namespace AscendC;
namespace {
constexpr uint32_t kElements = 16;
constexpr uint32_t kPackedWords = kElements / 2;
template <HardEvent event>
__aicore__ inline void Sync()
{
    SetFlag<event>(EVENT_ID0);
    WaitFlag<event>(EVENT_ID0);
}
}

extern "C" __global__ __aicore__ void tilexr_probe_bf16_writeback(
    GM_ADDR input, GM_ADDR control, GM_ADDR diagnostic, GM_ADDR output)
{
    TPipe pipe;
    TBuf<TPosition::VECCALC> inputBuf, castBuf, scalarBuf, controlBuf;
    pipe.InitBuffer(inputBuf, kElements * sizeof(float));
    pipe.InitBuffer(castBuf, 32);
    pipe.InitBuffer(scalarBuf, 32);
    pipe.InitBuffer(controlBuf, 32);
    GlobalTensor<float> in;
    GlobalTensor<uint32_t> bytesIn, captured;
    GlobalTensor<bfloat16_t> out;
    in.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(input));
    bytesIn.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(control));
    captured.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(diagnostic));
    out.SetGlobalBuffer(reinterpret_cast<__gm__ bfloat16_t *>(output));

    auto inputLocal = inputBuf.Get<float>();
    auto castLocal = castBuf.Get<bfloat16_t>();
    auto controlLocal = controlBuf.Get<uint32_t>();
    auto scalarLocal = scalarBuf.Get<uint32_t>();
    DataCopy(inputLocal, in, kElements);
    DataCopy(controlLocal, bytesIn, kPackedWords);
    Sync<HardEvent::MTE2_V>();
    Sync<HardEvent::MTE2_MTE3>();
    Cast(castLocal, inputLocal, RoundMode::CAST_RINT, kElements);
    Sync<HardEvent::V_S>();
    auto castWords = castLocal.ReinterpretCast<uint32_t>();
    for (uint32_t word = 0; word < kPackedWords; ++word) {
        scalarLocal.SetValue(word, castWords.GetValue(word));
    }
    Sync<HardEvent::S_MTE3>();
    DataCopy(captured, scalarLocal, kPackedWords);
    Sync<HardEvent::V_MTE3>();
    DataCopy(out, castLocal, kElements);
    DataCopy(out[kElements], controlLocal.ReinterpretCast<bfloat16_t>(), kElements);
    Sync<HardEvent::MTE3_S>();
}
