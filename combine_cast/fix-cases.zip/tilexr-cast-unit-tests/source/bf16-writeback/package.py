import hashlib
import io
import json
from pathlib import Path
import struct
import tarfile

base=Path("/tmp/crosszone-alltoall-b4f4660a")
stage=Path(__file__).parent
suite=base/"writeback_probe"
model=stage/"probe.o"
with tarfile.open(base/"final_reduce/cases.tar.gz") as orig:
    decode=orig.extractfile("decode.py").read()
files={"decode.py":decode,"probe.o":model.read_bytes(),"check.py":(suite/"check.py").read_bytes()}
out=stage/"case"/"ub"
out.mkdir(parents=True,exist_ok=True)
runroot="/work/final-reduce-bf16-writeback"
values=[0, -0.25, 1.0, 1.25, 2.5, 8.0, -4.75, 0.5, 128.5, -128.5, 0.03125, 1024.0, -1.0, -1.25, 0.75, 20.0]
data=struct.pack("<16f",*values)
raw=struct.unpack("<16I",data)
gold=struct.pack("<16H",*((x+0x7fff+((x>>16)&1))>>16 for x in raw))
params,exports={},{}
for i,(name,content) in enumerate((("input",data),("control",gold),("diagnostic",b"\xa5"*1536),("output",b"\xa5"*1536))):
    offset=0x100000000 + i*0x1000
    path=f"{name}.bin"
    files[f"ub/{path}"]=content
    params[f"load_{name}"]=dict(value=offset,param_offset=str(32+i*8),param_type="11",input_bin=f"{runroot}/ub/{path}")
    params[name]=dict(value=offset+(512 if i>=2 else 0),param_offset=str(i*8),param_type="11")
    if i>=2:
        regions=["cast_ub_scalar"] if i==2 else ["cast_gm","control_gm"]
        exports[name]=dict(addr=offset,size=len(content),payload_size=32*len(regions),regions=regions)
work=dict(gm_size=0x2000000000,sys_va_base_addr=0,ub_base_addr=0x80000,stack_base_addr=0x100000,
          param_base_addr=0x80000000,block_dim=1,subblock_dim=1,kernel_file=f"{runroot}/probe.o",
          vec_func="tilexr_probe_bf16_writeback",bin_param=dict(addr=0x40000000,size=model.stat().st_size),
          kernel_param=params,output_param={k:{q:v[q] for q in ("addr","size")} for k,v in exports.items()})
files["ub/workload.yml"]=json.dumps({"workload_config":{"chip0":work}}).encode()
files["ub/manifest.json"]=json.dumps({"case":"ub","hidden":16,"blocks":1,"exports":exports}).encode()
for key,content in files.items():
    if key.startswith("ub/"):
        (out/Path(key).name).write_bytes(content)
archive=suite/"cases.tar.gz"
with tarfile.open(archive,"w:gz") as f:
    for key,content in sorted(files.items()):
        member=tarfile.TarInfo(key);member.size=len(content)
        f.addfile(member,io.BytesIO(content))
meta=dict(object="probe.o",object_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),
          archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(suite/"identity.json").write_text(json.dumps(meta,indent=2)+"\n")
print(meta)
