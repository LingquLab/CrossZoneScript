# Copyright (c) 2026 TileXR Project.
"""Prepare SST arguments and independent bitwise references for Memory Combine."""
import argparse
import json
import math
from pathlib import Path
import struct

GM_SIZE = 0x2000000000
STRIPE = 512
PAYLOAD = 480
GUARD = 0xA5
COMBINE = "tilexr_ep_combine_memory_kernel"
PROBE = "tilexr_combine_cast_probe"


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def narrow(value, dtype):
    if dtype == "fp16":
        try:
            return struct.unpack("<H", struct.pack("<e", value))[0]
        except OverflowError:
            return 0xFC00 if value < 0 else 0x7C00
    bits = struct.unpack("<I", struct.pack("<f", value))[0]
    if math.isnan(value):
        return (bits >> 16) | 0x40
    return ((bits + 0x7FFF + ((bits >> 16) & 1)) >> 16) & 0xFFFF


def widen(bits, dtype):
    if dtype == "fp16":
        return struct.unpack("<e", struct.pack("<H", bits))[0]
    return struct.unpack("<f", struct.pack("<I", bits << 16))[0]


def words(values, code):
    return struct.pack("<" + str(len(values)) + code, *values)


class Chip:
    def __init__(self, root, runtime_root, rank, entry, kernel, args_count, blocks=1):
        self.root = root
        self.folder = root / f"chip{rank}"
        self.folder.mkdir()
        self.rank = rank
        self.base = rank * GM_SIZE
        self.next_image = self.base + 0x100000000
        self.runtime_root = runtime_root
        self.params = {}
        self.outputs = {}
        self.references = {}
        self.next_param = args_count * 8
        self.workload = {
            "gm_size": GM_SIZE, "sys_va_base_addr": self.base, "ub_base_addr": 0x80000,
            "stack_base_addr": 0x100000, "param_base_addr": self.base + 0x80000000,
            "block_dim": blocks, "subblock_dim": 1,
            "kernel_file": f"{runtime_root}/{kernel.name}", "vec_func": entry,
            "bin_param": {"addr": self.base + 0x40000000, "size": kernel.stat().st_size},
            "kernel_param": self.params, "output_param": self.outputs,
        }

    def image(self, name, data):
        address = self.next_image
        self.next_image += (len(data) + STRIPE - 1) // STRIPE * STRIPE
        path = self.folder / (name + ".bin")
        path.write_bytes(data)
        self.params["load_" + name] = {
            "value": address, "param_offset": str(self.next_param), "param_type": "11",
            "input_bin": f"{self.runtime_root}/{path.relative_to(self.root)}",
        }
        self.next_param += 8
        return address

    def output(self, name, reference, code, dtype):
        padded = (len(reference) + STRIPE - 1) // STRIPE * STRIPE
        address = self.image(name + "_sentinels", bytes([GUARD]) * (padded + 2 * STRIPE))
        self.outputs[name] = {"addr": address, "size": padded + 2 * STRIPE}
        expected = self.folder / (name + ".golden")
        expected.write_bytes(reference)
        self.references[name] = {"code": code, "dtype": dtype, "golden": str(expected.relative_to(self.root))}
        return address + STRIPE

    def bind(self, pointers, scalars):
        arguments = [(name, value, 11) for name, value in pointers.items()]
        arguments += [(name, value, 6) for name, value in scalars.items()]
        if len(arguments) * 8 != min(int(p["param_offset"]) for p in self.params.values()):
            raise ValueError("Kernel argument layout differs")
        for index, (name, value, code) in enumerate(arguments):
            self.params[name] = {"value": value, "param_offset": str(index * 8), "param_type": str(code)}


def make_combine(chip, abi, ranks, dtype, hidden, mode, weighted, shared):
    tokens, topk = 4, 2
    ulp = 2 ** (-10 if dtype == "fp16" else -7)
    pairs = [(1, ulp), (1 + ulp, ulp), (-1, -ulp), (-1 - ulp, -ulp),
             (9, -9), (2 ** -10, 2 ** -11), (-3, 5), (6, -0.25)]
    scales = [1.0, 0.5] * tokens if weighted else [1.0, 1.0] * tokens
    rows = []
    for token in range(tokens):
        patterns = [pairs[(col + token) % len(pairs)] for col in range(hidden)]
        rows.extend(words([narrow(p[slot], dtype) for p in patterns], "H") for slot in range(topk))
    extra = [narrow((-1) ** (i % 3) * 0.125, dtype) for i in range(tokens * hidden)]
    expected = []
    for token in range(tokens):
        left, right = [struct.unpack(f"<{hidden}H", row) for row in rows[token * topk:(token + 1) * topk]]
        for col, pair in enumerate(zip(left, right)):
            terms = [f32(widen(raw, dtype) * scales[token * topk + slot]) for slot, raw in enumerate(pair)]
            value = f32(terms[0] + terms[1])
            if shared:
                value = f32(value + widen(extra[token * hidden + col], dtype))
            expected.append(narrow(value, dtype))

    if mode == "receive":
        packed = b"".join(payload.ljust(PAYLOAD, b"\0") + words([1.0] * 8, "f")
                          for row in rows for start in range(0, len(row), PAYLOAD)
                          for payload in (row[start:start + PAYLOAD],))
    else:
        packed = bytes(tokens * topk * ((hidden * 2 + PAYLOAD - 1) // PAYLOAD) * STRIPE)
    window = chip.image("window", packed)
    comm = bytearray(abi["size"])
    struct.pack_into("<i", comm, abi["rank"], chip.rank)
    struct.pack_into("<i", comm, abi["rank_size"], ranks)
    struct.pack_into("<Q", comm, abi["peer_mems"] + 8 * chip.rank, window - abi["window_offset"])
    send = mode == "self_send"
    routes = [value for token in range(tokens) for slot in range(topk) for value in (chip.rank, token, slot)]
    chip.bind({
        "commArgsGM": chip.image("comm", comm), "expertOutGM": chip.image("expert", b"".join(rows)),
        "assistInfoForCombineGM": chip.image("assist", words(routes, "i")),
        "sendCountsGM": chip.image("counts", words([0] * (2 * ranks - 1) + [len(rows) if send else 0], "i")),
        "expertScalesGM": chip.image("scales", words(scales, "f")) if weighted else 0,
        "xActiveMaskGM": 0, "sharedExpertXGM": chip.image("shared", words(extra, "H")) if shared else 0,
        "yOutGM": chip.output("y", words(expected, "H"), "H", dtype),
    }, {
        "bs": tokens, "h": hidden, "topK": topk, "moeExpertNum": 2 * ranks, "sharedExpertNum": 0,
        "sharedExpertRankNum": 0, "globalBs": tokens, "activeMaskType": 0, "quantMode": 0,
        "dtype": abi[dtype], "magic": 2,
    })
    return {"dtype": dtype, "hidden": hidden, "mode": mode, "weighted": weighted, "shared": shared}


def make_probe(chip, abi, dtype):
    exp = 0x7C00 if dtype == "fp16" else 0x7F80
    min_normal = 0x0400 if dtype == "fp16" else 0x0080
    one = narrow(1, dtype)
    low = [0, 0x8000, 1, 0x8001, min_normal - 1, min_normal,
           one, one + 1, exp - 1, exp, exp | 0x8000, exp | 1]
    ulp = widen(one + 1, dtype) - 1
    half_way = 1 + ulp / 2
    near = [half_way - 2 ** -23, half_way, half_way + 2 ** -23, 1 + 1.5 * ulp]
    min_sub = widen(1, dtype)
    wide = near + [-v for v in near] + [0.0, -0.0, min_sub / 2, min_sub, min_sub * 1.5,
                                         widen(exp - 1, dtype), math.inf, -math.inf, math.nan]
    count = 65
    low = (low * count)[:count]
    wide = [f32(v) for v in (wide * count)[:count]]
    chip.bind({
        "low": chip.image("low", words(low, "H")), "wide": chip.image("wide", words(wide, "f")),
        "outWide": chip.output("widen", words([widen(v, dtype) for v in low], "f"), "I", dtype),
        "outLow": chip.output("narrow", words([narrow(v, dtype) for v in wide], "H"), "H", dtype),
    }, {"count": count, "dtype": abi[dtype]})
    return {"dtype": dtype, "mode": "cast_probe"}


def prepare(root, runtime_root, abi, combine_object, probe_object, ranks):
    root.mkdir()
    layout = []
    workloads = {}
    for rank in range(ranks):
        dtype = ("fp16", "bf16")[rank % 2]
        case = (rank // 2) % 4
        selecting_probe = case == 3
        entry, binary, arg_count = (PROBE, probe_object, 6) if selecting_probe else (COMBINE, combine_object, 19)
        chip = Chip(root, runtime_root, rank, entry, binary, arg_count)
        if selecting_probe:
            test = make_probe(chip, abi, dtype)
        else:
            test = make_combine(chip, abi, ranks, dtype, 496 if case == 2 else 256,
                                "self_send" if case == 1 else "receive", case < 2, case == 2)
        workloads[f"chip{rank}"] = chip.workload
        layout.append(dict(test, rank=rank, base=chip.base, exports=chip.workload["output_param"],
                           references=chip.references))
    (root / "workload.yml").write_text(json.dumps({"workload_config": workloads}, indent=2))
    (root / "expected.json").write_text(json.dumps(layout, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("runtime_root")
    parser.add_argument("abi", type=Path)
    parser.add_argument("combine_object", type=Path)
    parser.add_argument("probe_object", type=Path)
    parser.add_argument("--ranks", type=int, choices=(16, 32), default=16)
    args = parser.parse_args()
    prepare(args.output, args.runtime_root, json.loads(args.abi.read_text()),
            args.combine_object, args.probe_object, args.ranks)
