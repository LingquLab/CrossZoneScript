// Copyright (c) 2026 TileXR Project.
// Export both directions of the Memory Combine Cast independently of transport and reduction.
#include "kernel_operator.h"

namespace {
template<class T>
__aicore__ void Run(GM_ADDR low, GM_ADDR wide, GM_ADDR outWide, GM_ADDR outLow, uint32_t count)
{
    using namespace AscendC;
    constexpr uint32_t capacity = 256;
    if (count == 0 || count > capacity) {
        return;
    }
    TPipe pipe;
    TBuf<TPosition::VECCALC> lowIn, wideIn, lowOut, wideOut;
    pipe.InitBuffer(lowIn, capacity * sizeof(T));
    pipe.InitBuffer(wideIn, capacity * sizeof(float));
    pipe.InitBuffer(lowOut, capacity * sizeof(T));
    pipe.InitBuffer(wideOut, capacity * sizeof(float));
    GlobalTensor<T> input16, output16;
    GlobalTensor<float> input32, output32;
    input16.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(low));
    output16.SetGlobalBuffer(reinterpret_cast<__gm__ T*>(outLow));
    input32.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(wide));
    output32.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(outWide));
    auto copy16 = DataCopyExtParams{1, count * static_cast<uint32_t>(sizeof(T)), 0, 0, 0};
    auto copy32 = DataCopyExtParams{1, count * static_cast<uint32_t>(sizeof(float)), 0, 0, 0};
    DataCopyPad(lowIn.Get<T>(), input16, copy16, DataCopyPadExtParams<T>{false, 0, 0, 0});
    DataCopyPad(wideIn.Get<float>(), input32, copy32, DataCopyPadExtParams<float>{false, 0, 0, 0});
    SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
    WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
    Cast(wideOut.Get<float>(), lowIn.Get<T>(), RoundMode::CAST_NONE, count);
    Cast(lowOut.Get<T>(), wideIn.Get<float>(), RoundMode::CAST_RINT, count);
    SetFlag<HardEvent::V_MTE3>(EVENT_ID0);
    WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);
    DataCopyPad(output32, wideOut.Get<float>(), copy32);
    DataCopyPad(output16, lowOut.Get<T>(), copy16);
}
} // namespace

extern "C" __global__ __aicore__ void tilexr_combine_cast_probe(
    GM_ADDR low, GM_ADDR wide, GM_ADDR outWide, GM_ADDR outLow, int64_t count, int64_t dtype)
{
    if (dtype == 3) {
        Run<half>(low, wide, outWide, outLow, count);
    } else if (dtype == 11) {
        Run<bfloat16_t>(low, wide, outWide, outLow, count);
    }
}
