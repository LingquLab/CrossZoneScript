// Copyright (c) 2026 TileXR Project.
// Compare an aligned 16-bit writeback with a round trip through FP32 in UB.
#include "kernel_operator.h"

namespace {
template<typename T>
__aicore__ void CheckNarrowing(GM_ADDR input, GM_ADDR directOutput, GM_ADDR roundTripOutput)
{
    using namespace AscendC;
    constexpr uint32_t count = 64;
    TPipe pipe;
    TBuf<TPosition::VECCALC> inputBuffer, narrowBuffer, roundTripBuffer;
    pipe.InitBuffer(inputBuffer, count * sizeof(float));
    pipe.InitBuffer(narrowBuffer, count * sizeof(T));
    pipe.InitBuffer(roundTripBuffer, count * sizeof(float));
    auto inputLocal = inputBuffer.Get<float>();
    auto narrowLocal = narrowBuffer.Get<T>();
    auto roundTripLocal = roundTripBuffer.Get<float>();

    GlobalTensor<float> in, roundTrip;
    GlobalTensor<T> direct;
    in.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(input));
    direct.SetGlobalBuffer(reinterpret_cast<__gm__ T *>(directOutput));
    roundTrip.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(roundTripOutput));
    DataCopy(inputLocal, in, count);
    SetFlag<HardEvent::MTE2_V>(EVENT_ID0);
    WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);
    Cast(narrowLocal, inputLocal, RoundMode::CAST_RINT, count);
    PipeBarrier<PIPE_V>();
    Cast(roundTripLocal, narrowLocal, RoundMode::CAST_NONE, count);
    SetFlag<HardEvent::V_MTE3>(EVENT_ID0);
    WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);
    DataCopy(direct, narrowLocal, count);
    DataCopy(roundTrip, roundTripLocal, count);
}
} // namespace

extern "C" __global__ __aicore__ void tilexr_combine_cast_aligned(
    GM_ADDR input, GM_ADDR directOutput, GM_ADDR roundTripOutput, int64_t dtype)
{
    if (dtype == 3) {
        CheckNarrowing<half>(input, directOutput, roundTripOutput);
    } else if (dtype == 11) {
        CheckNarrowing<bfloat16_t>(input, directOutput, roundTripOutput);
    }
}
