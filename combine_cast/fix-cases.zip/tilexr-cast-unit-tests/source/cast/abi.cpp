// Copyright (c) 2026 TileXR Project.
// Report the host layout used to initialize the Combine communication window in SST.
#include "ep_memory_window.h"
#include <tilexr/comm/types.h>
#include <cstddef>
#include <iostream>

int main()
{
    std::cout << "{\"size\":" << sizeof(TileXR::CommArgs)
              << ",\"rank\":" << offsetof(TileXR::CommArgs, rank)
              << ",\"rank_size\":" << offsetof(TileXR::CommArgs, rankSize)
              << ",\"peer_mems\":" << offsetof(TileXR::CommArgs, peerMems)
              << ",\"window_offset\":" << TileXREp::TileXREpMemoryRoundDataOffset(2)
                     + TileXREp::kEpMemoryStateWindowBytes
              << ",\"fp16\":" << TileXR::TILEXR_DATA_TYPE_FP16
              << ",\"bf16\":" << TileXR::TILEXR_DATA_TYPE_BFP16 << "}\n";
}
