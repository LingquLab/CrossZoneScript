# Copyright (c) 2026 TileXR Project.
"""Check the independent formats and tie-to-even reference used by the SST fixtures."""
import math
import struct
import unittest

from check import compare
from fixture import narrow, widen


class CastReferenceTest(unittest.TestCase):
    def test_halfway_rounds_to_even(self):
        for dtype, shift in (("fp16", 10), ("bf16", 7)):
            with self.subTest(dtype=dtype):
                ulp = 2 ** -shift
                one = narrow(1.0, dtype)
                for sign, sign_bit in ((1, 0), (-1, 0x8000)):
                    self.assertEqual(narrow(sign * (1 + 0.5 * ulp), dtype), one | sign_bit)
                    self.assertEqual(narrow(sign * (1 + 1.5 * ulp), dtype), (one + 2) | sign_bit)

    def test_subnormals_and_signed_zero(self):
        for dtype, exponent in (("fp16", -24), ("bf16", -133)):
            with self.subTest(dtype=dtype):
                smallest = 2.0 ** exponent
                self.assertEqual(widen(1, dtype), smallest)
                self.assertEqual(narrow(smallest / 2, dtype), 0)
                self.assertEqual(narrow(-smallest / 2, dtype), 0x8000)
                self.assertEqual(narrow(smallest * 1.5, dtype), 2)
                self.assertEqual(math.copysign(1, widen(0x8000, dtype)), -1)

    def test_finite_and_special_values(self):
        for dtype, maximum, infinity in (("fp16", 65504, 0x7C00), ("bf16", 3.3895313892515355e38, 0x7F80)):
            with self.subTest(dtype=dtype):
                self.assertEqual(narrow(maximum, dtype), infinity - 1)
                self.assertEqual(narrow(math.inf, dtype), infinity)
                self.assertEqual(narrow(-math.inf, dtype), infinity | 0x8000)
                self.assertTrue(math.isnan(widen(narrow(math.nan, dtype), dtype)))

    def test_checker_distinguishes_nan_encoding_and_value_errors(self):
        expected = struct.pack("<4H", 0x7E00, 0x0001, 0x8000, 0x3C00)
        actual = struct.pack("<4H", 0x7E01, 0x0000, 0x0000, 0x3C00)
        result = compare(actual, expected, "H", "fp16")
        self.assertEqual(result["bitwise_differences"], 3)
        self.assertEqual(result["mismatches"], 2)
        self.assertEqual([item[0] for item in result["first"]], [1, 2])

    def test_float32_accumulation_can_preserve_small_term(self):
        for dtype, large in (("fp16", 2048.0), ("bf16", 256.0)):
            with self.subTest(dtype=dtype):
                self.assertEqual(narrow((large + 1) - large, dtype), narrow(1, dtype))
                self.assertEqual(widen(narrow(large + 1, dtype), dtype) - large, 0)


if __name__ == "__main__":
    unittest.main()
