"""生成共同的两rank小用例与独立逐token语义golden，只依赖Python标准库。"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
from .contract import Config, reference as f0_reference, core_pairs


def make_fixture(directory, cores=(56, 64)):
    pairs = core_pairs(cores)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    ids = ((0, 2), (1, 3), (0, 2), (1, 3))
    xs = [[[0x3f80 + rank * 0x80 + token * 0x10 + h % 32 for h in range(256)]
           for token in range(4)] for rank in (0, 1)]
    hashes = {}
    for rank, cores in pairs:
        target = directory / f'rank{rank}'
        target.mkdir()
        features, triples, counts, expert_nums = [], [], [], []
        # 按输出语义枚举，不使用TL的bucket/offset/prefix公式。
        for expert in (rank * 2, rank * 2 + 1):
            before = len(triples) // 3
            for source in (0, 1):
                for token, row in enumerate(ids):
                    for k, destination in enumerate(row):
                        if destination == expert:
                            features.extend(xs[source][token])
                            triples.extend((source, token, k))
                counts.append(len(triples) // 3)
            expert_nums.append(len(triples) // 3 - before)
        files = {'x.bin': ('H', [x for row in xs[rank] for x in row]),
                 'ids.bin': ('i', [x for row in ids for x in row]),
                 'expected_output.bin': ('H', features), 'expected_assist.bin': ('i', triples),
                 'expected_counts.bin': ('i', counts), 'expected_expert_nums.bin': ('q', expert_nums)}
        for name, (fmt, values) in files.items():
            data = struct.pack('<' + fmt * len(values), *values)
            (target / name).write_bytes(data)
            hashes[f'rank{rank}/{name}'] = hashlib.sha256(data).hexdigest()
        descriptors = f0_reference(Config(rank=rank, block_dim=cores, peer_base=32, magic=0))
        for row in descriptors:
            # 仅序列化相对bank0基址的四个地址字段，Host据真实映射与magic还原。
            for field in (22, 23, 24, 25):
                row[field] -= 32
        data = struct.pack('<' + 'Q' * (cores * 64), *(x for row in descriptors for x in row))
        (target / 'expected_desc.bin').write_bytes(data)
        hashes[f'rank{rank}/expected_desc.bin'] = hashlib.sha256(data).hexdigest()
    manifest = {'shape': {'world': 2, 'experts': 4, 'tokens_per_rank': 4, 'hidden': 256, 'topk': 2},
                'dtype': 'BF16 raw little-endian bits', 'expert_ids_both_ranks': ids,
                'x_formula': '0x3f80 + rank*0x80 + token*0x10 + hidden_index%32',
                'expected_valid_rows_per_rank': 8, 'hashes': hashes}
    (directory / 'case.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cores', type=int, nargs=2, default=[56, 64])
    args = parser.parse_args()
    make_fixture(args.output, args.cores)
