"""集成 Dispatch 的布局字段、配置校验与 Host 描述符参考。

参数格式为 uint64[16]，参考描述符为 uint64[核数,64]；供 Host 验收与核内字段索引使用。
没有 X/expertIds 输入；地址只是数值，不表示已分配或映射通信窗口。
"""
from .layout_reference import (
    Config, FIELD_NAMES as M0_FIELDS, reference as m0_reference,
)

ABI_VERSION = 1
NATIVE_REVISION = "423a36f9cc126be7484b3d38f638fccfbf4da072"
CONTRACT = "dispatch-functional-v1"
FIELD_NAMES = (
    "abi_version", "rank", "core", "block_dim", "local_experts", "receive_states",
    "cumsum_cores", "send_cores", "count_workers", "small_batch", "feature_bytes",
    "feature_aligned_bytes", "record_blocks", "packed_payload_bytes", "record_bytes",
    "expert_window_bytes", "combine_reserve_bytes", "dispatch_bytes", "workspace_bytes",
    "status_count_aligned", "histogram_offset_bytes", "status_buffer_bytes",
    "state_address", "payload_address", "dispatch_address", "workspace_address",
    "hcopy_bytes", "expert_ids_aligned_bytes", "round_index", "peer_capacity_bytes",
    "required_round_payload_bytes", "round_payload_capacity_bytes", "send_rounds",
    "count_executed", "count_begin", "count_end", "count_tasks",
    "status_executed", "status_begin", "status_end", "status_tasks",
    "receive_executed", "receive_begin", "receive_end", "receive_tasks",
    "layout_executed", "send_round_executed", "required_peer_bytes", "ub_budget_bytes",
) + tuple(f"reserved_{i}" for i in range(49, 64))
F = {name: i for i, name in enumerate(FIELD_NAMES)}
STAGES = ("layout", "send_round", "count_split", "status_split", "receive_split")


def reference(config):
    """迁移参考；TL实现另行执行，原生Host字段另行校验。"""
    old = m0_reference(config)  # 同时校验uint32范围、UB、窗口容量、基址溢出。
    rows = []
    for row in old:
        m = dict(zip(M0_FIELDS, row))
        count_executed = int(m["small_batch"] or m["core"] >= m["send_cores"])
        status_executed = int(m["core"] >= m["send_cores"])
        m.update(abi_version=ABI_VERSION, hcopy_bytes=m["feature_bytes"],
                 send_rounds=2 if config.tokens >= 48 and config.world_size in (64, 128) else 1,
                 count_executed=count_executed,
                 count_tasks=m["count_end"] - m["count_begin"],
                 status_executed=status_executed,
                 status_begin=m["cumsum_begin"], status_end=m["cumsum_end"],
                 status_tasks=m["cumsum_end"] - m["cumsum_begin"],
                 receive_executed=1, receive_tasks=m["receive_end"] - m["receive_begin"],
                 layout_executed=1, send_round_executed=1)
        rows.append([m.get(name, 0) for name in FIELD_NAMES])
    return rows


def validate(config):
    reference(config)
    return config.words()


# 固定双rank用例的GM窗口视图，偏移以uint32元素为单位。
STATE_WORDS = 1024 * 1024 // 4
PAYLOAD_WORDS = 16384 // 4
CUMSUM_WORD = 868 * 1024 // 4
GATE_WORD = 876 * 1024 // 4
READY = 0x3F800000


def validate_rank_cores(rank, cores):
    """固定两rank；每rank至少四个接收核，实际AIV上限由Host再次核验。"""
    if type(rank) is not int or rank not in (0, 1):
        raise ValueError('Fixed two-rank Dispatch requires rank 0 or 1')
    if type(cores) is not int or not 4 <= cores <= 200:
        raise ValueError('cores must be an integer in [4,200]')
    return cores


def core_pairs(cores=(56, 64)):
    """历史56/64仅为默认配置；保存结果必须显式携带两rank的真实核数。"""
    if not isinstance(cores, (list, tuple)) or len(cores) != 2:
        raise ValueError('Exactly two per-rank core counts required')
    return [(rank, validate_rank_cores(rank, count)) for rank, count in enumerate(cores)]
