# T16/64/256 均衡 Dispatch

`kernel.py` 的 `tokens` 参数和 `export --tokens` 支持每 rank T4/16/64/256，
固定 P2/E4/K2/H256/BF16；每 rank 的 AIV 核数独立配置为 4–200。
保留的默认导出是 rank0/56、rank1/64，默认 T4；其他核数须独立导出并核对打点 recipe。
本扩展保留 P1+P2：workspace 连续 UB 批量写回并完成等待，gate 逐核 32B 提交后组尾等待。

每个 batch 有独立真实导出、SHA 锁定的打点 recipe 和生成物，位于 `batch/bsT/`。
构建时同时指定 `-DTL_TOKENS_PER_RANK=T`、`-DTL_GENERATED_ROOT=.../batch/bsT/generated`；
默认 T4 使用上级 `generated/`。CMake 拒绝 Host 与导出 T 不一致及原始源码/生成物 SHA 不匹配。
前置 AR 构建仍启用 `TL_PRE_ALLREDUCE_SUPPORT=ON`，Host/核心库同为 ABI0；HCCL 参数不变。

## 扩容行为与计时

- 所有核读取 2T 条 expertIds。T<48 时前 4 核各计数 1 专家；T>=48 时末核计数全部 4 专家。
  F2 覆盖全部计数任务，F3 覆盖全部发布任务，各记录一次。
- 前 `min(2T, cores-1)` 核发送，第 c 核处理 `c, c+send_cores, ...` 的全部路由，
  每条仍按稳定专家位置打包 1024B，并完成等待。F4 包住整个任务循环。
- 末核执行 F5/F6，前 4 核各接收 T/2 条记录。payload、output/assist 容量与布局参数同 T 扩容，
  本候选的 F8 使用下述双缓冲跨步接收。T>=48 的角色切换是原生分工规则的扩容，不是新增 F6 优化。
- F0–F9、五模块及 F6/F7 子段按真实参与核统计 mean/max；模块均值不能相加为 kernel 时长。
  原始 tick 未校准，不做跨核/跨 rank 起止相减；ACL/msprof 四类时间独立保留。

## 输入与执行

使用 `dispatch-balanced-batch-20261110-v1` 的实际 fixture 字节，不重新生成或只核对 shape。
suite 根目录含 `suite.json` 和 `bs16/bs64/bs256/case.json`；每个 case 列出所有二进制 SHA。
Host 先核对输入字节及黄金输出，再上传，初始化阶段单存 `input-readback.x.bin` 和
`input-readback.ids.bin`；分析器逐字节核对设备回读与 fixture。设备回读是独立证据，不替代 fixture SHA。

将各 case 的安装与打点文件放到 `CASES_ROOT/bsT/{install,generated}`，调用：

```bash
python3 -m examples.tilelang_dispatch.tools.run_batch \
  --cases-root CASES_ROOT --suite-root SUITE_ROOT --output NEW_CORRECTNESS_DIR \
  --start-release RELEASE_JSON --start-release-sha256 RELEASE_SHA \
  --mode correctness --rounds 3 --comm-port PORT
python3 -m examples.tilelang_dispatch.tools.run_batch \
  --cases-root CASES_ROOT --suite-root SUITE_ROOT --output NEW_CAPTURE_DIR \
  --start-release RELEASE_JSON --start-release-sha256 RELEASE_SHA \
  --mode capture --rounds 10 --correctness NEW_CORRECTNESS_DIR --comm-port PORT
```

放行文件由协调方核验原生正式交付后提供，状态须为 `READY_AFTER_NATIVE_FORMAL_DELIVERY`；
执行前还须收到放行通知。工具将文件内容及 SHA 绑定到批次，不生成放行文件。
各轮顺序 bs16→bs64→bs256；每轮新双 rank 进程、20 连续预热+1 正式测量，
实时查卡，忙/未知/错误立即停止且不重试。无 msprof 不降级采集。采集前重验同身份正确性原始证据。
JSON/CSV 保留每轮四计时、五模块/F 段/子段 mean/max、参与核、有效工作核、并列最慢核及工作量。

## 维护要点与验证边界

扩容不能只放大 Tensor shape：需同步 route 循环、发送核多任务、计数任务范围、窗口步长、
Host warmup/正式输出容量和验收。T>=48 时发送核不得对计数范围做无符号负数减法。
循环计数器使用 `T.alloc_var` 声明后显式赋零；仅写 `init=0` 在当前 CPU 序列化/构建路径会丢失初始化，
造成未初始化的发送位置和越界。设备与 CPU 分支均须执行同一显式赋值，并运行真实导出。
循环内反复写同一 marker 槽会丢任务：打点需包住本核整个任务循环，更新真实导出 SHA 和行坐标。

CPU 测试执行真实 TL 宏的串行 C 版本，对照独立 oracle，覆盖完整路由、输出、工作量与轮次复用；
它不验证 MTE 并发、设备调度或 A5 性能。真实导出及离线验算通过也不等于 CANN 构建或 NPU 验收通过。

## ③ 打包并发送：批量匹配和双发送缓冲

F4 为四个专家一次生成逐 bit 匹配掩码。每条路由仅统计当前位置之前的 mask words，
替代逐条重新读取全部前序路由；不改变专家内稳定顺序。T4/16 的路由先补到 64 个
int32 元素，补值 -1 不匹配专家，统计范围严格排除当前及尾部路由。

512B feature 用 DMA 读到 compact 缓冲，来源三元组写在其后；两次向量 Copy 将两行
480B 有效数据放入两个 512B wire 行，保留各行尾部 READY。wire A/B 的 READY 和 compact
的零 padding 只初始化一次。两个 wire 槽轮转，复用本槽前或 F4 退出时等其 MTE3 完成；
compact 在向量读取完成后才能供下一条 feature 覆写。F4 包含初始化、掩码生成和最终排空。

## ⑤ 接收循环：精确 READY、直接 assist 输出和硬事件流水

`receive_ub_plan(tokens, cores)` 采用 190KiB 保守 UB 预算。批容量沿用基线每条 2048B 的
策略，运行时取 `min(capacity, remaining)`，避免批量变化干扰优化对比。实际删除 A/B assist
中间缓冲后，每条由 2×960B 数据和 64B READY 构成，另有 288B guard/归约结果区；
释放的空间容纳 F4 新增缓冲和专家掩码。真实导出核对全部 UB 视图末地址，不能只看估算。

F7 和 F9 业务保持基线。F8 批量读取有效 2N 个 READY 槽首，通过 uint32 ReduceMin 和
ReduceMax 均等于 READY 判断整批全等；非零值、浮点 NaN 位模式或相互抵消的错误值均不能通过。
每 repeat 的物理读取范围落在初始化的 flags/guard 内，尾批不会读出分配边界。

两段 480B 数据经跨步 DMA 压紧为每条 960B UB。512B feature 批量写出；来源三元组直接
从原数据 UB 跨步写出为每条 12B，使用 int32 位视图保留 uint32 原始位，取消逐条标量重排。
数据 MTE2→MTE3 用事件 2/3 建立依赖，A/B 的 MTE3→S 完成事件也分别为 2/3；
只在第三批复用同槽及退出时等待本槽完成，不增加跨核或跨 rank 屏障。

无论正常结束还是 READY 超限退出，F8 都先排空此前已提交输出；F9 仅清成功消费记录。
不能把完成等待挪到 F9 来报告 F8 加速。⑤/F7/F9 比较使用接收 core0–3 与非接收核分组，
接收效率和 F7+F8+F9 加和统一取四个接收核；max 从同一核的组合区间提取，不能相加不同核的 max。

这些桥接函数经 `T.import_source` 纳入导出，批量、轮转和地址仍由 TileLang 控制；
没有修改共享后端，也没有手改导出 C++。Host、AR、实际输入、1024B wire ABI 均保留。
`payload_polls` 仍按检查的记录数累计。CPU 行为测试及 C++ helper 模型不证明设备流水或性能；
本候选尚未 CANN 编译或 NPU 验证，不能引用历史实验数据作为本候选加速结论。
