"""Host lifecycle/profiler and evidence checks; synthetic, not NPU measurements."""
import csv
import hashlib
import json
import os
import shutil
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from uuid import UUID
from ..run_native import run, profiler_task
from ..analyze_native import analyze, host_timeline, check_warmup
from .test_analyze_a5 import write_csv, write_json, diagnostic_bytes, mapping, synthetic_records
from ..contract import Config
from ..hardware_fixture import make_fixture


class NativeHostTests(unittest.TestCase):
    def execute(self, root, fail=False, cores=(56, 64)):
        fixture, install = root / 'fixture', root / 'install'
        make_fixture(fixture)
        (install / 'bin').mkdir(parents=True)
        kernels = install / 'lib64/tilexr/kernels'; kernels.mkdir(parents=True)
        for rank, count in enumerate(cores):
            (kernels / f'tilelang_dispatch_r{rank}_c{count}_profile0.o').write_bytes(b'mock')
            binary = install / 'bin' / f'tilelang_dispatch_integrated_r{rank}_profile0'
            binary.write_text('#!/usr/bin/env python3\nimport os,sys,json\nfrom pathlib import Path\n'
                "assert sys.argv[1]=='--native' and len(sys.argv)==7\n"
                "p=Path(sys.argv[4]);p.mkdir()\n"
                "(p/'observed.json').write_text(json.dumps({'pid':os.getpid(),'argv':sys.argv[1:]}))\n"
                f'sys.exit({1 if fail and rank == 0 else 0})\n')
            binary.chmod(0o750)
        args = SimpleNamespace(install=install, fixture=fixture, output=root / 'run',
            mode='correctness', rounds=2, warmup=20, devices=[0, 1], cores=list(cores), comm_port=39090, timeout=5)
        with patch('examples.tilelang_dispatch.run_native.check_idle') as idle, \
                patch.dict(os.environ, {'ASCEND_RT_VISIBLE_DEVICES':'','ASCEND_VISIBLE_DEVICES':''}):
            result = run(args)
            self.assertEqual(idle.call_count, 2)
            return result

    def test_fresh_process_pair_each_round_and_no_control_fd(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); result = self.execute(root)
            self.assertEqual(len(result['rounds']), 2)
            pids = []
            for iteration in (1, 2):
                for rank in (0, 1):
                    r = json.loads((root / f'run/round{iteration}/rank{rank}/observed.json').read_text())
                    pids.append(r['pid'])
                    self.assertEqual(r['argv'][4], '20')
            self.assertEqual(len(set(pids)), 4)

    def test_configurable_cores_bind_actual_kernel_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.execute(root, cores=(8, 12))
            identity = json.loads((root / 'run/run.json').read_text())
            self.assertEqual(identity['cores'], [8, 12])
            names = {Path(name).name for name in identity['device_binaries']}
            self.assertEqual(names, {'tilelang_dispatch_r0_c8_profile0.o',
                                     'tilelang_dispatch_r1_c12_profile0.o'})

    def test_failure_stops_before_next_round(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with self.assertRaises(RuntimeError): self.execute(root, fail=True)
            self.assertFalse((root / 'run/round2').exists())
            states = json.loads((root / 'run/round1/process-exits.json').read_text())
            self.assertTrue(all(not s['group_remaining'] for s in states))

    def test_profiler_matches_exact_symbol_count_and_last_task(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows = [{'Op Name':'kernel', 'Task Start Time(us)':str(i),
                     'Task Duration(us)':str(2+i), 'Task ID':str(i), 'Stream ID':'7'} for i in (2,0,1)]
            write_csv(root / 'op_summary.csv', rows)
            self.assertEqual(profiler_task(root, 'kernel', 2)['device_task_us'], 4)
            with self.assertRaises(ValueError): profiler_task(root, 'kernel', 3)
            with self.assertRaises(ValueError): profiler_task(root, 'different', 2)

    def test_capture_must_finish_before_barrier(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            row = dict(round=20, rank=0, clock='CLOCK_MONOTONIC', capture_begin_ns=10,
                capture_end_ns=20, event_start_enqueue_ns=40, launch_before_ns=50,
                launch_after_ns=60, sync_end_ns=70, capture_id='example')
            write_csv(root / 'host-timeline.csv', [row])
            write_csv(root / 'native-barriers.csv', [dict(step='measured_ready', rank=0,
                clock='CLOCK_MONOTONIC', enter_ns=25, exit_ns=35)])
            self.assertEqual(host_timeline(root, 0, 20, True)['barrier_exit_ns'], 35)
            row['capture_end_ns'] = 30
            write_csv(root / 'host-timeline.csv', [row])
            with self.assertRaises(ValueError): host_timeline(root, 0, 20, True)

    def test_warmup_actual_bytes_and_batch_flags_are_rechecked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); fixture = root / 'fixture'; make_fixture(fixture)
            out = root / 'rank0'; out.mkdir()
            (out / 'round0.params.bin').write_bytes(struct.pack('<16Q', *Config(rank=0, block_dim=56).words()))
            for name, size in (('output',8192),('assist',192),('counts',16),('expert_nums',16)):
                data = (fixture / f'rank0/expected_{name}.bin').read_bytes()
                (out / f'round0.actual_{name}.bin').write_bytes(data + b'\xa5' * (size-len(data)))
            (out / 'round0.dispatch.diagnostics.bin').write_bytes(diagnostic_bytes(56))
            for bank in (0,1):
                (out / f'warmup.bank{bank}.state.bin').write_bytes(bytes(1<<20))
                (out / f'warmup.bank{bank}.payload.bin').write_bytes(bytes(16384))
            self.assertEqual(check_warmup(out, fixture / 'rank0', 1, 0, 56, False), [1])
            for name in ('round0.actual_output.bin', 'warmup.bank0.state.bin'):
                p = out / name; original = p.read_bytes(); changed=bytearray(original); changed[0]^=1
                p.write_bytes(changed)
                with self.subTest(name=name), self.assertRaises(ValueError):
                    check_warmup(out, fixture / 'rank0', 1, 0, 56, False)
                p.write_bytes(original)

    def test_complete_native_capture_and_rejects_warmup_or_identity_corruption(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture, directory, generated = root / 'fixture', root / 'run', root / 'generated'
            case = make_fixture(fixture)
            directory.mkdir(); generated.mkdir()
            batch = directory / 'round1'; batch.mkdir()
            identities = {}
            for rank in (0, 1):
                binary = root / f'runner{rank}'; binary.write_bytes(b'synthetic Host executable')
                identities[str(binary)] = hashlib.sha256(binary.read_bytes()).hexdigest()
            write_json(directory / 'run.json', {
                'schema':'tilelang_dispatch_native_run.v1', 'mode':'capture', 'rounds':1,
                'warmup':1, 'devices':[0,1], 'cores':[12,16],
                'process_lifecycle':'fresh rank pair per round',
                'warmup_schedule':'continuous submission then stream synchronization',
                'capture_placement':'before measured rank barrier',
                'primary_time_source':'msprof device task', 'binaries':identities,
                'device_binaries':identities, 'fixture_hashes':case['hashes']})
            profiles = []
            for rank, cores in ((0,12), (1,16)):
                out = batch / f'rank{rank}'; out.mkdir()
                gen = generated / f'rank{rank}'; gen.mkdir()
                write_json(gen / 'dispatch.ticks.json', mapping(rank,cores))
                for iteration in (0,1):
                    prefix = out / f'round{iteration}'
                    Path(str(prefix)+'.params.bin').write_bytes(struct.pack('<16Q',
                        *Config(rank=rank,block_dim=cores,magic=iteration+1).words()))
                    for name, size in (('output',8192),('assist',192),('counts',16),('expert_nums',16)):
                        expected = (fixture / f'rank{rank}/expected_{name}.bin').read_bytes()
                        Path(str(prefix)+f'.actual_{name}.bin').write_bytes(expected+b'\xa5'*(size-len(expected)))
                    Path(str(prefix)+'.dispatch.diagnostics.bin').write_bytes(diagnostic_bytes(cores))
                (out / 'round1.state.bin').write_bytes(bytes(1<<20))
                (out / 'round1.payload.bin').write_bytes(bytes(16384))
                (out / 'round1.dispatch.records').write_bytes(synthetic_records(rank,cores))
                for bank in (0,1):
                    (out / f'warmup.bank{bank}.state.bin').write_bytes(bytes(1<<20))
                    (out / f'warmup.bank{bank}.payload.bin').write_bytes(bytes(16384))
                write_json(out / 'summary.json', {'rank':rank,'device':rank,'cores':cores,
                    'profiling':True,'ready_probe':False,'capture_placement':'before-k',
                    'iterations':2,'verified_iterations':2,'measured_iterations':1,
                    'warmup_iterations':1,'capture_count':1,'operator_correctness':'PASS',
                    'flags_cleared':'PASS','observation':'integrated',
                    'flags_validation_scope':'both banks at warmup batch end; measured bank after completion barrier'})
                write_json(out / 'warmup-summary.json', {'warmup_iterations':1,'validated_outputs':1,
                    'validated_diagnostics':1,'flags_cleared':'PASS',
                    'flag_scope':'both banks at batch end','per_iteration_flags':'NOT_OBSERVED',
                    'params_storage':'immutable per launch','output_storage':'separate per iteration',
                    'stream_syncs_during_batch':1,'batch_enqueue_begin_ns':50,'batch_sync_end_ns':90})
                write_json(out / 'native-schedule.json', {'schema':'tilelang_native_host_schedule.v1',
                    'rank':rank,'warmup_iterations':1,'measured_round':1,'launches':2,
                    'barrier_protocol':'DemoBarrierAll one-byte arrival/release',
                    'barrier_endpoint':'loopback TCP','capture_placement':'before measured_ready barrier',
                    'parent_per_iteration_control':False,'warmup_stream_syncs':1,
                    'warmup_window_validation':'both banks at batch end only',
                    'measured_window_validation':'after measured_complete barrier'})
                write_csv(out / 'rounds.csv', [dict(round=i,magic=i+1,measured=i,profiling=i,
                    operator_correctness='PASS',flags_cleared='PASS' if i else 'NOT_OBSERVED') for i in (0,1)])
                cid = str(UUID(int=rank+1))
                write_csv(out / 'timing.csv', [dict(round=1,magic=2,device=rank,rank=rank,
                    aiv_count=cores,profiling=1,module='dispatch',acl_event_us=5.5,
                    host_launch_sync_us=8.0,capture_id=cid,operator_correctness='PASS')])
                write_csv(out / 'native-barriers.csv', [dict(step=step,rank=rank,
                    clock='CLOCK_MONOTONIC',enter_ns=begin,exit_ns=end) for step,begin,end in (
                    ('startup',10,20),('warmup_ready',30,40),('warmup_complete',100,110),
                    ('measured_ready',200,210),('measured_complete',310,320),('validated',350,360))])
                write_csv(out / 'host-timeline.csv', [dict(round=1,magic=2,rank=rank,
                    placement='before-k',clock='CLOCK_MONOTONIC',prepare_received_ns=120,
                    ready_reply_before_ns=180,k_received_ns=211,capture_begin_ns=150,
                    capture_end_ns=160,event_start_enqueue_ns=220,launch_before_ns=230+rank,
                    launch_after_ns=240,sync_end_ns=300,capture_id=cid)])
                prof = batch / f'prof-rank-{rank}'; prof.mkdir()
                symbol = f'tilexr_tl_dispatch_r{rank}_c{cores}'
                write_csv(prof / 'op_summary.csv', [{'Op Name':symbol,'Task Start Time(us)':i*100,
                    'Task Duration(us)':2+i+rank,'Task ID':i+1,'Stream ID':7} for i in (0,1)])
                profiles.append(profiler_task(prof,symbol,1))
            status = {'status':'PASS','profiler':profiles,
                      'scope':'process completion; operator/capture validation requires analyze_native'}
            write_json(batch / 'execution.json', status)
            write_json(batch / 'process-exits.json', [dict(pid=1234+rank,exit_code=0,
                group_remaining=False) for rank in (0,1)])
            write_json(directory / 'execution.json', {'status':'PASS','rounds':[dict(round=1,**status)]})
            result = analyze(directory,fixture,generated)
            self.assertEqual(result['status'],'PASS')
            self.assertEqual(result['rank_results'][0]['device_task_us']['mean'],3)
            self.assertEqual(result['rank_results'][0]['functions']['F5']['mean_ticks'],20)
            self.assertEqual(result['pairs'][0]['launch_rank1_minus_rank0_ns'],1)
            relocated = root / 'relocated-run'
            shutil.move(str(directory),str(relocated))
            directory, batch = relocated, relocated / 'round1'
            self.assertEqual(analyze(directory,fixture,generated)['status'],'PASS')
            corrupted = batch / 'rank0/round0.actual_output.bin'
            original = corrupted.read_bytes(); data=bytearray(original); data[0]^=1
            corrupted.write_bytes(data)
            with self.assertRaisesRegex(ValueError,'Warmup output'):
                analyze(directory,fixture,generated)
            corrupted.write_bytes(original)
            # A valid stream from another rank must not be accepted as this capture.
            capture = batch / 'rank0/round1.dispatch.records'
            capture.write_bytes(synthetic_records(0,12,capture_id=2))
            with self.assertRaisesRegex(ValueError,'capture identity'):
                analyze(directory,fixture,generated)


if __name__ == '__main__': unittest.main()
