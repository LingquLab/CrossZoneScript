"""[AI] Targeted variants: execute real TL macros against independent CPU oracles.

Serialized CPU execution checks arithmetic, byte layout and lifetime-visible
state. It cannot establish DMA ordering, event reuse safety or device timing.
"""
import importlib.util
import tempfile
import unittest

from .test_batch_kernel import compile_cpu


def compile_layout(rank, cores):
    """[AI] Compile the actual optimized F2/F3/F5/F6 macros, without send/receive."""
    import tilelang.language as T
    from ..contract import STATE_WORDS
    from ..kernel import layout, count_split, status_split, count_publish, count_prefix

    @T.prim_func
    def targeted_layout(params: T.Tensor((16,), 'uint64'),
                        ids: T.Tensor((512,), 'int32'),
                        state0: T.Tensor((STATE_WORDS,), 'uint32'),
                        state1: T.Tensor((STATE_WORDS,), 'uint32'),
                        counts: T.Tensor((4,), 'int32'),
                        diagnostics: T.Tensor((16,), 'int32'), step: T.int32):
        with T.block('layout_worker'):
            p = T.alloc_buffer((16,), 'uint64', scope='local')
            o = T.alloc_buffer((64,), 'uint64', scope='local')
            route = T.alloc_buffer((512,), 'int32', scope='local')
            amounts = T.alloc_buffer((4,), 'uint32', scope='local')
            records = T.alloc_buffer((32,), 'uint32', scope='local')
            prefix = T.alloc_buffer((4,), 'int32', scope='local')
            small = T.alloc_buffer((8,), 'uint32', scope='local')
            diag = T.alloc_buffer((16,), 'int32', scope='local')
            core = T.alloc_var('int32')
            core = cores - 1
            for i in T.serial(16):
                p[i] = params[i]
                diag[i] = 0
            for i in T.serial(512):
                route[i] = ids[i]
            layout(p, o)
            count_split(p, o, core)
            if step == 0:
                count_publish(route, state0, state1, rank, small, amounts, diag,
                              o, 512, True, True)
            else:
                status_split(p, o, core)
                if rank == 0:
                    count_prefix(state0, counts, core, cores, 3, records, prefix,
                                 small, diag, o, True, 3, True)
                else:
                    count_prefix(state1, counts, core, cores, 3, records, prefix,
                                 small, diag, o, True, 3, True)
            for i in T.serial(16):
                diagnostics[i] = diag[i]

    with tempfile.TemporaryDirectory() as directory:
        return compile_cpu(targeted_layout, directory, 'targeted_layout')


def compile_receive(capacity):
    """[AI] A larger fixture window exercises R128's third batch; target stays T256."""
    import tilelang.language as T
    from ..contract import STATE_WORDS
    from ..kernel import layout, receive_split, receive_output

    @T.prim_func
    def targeted_receive(params: T.Tensor((16,), 'uint64'),
                         state: T.Tensor((STATE_WORDS,), 'uint32'),
                         payload: T.Tensor((512 * 1024,), 'uint32'),
                         output: T.Tensor((512 * 512,), 'uint32'),
                         assist: T.Tensor((512 * 12,), 'int32'),
                         expert_nums: T.Tensor((2,), 'int64'),
                         diagnostics: T.Tensor((16,), 'int32')):
        with T.block('receive'):
            p = T.alloc_buffer((16,), 'uint64', scope='local')
            o = T.alloc_buffer((64,), 'uint64', scope='local')
            small = T.alloc_buffer((8,), 'uint32', scope='local')
            prefix = T.alloc_buffer((4,), 'int32', scope='local')
            nums = T.alloc_buffer((2,), 'int64', scope='local')
            diag = T.alloc_buffer((16,), 'int32', scope='local')
            core = T.alloc_var('int32')
            core = 0
            for i in T.serial(16):
                p[i] = params[i]
                diag[i] = 0
            layout(p, o)
            receive_split(p, o, core)
            receive_output(state, payload, output, assist, expert_nums, core, 0,
                           64, 3, small, prefix, nums, diag, o, True, capacity, True)
            for i in T.serial(16):
                diagnostics[i] = diag[i]

    with tempfile.TemporaryDirectory() as directory:
        return compile_cpu(targeted_receive, directory, 'targeted_receive')


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class TargetedLayoutTests(unittest.TestCase):
    def test_real_counts_prefix_workspace_gates_and_consecutive_generations(self):
        import numpy as np
        import tilelang as tl
        from ..contract import Config, CUMSUM_WORD, F, GATE_WORD, READY, STATE_WORDS, reference

        # [AI] Independent rank core counts remain configurable, including actual 64/64.
        for core_counts in ((8, 12), (64, 64)):
            modules = [compile_layout(rank, cores) for rank, cores in enumerate(core_counts)]
            array = tl.tvm.nd.array
            states = [array(np.zeros(STATE_WORDS, dtype=np.uint32)) for _ in range(2)]
            patterns = [
                (np.resize(np.arange(4), 512), np.resize(np.arange(4)[::-1], 512)),
                (np.r_[np.zeros(253), np.ones(1), np.full(258, 2)],
                 np.r_[np.full(511, 3), np.ones(1)]),
                (np.zeros(512), np.zeros(512)),
            ]
            for generation, routes in enumerate(patterns, 1):
                actual_routes = [np.asarray(route, dtype=np.int32).copy() for route in routes]
                for rank, route in enumerate(actual_routes):
                    np.random.default_rng(generation * 10 + rank).shuffle(route)
                args = []
                for rank, cores in enumerate(core_counts):
                    config = Config(tokens=256, rank=rank, block_dim=cores, magic=generation)
                    args.append([array(np.array(config.words(), dtype=np.uint64)),
                                 array(actual_routes[rank]), *states,
                                 array(np.full(4, -1, dtype=np.int32)),
                                 array(np.zeros(16, dtype=np.int32))])
                # [AI] Both ranks publish before either prefix consumer starts.
                for rank in range(2):
                    modules[rank]['targeted_layout'](*args[rank], 0)
                histograms = [np.bincount(route, minlength=4) for route in actual_routes]
                for rank in range(2):
                    slots = states[rank].numpy()[:32].reshape(4, 8)
                    expected_counts = [histograms[source][expert]
                                       for expert in (rank * 2, rank * 2 + 1)
                                       for source in range(2)]
                    np.testing.assert_array_equal(slots[:, 0], READY)
                    np.testing.assert_array_equal(slots[:, 1], expected_counts)
                    np.testing.assert_array_equal(slots[:, 2:], 0)
                    modules[rank]['targeted_layout'](*args[rank], 1)
                    self.assertEqual(int(args[rank][-1].numpy()[0]), 0)
                    prefix = np.cumsum(expected_counts, dtype=np.int32)
                    np.testing.assert_array_equal(args[rank][-2].numpy(), prefix)
                    config = Config(tokens=256, rank=rank, block_dim=core_counts[rank], magic=generation)
                    row = reference(config)[0]
                    workspace = (row[F['workspace_address']] - row[F['state_address']]) // 4
                    actual = states[rank].numpy()
                    np.testing.assert_array_equal(actual[workspace:workspace + core_counts[rank] * 4],
                                                  np.tile(prefix, core_counts[rank]))
                    np.testing.assert_array_equal(actual[GATE_WORD:GATE_WORD + core_counts[rank] * 8], 1)
                    np.testing.assert_array_equal(actual[CUMSUM_WORD:CUMSUM_WORD + 8], 0)
                    np.testing.assert_array_equal(actual[:32].reshape(4, 8)[:, 0], 0)
                    # [AI] Stand in only for each receiver's already-covered gate clear.
                    actual[GATE_WORD:GATE_WORD + core_counts[rank] * 8] = 0
                    states[rank].copyfrom(actual)


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class TargetedCompactReceiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.modules = {capacity: compile_receive(capacity) for capacity in (64, 128)}

    def run_case(self, capacity, size, bad_flag=None):
        import numpy as np
        import tilelang as tl
        from ..contract import Config, F, GATE_WORD, READY, STATE_WORDS, reference

        config = Config(tokens=512, rank=0, block_dim=64)
        row = reference(config)[0]
        workspace = (row[F['workspace_address']] - row[F['state_address']]) // 4
        state = np.zeros(STATE_WORDS, dtype=np.uint32)
        state[GATE_WORD:GATE_WORD + 8] = 1
        state[workspace:workspace + 4] = size
        payload = np.full(512 * 1024, 0xa5a5a5a5, dtype=np.uint32)
        # [AI] Bit patterns include sign, NaN/Inf and arbitrary BF16 halves; no float conversion.
        words = np.array([0x00008000, 0x7fc17f80, 0xff80bf80, 0x00013f80,
                          0x8000ffff, 0x7fff0000, 0xdeadbeef, 0x01234567], dtype=np.uint32)
        features, assists = [], []
        for token in range(size):
            feature = np.resize(words ^ np.uint32(token * 0x10001), 128)
            assist = np.array([0xffffffff, 0x80000000 + token, token % 2], dtype=np.uint32)
            features.append(feature)
            assists.append(assist.view(np.int32))
            offset = token * 256
            payload[offset:offset + 120] = feature[:120]
            payload[offset + 128:offset + 136] = feature[120:]
            payload[offset + 136:offset + 139] = assist
            payload[offset + 120:offset + 128] = READY
            payload[offset + 248:offset + 256] = READY
        if bad_flag is not None:
            token, block, value = bad_flag
            payload[token * 256 + block * 128 + 120] = value
        before = payload.copy()
        array = tl.tvm.nd.array
        args = [array(np.array(config.words(), dtype=np.uint64)), array(state), array(payload),
                array(np.full(512 * 512, 0xa5a5a5a5, dtype=np.uint32)),
                array(np.full(512 * 12, -1515870811, dtype=np.int32)),
                array(np.zeros(2, dtype=np.int64)), array(np.zeros(16, dtype=np.int32))]
        self.modules[capacity]['targeted_receive'](*args)
        consumed = size if bad_flag is None else bad_flag[0] // capacity * capacity
        diag = args[-1].numpy()
        self.assertEqual(int(diag[0]), 0 if bad_flag is None else 3)
        self.assertEqual(int(diag[7]), consumed)
        self.assertEqual(int(diag[10]), consumed * 1024)
        if consumed:
            np.testing.assert_array_equal(args[3].numpy()[:consumed * 128],
                                          np.concatenate(features[:consumed]))
            np.testing.assert_array_equal(args[4].numpy()[:consumed * 3],
                                          np.concatenate(assists[:consumed]))
        np.testing.assert_array_equal(args[3].numpy()[consumed * 128:], 0xa5a5a5a5)
        np.testing.assert_array_equal(args[4].numpy()[consumed * 3:], -1515870811)
        for token in range(consumed):
            before[token * 256 + 120:token * 256 + 128] = 0
            before[token * 256 + 248:token * 256 + 256] = 0
        np.testing.assert_array_equal(args[2].numpy(), before)
        np.testing.assert_array_equal(args[1].numpy()[GATE_WORD:GATE_WORD + 8], 0)
        np.testing.assert_array_equal(args[5].numpy(), [size, 0])
        if bad_flag is None:
            self.assertEqual(int(diag[3]), size)
        return args, payload, features, assists

    def test_compact_empty_full_tail_and_third_batch(self):
        for capacity in self.modules:
            for size in (0, 1, capacity - 1, capacity, capacity + 1,
                         2 * capacity, 2 * capacity + 1, 512):
                with self.subTest(capacity=capacity, size=size):
                    self.run_case(capacity, size)

    def test_missing_or_nonexact_either_ready_preserves_failed_batch(self):
        from ..contract import READY
        for capacity in self.modules:
            for token in (capacity - 1, capacity, 2 * capacity):
                for block in (0, 1):
                    for value in (0, READY - 1, READY + 1, 1, 0xffffffff):
                        with self.subTest(capacity=capacity, token=token, block=block, value=value):
                            self.run_case(capacity, 2 * capacity + 1, (token, block, value))

    def test_cleared_flags_reject_stale_generation_then_accept_new_data(self):
        import numpy as np
        from ..contract import GATE_WORD

        for capacity in self.modules:
            size = 2 * capacity + 1
            args, payload, features, assists = self.run_case(capacity, size)
            state = args[1].numpy()
            state[GATE_WORD:GATE_WORD + 8] = 1
            args[1].copyfrom(state)
            args[3].copyfrom(np.full(512 * 512, 0xa5a5a5a5, dtype=np.uint32))
            args[4].copyfrom(np.full(512 * 12, -1515870811, dtype=np.int32))
            # [AI] Reopening only the gate cannot consume last generation's cleared payload.
            self.modules[capacity]['targeted_receive'](*args)
            self.assertEqual(int(args[-1].numpy()[0]), 3)
            self.assertEqual(int(args[-1].numpy()[7]), 0)
            np.testing.assert_array_equal(args[3].numpy(), 0xa5a5a5a5)
            np.testing.assert_array_equal(args[4].numpy(), -1515870811)
            new_features, new_assists = [], []
            for token in range(size):
                feature = features[token] ^ np.uint32(0x80008000)
                assist = assists[token].view(np.uint32) ^ np.uint32(0x40000000)
                new_features.append(feature)
                new_assists.append(assist.view(np.int32))
                offset = token * 256
                payload[offset:offset + 120] = feature[:120]
                payload[offset + 128:offset + 136] = feature[120:]
                payload[offset + 136:offset + 139] = assist
            state = args[1].numpy()
            state[GATE_WORD:GATE_WORD + 8] = 1
            args[1].copyfrom(state)
            args[2].copyfrom(payload)
            self.modules[capacity]['targeted_receive'](*args)
            self.assertEqual(int(args[-1].numpy()[0]), 0)
            self.assertEqual(int(args[-1].numpy()[7]), size)
            np.testing.assert_array_equal(args[3].numpy()[:size * 128], np.concatenate(new_features))
            np.testing.assert_array_equal(args[4].numpy()[:size * 3], np.concatenate(new_assists))
            for token in range(size):
                payload[token * 256 + 120:token * 256 + 128] = 0
                payload[token * 256 + 248:token * 256 + 256] = 0
            np.testing.assert_array_equal(args[2].numpy(), payload)


if __name__ == '__main__':
    unittest.main()
