"""Execute the real TL data-path macros as serialized C on CPU.

Tests arithmetic, offsets, complete route coverage and round reuse against an
independent token/expert oracle. MTE overlap, scheduling, and performance still
require the A5 correctness/capture rounds; CPU execution is not device evidence.
"""
import importlib.util
from pathlib import Path
import tempfile
import unittest


def compile_cpu(primitive, directory, name):
    """[AI] 执行真实TL宏的串行分支；不模拟设备DMA/跨流水时序。"""
    import tilelang as tl
    # [AI] 保留实际操作，仅去掉引用块内局部变量的推导region注解并转换CPU存储scope。
    def without_regions(node):
        if isinstance(node, tl.tvm.tir.Block):
            return tl.tvm.tir.Block(node.iter_vars, [], [], node.name_hint, node.body,
                node.init, node.alloc_buffers, node.match_buffers, node.annotations)
    primitive = primitive.with_body(tl.tvm.tir.stmt_functor.ir_transform(primitive.body, None, without_regions))
    primitive = tl.tvm.script.from_source(primitive.script().replace('"local.var"', '"local"')
                                         .replace('"shared.ub"', '"local"'))
    def unsigned_div(node):
        if isinstance(node, tl.tvm.tir.For) and not tl.tvm.arith.Analyzer().can_prove(node.min == 0):
            body = tl.tvm.tir.stmt_functor.substitute(node.body, {node.loop_var: node.loop_var + node.min})
            return tl.tvm.tir.For(node.loop_var, 0, node.extent, node.kind, body,
                                  node.thread_binding, node.annotations)
        if isinstance(node, tl.tvm.tir.FloorDiv) and node.dtype == 'uint64':
            return tl.tvm.tir.truncdiv(node.a, node.b)
        if isinstance(node, tl.tvm.tir.FloorMod) and node.dtype == 'uint64':
            return tl.tvm.tir.truncmod(node.a, node.b)
    primitive = primitive.with_body(tl.tvm.tir.stmt_functor.ir_transform(primitive.body, None, unsigned_div))
    lib = Path(directory) / (name + '.so')
    tl.tvm.build(primitive, target='c', name=name).export_library(str(lib))
    return tl.tvm.runtime.load_module(str(lib))


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class BatchKernelTests(unittest.TestCase):
    def test_complete_data_path_and_reuse(self):
        import numpy as np
        import tilelang as tl
        import tilelang.language as T
        from ..contract import Config, STATE_WORDS
        from ..kernel import (layout, send_round, count_split, status_split, receive_split,
                              count_publish, pack_send, count_prefix, receive_output, receive_ub_plan)
        from ..analyze_a5 import check_windows, check_diagnostics
        for tokens, core_counts in ((4, (56, 64)), (16, (56, 64)), (64, (56, 64)),
                                   (256, (56, 64)), (4, (4, 8)), (256, (8, 12)),
                                   (256, (64, 64))):
            implementations = []
            for rank, cores in enumerate(core_counts):
                receive_capacity = receive_ub_plan(tokens, cores)["batch_capacity"]
                @T.prim_func
                def phase(params: T.Tensor((16,), 'uint64'), x: T.Tensor((tokens*128,), 'uint32'),
                          ids: T.Tensor((tokens*2,), 'int32'),
                          state0: T.Tensor((STATE_WORDS,), 'uint32'), state1: T.Tensor((STATE_WORDS,), 'uint32'),
                          data0: T.Tensor((tokens*1024,), 'uint32'), data1: T.Tensor((tokens*1024,), 'uint32'),
                          output: T.Tensor((tokens*512,), 'uint32'), assist: T.Tensor((tokens*12,), 'int32'),
                          counts: T.Tensor((4,), 'int32'), nums_out: T.Tensor((2,), 'int64'),
                          diagnostics: T.Tensor((cores*16,), 'int32'), step: T.int32):
                    for core in T.serial(cores):
                        with T.block('core'):
                            p = T.alloc_buffer((16,), 'uint64', scope='local')
                            o = T.alloc_buffer((64,), 'uint64', scope='local')
                            route = T.alloc_buffer((tokens*2,), 'int32', scope='local')
                            amounts = T.alloc_buffer((4,), 'uint32', scope='local')
                            record = T.alloc_buffer((256,), 'uint32', scope='local')
                            feature = T.alloc_buffer((128,), 'uint32', scope='local')
                            records = T.alloc_buffer((32,), 'uint32', scope='local')
                            prefix = T.alloc_buffer((4,), 'int32', scope='local')
                            small = T.alloc_buffer((8,), 'uint32', scope='local')
                            nums = T.alloc_buffer((2,), 'int64', scope='local')
                            diag = T.alloc_buffer((16,), 'int32', scope='local')
                            for i in T.serial(16):
                                p[i] = params[i]
                                diag[i] = diagnostics[core*16+i]
                            for i in T.serial(tokens*2):
                                route[i] = ids[i]
                            layout(p, o)
                            send_round(p, o)
                            count_split(p, o, core)
                            if step == 0:
                                count_publish(route, state0, state1, rank, small, amounts, diag, o, tokens*2, True)
                                if core < cores-1:
                                    pack_send(x, route, data0, data1, record, feature, core, rank, diag, o, tokens*2, True)
                            elif step == 1:
                                if core == cores-1:
                                    status_split(p, o, core)
                                    if rank == 0:
                                        count_prefix(state0, counts, core, cores, 100, records, prefix, small, diag, o, True, 3)
                                    else:
                                        count_prefix(state1, counts, core, cores, 100, records, prefix, small, diag, o, True, 3)
                            else:
                                receive_split(p, o, core)
                                if rank == 0:
                                    receive_output(state0, data0, output, assist, nums_out, core, rank, cores, 100,
                                                   small, prefix, nums, diag, o, True, receive_capacity)
                                else:
                                    receive_output(state1, data1, output, assist, nums_out, core, rank, cores, 100,
                                                   small, prefix, nums, diag, o, True, receive_capacity)
                            for i in T.serial(16):
                                diagnostics[core*16+i] = diag[i]
                with tempfile.TemporaryDirectory() as directory:
                    implementations.append(compile_cpu(phase, directory, 'phase'))
            array = tl.tvm.nd.array
            states = [array(np.zeros(STATE_WORDS, dtype=np.uint32)) for _ in range(2)]
            payloads = [array(np.zeros(tokens*1024, dtype=np.uint32)) for _ in range(2)]
            ids = np.array([(t%2, t%2+2) for t in range(tokens)], dtype=np.int32)
            xs = [np.array([[0x3f80 + rank*0x80 + t*0x10 + h%32 for h in range(256)]
                            for t in range(tokens)], dtype=np.uint16) for rank in range(2)]
            for magic in (1, 2):
                if magic == 2:
                    # 相同专家总量但打散路由，核对非连续专家位置和第二轮窗口复用。
                    np.random.default_rng(tokens).shuffle(ids.reshape(-1))
                args = []
                for rank, cores in enumerate(core_counts):
                    args.append([array(np.array(Config(tokens=tokens, rank=rank, block_dim=cores, magic=magic).words(),
                                                dtype=np.uint64)), array(xs[rank].reshape(-1).view(np.uint32)),
                                 array(ids.reshape(-1)), *states, *payloads,
                                 array(np.full(tokens*512, 0xa5a5a5a5, dtype=np.uint32)),
                                 array(np.full(tokens*12, -1515870811, dtype=np.int32)),
                                 array(np.zeros(4, dtype=np.int32)), array(np.zeros(2, dtype=np.int64)),
                                 array(np.zeros(cores*16, dtype=np.int32))])
                for step in range(3):
                    for rank in range(2):
                        implementations[rank]['phase'](*args[rank], step)
                for rank, cores in enumerate(core_counts):
                    expected_x, expected_assist, expected_counts = [], [], []
                    for expert in (rank*2, rank*2+1):
                        for source in range(2):
                            for token in range(tokens):
                                for k in range(2):
                                    if ids[token,k] == expert:
                                        expected_x.extend(xs[source][token])
                                        expected_assist.extend((source,token,k))
                            expected_counts.append(len(expected_assist)//3)
                    actual = args[rank]
                    want_x = np.array(expected_x, dtype=np.uint16).view(np.uint32)
                    np.testing.assert_array_equal(actual[7].numpy()[:len(want_x)], want_x)
                    np.testing.assert_array_equal(actual[7].numpy()[len(want_x):], 0xa5a5a5a5)
                    np.testing.assert_array_equal(actual[8].numpy()[:tokens*6], expected_assist)
                    np.testing.assert_array_equal(actual[8].numpy()[tokens*6:], -1515870811)
                    np.testing.assert_array_equal(actual[9].numpy(), expected_counts)
                    np.testing.assert_array_equal(actual[10].numpy(), [tokens,tokens])
                    check_windows(states[rank].numpy(), payloads[rank].numpy(), cores, tokens)
                    with tempfile.TemporaryDirectory() as directory:
                        path = Path(directory)/'diagnostics.bin'
                        path.write_bytes(actual[11].numpy().tobytes())
                        check_diagnostics(path, cores, tokens=tokens)


if __name__ == '__main__':
    unittest.main()
