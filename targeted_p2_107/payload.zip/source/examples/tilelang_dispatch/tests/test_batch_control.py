"""Batch gate, fail-stop control and lossless per-round reporting; no NPU."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from ..tools.run_batch import run_batch, write_tables


class BatchControlTests(unittest.TestCase):
    def test_gate_and_occupancy_failure_stop_before_next_case(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            release = root / 'release.json'
            release.write_text(json.dumps({'status': 'NOT_RELEASED'}))
            args = SimpleNamespace(mode='correctness', rounds=3, warmup=20, devices=[0, 1],
                start_release=release, start_release_sha256=hashlib.sha256(release.read_bytes()).hexdigest(),
                cases_root=root/'cases', suite_root=root/'suite', output=root/'run', comm_port=39090)
            with patch('examples.tilelang_dispatch.tools.run_batch.run') as device:
                with self.assertRaisesRegex(ValueError, 'released'):
                    run_batch(args)
                device.assert_not_called()
            release.write_text(json.dumps({'status': 'READY_AFTER_NATIVE_FORMAL_DELIVERY'}))
            args.start_release_sha256 = hashlib.sha256(release.read_bytes()).hexdigest()
            with patch('examples.tilelang_dispatch.tools.run_batch.batch_identity', return_value={f'bs{t}': {'cores': [8,12]} for t in (16,64,256)}), \
                    patch('examples.tilelang_dispatch.tools.run_batch.run',
                          side_effect=RuntimeError('busy or unknown occupancy')) as device:
                with self.assertRaisesRegex(RuntimeError, 'occupancy'):
                    run_batch(args)
                self.assertEqual(device.call_count, 1)
                self.assertEqual(device.call_args.args[0].fixture.name, 'bs16')
                failure = json.loads((args.output / 'failure.json').read_text())
                self.assertEqual(failure['completed'], [])
                self.assertFalse((args.output / 'bs64/round1').exists())

    def test_tables_preserve_long_tail_and_maximum_ties(self):
        metric = dict(mean_ticks=6, max_ticks=9, per_core_sum_ticks={0: 9, 1: 9, 2: 0},
                      participating_cores=3, active_workload_cores=2, workload={'received_records': 8})
        captures = [dict(capture_id=str(number), **{field: {'F6': copy.deepcopy(metric)}
                    for field in ('modules', 'functions', 'stages')}) for number in (1, 2)]
        evidence = [dict(device_task_us=value, F5_wait_ticks=10,
                        pre_allreduce=dict(dispatch_event_us=value+1, pre_dispatch_event_us=100,
                                           segment_event_us=value+101)) for value in (20, 200)]
        summary = {'cases': {'bs64': {'rank_results': [dict(rank=0, cores=56,
                    captures=captures, round_evidence=evidence)]}}}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            write_tables(summary, root)
            timing = json.loads((root/'timing-rounds.json').read_text())
            self.assertEqual([row['device_task_us'] for row in timing], [20, 200])
            self.assertEqual(timing[1]['T'], 64)
            with (root/'substage-rounds.csv').open() as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(json.loads(rows[0]['max_core_ids']), [0, 1])
            self.assertEqual(json.loads(rows[0]['workload']), {'received_records': 8})
            self.assertEqual([row['round'] for row in rows], ['1', '2'])


if __name__ == '__main__':
    unittest.main()
