"""Synthetic Host evidence and A/B scheduling tests, not device qualification."""
import copy
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from ..analyze_pre_allreduce import check_pre_allreduce
from .test_analyze_a5 import write_csv, write_json
from ..tools.run_pre_allreduce import run_ab


class PreAllReduceTests(unittest.TestCase):
    def evidence(self, root, enabled):
        mode = 'allreduce' if enabled else 'none'
        schedule = {'schema':'tilelang_pre_allreduce.v1', 'mode':mode, 'rank':0,
                    'count':1, 'dtype':'INT32', 'reduction':'SUM', 'send_value':1,
                    'expected_sum':2, 'common_warmup_result':2, 'same_stream':True,
                    'warmup_pre_allreduce_launches':20 if enabled else 0,
                    'validated_warmup_results':20 if enabled else 0,
                    'measured_pre_allreduce_launches':int(enabled),
                    'common_warmup_completed_ns':10, 'preparation_completed_ns':20}
        write_json(root / 'allreduce-schedule.json', schedule)
        write_csv(root / 'native-barriers.csv', [dict(step='warmup_ready',enter_ns=30)])
        (root / 'allreduce-send.bin').write_bytes(struct.pack('<i',1))
        (root / 'allreduce-results.bin').write_bytes(struct.pack('<i',2) * (22 if enabled else 1))
        row = dict(round=20,magic=21,rank=0,mode=mode,segment_event_us=12,
                   dispatch_event_us=10,pre_dispatch_event_us=2,
                   segment_start_enqueue_ns=60,allreduce_before_ns=65 if enabled else 0,
                   allreduce_after_ns=70 if enabled else 0,
                   dispatch_launch_before_ns=85,dispatch_launch_after_ns=90,
                   segment_sync_end_ns=100,validation_ns=110,
                   allreduce_result='2' if enabled else 'NOT_RUN')
        write_csv(root / 'allreduce.csv',[row])
        host = dict(barrier_exit_ns=50,event_start_enqueue_ns=80,
                    launch_before_ns=85,launch_after_ns=90,sync_end_ns=100)
        return schedule, row, host

    def test_modes_revalidate_sum_and_timing(self):
        for enabled in (False,True):
            with self.subTest(enabled=enabled), tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp); schedule,row,host=self.evidence(root,enabled)
                mode=schedule['mode']
                self.assertEqual(check_pre_allreduce(root,0,20,21,mode,host,10)['sum_results_checked'],
                                 22 if enabled else 1)
                p=root/'allreduce-results.bin';original=p.read_bytes();p.write_bytes(struct.pack('<i',3)+original[4:])
                with self.assertRaisesRegex(ValueError,'SUM result'): check_pre_allreduce(root,0,20,21,mode,host,10)
                p.write_bytes(original)
                row['allreduce_before_ns']=101
                write_csv(root/'allreduce.csv',[row])
                with self.assertRaises(ValueError): check_pre_allreduce(root,0,20,21,mode,host,10)

    def test_preparation_after_barrier_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);schedule,row,host=self.evidence(root,True)
            schedule['preparation_completed_ns']=31
            write_json(root/'allreduce-schedule.json',schedule)
            with self.assertRaisesRegex(ValueError,'preparation'): check_pre_allreduce(root,0,20,21,'allreduce',host,10)

    def test_interleaved_order_validates_each_round_and_stops_on_failure(self):
        for fail_at in (None,2):
            with self.subTest(fail_at=fail_at), tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)
                args=SimpleNamespace(install=root/'install',fixture=root/'fixture',generated=root/'generated',
                    output=root/'out',correctness=None,mode='correctness',rounds=3,warmup=20,
                    devices=[0,1],timeout=180,comm_port=39090)
                calls=[]
                def fake_run(current):
                    calls.append(('run',current.pre_allreduce))
                    current.output.mkdir()
                def fake_analyze(*unused):
                    calls.append(('analyze',None))
                    if fail_at is not None and sum(c[0]=='analyze' for c in calls)==fail_at:
                        raise ValueError('result failed')
                    return {'status':'PASS','rank_results':[]}
                with patch('examples.tilelang_dispatch.tools.run_pre_allreduce.candidate_identity',return_value={'same':True, 'cores':[8,12]}), \
                     patch('examples.tilelang_dispatch.tools.run_pre_allreduce.run',side_effect=fake_run), \
                     patch('examples.tilelang_dispatch.tools.run_pre_allreduce.analyze',side_effect=fake_analyze), \
                     patch('examples.tilelang_dispatch.tools.run_pre_allreduce.aggregate',return_value={}):
                    if fail_at:
                        with self.assertRaisesRegex(ValueError,'result failed'):run_ab(args)
                        self.assertEqual(len(calls),4)
                        self.assertFalse((args.output/'summary.json').exists())
                    else:
                        result=run_ab(args)
                        self.assertEqual(result['status'],'PASS')
                        self.assertEqual([c[1] for c in calls if c[0]=='run'],
                                         ['none','allreduce','allreduce','none','none','allreduce'])
                        self.assertEqual([c[0] for c in calls],['run','analyze']*6)

    def test_capture_requires_matching_correctness(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            args=SimpleNamespace(install=root/'install',fixture=root/'fixture',generated=root/'generated',
                output=root/'out',correctness=None,mode='capture',rounds=5,warmup=20,
                devices=[0,1],timeout=180,comm_port=39090)
            with patch('examples.tilelang_dispatch.tools.run_pre_allreduce.candidate_identity',return_value={'same':True, 'cores':[8,12]}):
                with self.assertRaisesRegex(ValueError,'requires completed'):run_ab(args)
                self.assertFalse(args.output.exists())
                args.correctness=root/'correctness';args.correctness.mkdir()
                write_json(args.correctness/'summary.json',dict(status='PASS',mode='correctness',
                    rounds_per_group=3,identity={'different':True},devices=[0,1],warmup=20))
                with self.assertRaisesRegex(ValueError,'identity mismatch'):run_ab(args)
                self.assertFalse(args.output.exists())


if __name__=='__main__': unittest.main()
