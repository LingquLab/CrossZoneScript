"""把已审查的集成单kernel导出适配为纯 AIV TileXR 打点源码；不编译或运行设备。"""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from .contract import validate_rank_cores



ROOT = Path(__file__).resolve().parent
ARGS = ['params', 'x', 'ids', 'state0', 'state1',
        'data0', 'data1', 'output', 'assist', 'counts', 'expert_nums',
        'diagnostics', 'fftsAddr_unused_u64', 'profileGM']


def replace_once(source, old, new):
    """锁定导出适配锚点；缺失或重复时停止，防止错误插桩。"""
    if source.count(old) != 1:
        raise ValueError(f"Unexpected export: unique conversion anchor missing: {old[:90]!r}")
    return source.replace(old, new, 1)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def instrument(raw, spec, module, rank, cores, ready_probe=False):
    """行坐标仅适用于完整 SHA256 锁定的原样导出，不接受相似源码。"""
    if sha(raw.encode()) != spec['raw_sha256_by_rank'][str(rank)]:
        raise ValueError(f'{module}: source differs from reviewed export')
    lines = raw.splitlines(keepends=True)
    # 坐标为原始文件的行间隙：start-1之前，end之后。
    inserts = defaultdict(list)
    for stage in spec['stages']:
        start, end = stage['raw_lines']
        inserts[start - 1].append((stage, 'begin'))
        inserts[end].insert(0, (stage, 'end'))
    slot = 0
    result = []
    events = []
    for index, line in enumerate(lines):
        for stage, edge in inserts[index]:
            event = stage[edge]
            anchor = stage['raw_lines'][0 if edge == 'begin' else 1] - 1
            indent = lines[anchor][:len(lines[anchor]) - len(lines[anchor].lstrip())]
            label = '开始' if edge == 'begin' else '结束'
            result += [f'{indent}// 【{label} ID={event}】{stage["name"]}：{stage["description"]}\n',
                       f'{indent}recorder.RecordMarker<{slot}, {event}>();\n']
            events.append({'slot': slot, 'id': event, 'stage': stage['name'], 'edge': edge})
            slot += 1
        result.append(line)
    if slot > 64:
        raise ValueError('Recorder capacity exceeded')
    device = ''.join(result)
    delimiter = '\nvoid dispatch_kernel_tiling() {\n'
    if device.count(delimiter) != 1:
        raise ValueError('Missing unique Host wrapper boundary')
    device = device.split(delimiter)[0]
    device = replace_once(device, '#include "tl_templates/ascend/common.h"',
                          '#include "kernel_operator.h"\n#include <tilexr/profiling.h>\n#include "tl_templates/ascend/common.h"')
    device = replace_once(device, '#include <runtime/rt_ffts.h>\n', '')
    entry = f'tilexr_tl_dispatch_r{rank}_c{cores}'
    device = replace_once(device, 'void dispatch_kernel(', f'void {entry}(')
    device = replace_once(device, 'uint64_t fftsAddr) {', 'uint64_t fftsAddr, GM_ADDR profileGM) {')
    device = replace_once(device, 'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_1);',
                          'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);')
    # [AI] import_source可能增加声明行；在SHA锁定raw中定位完整TPipe缓冲段，保留实际UB偏移。
    setup_begin = raw.index('  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;')
    setup_end = raw.index('  pipe.Destroy();', setup_begin) + len('  pipe.Destroy();\n')
    setup = raw[setup_begin:setup_end]
    device = replace_once(device, setup,
        '  // AIV适配：保留实际UB，生命周期到全部工作和Flush之后。\n'
        '  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;\n'
        f'  pipe.InitBuffer(ascend_ub, {spec["ub_bytes"]});\n')
    device = replace_once(device, '  auto vid = AscendC::GetSubBlockIdx();',
        '  auto vid = AscendC::GetSubBlockIdx();\n'
        '  // Recorder初始化不计入module.whole；一个AIV核唯一拥有一条lane。\n'
        '  TileXR::Profiling::Recorder<64> recorder;')
    device = replace_once(device, '    }\n  }\n}\n',
        '      // Flush位于module.whole之外；profileGM来自当前launch的AclCapture。\n'
        '      recorder.Flush(profileGM, static_cast<uint32_t>(core));\n'
        '    }\n  }\n  pipe.Destroy();\n}\n')
    if ready_probe:
        device = add_ready_probe(device)
    return device, entry, events



def add_ready_probe(device):
    """仅对SHA锁定的原样导出添加有限诊断；不改业务原始TL或raw导出。"""
    device = replace_once(device, '#include "kernel_operator.h"',
                          '#include "kernel_operator.h"\n#include "ready_probe.h"')
    device = replace_once(device, '          ready = 0;\n          attempts = 0;',
        '          TileLangDiagnostic::ReadyProbe readyProbe(AscendC::GetSystemCycle());\n'
        '          ready = 0;\n          attempts = 0;')
    device = replace_once(device, '            ready = 1;\n',
                          '            ready = 1;\n            uint32_t readyMask = 0;\n')
    device = replace_once(device,
        '              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {\n'
        '                ready = 0;\n              }',
        '              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {\n'
        '                ready = 0;\n              } else {\n'
        '                readyMask |= 1U << static_cast<uint32_t>(q);\n              }')
    device = replace_once(device, '            attempts = (attempts + 1);\n',
        '            // Read the timer only when at least one previously unseen slot is ready.\n'
        '            readyProbe.Observe(readyMask, readyProbe.HasNew(readyMask) ?\n'
        '                AscendC::GetSystemCycle() : readyProbe.origin);\n'
        '            attempts = (attempts + 1);\n')
    device = replace_once(device, '          diag.SetValue(1, attempts);',
        '          for (int32_t slot = 0; slot < 4; ++slot)\n'
        '            diag.SetValue(11 + slot, readyProbe.first[slot]);\n'
        '          diag.SetValue(15, readyProbe.firstMask);\n'
        '          diag.SetValue(1, attempts);')
    return device

def adapt(source_dir, output_dir, ready_probe=False, recipe_path=None):
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    recipe_path = Path(recipe_path) if recipe_path is not None else ROOT / 'profile_recipe.json'
    recipe = json.loads(recipe_path.read_text())
    metadata = json.loads((source_dir / 'export.json').read_text())
    if any(metadata[key] != recipe[key] for key in ('backend_revision', 'backend_diff_sha256')):
        raise ValueError('Backend provenance differs from reviewed export')
    variant = metadata.get('variant', 'baseline')
    if variant != recipe.get('variant', 'baseline'):
        raise ValueError('F6 variant differs from reviewed recipe')
    targeted = metadata.get('targeted', 'B')
    if targeted != recipe.get('targeted', 'B'):
        raise ValueError('Targeted optimization differs from reviewed recipe')
    tokens = metadata.get('tokens_per_rank', 4)
    if tokens != recipe.get('tokens_per_rank', 4):
        raise ValueError('Batch size differs from reviewed recipe')
    rank, cores = metadata['rank'], metadata['cores']
    validate_rank_cores(rank, cores)
    if recipe.get('cores_by_rank', {}).get(str(rank)) != cores:
        raise ValueError('Core count differs from reviewed recipe; review a matching recipe first')
    outputs, rows = {}, []
    for item in metadata['modules']:
        module = item['module']
        raw_bytes = (source_dir / (module + '.raw.cpp')).read_bytes()
        if sha(raw_bytes) != item['source_sha256']:
            raise ValueError(f'{module}: export metadata hash mismatch')
        spec = recipe['modules'][module]
        if 'ub_bytes_by_rank' in spec:
            spec = dict(spec, ub_bytes=spec['ub_bytes_by_rank'][str(rank)])
        device, entry, events = instrument(raw_bytes.decode(), spec, module, rank, cores, ready_probe)
        mapping = {'schema': 'tilelang_dispatch_ticks.v1', 'contract': recipe['contract'],
                   'module': module, 'rank': rank, 'cores': cores, 'variant': variant, 'tokens_per_rank': tokens, 'targeted': targeted,
                   'observation': 'integrated_single_kernel',
                   'clock': 'AscendC::GetSystemCycle', 'unit': 'ticks', 'cycles_per_us': None,
                   'record_capacity': 64, 'events': events, 'stages': spec['stages'], 'module_groups': recipe['module_groups'],
                   'excluded': ['TPipe/UB setup', 'Recorder construction', 'Flush', 'pipe.Destroy', 'Host time'],
                   'aggregation': '每轮按实际参与核统计均值/最大值；轮间等权。不跨rank相减、不跨核相加，不把module.whole当ACL完整kernel时间。',
                   'validation_required': '所有核diagnostics[core*16]错误码为0且业务输出通过；诊断列1–10为轮询及工作量；11–15保留为0。'}
        if ready_probe:
            mapping['count_ready_probe'] = 'first_seen.v1'
            mapping['validation_required'] = ('Only prefix core uses diagnostics 11–14: first-seen relative ticks, '
                '-1 unseen, -2 overflow; 15 first-poll mask. Other cores retain zero. '
                'Origin is inside F5 after marker500; observations are not peer arrival timestamps.')
        outputs[module + '.raw.cpp'] = raw_bytes
        outputs[module + '.device.cpp'] = device.encode()
        outputs[module + '.ticks.json'] = (json.dumps(mapping, ensure_ascii=False, indent=2) + '\n').encode()
        rows.append({'module': module, 'entry': entry, 'ub_bytes': spec['ub_bytes'],
                     'marker_slots': len(events), 'record_capacity': 64,
                     'raw_sha256': sha(raw_bytes), 'device_sha256': sha(device.encode())})
    # 先验证全部输入，避免源不匹配留下部分生成结果；禁止覆写已有目录。
    output_dir.mkdir(parents=True, exist_ok=False)
    outputs['export.json'] = (source_dir / 'export.json').read_bytes()
    summary = {'schema': 'tilelang_dispatch_instrumentation.v1', 'rank': rank, 'cores': cores,
               'variant': variant, 'tokens_per_rank': tokens, 'targeted': targeted,
               'mode': 'AIV_ONLY', 'observation': 'integrated_single_kernel', 'args': ARGS, 'args_bytes_aarch64': 112,
               'recipe_sha256': sha(recipe_path.read_bytes()),
               'adapter_sha256': sha(Path(__file__).read_bytes()),
               'modules': rows, 'device_compile': 'NOT_RUN', 'device_execution': 'NOT_RUN',
               'changes': ['删除未使用Cube缓冲及Host三尖括号包装', '实际UB大小并延后Destroy',
                           '唯一纯AIV入口，追加profileGM', '加入Recorder/Marker/Flush；不增加流水同步'],
               'hashes': {name: sha(data) for name, data in outputs.items()}}
    if ready_probe:
        summary['count_ready_probe'] = 'first_seen.v1'
        summary['ready_probe_header_sha256'] = sha((ROOT / 'ready_probe.h').read_bytes())
        summary['changes'].append('F5 bounded first-seen diagnostics; diagnostic overhead, not optimization')
    for name, data in outputs.items():
        (output_dir / name).write_bytes(data)
    (output_dir / 'adaptation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ready-probe', action='store_true')
    parser.add_argument('--recipe', type=Path)
    args = parser.parse_args()
    result = adapt(args.source, args.output, args.ready_probe, args.recipe)
    print(json.dumps({'rank': result['rank'], 'modules': len(result['modules']),
                      'instrumentation': 'GENERATED', 'device_compile': 'NOT_RUN',
                      'device_execution': 'NOT_RUN'}))


if __name__ == '__main__':
    main()
