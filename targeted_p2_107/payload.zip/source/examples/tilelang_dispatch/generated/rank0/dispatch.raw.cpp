
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] 9.1/950整数归约：每repeat只比较32B槽首；Min和Max都为READY才全等。
// flags后的56个uint32保护区由TL初始化，末次repeat的整个256B读取范围均已分配。
// 两个结果独立32B对齐；950无需sharedTmpBuffer，按该版本文档传src。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    constexpr uint32_t result = Capacity * 16 + 56;
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows), 1,
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// [AI] assist保留uint32来源的全部位；GM输出仍是int32，不能用异型Tensor实例化同T模板。
template <uint32_t Capacity, uint32_t Pitch = 240>
__aicore__ inline void copy_ub_to_gm_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t dstPitch, uint32_t rows,
    uint32_t width) {
    auto signedSrc = src.ReinterpretCast<int32_t>();
    // import_source位于common.h之前；直接提交DMA，不依赖尚未声明的后端模板。
    AscendC::DataCopyExtParams params{static_cast<uint16_t>(rows), width * 4,
        (Pitch * 4 - width * 4) / 32, dstPitch * 4 - width * 4, 0};
    AscendC::DataCopyPad(dst, signedSrc, params);
}

// [AI] 两段都以1024B GM行距/544B UB行距提交；末行最大读到GM字节575。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_compact(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    AscendC::DataCopyParams first{static_cast<uint16_t>(rows), 15, 17, 2};
    AscendC::DataCopyParams second{static_cast<uint16_t>(rows), 2, 30, 15};
    AscendC::DataCopy(dst, src, first);
    AscendC::DataCopy(dst[120], src[128], second);
}
// [AI] 32B种子含两份真实prefix；重复源步长0，奇数核尾部仅留在已分配UB。
template <uint32_t Cores>
__aicore__ inline void copy_ub_to_ub_prefix(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(8), uint8_t((Cores + 1) / 2), {1, 1, 1, 0});
}
// F4: vector equality masks are computed once for all four experts. Padding is
// -1 and excluded from prefix counts. Every predicate row starts on 32 bytes.
template <uint32_t Count>
__aicore__ inline void copy_ub_to_ub_send_masks(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> route) {
    constexpr uint32_t padded = (Count + 63) / 64 * 64;
    constexpr uint32_t stride = ((padded / 32 + 7) / 8) * 8;
    auto values = scratch.ReinterpretCast<int32_t>();
    AscendC::Duplicate<int32_t>(values, -1, padded);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::DataCopy(values, route, Count);
    AscendC::PipeBarrier<PIPE_V>();
    for (int32_t expert = 0; expert < 4; ++expert) {
        auto predicate = scratch[padded + expert * stride].ReinterpretCast<uint8_t>();
        AscendC::Compares(predicate, values, expert, AscendC::CMPMODE::EQ, padded);
    }
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// Compact 2x480-byte data rows -> 2x512-byte wire rows; preserve READY tails.
__aicore__ inline void copy_ub_to_ub_send_pack(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(64), uint8_t(2), {1, 1, 16, 15});
    AscendC::Copy(dst[64], src[64], uint64_t(56), uint8_t(2), {1, 1, 16, 15});
}
} }
#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void dispatch_kernel( GM_ADDR params_handle,  GM_ADDR x_handle,  GM_ADDR ids_handle,  GM_ADDR state0_handle,  GM_ADDR state1_handle,  GM_ADDR data0_handle,  GM_ADDR data1_handle,  GM_ADDR output_handle,  GM_ADDR assist_handle,  GM_ADDR counts_handle,  GM_ADDR expert_nums_handle,  GM_ADDR diagnostics_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_1);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<uint64_t> params;
  params.SetGlobalBuffer((__gm__ uint64_t*)params_handle);
  AscendC::GlobalTensor<uint32_t> x;
  x.SetGlobalBuffer((__gm__ uint32_t*)x_handle);
  AscendC::GlobalTensor<int> ids;
  ids.SetGlobalBuffer((__gm__ int*)ids_handle);
  AscendC::GlobalTensor<uint32_t> state0;
  state0.SetGlobalBuffer((__gm__ uint32_t*)state0_handle);
  AscendC::GlobalTensor<uint32_t> state1;
  state1.SetGlobalBuffer((__gm__ uint32_t*)state1_handle);
  AscendC::GlobalTensor<uint32_t> data0;
  data0.SetGlobalBuffer((__gm__ uint32_t*)data0_handle);
  AscendC::GlobalTensor<uint32_t> data1;
  data1.SetGlobalBuffer((__gm__ uint32_t*)data1_handle);
  AscendC::GlobalTensor<uint32_t> output;
  output.SetGlobalBuffer((__gm__ uint32_t*)output_handle);
  AscendC::GlobalTensor<int> assist;
  assist.SetGlobalBuffer((__gm__ int*)assist_handle);
  AscendC::GlobalTensor<int> counts;
  counts.SetGlobalBuffer((__gm__ int*)counts_handle);
  AscendC::GlobalTensor<int64_t> expert_nums;
  expert_nums.SetGlobalBuffer((__gm__ int64_t*)expert_nums_handle);
  AscendC::GlobalTensor<int> diagnostics;
  diagnostics.SetGlobalBuffer((__gm__ int*)diagnostics_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 262144);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 262144);
  pipe.Destroy();
  auto core = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    }
  auto diag = ascend_ub.GetWithOffset<int>(16, 0);
  auto p = ascend_ub.GetWithOffset<uint64_t>(16, 64);
  uint64_t experts = (uint64_t)0;
  uint64_t cores = (uint64_t)0;
  uint64_t cumsum = (uint64_t)0;
  uint64_t feature = (uint64_t)0;
  uint64_t workspace = (uint64_t)0;
  uint64_t state_address = (uint64_t)0;
  auto o = ascend_ub.GetWithOffset<uint64_t>(64, 192);
  auto route = ascend_ub.GetWithOffset<int>(8, 704);
  uint64_t worker = (uint64_t)0;
  uint64_t n = (uint64_t)0;
  uint64_t b = (uint64_t)0;
  uint64_t begin = (uint64_t)0;
  uint64_t size = (uint64_t)0;
  auto amounts = ascend_ub.GetWithOffset<uint32_t>(4, 736);
  auto small = ascend_ub.GetWithOffset<uint32_t>(8, 768);
  int offset = 0;
  uint32_t amount = (uint32_t)0;
  auto record = ascend_ub.GetWithOffset<uint32_t>(256, 800);
  auto wire_b = ascend_ub.GetWithOffset<uint32_t>(256, 1824);
  auto compact = ascend_ub.GetWithOffset<uint32_t>(256, 2848);
  auto masks = ascend_ub.GetWithOffset<uint32_t>(96, 3872);
  int issued = 0;
  int offset_1 = 0;
  int offset_2 = 0;
  uint64_t worker_1 = (uint64_t)0;
  uint64_t n_1 = (uint64_t)0;
  uint64_t b_1 = (uint64_t)0;
  uint64_t begin_1 = (uint64_t)0;
  uint64_t size_1 = (uint64_t)0;
  int ready = 0;
  int attempts = 0;
  auto records = ascend_ub.GetWithOffset<uint32_t>(32, 4256);
  uint32_t total = (uint32_t)0;
  uint32_t running = (uint32_t)0;
  auto prefix = ascend_ub.GetWithOffset<int>(4, 4384);
  int workspace_word = 0;
  auto publish_buf = ascend_ub.GetWithOffset<uint32_t>(448, 4416);
  int route_index = 0;
  int expert = 0;
  int position = 0;
  int target = 0;
  int bucket = 0;
  int target_1 = 0;
  int bucket_1 = 0;
  uint32_t bits = (uint32_t)0;
  uint64_t worker_2 = (uint64_t)0;
  uint64_t n_2 = (uint64_t)0;
  uint64_t b_2 = (uint64_t)0;
  uint64_t begin_2 = (uint64_t)0;
  int ready_1 = 0;
  int attempts_1 = 0;
  auto nums = ascend_ub.GetWithOffset<int64_t>(2, 6208);
  int begin_3 = 0;
  int size_2 = 0;
  int bucket_2 = 0;
  int consumed = 0;
  int batch_index = 0;
  int pending_a = 0;
  int pending_b = 0;
  auto batch_flags = ascend_ub.GetWithOffset<uint32_t>(1544, 6240);
  int batch_count = 0;
  int offset_3 = 0;
  int arrived = 0;
  int polls = 0;
  auto batch_data_a = ascend_ub.GetWithOffset<uint32_t>(22080, 12416);
  auto batch_data_b = ascend_ub.GetWithOffset<uint32_t>(22080, 100736);
  int cleared = 0;
  int clear_count = 0;
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    if ASCEND_IS_AIV {
      for (int32_t i = 0; i < 16; ++i) {
        diag.SetValue(i, 0);
      }
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<uint64_t, 16>(p[0], params[0], 16, 1, 16, (uint64_t)0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      experts = p.GetValue(3);
      cores = p.GetValue(6);
      cumsum = ((((experts + (uint64_t)31) / (uint64_t)32) > (uint64_t)1 ? ((experts + (uint64_t)31) / (uint64_t)32) : (uint64_t)1) < ((cores / (uint64_t)2) < (uint64_t)8 ? (cores / (uint64_t)2) : (uint64_t)8) ? (((experts + (uint64_t)31) / (uint64_t)32) > (uint64_t)1 ? ((experts + (uint64_t)31) / (uint64_t)32) : (uint64_t)1) : ((cores / (uint64_t)2) < (uint64_t)8 ? (cores / (uint64_t)2) : (uint64_t)8));
      feature = (p.GetValue(1) * (uint64_t)2);
      feature = ((((feature + (uint64_t)31) / (uint64_t)32) + (uint64_t)15) / (uint64_t)15);
      feature = (feature * (uint64_t)512);
      workspace = ((((cores * experts) + (uint64_t)7) / (uint64_t)8) * (uint64_t)32);
      state_address = ((p.GetValue(8) + ((p.GetValue(7) % (uint64_t)2) * (uint64_t)1073741824)) + (uint64_t)2097152);
      o.SetValue(5, experts);
      o.SetValue(6, cumsum);
      o.SetValue(7, (cores - cumsum));
      o.SetValue(8, cores);
      if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
        o.SetValue(8, cumsum);
      }
      o.SetValue(14, feature);
      o.SetValue(15, ((p.GetValue(10) / p.GetValue(4)) * feature));
      o.SetValue(22, state_address);
      o.SetValue(25, ((state_address + (uint64_t)786432) - workspace));
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<int, 8>(route[0], ids[0], 8, 1, 8, 0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      o.SetValue(32, (uint64_t)1);
      if (((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) && ((p.GetValue(4) == (uint64_t)64) || (p.GetValue(4) == (uint64_t)128))) {
        o.SetValue(32, (uint64_t)2);
      }
      o.SetValue(34, (uint64_t)0);
      o.SetValue(35, (uint64_t)0);
      o.SetValue(36, (uint64_t)0);
      if (((p.GetValue(0) / (uint64_t)48) < (uint64_t)1) || (o.GetValue(7) <= ((uint64_t)core))) {
        worker = ((uint64_t)core);
        if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
          worker = (worker - o.GetValue(7));
        }
        n = p.GetValue(3);
        b = o.GetValue(8);
        begin = (((n / b) * worker) + (worker < (n % b) ? worker : (n % b)));
        size = ((n / b) + ((uint64_t)(worker < (n % b))));
        o.SetValue(34, begin);
        o.SetValue(35, (begin + size));
        o.SetValue(36, size);
      }
      if ((uint64_t)0 < o.GetValue(36)) {
        for (int32_t expert_1 = ((int32_t)o.GetValue(34)); expert_1 < ((int32_t)o.GetValue(35)); ++expert_1) {
          amount = (uint32_t)0;
          for (int32_t i_1 = 0; i_1 < 8; ++i_1) {
            if (route.GetValue(i_1) == expert_1) {
              amount = (amount + (uint32_t)1);
            }
          }
          amounts.SetValue(((int64_t)expert_1), amount);
        }
        diag.SetValue(4, ((int32_t)o.GetValue(36)));
        for (int32_t expert_2 = ((int32_t)o.GetValue(34)); expert_2 < ((int32_t)o.GetValue(35)); ++expert_2) {
          for (int32_t i_2 = 0; i_2 < 8; ++i_2) {
            small.SetValue(i_2, (uint32_t)0);
          }
          small.SetValue(0, (uint32_t)1065353216);
          small.SetValue(1, amounts.GetValue(((int64_t)expert_2)));
          offset = ((expert_2 % 2) * 16);
          if (expert_2 < 2) {
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            int32_t condval;
            if (offset <= 262136) {
              condval = 8;
            } else {
              int32_t condval_1;
              if (offset < 262144) {
                condval_1 = (262144 - offset);
              } else {
                condval_1 = 0;
              }
              condval = condval_1;
            }
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[offset], small[0], 262144, 1, condval);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          } else {
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            int32_t condval_2;
            if (offset <= 262136) {
              condval_2 = 8;
            } else {
              int32_t condval_3;
              if (offset < 262144) {
                condval_3 = (262144 - offset);
              } else {
                condval_3 = 0;
              }
              condval_2 = condval_3;
            }
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(state1[offset], small[0], 262144, 1, condval_2);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          AscendC::PipeBarrier<PIPE_MTE3>();
        }
      }
      if (((uint64_t)core) < o.GetValue(7)) {
        if ((core < 8) && (o.GetValue(32) == (uint64_t)1)) {
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(record[0], (uint32_t)1065353216, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(wire_b[0], (uint32_t)1065353216, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(compact[0], (uint32_t)0, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::copy_ub_to_ub_send_masks<8>(masks[0], route[0]);
          issued = 0;
          for (int32_t task = 0; task < ((7 / ((int32_t)o.GetValue(7))) + 1); ++task) {
            route_index = (core + (task * ((int32_t)o.GetValue(7))));
            if (route_index < 8) {
              expert = route.GetValue(route_index);
              if ((0 <= expert) && (expert < 4)) {
                position = 0;
                for (int32_t word = 0; word < ((route_index + 31) / 32); ++word) {
                  bits = masks.GetValue((((expert * 8) + word) + 64));
                  int32_t valid = (route_index - (word * 32));
                  if (valid < 32) {
                    bits = (bits & (((uint32_t)1 << ((uint32_t)valid)) - (uint32_t)1));
                  }
                  bits = (bits - ((bits >> (uint32_t)1) & (uint32_t)1431655765));
                  bits = ((bits & (uint32_t)858993459) + ((bits >> (uint32_t)2) & (uint32_t)858993459));
                  bits = ((bits + (bits >> (uint32_t)4)) & (uint32_t)252645135);
                  position = (position + ((int32_t)((bits * (uint32_t)16843009) >> (uint32_t)24)));
                }
                if ((issued % 2) == 0) {
                  if (2 <= issued) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 128, 1>(compact[0], x[((route_index / 2) * 128)], 128, 1, 128, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  compact.SetValue(128, (uint32_t)0);
                  compact.SetValue(129, ((uint32_t)(route_index / 2)));
                  compact.SetValue(130, ((uint32_t)(route_index % 2)));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::copy_ub_to_ub_send_pack(record[0], compact[0]);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  target = (expert / 2);
                  bucket = (((target % 2) * 2) + (expert % 2));
                  offset_1 = ((bucket * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (position * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  if (expert < 2) {
                    int32_t condval_4;
                    if (offset_1 <= 3840) {
                      condval_4 = 256;
                    } else {
                      int32_t condval_5;
                      if (offset_1 < 4096) {
                        condval_5 = (4096 - offset_1);
                      } else {
                        condval_5 = 0;
                      }
                      condval_4 = condval_5;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data0[offset_1], record[0], 4096, 1, condval_4);
                  } else {
                    int32_t condval_6;
                    if (offset_1 <= 3840) {
                      condval_6 = 256;
                    } else {
                      int32_t condval_7;
                      if (offset_1 < 4096) {
                        condval_7 = (4096 - offset_1);
                      } else {
                        condval_7 = 0;
                      }
                      condval_6 = condval_7;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data1[offset_1], record[0], 4096, 1, condval_6);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                } else {
                  if (2 <= issued) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 128, 1>(compact[0], x[((route_index / 2) * 128)], 128, 1, 128, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  compact.SetValue(128, (uint32_t)0);
                  compact.SetValue(129, ((uint32_t)(route_index / 2)));
                  compact.SetValue(130, ((uint32_t)(route_index % 2)));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::copy_ub_to_ub_send_pack(wire_b[0], compact[0]);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  target_1 = (expert / 2);
                  bucket_1 = (((target_1 % 2) * 2) + (expert % 2));
                  offset_2 = ((bucket_1 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (position * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  if (expert < 2) {
                    int32_t condval_8;
                    if (offset_2 <= 3840) {
                      condval_8 = 256;
                    } else {
                      int32_t condval_9;
                      if (offset_2 < 4096) {
                        condval_9 = (4096 - offset_2);
                      } else {
                        condval_9 = 0;
                      }
                      condval_8 = condval_9;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data0[offset_2], wire_b[0], 4096, 1, condval_8);
                  } else {
                    int32_t condval_10;
                    if (offset_2 <= 3840) {
                      condval_10 = 256;
                    } else {
                      int32_t condval_11;
                      if (offset_2 < 4096) {
                        condval_11 = (4096 - offset_2);
                      } else {
                        condval_11 = 0;
                      }
                      condval_10 = condval_11;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data1[offset_2], wire_b[0], 4096, 1, condval_10);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                }
                issued = (issued + 1);
                diag.SetValue(5, (diag.GetValue(5) + 1));
                diag.SetValue(9, (diag.GetValue(9) + ((int32_t)o.GetValue(14))));
              } else {
                diag.SetValue(0, 6);
              }
            }
          }
          if (0 < issued) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
          }
          if (1 < issued) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
          }
        }
      } else {
        worker_1 = (((uint64_t)core) - o.GetValue(7));
        n_1 = o.GetValue(5);
        b_1 = o.GetValue(6);
        begin_1 = (((n_1 / b_1) * worker_1) + (worker_1 < (n_1 % b_1) ? worker_1 : (n_1 % b_1)));
        size_1 = ((n_1 / b_1) + ((uint64_t)(worker_1 < (n_1 % b_1))));
        o.SetValue(38, begin_1);
        o.SetValue(39, (begin_1 + size_1));
        o.SetValue(40, size_1);
        if (core == 55) {
          ready = 0;
          attempts = 0;
          while (1) {
            if (!(((ready == 0) && (attempts < 100000)))) { break; }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 32>(records[0], state0[0], 262144, 1, 32, (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            ready = 1;
            for (int32_t q = ((int32_t)o.GetValue(38)); q < ((int32_t)o.GetValue(39)); ++q) {
              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {
                ready = 0;
              }
            }
            attempts = (attempts + 1);
          }
          diag.SetValue(1, attempts);
          diag.SetValue(6, ((int32_t)o.GetValue(40)));
          if (ready == 0) {
            diag.SetValue(0, 1);
          } else {
            total = (uint32_t)0;
            for (int32_t q_1 = ((int32_t)o.GetValue(38)); q_1 < ((int32_t)o.GetValue(39)); ++q_1) {
              total = (total + records.GetValue(((((int64_t)q_1) * (int64_t)8) + (int64_t)1)));
              records.SetValue((((int64_t)q_1) * (int64_t)8), (uint32_t)0);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 32>(state0[0], records[0], 262144, 1, 32);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            for (int32_t i_3 = 0; i_3 < 8; ++i_3) {
              small.SetValue(i_3, (uint32_t)0);
            }
            small.SetValue(0, total);
            small.SetValue(1, (uint32_t)1065353216);
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[222208], small[0], 262144, 1, 8);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], state0[222208], 262144, 1, 8, (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            if (small.GetValue(1) != (uint32_t)1065353216) {
              diag.SetValue(0, 4);
            } else {
              running = (uint32_t)0;
              for (int32_t q_2 = 0; q_2 < 4; ++q_2) {
                running = (running + records.GetValue(((q_2 * 8) + 1)));
                prefix.SetValue(q_2, ((int32_t)running));
              }
              for (int32_t i_4 = 0; i_4 < 8; ++i_4) {
                small.SetValue(i_4, (uint32_t)0);
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[222208], small[0], 262144, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<int, 4>(counts[0], prefix[0], 4, 1, 4);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              workspace_word = ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4));
              for (int32_t c = 0; c < 56; ++c) {
                for (int32_t q_3 = 0; q_3 < 4; ++q_3) {
                  publish_buf.SetValue(((c * 4) + q_3), ((uint32_t)prefix.GetValue(q_3)));
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              int32_t condval_12;
              if (workspace_word <= 261920) {
                condval_12 = 224;
              } else {
                int32_t condval_13;
                if (workspace_word < 262144) {
                  condval_13 = (262144 - workspace_word);
                } else {
                  condval_13 = 0;
                }
                condval_12 = condval_13;
              }
              tl::ascend::copy_ub_to_gm<uint32_t, 224>(state0[workspace_word], publish_buf[0], 262144, 1, condval_12);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::PipeBarrier<PIPE_MTE3>();
              for (int32_t i_5 = 0; i_5 < 8; ++i_5) {
                small.SetValue(i_5, (uint32_t)1);
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              for (int32_t c_1 = 0; c_1 < 56; ++c_1) {
                tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[((c_1 * 8) + 224256)], small[0], 262144, 1, 8);
              }
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::PipeBarrier<PIPE_MTE3>();
            }
          }
        }
      }
      AscendC::PipeBarrier<PIPE_ALL>();
      worker_2 = ((uint64_t)core);
      n_2 = o.GetValue(5);
      b_2 = p.GetValue(6);
      begin_2 = (((n_2 / b_2) * worker_2) + (worker_2 < (n_2 % b_2) ? worker_2 : (n_2 % b_2)));
      n_2 = ((n_2 / b_2) + ((uint64_t)(worker_2 < (n_2 % b_2))));
      o.SetValue(42, begin_2);
      o.SetValue(43, (begin_2 + n_2));
      o.SetValue(44, n_2);
      ready_1 = 0;
      attempts_1 = 0;
      while (1) {
        if (!(((ready_1 == 0) && (attempts_1 < 100000)))) { break; }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
        tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], state0[((core * 8) + 224256)], 262144, 1, 8, (uint32_t)0);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        ready_1 = 1;
        for (int32_t i_6 = 0; i_6 < 8; ++i_6) {
          if (small.GetValue(i_6) != (uint32_t)1) {
            ready_1 = 0;
          }
        }
        attempts_1 = (attempts_1 + 1);
      }
      diag.SetValue(2, attempts_1);
      if (ready_1 == 0) {
        if (diag.GetValue(0) == 0) {
          diag.SetValue(0, 2);
        }
      } else {
        for (int32_t i_7 = 0; i_7 < 8; ++i_7) {
          small.SetValue(i_7, (uint32_t)0);
        }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
        tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[((core * 8) + 224256)], small[0], 262144, 1, 8);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
        if ((uint64_t)0 < o.GetValue(44)) {
          diag.SetValue(8, ((int32_t)o.GetValue(44)));
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval_14;
          if (-262140 <= ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4))) {
            condval_14 = 4;
          } else {
            int32_t condval_15;
            if (-262144 < ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4))) {
              condval_15 = ((262144 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4));
            } else {
              condval_15 = 0;
            }
            condval_14 = condval_15;
          }
          tl::ascend::copy_gm_to_ub<uint32_t, 4>(small[0], state0[((core * 4) + ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4)))], 262144, 1, condval_14, (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
          for (int32_t i_8 = 0; i_8 < 4; ++i_8) {
            prefix.SetValue(i_8, ((int32_t)small.GetValue(i_8)));
          }
          if (core == 0) {
            nums.SetValue(0, ((int64_t)prefix.GetValue(1)));
            nums.SetValue(1, (((int64_t)prefix.GetValue(3)) - ((int64_t)prefix.GetValue(1))));
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int64_t, 2>(expert_nums[0], nums[0], 2, 1, 2);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          begin_3 = 0;
          if (0 < core) {
            begin_3 = prefix.GetValue((core - 1));
          }
          size_2 = (prefix.GetValue(core) - begin_3);
          bucket_2 = (((core % 2) * 2) + (core / 2));
          if ((((size_2 < 0) || (((int32_t)(o.GetValue(15) / o.GetValue(14))) < size_2)) || (begin_3 < 0)) || (((int32_t)(((uint64_t)4 * o.GetValue(15)) / o.GetValue(14))) < prefix.GetValue(core))) {
            if (diag.GetValue(0) == 0) {
              diag.SetValue(0, 5);
            }
          } else {
            consumed = 0;
            batch_index = 0;
            pending_a = 0;
            pending_b = 0;
            if (0 < size_2) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[0], (uint32_t)0, (~(uint64_t)0), 23, 1, 8);
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[1472], (uint32_t)0, (((uint64_t)1 << (uint64_t)56) - (uint64_t)1), 1, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
            }
            while (1) {
              if (!(((consumed < size_2) && (diag.GetValue(0) == 0)))) { break; }
              batch_count = (92 < (size_2 - consumed) ? 92 : (size_2 - consumed));
              offset_3 = ((bucket_2 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (consumed * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
              arrived = 0;
              polls = 0;
              while (1) {
                if (!(((arrived == 0) && (polls < 100000)))) { break; }
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                tl::ascend::copy_gm_to_ub_ready<92>(batch_flags[0], data0[(offset_3 + 120)], 128, (batch_count * 2), 8, (uint32_t)0);
                arrived = ((int32_t)((batch_flags.GetValue(1528) == (uint32_t)1065353216) && (batch_flags.GetValue(1536) == (uint32_t)1065353216)));
                polls = (polls + 1);
              }
              diag.SetValue(3, (diag.GetValue(3) + (polls * batch_count)));
              if (arrived == 0) {
                diag.SetValue(0, 3);
              } else {
                if ((batch_index % 2) == 0) {
                  if (pending_a != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 184>(batch_data_a[0], data0[offset_3], 128, (batch_count * 2), 120, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 240, 92>(output[((begin_3 * 128) + (consumed * 128))], batch_data_a[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm_assist<92>(assist[((begin_3 * 3) + (consumed * 3))], batch_data_a[128], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                  pending_a = 1;
                } else {
                  if (pending_b != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 184>(batch_data_b[0], data0[offset_3], 128, (batch_count * 2), 120, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 240, 92>(output[((begin_3 * 128) + (consumed * 128))], batch_data_b[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm_assist<92>(assist[((begin_3 * 3) + (consumed * 3))], batch_data_b[128], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                  pending_b = 1;
                }
                batch_index = (batch_index + 1);
                consumed = (consumed + batch_count);
              }
            }
            if (pending_a != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
            }
            if (pending_b != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
            }
            diag.SetValue(7, consumed);
            diag.SetValue(10, (consumed * ((int32_t)o.GetValue(14))));
            for (int32_t i_9 = 0; i_9 < ((92 < consumed ? 92 : consumed) * 16); ++i_9) {
              batch_flags.SetValue(i_9, (uint32_t)0);
            }
            cleared = 0;
            while (1) {
              if (!((cleared < consumed))) { break; }
              clear_count = (92 < (consumed - cleared) ? 92 : (consumed - cleared));
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8, 184>(data0[(((bucket_2 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (cleared * ((int32_t)(o.GetValue(14) / (uint64_t)4)))) + 120)], batch_flags[0], 128, (clear_count * 2), 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              cleared = (cleared + clear_count);
            }
          }
        }
        AscendC::PipeBarrier<PIPE_MTE3>();
      }
      AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
      tl::ascend::copy_ub_to_gm<int, 16>(diagnostics[(core * 16)], diag[0], 896, 1, 16);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
    }
  }
}

void dispatch_kernel_tiling() {
}

extern "C" void call(uint8_t* params_handle, uint8_t* x_handle, uint8_t* ids_handle, uint8_t* state0_handle, uint8_t* state1_handle, uint8_t* data0_handle, uint8_t* data1_handle, uint8_t* output_handle, uint8_t* assist_handle, uint8_t* counts_handle, uint8_t* expert_nums_handle, uint8_t* diagnostics_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  dispatch_kernel_tiling();
  dispatch_kernel<<<56, nullptr, stream>>>(params_handle, x_handle, ids_handle, state0_handle, state1_handle, data0_handle, data1_handle, output_handle, assist_handle, counts_handle, expert_nums_handle, diagnostics_handle, fftsAddr);
}
