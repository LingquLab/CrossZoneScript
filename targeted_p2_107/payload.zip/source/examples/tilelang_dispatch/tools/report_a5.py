"""从核验后的 TileXR 原始区间生成可离线查看的 ticks 时间线与逐轮表。"""
import argparse
import json
from pathlib import Path


HTML = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<title>TileLang 集成 Dispatch 打点结果</title>
<style>
body{font:15px system-ui,sans-serif;margin:28px;color:#1a2838;background:#f4f7fb}
main{max-width:1280px;margin:auto}h1{font-size:26px}p{line-height:1.7}
table{border-collapse:collapse;background:white;width:100%;margin:18px 0}
th,td{padding:9px 12px;border-bottom:1px solid #dce4ef;text-align:right}
th:first-child,td:first-child{text-align:left}select{padding:7px;margin-right:18px}
#plot{overflow:auto;background:white;border:1px solid #dce4ef;margin-top:16px}
small{color:#506278}.legend{display:flex;gap:15px;flex-wrap:wrap}
</style><main><h1>每 rank 一个 Dispatch kernel</h1>
<p>内部时间单位为 <strong>raw ticks</strong>，频率未校准；完整 kernel 的 ACL event 另列微秒。
五模块先在同核内累计不重叠功能片段，再按参与核计算均值/最大值。
不同核可以并行，不能将模块均值相加作为完整 Dispatch 延迟。</p>
<div id="overall"></div>
<label>rank <select id="rank"><option>0</option><option>1</option></select></label>
<label>采集轮 <select id="round"></select></label>
<div id="table"></div><div class="legend" id="legend"></div>
<p><small>每条核泳道以自己的 whole 起点为零；横向对齐仅用于比较核内相对位置，
不是跨核或跨 rank 的同步时钟。蓝灰色表示 harness；hover 查看原始 tick 起止。</small></p>
<div id="plot"></div>
<script type="application/json" id="data">__DATA__</script>
<script>
const data=JSON.parse(document.getElementById('data').textContent);
const names={prepare:'准备与路由（F0+F1）',count_publish:'计数与发布（F2+F3）',
pack_send:'打包与发送（F4）',count_prefix:'计数接收与前缀和（F5+F6）',receive_output:'接收与输出（F7+F8+F9）'};
const colors={F0:'#3b82f6',F1:'#06b6d4',F2:'#8b5cf6',F3:'#a855f7',F4:'#f59e0b',
F5:'#ef4444',F6:'#f97316',F7:'#14b8a6',F8:'#22c55e',F9:'#84cc16'};
const fmt=x=>Number(x).toFixed(3), el=id=>document.getElementById(id);
el('overall').innerHTML='<table><tr><th>完整 kernel ACL event（µs）</th><th>均值</th><th>中位数</th><th>最小</th><th>最大</th></tr>'+
data.rank_results.map(r=>'<tr><td>rank '+r.rank+'</td>'+['mean','median','min','max'].map(k=>'<td>'+fmt(r.acl_event_us[k])+'</td>').join('')+'</tr>').join('')+'</table>';
el('legend').innerHTML=Object.entries(colors).map(([n,c])=>'<span style="color:'+c+'">■ '+n+'</span>').join('');
for(let i=0;i<data.rounds;i++){const o=document.createElement('option');o.value=i;o.textContent=i+1;el('round').appendChild(o);}
const ns='http://www.w3.org/2000/svg';
function svgNode(name,attrs){const n=document.createElementNS(ns,name);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));return n;}
function draw(){
 const rank=data.rank_results[Number(el('rank').value)], j=Number(el('round').value), cap=rank.captures[j];
 el('table').innerHTML='<p>实际迭代 '+cap.iteration+'；本轮完整 kernel ACL：'+fmt(rank.acl_event_per_round_us[j])+' µs</p>'+
 '<table><tr><th>模块</th><th>参与核均值（ticks）</th><th>参与核最大（ticks）</th><th>参与核数</th><th>有数据工作核数</th></tr>'+
 Object.entries(cap.modules).map(([name,v])=>'<tr><td>'+names[name]+'</td><td>'+fmt(v.mean_ticks)+'</td><td>'+fmt(v.max_ticks)+'</td><td>'+v.participating_cores+'</td><td>'+v.active_workload_cores+'</td></tr>').join('')+'</table>';
 const whole=lane=>Object.values(lane.intervals).find(v=>v.is_whole);
 const max=Math.max(...cap.lanes.map(l=>whole(l).ticks));
 const width=1180,left=70,usable=1080,height=45+cap.lanes.length*25;
 const svg=svgNode('svg',{viewBox:'0 0 '+width+' '+height,width,height});
 for(let i=0;i<=5;i++){const x=left+usable*i/5;svg.appendChild(svgNode('line',{x1:x,x2:x,y1:25,y2:height,stroke:'#e2e8f0'}));
 const t=svgNode('text',{x,y:17,'font-size':11,fill:'#506278'});t.textContent=Math.round(max*i/5)+' ticks';svg.appendChild(t);}
 cap.lanes.forEach((lane,i)=>{const y=35+i*25,origin=whole(lane).begin_tick;
 const label=svgNode('text',{x:8,y:y+12,'font-size':11});label.textContent='核 '+lane.core;svg.appendChild(label);
 Object.entries(lane.intervals).filter(([,v])=>!v.is_whole).forEach(([name,v])=>{
 const bar=svgNode('rect',{x:left+(v.begin_tick-origin)/max*usable,y,width:Math.max(.6,v.ticks/max*usable),height:17,fill:colors[name.split('.')[0]]||'#94a3b8'});
 const title=svgNode('title',{});title.textContent=name+' | '+v.ticks+' ticks | '+v.begin_tick+' → '+v.end_tick;bar.appendChild(title);svg.appendChild(bar);});});
 el('plot').replaceChildren(svg);
}
el('rank').onchange=el('round').onchange=draw;draw();
</script></main></html>'''


def report(result, output):
    if result.get('status') != 'PASS' or not result.get('capture_checked'):
        raise ValueError('A verified capture analysis is required')
    # The report never assigns a ticks/us conversion or manufactures a common
    # core clock. The raw trace files preserve the original SDK timestamps.
    data = json.loads(json.dumps(result))
    traces = []
    for rank in data['rank_results']:
        for cap in rank['captures']:
            if not cap['performance_sample_accepted'] or cap['operator_correctness'] != 'PASS':
                raise ValueError('Unaccepted capture cannot become a performance report')
            for lane in cap['lanes']:
                whole = [v for name, v in lane['intervals'].items() if name.endswith('.whole')]
                if len(whole) != 1 or whole[0]['ticks'] <= 0:
                    raise ValueError('Missing or invalid whole interval')
                whole[0]['is_whole'] = True
            name = f"rank{rank['rank']}-iteration{cap['iteration']}.ticks.json"
            traces.append((name, {'schema': 'tilelang_dispatch_raw_tick_trace.v1',
                                 'unit': 'ticks', 'cycles_per_us': None,
                                 'rank': rank['rank'], 'iteration': cap['iteration'],
                                 'capture_id': cap['capture_id'],
                                 'clock_alignment': 'unverified across cores/ranks',
                                 'lanes': cap['lanes']}))
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'traces').mkdir()
    for name, trace in traces:
        (output / 'traces' / name).write_text(json.dumps(trace, ensure_ascii=False, indent=2) + '\n')
    serialized = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
    (output / 'index.html').write_text(HTML.replace('__DATA__', serialized))
    return {'reports': len(traces), 'core_lanes': sum(len(t['lanes']) for _, t in traces),
            'intervals': sum(len(l['intervals']) for _, t in traces for l in t['lanes']),
            'unit': 'ticks', 'cycles_per_us': None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(report(json.loads(args.analysis.read_text()), args.output)))
