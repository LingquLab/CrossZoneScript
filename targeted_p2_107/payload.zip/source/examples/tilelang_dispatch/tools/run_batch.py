"""Run the three reviewed batch specializations with the same AR/Host schedule.

Requires a SHA-bound coordinator release file before any device launch. Each
individual round delegates occupancy checks and fresh process ownership to
run_native; busy/unknown occupancy or any failed validation stops the batch.
"""
import argparse
import copy
import csv
import json
from pathlib import Path

from ..analyze_a5 import fixture_tokens, require
from ..analyze_native import analyze
from ..contract import core_pairs
from ..run_native import digest, run, save
from .run_pre_allreduce import aggregate, candidate_identity


TOKENS = (16, 64, 256)
SUITE_ID = 'dispatch-balanced-batch-20261110-v1'


def execution_order(rounds):
    return [dict(case_id=f'bs{tokens}', tokens=tokens, round=number,
                 directory=f'bs{tokens}/round{number}')
            for number in range(1, rounds + 1) for tokens in TOKENS]


def check_release(path, expected_sha):
    require(digest(path) == expected_sha, 'Coordinator release SHA mismatch')
    release = json.loads(path.read_text())
    require(release['status'] == 'READY_AFTER_NATIVE_FORMAL_DELIVERY',
            'Native formal delivery has not been released by coordinator')
    return {'sha256': expected_sha, 'document': release}


def batch_identity(cases_root, suite_root):
    suite = json.loads((suite_root / 'suite.json').read_text())
    require(suite['suite_id'] == SUITE_ID, 'Wrong shared input suite')
    locked = json.loads((Path(__file__).resolve().parents[1] / 'batch/input-manifest.json').read_text())
    expected = {case['case_id']: case for case in suite['cases']}
    require(set(expected) == {f'bs{t}' for t in TOKENS}, 'Incomplete shared input suite')
    identities = {}
    for tokens in TOKENS:
        name = f'bs{tokens}'
        base, fixture = cases_root / name, suite_root / name
        case = json.loads((fixture / 'case.json').read_text())
        require(case['hashes'] == expected[name]['hashes'] == locked['cases'][name]['hashes']
                and fixture_tokens(fixture / 'rank0') == tokens,
                'Shared case identity mismatch: ' + name)
        identities[name] = candidate_identity(base / 'install', fixture, base / 'generated')
        for rank, cores in core_pairs(identities[name]['cores']):
            generated = base / f'generated/rank{rank}'
            mapping = json.loads((generated / 'dispatch.ticks.json').read_text())
            export = json.loads((generated / 'export.json').read_text())
            adaptation = json.loads((generated / 'adaptation.json').read_text())
            require(mapping['tokens_per_rank'] == export['tokens_per_rank'] == tokens
                    and mapping['variant'] == export['variant'] == 'p1p2'
                    and mapping['rank'] == rank and mapping['cores'] == cores
                    and not mapping.get('count_ready_probe'), 'Wrong batch device mapping')
            for relative, sha in adaptation['hashes'].items():
                require(digest(generated / relative) == sha, 'Generated artifact changed: ' + relative)
            for suffix, size in (('x', tokens * 512), ('ids', tokens * 8)):
                require((fixture / f'rank{rank}/{suffix}.bin').stat().st_size == size,
                        'Wrong actual input byte count')
    require(len({tuple(value['cores']) for value in identities.values()}) == 1,
            'Batch specializations must use the same per-rank core counts')
    return identities


def check_correctness(args, identity):
    require(args.correctness is not None, 'Capture requires three correctness rounds per case')
    previous = json.loads((args.correctness / 'summary.json').read_text())
    require(previous['status'] == 'PASS' and previous['mode'] == 'correctness'
            and previous['rounds_per_case'] == 3 and previous['identity'] == identity
            and previous['devices'] == args.devices and previous['warmup'] == 20
            and previous['pre_allreduce'] == 'allreduce'
            and previous['execution_order'] == execution_order(3),
            'Correctness source/input/device/schedule mismatch')
    for item in previous['execution_order']:
        directory = args.correctness / item['directory']
        actual = json.loads((directory / 'run.json').read_text())
        require(actual['pre_allreduce'] == 'allreduce' and actual['mode'] == 'correctness',
                'Correctness round AR mode mismatch')
        analyze(directory, args.suite_root / item['case_id'],
                args.cases_root / item['case_id'] / 'generated')


def run_batch(args):
    expected_rounds = 3 if args.mode == 'correctness' else 10
    require(args.rounds == expected_rounds and args.warmup == 20 and args.devices == [0, 1],
            'Authorized batch schedule: 0/1, 3 correctness or 10 capture, warmup 20')
    release = check_release(args.start_release, args.start_release_sha256)
    identity = batch_identity(args.cases_root, args.suite_root)
    if args.mode == 'capture':
        check_correctness(args, identity)
    args.output.mkdir(parents=True, exist_ok=False)
    for tokens in TOKENS:
        (args.output / f'bs{tokens}').mkdir()
    order = execution_order(args.rounds)
    config = dict(schema='tilelang_dispatch_batch.v1', mode=args.mode,
                  rounds_per_case=args.rounds, warmup=20, devices=args.devices, cores=next(iter(identity.values()))['cores'],
                  suite_id=SUITE_ID, identity=identity, release=release, execution_order=order,
                  pre_allreduce='allreduce', variant='p1p2',
                  process_lifecycle='fresh rank pair per individual case/round',
                  device_clock='NOT_VERIFIED; raw ticks, no cross-core/rank subtraction')
    save(args.output / 'experiment.json', config)
    results = {f'bs{tokens}': [] for tokens in TOKENS}
    completed, capture_ids = [], set()
    try:
        for item in order:
            check_release(args.start_release, args.start_release_sha256)
            require(batch_identity(args.cases_root, args.suite_root) == identity,
                    'Candidate or shared fixture changed during batch')
            name = item['case_id']
            current = copy.copy(args)
            current.install = args.cases_root / name / 'install'
            current.fixture = args.suite_root / name
            current.output = args.output / item['directory']
            current.cores = identity[name]['cores']
            current.rounds, current.pre_allreduce = 1, 'allreduce'
            run(current)  # Real-time check before every new pair; no retries.
            result = analyze(current.output, current.fixture, args.cases_root / name / 'generated')
            for rank in result['rank_results']:
                for capture in rank['captures']:
                    require(capture['capture_id'] not in capture_ids, 'Duplicate batch capture UUID')
                    capture_ids.add(capture['capture_id'])
            save(current.output / 'analysis.json', result)
            results[name].append(result)
            completed.append(dict(item, status='PASS'))
            save(args.output / 'completed.json', completed)
        summary = dict(config, status='PASS', cases={
            name: aggregate('allreduce', values) for name, values in results.items()})
        save(args.output / 'summary.json', summary)
        if args.mode == 'capture':
            write_tables(summary, args.output)
        return summary
    except BaseException as error:
        save(args.output / 'failure.json', dict(status='FAIL', type=type(error).__name__,
                                               detail=str(error), completed=completed))
        raise


def write_tables(summary, output):
    """Keep every per-round tail, per-core maximum tie and workload in JSON/CSV."""
    timing, metrics = [], {name: [] for name in ('modules', 'functions', 'stages')}
    for name, case in summary['cases'].items():
        tokens = int(name[2:])
        for rank in case['rank_results']:
            for number, evidence in enumerate(rank['round_evidence'], 1):
                base = dict(case_id=name, T=tokens, round=number, rank=rank['rank'], cores=rank['cores'])
                events = evidence['pre_allreduce']
                timing.append(dict(base, device_task_us=evidence['device_task_us'],
                    **{key: events[key] for key in
                       ('dispatch_event_us', 'pre_dispatch_event_us', 'segment_event_us')},
                    capture_id=rank['captures'][number-1]['capture_id'],
                    F5_wait_ticks=evidence['F5_wait_ticks']))
                for field in metrics:
                    for metric_name, value in rank['captures'][number-1][field].items():
                        maxima = sorted(int(core) for core, ticks in value['per_core_sum_ticks'].items()
                                        if ticks == value['max_ticks'])
                        metrics[field].append(dict(base, name=metric_name, unit='ticks',
                            mean_tick=value['mean_ticks'], max_tick=value['max_ticks'],
                            participants=value['participating_cores'], active=value['active_workload_cores'],
                            max_core_ids=maxima, workload=value['workload']))
    tables = {'timing-rounds': timing, 'module-rounds': metrics['modules'],
              'function-rounds': metrics['functions'], 'substage-rounds': metrics['stages']}
    for name, rows in tables.items():
        save(output / (name + '.json'), rows)
        with (output / (name + '.csv')).open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows({key: json.dumps(value, separators=(',', ':'))
                              if isinstance(value, (dict, list)) else value
                              for key, value in row.items()} for row in rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('cases-root', 'suite-root', 'output', 'start-release'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--start-release-sha256', required=True)
    parser.add_argument('--correctness', type=Path)
    parser.add_argument('--mode', choices=('correctness', 'capture'), required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--devices', type=int, nargs=2, default=[0, 1])
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--comm-port', type=int, required=True)
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    result = run_batch(args)
    print(json.dumps(dict(status=result['status'], mode=args.mode, rounds_per_case=args.rounds)))


if __name__ == '__main__':
    main()
