"""Recheck saved HCCL A/B evidence; no device execution or inferred common clock."""
import csv
import math
from pathlib import Path
import struct

from .analyze_a5 import read_csv, read_json, require


def check_pre_allreduce(root, rank, iteration, magic, mode, host, dispatch_us):
    root = Path(root)
    schedule = read_json(root / 'allreduce-schedule.json')
    enabled = mode == 'allreduce'
    require(mode in ('none', 'allreduce'), 'Unknown pre-AllReduce mode')
    expected = {'schema': 'tilelang_pre_allreduce.v1', 'mode': mode, 'rank': rank,
                'count': 1, 'dtype': 'INT32', 'reduction': 'SUM', 'send_value': 1,
                'expected_sum': 2, 'common_warmup_result': 2, 'same_stream': True,
                'warmup_pre_allreduce_launches': iteration if enabled else 0,
                'validated_warmup_results': iteration if enabled else 0,
                'measured_pre_allreduce_launches': int(enabled)}
    require(all(schedule.get(k) == v for k, v in expected.items()),
            'Pre-AllReduce schedule mismatch')
    barriers = read_csv(root / 'native-barriers.csv')
    ready = next(b for b in barriers if b['step'] == 'warmup_ready')
    require(0 < schedule['common_warmup_completed_ns'] <= schedule['preparation_completed_ns']
            <= int(ready['enter_ns']), 'HCCL preparation not finished before warmup barrier')
    results = (root / 'allreduce-results.bin').read_bytes()
    expected_count = iteration + 2 if enabled else 1
    require(len(results) == expected_count * 4 and
            struct.unpack('<' + 'i' * expected_count, results) == (2,) * expected_count,
            'HCCL SUM result bytes mismatch')
    require((root / 'allreduce-send.bin').read_bytes() == struct.pack('<i', 1),
            'HCCL send value bytes mismatch')
    rows = read_csv(root / 'allreduce.csv')
    require(len(rows) == 1, 'Expected one measured AllReduce segment record')
    row = rows[0]
    require(int(row['rank']) == rank and int(row['round']) == iteration
            and int(row['magic']) == magic and row['mode'] == mode,
            'AllReduce timing identity mismatch')
    ns = {k: int(v) for k, v in row.items() if k.endswith('_ns')}
    require(host['barrier_exit_ns'] <= ns['segment_start_enqueue_ns']
            <= host['event_start_enqueue_ns'] <= host['launch_before_ns']
            and ns['dispatch_launch_before_ns'] == host['launch_before_ns']
            and ns['dispatch_launch_after_ns'] == host['launch_after_ns']
            and ns['segment_sync_end_ns'] == host['sync_end_ns']
            <= ns['validation_ns'], 'AllReduce/Dispatch Host chronology mismatch')
    if enabled:
        require(ns['segment_start_enqueue_ns'] <= ns['allreduce_before_ns']
                <= ns['allreduce_after_ns'] <= host['event_start_enqueue_ns']
                and row['allreduce_result'] == '2', 'Pre-AllReduce enqueue/result mismatch')
    else:
        require(ns['allreduce_before_ns'] == ns['allreduce_after_ns'] == 0
                and row['allreduce_result'] == 'NOT_RUN', 'Unexpected measured AllReduce in A')
    event = {k: float(row[k]) for k in
             ('segment_event_us', 'dispatch_event_us', 'pre_dispatch_event_us')}
    require(all(math.isfinite(v) and v >= 0 for v in event.values())
            and event['segment_event_us'] > 0 and event['dispatch_event_us'] > 0,
            'Invalid segment event time')
    require(math.isclose(event['dispatch_event_us'], dispatch_us, rel_tol=1e-6, abs_tol=.001),
            'Dispatch event records disagree')
    require(math.isclose(event['segment_event_us'],
                        event['dispatch_event_us'] + event['pre_dispatch_event_us'],
                        rel_tol=1e-4, abs_tol=.02), 'Segment event intervals do not compose')
    return {'mode': mode, **event, 'host_ns': ns,
            'sum_results_checked': expected_count,
            'pre_dispatch_scope': 'AllReduce plus event boundaries' if enabled else 'event boundaries only',
            'segment_scope': 'same-stream start event to end event; includes waiting',
            'common_hccl_warmup': True}


def profiler_context(directory, dispatch_symbol):
    """Keep profiler task identities, without inventing a wall time from subtask sums."""
    directory = Path(directory)
    files = list(directory.rglob('op_summary*.csv'))
    require(len(files) == 1, 'Expected one profiler op_summary')
    with files[0].open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    # HCCL may use multiple kernels/streams; names alone do not identify its full span.
    others = [r for r in rows if r.get('Op Name') != dispatch_symbol]
    communication = sorted({p.relative_to(directory).as_posix()
                            for pattern in ('*hccl*.csv', '*communication*.csv')
                            for p in directory.rglob(pattern)})
    return {'op_summary': files[0].relative_to(directory).as_posix(),
            'non_dispatch_rows': others, 'communication_csv_files': communication,
            'scope': 'all non-Dispatch tasks retained, not all proven HCCL; no subtask-duration sum',
            'allreduce_wall_time_source': 'same-stream pre_dispatch_event_us in B'}
