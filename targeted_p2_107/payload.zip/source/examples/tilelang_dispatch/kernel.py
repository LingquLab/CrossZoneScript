"""每rank一个集成Dispatch kernel；P2/E4/H256/K2 BF16；T=4/16/64/256编译期专化。

默认 TL v2（variant=3 / p1p2）：workspace 批量完成，gate 逐核32B提交后组尾等待。
小batch全部核、大batch末核计数分工；末核前缀和与发送核并行；每核由自己的gate进入接收。
只有核内流水依赖，无全核barrier。参数/路由留在UB，不输出中间描述符。

阅读顺序（F编号对应profile_recipe.json中的观测片段，不是独立kernel）：
① prepare：F0计算窗口地址与本核任务范围；F1将expertIds读入本核UB。
② count_publish：F2统计专家路由数；F3将计数与READY标志发给目标rank。
③ pack_send：F4按路由打包BF16特征、来源信息及READY标志并发送。
④ count_prefix：F5等齐并消费计数；F6计算前缀和，发布workspace及gate。
⑤ receive_output：F7等待布局并规划输出；F8接收特征；F9清理已消费标志。
发送路径与末核的前缀和路径并行；所有核随后等待各自的gate进入接收。
"""
import tilelang.language as T
from tilelang.language.ascend_tile import fill_experiment
from tvm import tir
from .contract import F, READY, CUMSUM_WORD, GATE_WORD, STATE_WORDS, validate_rank_cores

# [AI] A5接收UB逻辑预算采用与原生相同的保守190KiB；不是整机内存或每rank输入大小。
# 本TL版本另保留显式分配的共用UB，不能直接照搬原生97条容量。
RECEIVE_UB_BYTES = 190 * 1024


def receive_ub_plan(tokens, cores, targeted="B"):
    """[AI] 编译期UB计划；所有条数/shape均由本计划决定，尾批仅改变有效rows。

    common包括原公共UB、F6发布区及F4的两个附加1024B缓冲和路由mask。
    容量沿用原2048B/条预算；实际A/B数据+READY为1984B/条，另有288B
    READY保护/结果区。移除assist中间缓冲释放空间供F4使用，不改变批量策略。
    不依赖跨阶段复用；导出后核验实际UB末地址不超过190KiB。
    """
    if targeted not in ('B', 'U', 'R64', 'R128'):
        raise ValueError('targeted must be B, U, R64, or R128')
    align = lambda size: (size + 31) // 32 * 32
    common_sizes = (128, 512, tokens * 8, 16, 1024, 512, 128, 16, 32, 16, 64,
                    cores * 8 * 4)
    padded = ((tokens * 2 + 63) // 64) * 64
    mask_stride = ((padded // 32 + 7) // 8) * 8
    baseline_common = sum(align(size) for size in common_sizes)
    common_bytes = baseline_common + 2048 + (padded + 4 * mask_stride) * 4
    bytes_per_record = 2 * (960 + 32) + 64
    capacity = (RECEIVE_UB_BYTES - baseline_common) // bytes_per_record
    # [AI] F2使用本计数核独有scratch，不假设与F4自动复用；紧凑A/B每条544B。
    if targeted != 'B':
        common_bytes += (padded + 4 * mask_stride) * 4
    data_bytes = 544 if targeted in ('R64', 'R128') else 960
    if targeted in ('R64', 'R128'):
        capacity = 64 if targeted == 'R64' else 128
    elif targeted == 'U':
        capacity = min(capacity, (RECEIVE_UB_BYTES - common_bytes - 288) // 1984)
    planned = common_bytes + capacity * (2 * data_bytes + 64) + 288
    if capacity < 1 or planned > RECEIVE_UB_BYTES:
        raise ValueError('Targeted receive buffers exceed UB budget')
    return {'ub_budget_bytes': RECEIVE_UB_BYTES, 'common_bytes': common_bytes,
            'bytes_per_record': (2 * data_bytes + 64 if targeted in ('R64', 'R128') else bytes_per_record), 'batch_capacity': capacity,
            'planned_bytes': planned, 'capacity_policy_bytes': (planned if targeted != 'B' else baseline_common + capacity * bytes_per_record),
            'data_buffers': 2, 'data_bytes_per_record': data_bytes, 'targeted': targeted,
            'assist_bytes_per_record_per_buffer': 0, 'flag_bytes_per_record': 64,
            'ready_guard_and_result_bytes': 288}


# [AI] 固定后端只生成tl::ascend::copy*外部调用；通用GM→UB模板会补零并等待MTE3。
# 通过TileLang已有import_source接口提供此最小适配：对齐DMA只搬有效行，不写未用尾部。
# 形状/地址/事件由下面TL宏传入；不依赖C++生成变量名，不修改后端或导出后的文件。
RECEIVE_COPY_SOURCE = r"""
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] 9.1/950整数归约：每repeat只比较32B槽首；Min和Max都为READY才全等。
// flags后的56个uint32保护区由TL初始化，末次repeat的整个256B读取范围均已分配。
// 两个结果独立32B对齐；950无需sharedTmpBuffer，按该版本文档传src。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    constexpr uint32_t result = Capacity * 16 + 56;
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows), 1,
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// [AI] assist保留uint32来源的全部位；GM输出仍是int32，不能用异型Tensor实例化同T模板。
template <uint32_t Capacity, uint32_t Pitch = 240>
__aicore__ inline void copy_ub_to_gm_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t dstPitch, uint32_t rows,
    uint32_t width) {
    auto signedSrc = src.ReinterpretCast<int32_t>();
    // import_source位于common.h之前；直接提交DMA，不依赖尚未声明的后端模板。
    AscendC::DataCopyExtParams params{static_cast<uint16_t>(rows), width * 4,
        (Pitch * 4 - width * 4) / 32, dstPitch * 4 - width * 4, 0};
    AscendC::DataCopyPad(dst, signedSrc, params);
}

// [AI] 两段都以1024B GM行距/544B UB行距提交；末行最大读到GM字节575。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_compact(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    AscendC::DataCopyParams first{static_cast<uint16_t>(rows), 15, 17, 2};
    AscendC::DataCopyParams second{static_cast<uint16_t>(rows), 2, 30, 15};
    AscendC::DataCopy(dst, src, first);
    AscendC::DataCopy(dst[120], src[128], second);
}
// [AI] 32B种子含两份真实prefix；重复源步长0，奇数核尾部仅留在已分配UB。
template <uint32_t Cores>
__aicore__ inline void copy_ub_to_ub_prefix(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(8), uint8_t((Cores + 1) / 2), {1, 1, 1, 0});
}
// F4: vector equality masks are computed once for all four experts. Padding is
// -1 and excluded from prefix counts. Every predicate row starts on 32 bytes.
template <uint32_t Count>
__aicore__ inline void copy_ub_to_ub_send_masks(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> route) {
    constexpr uint32_t padded = (Count + 63) / 64 * 64;
    constexpr uint32_t stride = ((padded / 32 + 7) / 8) * 8;
    auto values = scratch.ReinterpretCast<int32_t>();
    AscendC::Duplicate<int32_t>(values, -1, padded);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::DataCopy(values, route, Count);
    AscendC::PipeBarrier<PIPE_V>();
    for (int32_t expert = 0; expert < 4; ++expert) {
        auto predicate = scratch[padded + expert * stride].ReinterpretCast<uint8_t>();
        AscendC::Compares(predicate, values, expert, AscendC::CMPMODE::EQ, padded);
    }
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// Compact 2x480-byte data rows -> 2x512-byte wire rows; preserve READY tails.
__aicore__ inline void copy_ub_to_ub_send_pack(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(64), uint8_t(2), {1, 1, 16, 15});
    AscendC::Copy(dst[64], src[64], uint64_t(56), uint8_t(2), {1, 1, 16, 15});
}
} }
"""


@T.macro
def read_receive_rows(src, dst, src_offset, width, rows, capacity, cpu):
    # [AI] GM→UB跨步读：src为uint32 GM，dst为uint32 UB；offset/width以uint32为单位。
    # GM行距固定128 words=512B，UB紧排width words；rows是本批有效行数，capacity是UB行容量。
    # READY读取width=8（32B）；数据读取width=120（480B），均跳过各自GM行的剩余部分。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[row * width + col] = src[src_offset + row * 128 + col]
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        # [AI] 全部地址/width均32B对齐，DataCopyParams单位为32B块。
        # 只搬有效rows，不调用会在尾批Duplicate并等待MTE3的通用补零模板。
        # 未搬行不被读取；从而上一批MTE3写出可与本次MTE2读取重叠。
        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, {width}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w'),
                      128, rows, width, T.uint32(0))
        T.set_flag('MTE2', 'S', 0)
        T.wait_flag('MTE2', 'S', 0)


@T.macro
def write_receive_rows(src, dst, src_offset, dst_offset, src_pitch, dst_pitch,
                       width, rows, capacity, cpu):
    # [AI] UB→GM批量跨步提交；offset/pitch/width均以src/dst的32位元素为单位。
    # src_pitch必须是8 words（32B）的整数倍；dst_pitch可为3 words，使assist紧排为12B/条。
    # 此宏只提交DMA。调用者须先S→MTE3，并在整组提交后MTE3→S，期间不得改写src。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[dst_offset + row * dst_pitch + col] = src[src_offset + row * src_pitch + col]
    else:
        T.call_extern('handle', f'tl::ascend::copy_ub_to_gm<{src.dtype}_t, {src_pitch}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w', offset=dst_offset),
                      dst_pitch, rows, width)


@T.macro
def copy_words(src, dst, src_offset, dst_offset, size, cpu):
    # offset/size以缓冲区元素为单位。GM→UB使用MTE2，UB→GM使用MTE3；
    # copy返回前等待搬运完成，后面的scalar代码才可读结果或改写同一UB。
    if cpu:
        for i in T.serial(size):
            dst[dst_offset + i] = src[src_offset + i]
    else:
        if src.scope() == 'global':
            T.set_flag('S', 'MTE2', 0)
            T.wait_flag('S', 'MTE2', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE2', 'S', 0)
            T.wait_flag('MTE2', 'S', 0)
        else:
            T.set_flag('S', 'MTE3', 0)
            T.wait_flag('S', 'MTE3', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE3', 'S', 0)
            T.wait_flag('MTE3', 'S', 0)


@T.macro
def fence(cpu):
    if not cpu:
        # 所有copy已建立scalar完成依赖；本地MTE3排序，不是跨核/rank barrier。
        T.pipe_barrier('MTE3')


@T.macro
def send_round(p, o):
    # F0.send_round：无共享专家版本的CalSendRound；不消费F1路由结果。
    o[F["send_rounds"]] = 1
    if p[0] >= 48 and (p[4] == 64 or p[4] == 128):
        o[F["send_rounds"]] = 2


@T.macro
def count_split(p, o, core):
    # F0.count_split：小batch全部核；大batch仅末尾count/cumsum核调用。
    o[F["count_begin"]] = 0
    o[F["count_end"]] = 0
    o[F["count_tasks"]] = 0
    if p[0] < 48 or T.cast(core, "uint64") >= o[F["send_cores"]]:
        worker = T.alloc_var("uint64", init=T.cast(core, "uint64"))
        if p[0] >= 48:
            worker = worker - o[F["send_cores"]]
        n = T.alloc_var("uint64", init=p[3])
        b = T.alloc_var("uint64", init=o[F["count_workers"]])
        begin = T.alloc_var("uint64", init=n // b * worker + T.min(worker, n % b))
        size = T.alloc_var("uint64", init=n // b + T.cast(worker < n % b, "uint64"))
        o[F["count_begin"]] = begin
        o[F["count_end"]] = begin + size
        o[F["count_tasks"]] = size


@T.macro
def status_split(p, o, core):
    # F0.status_split：输入是接收状态槽数量，不是接收token数量。
    worker = T.alloc_var("uint64", init=T.cast(core, "uint64") - o[F["send_cores"]])
    n = T.alloc_var("uint64", init=o[F["receive_states"]])
    b = T.alloc_var("uint64", init=o[F["cumsum_cores"]])
    begin = T.alloc_var("uint64", init=n // b * worker + T.min(worker, n % b))
    size = T.alloc_var("uint64", init=n // b + T.cast(worker < n % b, "uint64"))
    o[F["status_begin"]] = begin
    o[F["status_end"]] = begin + size
    o[F["status_tasks"]] = size


@T.macro
def receive_split(p, o, core):
    """
    给 解包核分配接收地址槽位，起始地址、结束地址等
    p:在本核 UB 中,用于记录token数量、隐藏维度、top-k、专家数、rank 数量及编号、启动核数、轮次编号、通信窗口地址和容量等
    o:在本核 UB 中，用于存储布局和任务信息
    core: 本核编号
    """
    # worker 获取当前的核编号
    worker = T.alloc_var("uint64", init=T.cast(core, "uint64"))
    # 表示有n个接收的槽位，槽位 = 某个rank的某个专家gm存储空间
    n = T.alloc_var("uint64", init=o[F["receive_states"]])
    # b可以被分配任务的核数, p[6] 表示本rank的核数
    b = T.alloc_var("uint64", init=p[6])
    # 以下开始对本核要计算的gm槽位地址进行分配，计算本核负责的接收任务的起点和终点
    begin = T.alloc_var("uint64", init=n // b * worker + T.min(worker, n % b))
    #  计算接收的槽位地址信息
    size = T.alloc_var("uint64", init=n // b + T.cast(worker < n % b, "uint64"))
    o[F["receive_begin"]] = begin
    o[F["receive_end"]] = begin + size
    o[F["receive_tasks"]] = size


@T.macro
def layout(p, o):
    # 固定BF16用例；保留真实被后续地址/任务计算使用的布局，不构造独立测试描述符。
    # F0.layout：p是Host传入的uint64[16]参数，o是本核使用的字段表，F提供字段索引。
    # p[3]=4个全局专家，p[6]=本rank核数56/64，因此cumsum=1，末核负责前缀和。
    experts = T.alloc_var('uint64', init=p[3])
    cores = T.alloc_var('uint64', init=p[6])
    cumsum = T.alloc_var('uint64', init=T.min(T.max((experts + 31) // 32, T.uint64(1)), T.min(cores // 2, T.uint64(8))))
    feature = T.alloc_var('uint64', init=p[1] * 2)
    blocks = T.alloc_var('uint64', init=(((feature + 31) // 32 * 32) + 32 + 479) // 480)
    record_bytes = T.alloc_var('uint64', init=blocks * 512)
    workspace = T.alloc_var('uint64', init=(cores * experts * 4 + 31) // 32 * 32)
    state_address = T.alloc_var('uint64', init=p[8] + (p[7] % 2) * T.uint64(1073741824) + 2097152)
    o[F['receive_states']] = experts
    o[F['cumsum_cores']] = cumsum
    o[F['send_cores']] = cores - cumsum
    o[F['count_workers']] = cores
    if p[0] >= 48:
        o[F['count_workers']] = cumsum
    o[F['record_bytes']] = record_bytes
    o[F['expert_window_bytes']] = (p[10] // p[4]) * record_bytes
    o[F['state_address']] = state_address
    o[F['workspace_address']] = state_address + 786432 - workspace


# ② F2＋F3：每核读取完整route[2*T]。T<48由前4核各计一个专家，
# T>=48由末核计4个专家；先完成本核计数，再逐专家发布32B READY槽。
# 分开两个循环使F2/F3各有一个完整观测区间，不能在循环内覆盖同一Recorder槽。
@T.macro
def count_publish(route, state0, state1, rank, small, amounts, diag, o, route_count, cpu, layout_optimized=False):
    if o[F['count_tasks']] > T.uint64(0):
        # F2.expert_count：统计本核负责的全部专家；4项amounts是核内UB，不跨核。
        if layout_optimized:
            # [AI] 不跨核借用mask；CPU分支执行同一predicate-word及SWAR算法。
            padded = ((route_count + 63) // 64) * 64
            stride = ((padded // 32 + 7) // 8) * 8
            count_masks = T.alloc_ub((((route_count + 63) // 64) * 64 + 4 * (((((route_count + 63) // 64) * 2 + 7) // 8) * 8),), 'uint32')
            if cpu:
                for expert in T.serial(4):
                    for word in T.serial(stride):
                        bits = T.alloc_var('uint32')
                        bits = T.uint32(0)
                        for bit in T.serial(32):
                            index = word * 32 + bit
                            if index < route_count:
                                if route[index] == expert:
                                    bits = T.bitwise_or(bits, T.uint32(1) << T.cast(bit, 'uint32'))
                        count_masks[padded + expert * stride + word] = bits
            else:
                T.set_flag('S', 'V', 0)
                T.wait_flag('S', 'V', 0)
                T.call_extern('handle', f'tl::ascend::copy_ub_to_ub_send_masks<{route_count}>',
                              route.access_ptr('r'), count_masks.access_ptr('w'))
            for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
                amount = T.alloc_var('uint32')
                amount = T.uint32(0)
                for word in T.serial((route_count + 31) // 32):
                    bits = T.alloc_var('uint32')
                    bits = count_masks[padded + expert * stride + word]
                    if word * 32 + 32 > route_count:
                        bits = T.bitwise_and(bits, (T.uint32(1) << (route_count - word * 32)) - T.uint32(1))
                    bits = bits - T.bitwise_and(bits >> 1, T.uint32(0x55555555))
                    bits = T.bitwise_and(bits, T.uint32(0x33333333)) + T.bitwise_and(bits >> 2, T.uint32(0x33333333))
                    bits = T.bitwise_and(bits + (bits >> 4), T.uint32(0x0f0f0f0f))
                    amount = amount + ((bits * T.uint32(0x01010101)) >> 24)
                amounts[expert] = amount
        else:
            for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
                amount = T.alloc_var('uint32')
                amount = T.uint32(0)
                for i in T.serial(route_count):
                    if route[i] == expert:
                        amount = amount + T.uint32(1)
                amounts[expert] = amount
        diag[4] = T.cast(o[F['count_tasks']], 'int32')
        # F3.count_publish：即使计数为0也发布READY；copy完成后才重用small。
        for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
            for i in T.serial(8):
                small[i] = T.uint32(0)
            small[0] = T.uint32(READY)
            small[1] = amounts[expert]
            offset = T.alloc_var('int32', init=((expert % 2) * 2 + rank) * 8)
            if expert < 2:
                copy_words(small, state0, 0, offset, 8, cpu)
            else:
                copy_words(small, state1, 0, offset, 8, cpu)
            fence(cpu)


# ③ F4：发送核按core, core+send_cores,...覆盖2*T条路由，末核不发送。
# 每条1024B记录包含512B BF16特征、来源三元组和两个32B READY尾槽。
# 在整段循环外打一次F4点；不把单条的耗时当作整核发送耗时。
@T.macro
def send_fill(buf, value, cpu):
    if cpu:
        for j in T.serial(buf.shape[0]):
            buf[j] = value
    else:
        T.set_flag('S', 'V', 0)
        T.wait_flag('S', 'V', 0)
        fill_experiment(buf, value, [T.bitwise_not(T.uint64(0))], buf.shape[0] // 64, 1, 8)
        T.set_flag('V', 'S', 0)
        T.wait_flag('V', 'S', 0)


@T.macro
def send_record(x, compact, wire, data0, data1, route_index, expert, position,
                rank, o, event_id, cpu):
    # compact只有512B特征和12B来源信息逐条更新；其余padding沿用一次初始化的0。
    if cpu:
        for j in T.serial(128):
            compact[j] = x[(route_index // 2) * 128 + j]
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        T.call_extern('handle', 'tl::ascend::copy_gm_to_ub_valid<uint32_t, 128, 1>',
                      x.access_ptr('r', offset=(route_index // 2) * 128),
                      compact.access_ptr('w'), 128, 1, 128, T.uint32(0))
        T.set_flag('MTE2', 'S', 0)
        T.wait_flag('MTE2', 'S', 0)
    compact[128] = T.uint32(rank)
    compact[129] = T.cast(route_index // 2, 'uint32')
    compact[130] = T.cast(route_index % 2, 'uint32')
    if cpu:
        for j in T.serial(240):
            wire[(j // 120) * 128 + j % 120] = compact[j]
    else:
        T.set_flag('S', 'V', 0)
        T.wait_flag('S', 'V', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_ub_send_pack',
                      compact.access_ptr('r'), wire.access_ptr('w'))
        T.set_flag('V', 'MTE3', 0)
        T.wait_flag('V', 'MTE3', 0)
    target = T.alloc_var('int32', init=expert // 2)
    bucket = T.alloc_var('int32', init=((rank + target) % 2) * 2 + expert % 2)
    offset = T.alloc_var('int32', init=bucket * T.cast(o[F['expert_window_bytes']] // 4, 'int32')
                         + position * T.cast(o[F['record_bytes']] // 4, 'int32'))
    if cpu:
        if expert < 2:
            copy_words(wire, data0, 0, offset, 256, cpu)
        else:
            copy_words(wire, data1, 0, offset, 256, cpu)
    else:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
        if expert < 2:
            T.copy(wire[:256], data0[offset:offset + 256])
        else:
            T.copy(wire[:256], data1[offset:offset + 256])
        T.set_flag('MTE3', 'S', event_id)
        # compact由vector读完才可供下一条GM输入覆盖；无需等待wire的GM发送。
        T.set_flag('V', 'S', 0)
        T.wait_flag('V', 'S', 0)


@T.macro
def pack_send(x, route, data0, data1, record, feature, core, rank, diag, o, route_count, cpu):
    # 两个wire槽轮转；只在复用本槽/退出时等待MTE3。保持路由顺序与1024B线格式。
    wire_b = T.alloc_ub((256,), 'uint32')
    compact = T.alloc_ub((256,), 'uint32')
    padded = ((route_count + 63) // 64) * 64
    mask_stride = ((padded // 32 + 7) // 8) * 8
    masks = T.alloc_ub((((route_count + 63) // 64) * 64 + 4 * (((((route_count + 63) // 64) * 2 + 7) // 8) * 8),), 'uint32')
    if core < route_count and o[F['send_rounds']] == T.uint64(1):
        send_fill(record, T.uint32(READY), cpu)
        send_fill(wire_b, T.uint32(READY), cpu)
        send_fill(compact, T.uint32(0), cpu)
        if not cpu:
            T.set_flag('S', 'V', 0)
            T.wait_flag('S', 'V', 0)
            T.call_extern('handle', f'tl::ascend::copy_ub_to_ub_send_masks<{route_count}>',
                          route.access_ptr('r'), masks.access_ptr('w'))
        issued = T.alloc_var('int32')
        issued = 0
        for task in T.serial((route_count + T.cast(o[F['send_cores']], 'int32') - 1) // T.cast(o[F['send_cores']], 'int32')):
            route_index = T.alloc_var('int32', init=core + task * T.cast(o[F['send_cores']], 'int32'))
            if route_index < route_count:
                expert = T.alloc_var('int32', init=route[route_index])
                if expert >= 0 and expert < 4:
                    position = T.alloc_var('int32')
                    position = 0
                    if cpu:
                        for i in T.serial(route_index):
                            if route[i] == expert:
                                position = position + 1
                    else:
                        for word in T.serial((route_index + 31) // 32):
                            bits = T.alloc_var('uint32', init=masks[padded + expert * mask_stride + word])
                            valid = T.min(32, route_index - word * 32)
                            if valid < 32:
                                bits = T.bitwise_and(bits, T.shift_left(T.uint32(1), valid) - T.uint32(1))
                            bits = bits - T.bitwise_and(T.shift_right(bits, 1), T.uint32(0x55555555))
                            bits = T.bitwise_and(bits, T.uint32(0x33333333)) + T.bitwise_and(T.shift_right(bits, 2), T.uint32(0x33333333))
                            bits = T.bitwise_and(bits + T.shift_right(bits, 4), T.uint32(0x0F0F0F0F))
                            position = position + T.cast(T.shift_right(bits * T.uint32(0x01010101), 24), 'int32')
                    if issued % 2 == 0:
                        if not cpu:
                            if issued >= 2:
                                T.wait_flag('MTE3', 'S', 2)
                        send_record(x, compact, record, data0, data1, route_index, expert, position,
                                    rank, o, 2, cpu)
                    else:
                        if not cpu:
                            if issued >= 2:
                                T.wait_flag('MTE3', 'S', 3)
                        send_record(x, compact, wire_b, data0, data1, route_index, expert, position,
                                    rank, o, 3, cpu)
                    issued = issued + 1
                    diag[5] = diag[5] + 1
                    diag[9] = diag[9] + T.cast(o[F['record_bytes']], 'int32')
                else:
                    diag[0] = 6
        if not cpu:
            if issued > 0:
                T.wait_flag('MTE3', 'S', 2)
            if issued > 1:
                T.wait_flag('MTE3', 'S', 3)


@T.macro
def count_prefix(state, counts, core, cores, poll_limit, records, prefix, small, diag, o, cpu, variant, layout_optimized=False):
    # ④ F5＋F6：仅本rank末核执行，rank0为核55、rank1为核63。
    # state为本rank的GM状态窗口；records接收4个32B计数槽，prefix保存4项累计计数。
    if core == cores - 1:
        ready = T.alloc_var('int32')
        ready = 0
        attempts = T.alloc_var('int32')
        attempts = 0
        # F5.wait_count：等待两个来源rank×两个本地专家的计数槽全部READY。
        while ready == 0 and attempts < poll_limit:
            copy_words(state, records, 0, 0, 32, cpu)
            ready = 1
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                if records[q * 8] != T.uint32(READY):
                    ready = 0
            attempts = attempts + 1
        diag[1] = attempts
        diag[6] = T.cast(o[F["status_tasks"]], "int32")
        if ready == 0:
            diag[0] = 1  # 计数未就绪：不构造/发布虚假输出布局。
        else:
            # F5.consume_clear：汇总本核负责的计数并清READY，保留计数值供F6使用。
            total = T.alloc_var('uint32')
            total = 0
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                total = total + records[q * 8 + 1]
                records[q * 8] = T.uint32(0)
            copy_words(records, state, 0, 0, 32, cpu)
            fence(cpu)
            # F6.prefix_publish / F6.prepare：发布并回读局部汇总槽，计算inclusive prefix。
            # 当前只有一个cumsum核，保留其32B局部汇总槽的发布/消费/清理。
            if not layout_optimized:
                for i in T.serial(8):
                    small[i] = T.uint32(0)
                small[0] = total
                small[1] = T.uint32(READY)
                copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
                fence(cpu)
                copy_words(state, small, CUMSUM_WORD, 0, 8, cpu)
            if not layout_optimized and small[1] != T.uint32(READY):
                diag[0] = 4
            else:
                running = T.alloc_var('uint32')
                running = 0
                for q in T.serial(4):
                    running = running + records[q * 8 + 1]
                    prefix[q] = T.cast(running, 'int32')
                # 均衡输入得到[T/2,T,3*T/2,2*T]，每项是对应接收槽的输出结束位置。
                # [AI] U不触碰自用CUMSUM槽，Host初始零值跨代保持。
                if not layout_optimized:
                    for i in T.serial(8):
                        small[i] = T.uint32(0)
                    copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
                copy_words(prefix, counts, 0, 0, 4, cpu)
                #  分配计数槽位，用于记录rank 给某专家的token数量 等信息 [READY标志，token数量，预留空间……]
                # workspace为每个接收核保留同一份4项prefix；gate为每核独立的32B通知槽。
                # 必须先完成workspace发布再通知gate；复用small前也必须完成其前一批搬运。
                if variant == 0:
                    # baseline：workspace、gate均逐核搬运，每次copy都等待完成。
                    for q in T.serial(4):
                        small[q] = T.cast(prefix[q], 'uint32')
                    for c in T.serial(cores):
                        copy_words(small, state, 0, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + c * 4, 4, cpu)
                    fence(cpu)
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    for c in T.serial(cores):
                        copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    fence(cpu)
                elif variant == 2 or variant == 3:
                    # F6.workspace_publish（P2）：在连续UB中排列cores份prefix，一次写GM。
                    # 每份内容和目标地址与baseline一致，减少小块copy次数，未减少数据量。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    publish_buf = T.alloc_ub((cores * 8,), 'uint32')
                    if layout_optimized and not cpu:
                        for q in T.serial(8):
                            small[q] = T.cast(prefix[q % 4], 'uint32')
                        T.set_flag('S', 'V', 0)
                        T.wait_flag('S', 'V', 0)
                        T.call_extern('handle', f'tl::ascend::copy_ub_to_ub_prefix<{cores}>',
                                      small.access_ptr('r'), publish_buf.access_ptr('w'))
                        T.set_flag('V', 'S', 0)
                        T.wait_flag('V', 'S', 0)
                    else:
                        for c in T.serial(cores):
                            for q in T.serial(4):
                                publish_buf[c * 4 + q] = T.cast(prefix[q], 'uint32')
                    copy_words(publish_buf, state, 0, workspace_word, cores * 4, cpu)
                    fence(cpu)
                    # P2-safe-gate：workspace仍批量发布；gate恢复独立32B槽及逐次完成等待。
                    # 保留原publish_buf容量，避免同时改变UB布局；接收核仍只清自己的槽。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    # F6.gate_publish：P2-safe-gate逐核等待；默认P1+P2只在整组末尾等待。
                    if variant == 2 or cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        # P1+P2：P2 workspace已完成；gate采用P1组尾完成等待。
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                else:
                    # P1：保留逐核小块copy，workspace组和gate组各等待一次完成。
                    # workspace每核4个int32；保留原生整数位模式与逐核地址覆盖。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    for q in T.serial(4):
                        small[q] = T.cast(prefix[q], 'uint32')
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, workspace_word + c * 4, 4, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:4], state[workspace_word + c * 4:workspace_word + c * 4 + 4])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                    # gate是8个int32(1)，区别于计数/payload的float(1)位模式。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)

@T.macro
def read_receive_payload(src, dst, offset, rows, capacity, event_id, cpu, compact=False):
    # [AI] payload无scalar消费者：S准备参数，MTE2完成直接交MTE3；不等待MTE2→S。
    # 调用前已消费本A/B旧输出的MTE3→S事件；该完成依赖经S→MTE2保护第三批复用。
    if cpu:
        if compact:
            for row in T.serial(rows // 2):
                for col in T.serial(120):
                    dst[row * 136 + col] = src[offset + row * 256 + col]
                for col in T.serial(16):
                    dst[row * 136 + 120 + col] = src[offset + row * 256 + 128 + col]
        else:
            read_receive_rows(src, dst, offset, 120, rows, capacity * 2, cpu)
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        if compact:
            # [AI] 同一MTE2队列先后提交两段；一个MTE2→MTE3事件覆盖两段完成。
            T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_compact<{capacity}>',
                          src.access_ptr('r', offset=offset), dst.access_ptr('w'),
                          256, rows // 2, 136, T.uint32(0))
        else:
            T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, {capacity * 2}>',
                          src.access_ptr('r', offset=offset), dst.access_ptr('w'),
                          128, rows, 120, T.uint32(0))
        T.set_flag('MTE2', 'MTE3', event_id)
        T.wait_flag('MTE2', 'MTE3', event_id)


@T.macro
def initialize_receive_flags(flags, capacity, cpu):
    # [AI] 全容量槽及224B保护区每来源槽初始化一次；掩码外即使发生物理读取也无未初始化值。
    # 归约只依赖2*N个槽首，不把保护值算入结果；初始化计入F8。
    words = capacity * 16 + 56
    if cpu:
        for i in T.serial(words):
            flags[i] = T.uint32(0)
    else:
        T.set_flag('S', 'V', 0)
        T.wait_flag('S', 'V', 0)
        fill_experiment(flags, T.uint32(0), [T.bitwise_not(T.uint64(0))], words // 64, 1, 8)
        T.call_intrin('handle', tir.op.Op.get('tl.ascend_fill_experiment'),
                      'Fill_experiment<uint32_t>', flags.access_ptr('w', offset=(words // 64) * 64),
                      T.uint32(0), (T.uint64(1) << (words % 64)) - T.uint64(1), 1, 1, 8)
        T.set_flag('V', 'MTE2', 0)
        T.wait_flag('V', 'MTE2', 0)


@T.macro
def receive_batch_output(payload, output, assist, offset, destination, batch_count,
                         batch_data, capacity, event_id, cpu, compact=False):
    # [AI] 当前A/B槽已空闲。直接从960B压紧记录分别跨步输出512B特征与12B assist。
    # 两次输出共用MTE3→S完成事件，复用/退出前必须消费，不复制assist到中间UB。
    read_receive_payload(payload, batch_data, offset, batch_count * 2, capacity, event_id, cpu, compact)
    if not cpu:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
    write_receive_rows(batch_data, output, 0, destination * 128,
                       (136 if compact else 240), 128, 128, batch_count, capacity, cpu)
    if cpu:
        for row in T.serial(batch_count):
            for col in T.serial(3):
                assist[(destination + row) * 3 + col] = T.reinterpret(
                    'int32', batch_data[row * (136 if compact else 240) + 128 + col])
    else:
        if compact:
            T.call_extern('handle', f'tl::ascend::copy_ub_to_gm_assist<{capacity}, 136>',
                          batch_data.access_ptr('r', offset=128),
                          assist.access_ptr('w', offset=destination * 3), 3, batch_count, 3)
        else:
            T.call_extern('handle', f'tl::ascend::copy_ub_to_gm_assist<{capacity}>',
                          batch_data.access_ptr('r', offset=128),
                          assist.access_ptr('w', offset=destination * 3), 3, batch_count, 3)
    if not cpu:
        T.set_flag('MTE3', 'S', event_id)


@T.macro
def receive_output(state, payload, output, assist, expert_nums, core, rank, cores,
                   poll_limit, small, prefix, nums, diag, o, cpu, capacity, compact=False):
    # ⑤ F7＋F8＋F9：全核等自己的gate；只有分到接收状态槽的前4核搬运payload。
    # [AI] 入参：state/payload是本rank GM通信窗口；output为uint32承载的BF16[T*4,256]容量，
    # assist为int32[T*4,3]容量；实际有效行由prefix决定。expert_nums为int64[2]专家计数。
    # small/prefix/nums/diag/o均为本核UB；poll_limit限制每批READY轮询，cpu仅用于串行行为验证。
    # 每条GM记录=2*(480B数据+32B READY)；压紧UB记录=960B，特征占前512B，随后12B来源信息。
    # [AI] A/B数据独立占用UB，特征与assist共享本批源；READY缓冲含归约保护区。
    batch_data_a = T.alloc_ub((capacity * (136 if compact else 240),), 'uint32')
    batch_data_b = T.alloc_ub((capacity * (136 if compact else 240),), 'uint32')
    batch_flags = T.alloc_ub((capacity * 2 * 8 + 72,), 'uint32')
    ready = T.alloc_var('int32')
    ready = 0
    attempts = T.alloc_var('int32')
    attempts = 0
    # F7.layout_wait：检查本核gate的8个uint32均为1；Host提交不代表这里已开始。
    while ready == 0 and attempts < poll_limit:
        copy_words(state, small, GATE_WORD + core * 8, 0, 8, cpu)
        ready = 1
        for i in T.serial(8):
            if small[i] != T.uint32(1):
                ready = 0
        attempts = attempts + 1
    diag[2] = attempts
    if ready == 0:
        if diag[0] == 0:
            diag[0] = 2
    else:
        # F7.gate_clear：每核只清自己的32B gate，供下一轮复用。
        for i in T.serial(8):
            small[i] = T.uint32(0)
        copy_words(small, state, 0, GATE_WORD + core * 8, 8, cpu)
        if o[F["receive_tasks"]] > T.uint64(0):
            # F7.receive_plan：读取本核的prefix副本，确定输出起点/条数和payload桶。
            # core0还将四项prefix归并为两个本地专家的总接收数。
            diag[8] = T.cast(o[F["receive_tasks"]], "int32")
            copy_words(state, small, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + core * 4, 0, 4, cpu)
            for i in T.serial(4):
                prefix[i] = T.cast(small[i], 'int32')
            if core == 0:
                nums[0] = T.cast(prefix[1], 'int64')
                nums[1] = T.cast(prefix[3] - prefix[1], 'int64')
                copy_words(nums, expert_nums, 0, 0, 2, cpu)
            begin = T.alloc_var('int32')
            begin = 0
            if core > 0:
                begin = prefix[core - 1]
            size = T.alloc_var('int32', init=prefix[core] - begin)
            bucket = T.alloc_var('int32', init=((core + rank) % 2) * 2 + core // 2)
            if size < 0 or size > T.cast(o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32') or begin < 0 or prefix[core] > T.cast(4 * o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32'):
                if diag[0] == 0:
                    diag[0] = 5  # 无效窗口内容，不能据此越界读写。
            else:
                consumed = T.alloc_var('int32')
                consumed = 0
                # [AI] F8.payload_loop：容量由UB预算决定；A/B交替，尾批仅处理有效条数。
                # pending表示本槽已提交且尚未消费MTE3→S事件；空桶/失败前未用槽不等待。
                batch_index = T.alloc_var('int32')
                batch_index = 0
                pending_a = T.alloc_var('int32')
                pending_a = 0
                pending_b = T.alloc_var('int32')
                pending_b = 0
                if size > 0:
                    initialize_receive_flags(batch_flags, capacity, cpu)
                while consumed < size and diag[0] == 0:
                    batch_count = T.alloc_var('int32', init=T.min(capacity, size - consumed))
                    offset = T.alloc_var('int32', init=bucket * T.cast(o[F["expert_window_bytes"]] // 4, "int32") + consumed * T.cast(o[F["record_bytes"]] // 4, "int32"))
                    arrived = T.alloc_var('int32')
                    arrived = 0
                    polls = T.alloc_var('int32')
                    polls = 0
                    while arrived == 0 and polls < poll_limit:
                        if cpu:
                            read_receive_rows(payload, batch_flags, offset + 120, 8,
                                              batch_count * 2, capacity * 2, cpu)
                            arrived = 1
                            for row in T.serial(batch_count * 2):
                                if batch_flags[row * 8] != T.uint32(READY):
                                    arrived = 0
                        else:
                            T.set_flag('S', 'MTE2', 0)
                            T.wait_flag('S', 'MTE2', 0)
                            T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_ready<{capacity}>',
                                          payload.access_ptr('r', offset=offset + 120),
                                          batch_flags.access_ptr('w'), 128, batch_count * 2, 8, T.uint32(0))
                            arrived = T.cast(batch_flags[capacity * 16 + 56] == T.uint32(READY)
                                             and batch_flags[capacity * 16 + 64] == T.uint32(READY), 'int32')
                        polls = polls + 1
                    # [AI] 保留payload_polls的逐条检查口径：一次批轮询检查batch_count条的两槽。
                    diag[3] = diag[3] + polls * batch_count
                    if arrived == 0:
                        diag[0] = 3
                    else:
                        if batch_index % 2 == 0:
                            if not cpu:
                                if pending_a != 0:
                                    T.wait_flag('MTE3', 'S', 2)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_a,
                                                 capacity, 2, cpu, compact)
                            pending_a = 1
                        else:
                            if not cpu:
                                if pending_b != 0:
                                    T.wait_flag('MTE3', 'S', 3)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_b,
                                                 capacity, 3, cpu, compact)
                            pending_b = 1
                        batch_index = batch_index + 1
                        consumed = consumed + batch_count
                # [AI] 包括READY超限退出：排空先前已提交的A/B，再计成功消费/清flag。
                # 等待属于F8，不能将完成成本转移到F9制造计时改善。
                if not cpu:
                    if pending_a != 0:
                        T.wait_flag('MTE3', 'S', 2)
                    if pending_b != 0:
                        T.wait_flag('MTE3', 'S', 3)
                diag[7] = consumed
                diag[10] = consumed * T.cast(o[F["record_bytes"]], "int32")
                # [AI] F9.payload_clear：每批跨步清2*N个32B尾槽，GM目的行距512B。
                # 仅清已完成输出的记录；失败批不消费/不清理，保留诊断现场。
                # [AI] 仅初始化本核清理DMA会读取的有效零槽，避免小batch清整块大容量UB。
                for i in T.serial(T.min(capacity, consumed) * 2 * 8):
                    batch_flags[i] = T.uint32(0)
                cleared = T.alloc_var('int32')
                cleared = 0
                while cleared < consumed:
                    clear_count = T.alloc_var('int32', init=T.min(capacity, consumed - cleared))
                    if not cpu:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                    write_receive_rows(batch_flags, payload, 0,
                                       bucket * T.cast(o[F['expert_window_bytes']] // 4, 'int32')
                                       + cleared * T.cast(o[F['record_bytes']] // 4, 'int32') + 120,
                                       8, 128, 8, clear_count * 2, capacity * 2, cpu)
                    if not cpu:
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    cleared = cleared + clear_count
        # F9.final_fence：本核收尾的MTE3排序，不是跨核/rank完成屏障。
        fence(cpu)

@T.macro
def dispatch_body(params, x, ids, state0, state1, data0, data1, output, assist,
                  counts, expert_nums, diagnostics, core, rank, cores, poll_limit, variant, tokens, receive_capacity, layout_optimized=False, compact=False):
    # 各核独立拥有这些UB缓冲；o的64是字段数量，不是核数，也不是核间共享表。
    p = T.alloc_ub((16,), 'uint64')
    o = T.alloc_ub((64,), 'uint64')
    route = T.alloc_ub((tokens * 2,), 'int32')
    amounts = T.alloc_ub((4,), 'uint32')
    record = T.alloc_ub((256,), 'uint32')
    feature = T.alloc_ub((128,), 'uint32')
    records = T.alloc_ub((32,), 'uint32')
    prefix = T.alloc_ub((4,), 'int32')
    small = T.alloc_ub((8,), 'uint32')
    nums = T.alloc_ub((2,), 'int64')
    diag = T.alloc_ub((16,), 'int32')
    for i in T.serial(16):
        diag[i] = 0
    copy_words(params, p, 0, 0, 16, False)
    # F0只保留核内布局；输出字段未初始化/未使用不做GM物化。
    layout(p, o)
    # F1.route_read：将expertIds[T,2]的2*T个int32读入本核route，供F2计数/F4发送使用。
    # 此处只读取路由，不移动X特征；F0.send_round不依赖route的内容。
    copy_words(ids, route, 0, 0, tokens * 2, False)
    send_round(p, o)
    count_split(p, o, core)
    # ② F2＋F3：按小/大batch角色统计本核负责的专家并发布计数。
    count_publish(route, state0, state1, rank, small, amounts, diag, o, tokens * 2, False, layout_optimized)
    # ③/④角色分流：发送角色核走F4，末核走F5/F6；两条路径不做全核等待。
    if T.cast(core, 'uint64') < o[F['send_cores']]:
        pack_send(x, route, data0, data1, record, feature, core, rank, diag, o, tokens * 2, False)
    else:
        status_split(p, o, core)
        if rank == 0:
            count_prefix(state0, counts, core, cores, poll_limit, records, prefix, small, diag, o, False, variant, layout_optimized)
        else:
            count_prefix(state1, counts, core, cores, poll_limit, records, prefix, small, diag, o, False, variant, layout_optimized)
    # 原生角色分支返回后的核内PIPE_ALL；绝非跨核同步。
    T.pipe_barrier('ALL')

    # 给接收核分配计数槽位，根据计数槽位找到关联的token的数据桶，用于后续的解包
    receive_split(p, o, core)

    # ⑤ F7–F9：按本rank通信窗口接收；gate将每个核连接到F6发布的布局。
    # 此分支保持固定两rank，核数由各rank的编译参数决定。
    if rank == 0:
        receive_output(state0, data0, output, assist, expert_nums, core, rank, cores,
                       poll_limit, small, prefix, nums, diag, o, False, receive_capacity, compact)
    else:
        receive_output(state1, data1, output, assist, expert_nums, core, rank, cores,
                       poll_limit, small, prefix, nums, diag, o, False, receive_capacity, compact)
    copy_words(diag, diagnostics, 0, core * 16, 16, False)


def make_kernel(rank, cores, *, poll_limit=100000, variant=3, tokens=4, targeted="B"):
    # Python侧构造入口：选择固定rank/核数和F6变体，再返回可交给TileLang编译的PrimFunc。
    validate_rank_cores(rank, cores)
    if isinstance(poll_limit, bool) or not isinstance(poll_limit, int) or not 1 <= poll_limit <= 10000000:
        raise ValueError('poll_limit must be an integer in [1,10000000]')
    if variant not in (0, 1, 2, 3):
        raise ValueError('variant must be 0 (baseline), 1 (P1), 2 (P2-safe-gate), or 3 (P1+P2)')
    if type(tokens) is not int or tokens not in (4, 16, 64, 256):
        raise ValueError('tokens must be 4, 16, 64, or 256')
    receive_capacity = receive_ub_plan(tokens, cores, targeted)['batch_capacity']
    @T.prim_func
    def dispatch(
        params: T.Tensor((16,), 'uint64'), x: T.Tensor((tokens * 128,), 'uint32'),
        ids: T.Tensor((tokens * 2,), 'int32'),
        state0: T.Tensor((STATE_WORDS,), 'uint32'), state1: T.Tensor((STATE_WORDS,), 'uint32'),
        data0: T.Tensor((tokens * 1024,), 'uint32'), data1: T.Tensor((tokens * 1024,), 'uint32'),
        output: T.Tensor((tokens * 512,), 'uint32'), assist: T.Tensor((tokens * 12,), 'int32'),
        counts: T.Tensor((4,), 'int32'), expert_nums: T.Tensor((2,), 'int64'),
        diagnostics: T.Tensor((cores * 16,), 'int32')):
        # 一个rank一次launch启用cores个AIV；core是核编号，具体任务由dispatch_body分配。
        with T.Kernel(cores, threads=1, is_npu=True) as core:
            T.import_source(RECEIVE_COPY_SOURCE)
            with T.Scope('V'):
                dispatch_body(params, x, ids, state0, state1, data0, data1,
                              output, assist, counts, expert_nums, diagnostics,
                              core, rank, cores, poll_limit, variant, tokens, receive_capacity,
                              targeted != "B", targeted in ("R64", "R128"))
    return dispatch
