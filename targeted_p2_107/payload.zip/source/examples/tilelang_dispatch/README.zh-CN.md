# TileLang Dispatch：固定2rank专用分支

五个功能模块在同一个 Dispatch kernel 中执行，每 rank 每次只启动一次 Dispatch。
当前默认 `p1p2`：F6 的 workspace 连续构造后批量写 GM 并等待完成，gate 保留逐核32B提交、组尾等待。
F8 按190KiB UB预算计算每批接收条数，使用A/B双缓冲；读feature时跨过READY标识，assist单独批量搬运，输出完成后再复用对应缓冲。
常规测试在同一 stream 显式前置 AllReduce，不改变 Dispatch 的 X/ids 输入。
默认 T4；T16/64/256 的独立导出、角色差异、输入与执行方式见 [Batch 扩容](docs/BATCH.zh-CN.md)。

## 分支维护约定

本分支为个人仓库 `BruceFang123/TileLang-Dispatch-A5` 的 `tilelang-dispatch-2rank`，
从固定两rank版本 `6ae8c9df08a3ad459deff438e3347ab19e090aed` 建立。
后续优化固定为 **2rank** 场景，不转为多rank/ABI3；每rank AIV核数是独立编译配置，不绑定56/64。
本次建立并上传已获用户授权；**此后每次将代码提交/合并纳入或推送到本分支前，须向用户说明范围并获得确认**。
实验在独立工作树准备，不自动发布到另一仓或 `tilelang-dispatch`。

核数入口为 `make_kernel(rank, cores)` / 导出命令 `--cores N`；允许整数4–200，
下限来自固定四个接收核core0–3，上限沿用布局容量限制。实际启动还须满足目标设备AIV数量，Host会实时拒绝超出数量的配置。
随仓库保留的56/64核导出只是一组默认配置；改变核数必须重新导出、核验实际UB和打点边界、重新构建，不能复用旧ELF。
CMake从两份 `export.json` 读取核数并核对适配清单；直接运行控制器时用 `--cores RANK0 RANK1` 与构建配置一致，
A/B及batch包装器从生成映射自动取核数，分析器从保存的run身份取核数。
原有recipe继续严格绑定raw SHA和UB；其他核数须提供已审查的 `--recipe PATH`，不会自动套用56/64 recipe。
本分支新增核数组合仅完成离线验证；历史A5结果仍绑定当时的源码、核数和ELF，不外推为新配置实测。

## 先看哪些代码

| 文件/目录 | 内容 |
|---|---|
| `kernel.py` | 全部设备业务逻辑：F0–F9、搬运同步、五模块调度，均在一个文件 |
| `contract.py`、`layout_reference.py` | 参数和布局字段约定、独立 CPU 布局参考；供导出、Host fixture、验收共用 |
| `hardware_fixture.py` | 不依赖 TileLang 的两 rank 输入/golden 生成器 |
| `export.py`、`backend.lock.json` | 固定 TileLang 后端，将 kernel 导出为 Ascend C/TIR；默认 p1p2 |
| `reference_exports/rank*/` | 当前 v2 的原样 Ascend C、TIR、导出来源清单 |
| `profile.py`、`profile_recipe.json` | 固定 raw SHA、UB 和区间边界的 AIV 适配/TileXR 插桩 |
| `generated/rank*/` | 当前 v2 的打点 Ascend C、ticks 映射与来源清单；CMake 默认使用这里 |
| `runner.cpp`、`pre_allreduce.h`、`native_host_barrier.h` | Host 注册/启动纯设备 ELF、真实 peer 窗口、可选 HCCL 前置任务与 rank 握手 |
| `run_native.py`、`host_control.py` | 常规运行入口、每轮新进程、临启动查卡及超时处理 |
| `analyze_native.py`、`analyze_a5.py`、`analyze_pre_allreduce.py` | 常规/共用业务与打点验收、AllReduce 结果与计时检查 |
| `tests/` | Python 行为测试、真实 TL 宏算术及 C++14/ABI 检查 |
| `docs/` | [Host 流程](docs/HOST_ALIGNMENT.zh-CN.md)、[AllReduce](docs/PRE_ALLREDUCE.zh-CN.md)、[F5 诊断](docs/F5_DIAGNOSTIC.zh-CN.md)、[F6 变体](docs/F6_COMBINED.zh-CN.md) |
| `tools/` | 历史逐次诊断、A/B、多变体调度和旧格式 HTML 工具，见 [工具说明](tools/README.zh-CN.md) |

宏是编译时展开的代码片段。`count_publish`、`pack_send` 等宏帮助按模块阅读；它们不会成为五个独立 kernel，也没有引入额外 launch。
Host 配置、输入生成、参考验收保留在独立文件，避免 A5 上仅生成 fixture 就必须安装 TileLang/TVM。

## 五模块及核角色

| 模块 | kernel.py 入口 | 核分工 |
|---|---|---|
| ① 公共准备 F0＋F1 | `layout`、`send_round`、三个 `*_split`；`dispatch_body` 中路由读取 | 全核；部分 F0 仅在相应角色分支计算 |
| ② 专家计数与发布 F2＋F3 | `count_publish` | T<48：核0–3各一个专家；T>=48：末核处理4专家 |
| ③ Token 打包发送 F4 | `pack_send` | 前 min(2T,cores−1) 核循环处理路由；T4为核0–7各一项 |
| ④ 接收计数与生成布局 F5＋F6 | `count_prefix` | 各rank末核 `cores−1` |
| ⑤ 接收数据与完成输出 F7＋F8＋F9 | `receive_output` | 全核等待/清理自己的 gate；核0–3执行 payload 接收 |

`dispatch_body` 保持原调度顺序：计数发布后，payload 发送与末核前缀和路径可以并行；各核通过自己的 gate 进入接收。
F0 保留在实际使用布局/分工的位置，不强行提前；`PIPE_ALL` 是核内流水屏障，不是全核 barrier。

## 固定用例与接口

两 rank、4 专家（每 rank 2 专家），每 rank `X[4,256]` BF16、`expertIds[4,2]` INT32。
两 rank 路由均为 `[[0,2],[1,3],[0,2],[1,3]]`；X 的 BF16 位模式是
`0x3f80 + rank*0x80 + token*0x10 + hidden%32`，因此两 rank 的 X 按公式不同。
无 mask、量化、共享专家，有效 TP=1。每rank启动其导出时配置的AIV数量，随仓库示例为56/64。

每 rank 有效输出8条 token，按本地专家、来源 rank、来源 token 排序；assist 为
`[source_rank, token_index, topk_index]`，累计计数 `[2,4,6,8]`、专家数量 `[4,4]`。
Host 验收有效输出、assist、未使用尾部哨兵、窗口清理及复用；输入跨实现一致性以实际文件 SHA 核验，不能由 AllReduce 的 SUM=2 代替。

设备 ABI 是12个 GM 指针，依次为 `params,x,ids,state0,state1,data0,data1,output,assist,counts,expert_nums,diagnostics`，
再接 `fftsAddr` 占位 u64 和 `profileGM`，AArch64 下共112字节。`contract.py` 定义字段索引，`runner.cpp` 构造实参。
`x` 的设备形参是 `uint32[512]`，用于按位搬运 BF16[4,256]；不表示输入改成 FP32。

## 导出与打点

在匹配 `backend.lock.json` 的后端环境、仓库根目录执行，输出目录必须是新目录：

```bash
python3 -m examples.tilelang_dispatch.export --rank 0 --cores 56 --output /tmp/tl-v2-raw/rank0
python3 -m examples.tilelang_dispatch.export --rank 1 --cores 64 --output /tmp/tl-v2-raw/rank1
python3 -m examples.tilelang_dispatch.profile --source /tmp/tl-v2-raw/rank0 --output /tmp/tl-v2-generated/rank0
python3 -m examples.tilelang_dispatch.profile --source /tmp/tl-v2-raw/rank1 --output /tmp/tl-v2-generated/rank1
```

默认 `make_kernel`、导出器、recipe 和随分支生成物均为 TL v2。
`--variant baseline|p1|p2` 仅供显式对照，不能套用当前 v2 recipe；其他 recipe 从 Git 历史找回并核验 raw SHA/UB/边界。
当前每批容量T4/16/64为92条、T256为91条；这是按形状和核数在导出时计算的容量，尾批仅处理实际剩余条数。
T4 两 rank UB 实际末地址分别192736/192992B；各 batch 实际 UB 见 recipe；每核52个 marker 槽、容量64。
固定后端需完整匹配源码修订、差异哈希、TVM 和动态库；不要重置已有后端或用另一个同名安装替代。
生成清单中的 `NOT_RUN` 只描述源码生成阶段，实机结果须另绑定候选提交、二进制及输入/records 身份。

## 构建与常规测试

`CANN_ROOT`、`BACKEND_ROOT`、`COMM_INSTALL` 为已验证的 CANN9.1、匹配后端头文件与 TileXR 安装目录。
前置 HCCL 要求本实验的 Host 和 core 均以 ABI0 构建，不能仅重编 runner；见 [ABI 经验](docs/PRE_ALLREDUCE.zh-CN.md)。

```bash
cmake -S examples/tilelang_dispatch -B build-tl-integrated \
  -DTL_CANN_ROOT="$CANN_ROOT" -DTL_BACKEND_ROOT="$BACKEND_ROOT" -DTL_COMM_PREFIX="$COMM_INSTALL" \
  -DTL_PRE_ALLREDUCE_SUPPORT=ON -DCMAKE_CXX_FLAGS=-D_GLIBCXX_USE_CXX11_ABI=0 \
  -DCMAKE_INSTALL_PREFIX="$PWD/install-tl-integrated"
cmake --build build-tl-integrated --parallel 2 --verbose
cmake --install build-tl-integrated
python3 -m examples.tilelang_dispatch.hardware_fixture --output fixture-integrated
python3 -m examples.tilelang_dispatch.run_native \
  --install install-tl-integrated --fixture fixture-integrated --output correctness-integrated \
  --devices 0 1 --cores 56 64 --comm-port 39185 --mode correctness --rounds 3 --warmup 20 --pre-allreduce allreduce
python3 -m examples.tilelang_dispatch.analyze_native \
  --run correctness-integrated --fixture fixture-integrated \
  --generated examples/tilelang_dispatch/generated --output correctness-analysis.json
```

正确性验收通过后，使用新的输出目录/端口运行 `--mode capture --rounds 5 --warmup 20 --pre-allreduce allreduce` 并重新分析。
每轮新建两个 rank 进程，连续20次预热后一次正式测量；缺少 msprof 则采集失败，不退化为 ACL-only。
临启动实时查卡，忙/未知/失败停止，不自动重跑或重置设备。
`--pre-allreduce none` 只用于显式对照，仍初始化并公共热身 HCCL；省略参数才完全不启用 HCCL，CLI 语义保持。

## 统计与维护边界

每轮先在同核累计不重叠功能片段，再按真实参与核统计 mean/max、核数和工作量，最后轮间等权。
F6 三个子段用于细分观察，不能与 F6 父包络重复相加。
⑤、F7、F9分别按接收core0–3和非接收core4–(cores−1)统计；F8仅接收四核执行。
核对⑤=F7+F8+F9时须先在同一核组合片段，再在同一核集合统计；不能混加全核均值与四核均值，也不能相加各阶段最大值。
接收核用实际received_records确认；未执行的片段标为未执行，不能记作测得0。
内部为未校准 raw ticks；msprof Dispatch 设备任务、ACL Dispatch 事件、前段与整段 ACL 分列。
模块重叠且不同核并行，不能把模块均值求和当作完整 Dispatch 延迟。此分支没有证明跨核/跨 rank 共同时钟。

清理历史实验时必须先检查现有 Host/分析器仍用的辅助函数，并迁移共用依赖。
只保留一套当前版本的 raw/TIR/recipe/generated，旧导出和旧 mapping 可从 Git 历史 `d46e96bb` 找回。
移动代码或提取宏后必须真实重导出，核验 raw、适配后的 device、mapping 及 fixture 字节一致；不能只更新清单哈希假装验证过。
当前目录与 Python 模块名统一为 `examples/tilelang_dispatch` / `examples.tilelang_dispatch`；改名时需同步命令、测试导入和导出来源路径。
给 kernel 增加注释也会改变来源 SHA，须真实重导出并复核生成物；保留现有 Host 可执行文件名和证据 schema，以便读取旧实验。
接收优化的A5验证绑定候选`046f9b47`：T16/64/256各3轮正确性和各10轮20预热+1测量通过。均衡输入至多触发两批，尚未覆盖第三批复用同一缓冲的硬件路径；未证明跨核/跨rank共同时钟。
本次发布保留用户已有注释；真实重导出核对后再更新来源清单，不因发布重新运行A5实验。

离线测试从仓库根目录运行（真实宏算术需匹配 TileLang 环境）：

```bash
python3 -m unittest discover -s examples/tilelang_dispatch/tests -t . -v
```

核数配置经验：不能只解除kernel入口限制；导出、清单、Host编译参数、二进制名称、采集与分析分母必须使用同一配置。
保持raw SHA与真实重导出绑定，避免参数化后旧打点看似可用却统计了另一组核。
