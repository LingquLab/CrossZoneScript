"""验收单 kernel 双 rank 证据；同核累计不重叠区间，raw ticks 与 ACL us 分开。"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct
import sys

from .contract import Config, validate as validate_config
from .contract import core_pairs

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'tools/profiling/python'))
from tilexr_profiling.records import load_record_files


FUNCTIONS = {
    'F0': ('F0.layout', 'F0.send_round', 'F0.count_split', 'F0.status_split', 'F0.receive_split'),
    'F1': ('F1.route_read',),
    'F2': ('F2.expert_count',), 'F3': ('F3.count_publish',), 'F4': ('F4.pack_send',),
    'F5': ('F5.wait_count', 'F5.consume_clear'), 'F6': ('F6.prefix_publish',),
    'F7': ('F7.layout_wait', 'F7.gate_clear', 'F7.receive_plan'),
    'F8': ('F8.payload_loop',), 'F9': ('F9.payload_clear', 'F9.final_fence'),
}
MODULES = {'prepare': ('F0', 'F1'), 'count_publish': ('F2', 'F3'),
           'pack_send': ('F4',), 'count_prefix': ('F5', 'F6'),
           'receive_output': ('F7', 'F8', 'F9')}
F6_SUBSTAGES = ('F6.prepare', 'F6.workspace_publish', 'F6.gate_publish')
DIAGNOSTICS = ('error', 'count_polls', 'gate_polls', 'payload_polls', 'count_tasks',
               'sent_records', 'status_slots', 'received_records', 'receive_states',
               'sent_wire_bytes', 'received_wire_bytes')
WORKLOAD_FIELDS = {
    'F0': ('layout_instances',), 'F1': ('route_ids_read',), 'F2': ('count_tasks',),
    'F3': ('count_tasks',), 'F4': ('sent_records', 'sent_wire_bytes'),
    'F5': ('status_slots', 'count_polls'), 'F6': ('status_slots',),
    'F7': ('receive_states', 'gate_polls'),
    'F8': ('received_records', 'received_wire_bytes', 'payload_polls'),
    'F9': ('received_records', 'received_wire_bytes'),
}


def validate_probe(first, mask, f5_ticks):
    require(len(first) == 4 and all(0 <= x <= f5_ticks for x in first) and 0 <= mask <= 15,
            'Invalid first-seen values (unseen/overflow/outside F5)')
    # All bits seen on the first successful read receive one shared timer sample.
    initial = [first[q] for q in range(4) if mask & (1 << q)]
    require(not initial or len(set(initial)) == 1, 'First-poll mask has different timestamps')
    require(not initial or all(x >= initial[0] for x in first), 'Later observation predates first poll')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def words(path, fmt, count):
    data = path.read_bytes()
    require(len(data) == struct.calcsize('<' + fmt) * count, 'Unexpected size: ' + str(path))
    return struct.unpack('<' + fmt * count, data)


def read_json(path):
    return json.loads(path.read_text())


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def stats(values):
    return {'mean': statistics.mean(values), 'median': statistics.median(values),
            'min': min(values), 'max': max(values)}


def fixture_tokens(fixture):
    case = read_json(Path(fixture).parent / 'case.json')
    shape = case['shape']
    tokens = shape['tokens_per_rank']
    require(type(tokens) is int and tokens in (4, 16, 64, 256)
            and {k: shape[k] for k in ('world', 'experts', 'hidden', 'topk')}
            == {'world': 2, 'experts': 4, 'hidden': 256, 'topk': 2},
            'Unsupported balanced fixture specialization')
    return tokens


def check_outputs(directory, fixture, iteration, rank, cores):
    tokens = fixture_tokens(fixture)
    prefix = directory / f'round{iteration}'
    p = words(Path(str(prefix) + '.params.bin'), 'Q', 16)
    config = Config(tokens=p[0], hidden=p[1], top_k=p[2], experts=p[3], world_size=p[4],
                    rank=p[5], block_dim=p[6], magic=p[7], peer_base=p[8], peer_bytes=p[9])
    require(validate_config(config) == list(p) and p[:7] == (tokens, 256, 2, 4, 2, rank, cores),
            'Parameter identity mismatch')
    for name, byte_count in (('output', tokens * 2048), ('assist', tokens * 48), ('counts', 16), ('expert_nums', 16)):
        actual = Path(str(prefix) + f'.actual_{name}.bin').read_bytes()
        expected = (fixture / f'expected_{name}.bin').read_bytes()
        require(len(actual) == byte_count and actual[:len(expected)] == expected
                and actual[len(expected):] == b'\xa5' * (byte_count - len(expected)),
                'Output or sentinel mismatch: ' + name)
    state = words(Path(str(prefix) + '.state.bin'), 'I', 262144)
    payload = words(Path(str(prefix) + '.payload.bin'), 'I', tokens * 1024)
    check_windows(state, payload, cores, tokens)
    return p[7]


def check_windows(state, payload, cores, tokens=4):
    require(all(state[q * 8] == 0 for q in range(4)), 'Count flags not cleared')
    require(all(x == 0 for x in state[222208:222216]), 'Cumsum not cleared')
    require(all(x == 0 for x in state[224256:224256 + cores * 8]), 'Gate flags not cleared')
    require(all(payload[b * tokens * 256 + t * 256 + block * 128 + 120 + w] == 0
                for b in range(4) for t in range(tokens // 2) for block in range(2) for w in range(8)),
            'Payload flags not cleared')


def check_diagnostics(path, cores, ready_probe=False, tokens=4):
    values = words(path, 'i', cores * 16)
    result = []
    for core in range(cores):
        row = values[core * 16:(core + 1) * 16]
        require(row[0] == 0 and all(v >= 0 for v in row[:11]), 'Kernel diagnostic error or negative counter')
        if ready_probe and core == cores - 1:
            require(all(v >= 0 for v in row[11:15]) and 0 <= row[15] <= 15,
                    'Ready probe unseen/overflow/invalid mask')
        else:
            require(not any(row[11:]), 'Reserved probe fields must be zero on other cores/default build')
        count_tasks = int(core < 4) if tokens < 48 else 4 * int(core == cores - 1)
        sent = max(0, (tokens * 2 - 1 - core) // (cores - 1) + 1) if core < cores - 1 else 0
        received = tokens // 2 if core < 4 else 0
        expected = (count_tasks, sent, 4 * int(core == cores - 1), received, int(core < 4),
                    sent * 1024, received * 1024)
        require(row[4:11] == expected, 'Balanced-case workload mismatch')
        require((row[1] >= 1 if core == cores - 1 else row[1] == 0)
                and row[2] >= 1 and (row[3] >= received if received else row[3] == 0),
                'Poll counters inconsistent with executed roles')
        result.append(dict(zip(DIAGNOSTICS, row[:11]), layout_instances=1, route_ids_read=tokens * 2))
    return result


def stage_executes(name, core, cores, tokens=4):
    if name in ('F0.status_split', 'F5.wait_count', 'F5.consume_clear', 'F6.prefix_publish') + F6_SUBSTAGES:
        return core == cores - 1
    if name in ('F2.expert_count', 'F3.count_publish'):
        return core < 4 if tokens < 48 else core == cores - 1
    if name in ('F7.receive_plan', 'F8.payload_loop', 'F9.payload_clear'):
        return core < 4
    if name == 'F4.pack_send':
        return core < min(tokens * 2, cores - 1)
    return True


def disjoint(intervals):
    ordered = sorted(intervals, key=lambda item: (item['begin_tick'], item['end_tick']))
    require(all(a['end_tick'] <= b['begin_tick'] for a, b in zip(ordered, ordered[1:])),
            'Selected functional intervals overlap; cannot add parent and child intervals')


def aggregate(lanes, stage_names, workload_fields, active_ids):
    participants, totals = [], []
    for lane in lanes:
        selected = [lane['intervals'][name] for name in stage_names if name in lane['intervals']]
        if not selected:
            continue  # Missing/conditional intervals are never silently replaced by zero.
        disjoint(selected)
        participants.append(lane['core'])
        totals.append(sum(value['ticks'] for value in selected))
    require(participants, 'No participating cores for a required functional group')
    active = sorted(set(participants) & set(active_ids))
    by_core = dict(zip(participants, totals))
    return {'selected_stages': list(stage_names), 'participating_core_ids': participants,
            'participating_cores': len(participants), 'mean_ticks': statistics.mean(totals),
            'max_ticks': max(totals), 'per_core_sum_ticks': by_core,
            'all_launch_core_normalized_ticks': sum(totals) / len(lanes),
            'active_workload_core_ids': active, 'active_workload_cores': len(active),
            'active_workload_mean_ticks': statistics.mean(by_core[c] for c in active) if active else None,
            'workload': {field: sum(lane['workload'][field] for lane in lanes
                                    if lane['core'] in participants) for field in workload_fields}}


def summarize_capture(record_file, mapping, diagnostics):
    require(mapping['schema'] == 'tilelang_dispatch_ticks.v1' and mapping['cycles_per_us'] is None
            and mapping['module'] == 'dispatch' and mapping['record_capacity'] == 64,
            'Expected integrated uncalibrated tick mapping with 64 slots')
    rank, cores = mapping['rank'], mapping['cores']
    tokens = mapping.get('tokens_per_rank', 4)
    streams = record_file.streams
    require(len(streams) == cores and {s.id for s in streams} == {(rank << 16) | c for c in range(cores)},
            'Missing or unexpected core lanes')
    events = mapping['events']
    order = {event['id']: event['slot'] for event in events}
    require(len(order) == len(events) and len(set(order.values())) == len(order)
            and all(0 <= slot < 64 for slot in order.values()), 'Invalid event slots or capacity')
    stage_map = {s['name']: s for s in mapping['stages']}
    functional = {name for names in FUNCTIONS.values() for name in names}
    require(len(stage_map) == len(mapping['stages']) and functional <= set(stage_map),
            'Missing or duplicate functional mapping')
    children = set(F6_SUBSTAGES) & set(stage_map)
    require(not children or children == set(F6_SUBSTAGES), 'Incomplete F6 substage mapping')
    require({name for name in stage_map if name.startswith('F')} == functional | children,
            'Unexpected functional mapping; explicitly define non-overlapping selection')
    require(set(order) == {event for stage in stage_map.values() for event in (stage['begin'], stage['end'])},
            'Events and stage mapping differ')
    lanes = []
    for stream in sorted(streams, key=lambda s: s.id):
        core = stream.id & 0xffff
        require(stream.complete and not stream.overflow and stream.dropped_count == 0,
                'Incomplete/overflowed capture lane')
        ids = [r.event_id for r in stream.records]
        require(2 <= len(ids) <= 64 and len(ids) == len(set(ids)) and set(ids) <= set(order),
                'Duplicate, unmapped or over-capacity events')
        require(ids == sorted(ids, key=order.__getitem__), 'Marker execution order differs from slot order')
        timestamps = [r.timestamp for r in stream.records]
        require(ids[0] == 1 and ids[-1] == 2 and timestamps[0] < timestamps[-1]
                and all(a <= b for a, b in zip(timestamps, timestamps[1:])),
                'Invalid whole bounds or non-monotonic raw timestamps')
        times = {r.event_id: r.timestamp for r in stream.records}
        require(1 in times and 2 in times, 'Missing whole-kernel body interval')
        intervals = {}
        for name, stage in stage_map.items():
            begin, end = stage['begin'], stage['end']
            require((begin in times) == (end in times), 'Unpaired interval: ' + name)
            require((begin in times) == stage_executes(name, core, cores, tokens),
                    'Expected functional/harness interval missing or unexpected: ' + name)
            if begin in times:
                require(times[1] <= times[begin] <= times[end] <= times[2], 'Interval outside whole body')
                intervals[name] = {'begin_tick': times[begin], 'end_tick': times[end],
                                   'ticks': times[end] - times[begin]}
        disjoint([intervals[name] for name in functional if name in intervals])
        if children and core == cores - 1:
            parent = intervals['F6.prefix_publish']
            ordered = [intervals[name] for name in F6_SUBSTAGES]
            require(all(parent['begin_tick'] <= child['begin_tick'] <= child['end_tick']
                        <= parent['end_tick'] for child in ordered), 'F6 child outside parent')
            require(all(a['end_tick'] <= b['begin_tick'] for a, b in zip(ordered, ordered[1:])),
                    'F6 child order/overlap invalid')
        lanes.append({'core': core, 'stream_id': stream.id, 'intervals': intervals,
                      'workload': diagnostics[core]})
    all_ids = set(range(cores))
    active = {'F0': all_ids, 'F1': all_ids, 'F2': set(range(4)) if tokens < 48 else {cores - 1},
              'F3': set(range(4)) if tokens < 48 else {cores - 1},
              'F4': set(range(min(tokens * 2, cores - 1))), 'F5': {cores - 1}, 'F6': {cores - 1},
              'F7': set(range(4)), 'F8': set(range(4)), 'F9': set(range(4))}
    functions = {name: aggregate(lanes, stages, WORKLOAD_FIELDS[name], active[name])
                 for name, stages in FUNCTIONS.items()}
    modules = {name: aggregate(lanes, [s for f in fs for s in FUNCTIONS[f]],
                               sorted({w for f in fs for w in WORKLOAD_FIELDS[f]}),
                               set().union(*(active[f] for f in fs))) for name, fs in MODULES.items()}
    stages = {name: aggregate(lanes, [name], [], all_ids) for name in stage_map}
    return {'capture_id': str(record_file.capture_id), 'rank': rank, 'unit': 'ticks',
            'cycles_per_us': None, 'capture_structure': 'PASS', 'performance_sample_accepted': False,
            'operator_correctness': 'NOT_CHECKED',
            'functions': functions, 'modules': modules, 'stages': stages, 'lanes': lanes}


def equal_round_summary(captures, field):
    result = {}
    for name in captures[0][field]:
        rows = [capture[field][name] for capture in captures]
        result[name] = {'mean_ticks': statistics.mean(r['mean_ticks'] for r in rows),
                        'mean_of_core_max_ticks': statistics.mean(r['max_ticks'] for r in rows),
                        'max_ticks': max(r['max_ticks'] for r in rows),
                        'per_round': rows}
    return result


def analyze(directory, fixture, generated):
    directory, fixture, generated = Path(directory), Path(fixture), Path(generated)
    parent, run = read_json(directory / 'summary.json'), read_json(directory / 'run.json')
    require(run['schema'] == 'tilelang_dispatch_integrated_run.v1'
            and run['observation'] == 'integrated single-kernel dispatch', 'Wrong run identity')
    require(run['mode'] in ('capture', 'correctness') and run['rounds'] > 0 and run['warmup'] >= 0,
            'Invalid run schedule')
    require(parent['status'] == 'PASS' and parent['rank_exit_codes'] == [0, 0], 'Parent execution did not pass')
    measured = [r * (run['warmup'] + 1) + run['warmup'] for r in range(run['rounds'])]
    iterations = run['rounds'] * (run['warmup'] + 1)
    require(parent['measured_iterations'] == measured and len(parent['iterations']) == iterations,
            'Unexpected iteration schedule')
    for index, row in enumerate(parent['iterations']):
        require(row['iteration'] == index and row['round'] == index // (run['warmup'] + 1)
                and row['measured'] == (index in measured), 'Parent iteration identity mismatch')
    case = read_json(fixture / 'case.json')
    for name, digest in case['hashes'].items():
        require(hashlib.sha256((fixture / name).read_bytes()).hexdigest() == digest, 'Fixture hash mismatch')
    ranks, rank_magic = [], []
    capture_ids = set()
    profiling = run['mode'] == 'capture'
    for rank, cores in core_pairs(run["cores"]):
        root = directory / f'rank{rank}'
        tokens = fixture_tokens(fixture / f'rank{rank}')
        summary = read_json(root / 'summary.json')
        require(summary['operator_correctness'] == summary['flags_cleared'] == 'PASS'
                and summary['observation'] == 'integrated'
                and summary['rank'] == rank and summary['cores'] == cores
                and summary['device'] == run['devices'][rank] and summary['profiling'] == profiling
                and summary['verified_iterations'] == summary['iterations'] == iterations
                and summary['measured_iterations'] == len(measured)
                and summary['capture_count'] == (len(measured) if profiling else 0), 'Rank summary mismatch')
        rounds = read_csv(root / 'rounds.csv')
        require(len(rounds) == iterations and all(int(row['round']) == i
                and row['operator_correctness'] == row['flags_cleared'] == 'PASS'
                and int(row['profiling']) == int(profiling and i in measured)
                and int(row['measured']) == int(i in measured) for i, row in enumerate(rounds)),
                'Warmup/measured validation missing')
        timings = read_csv(root / 'timing.csv')
        indexed = {int(row['round']): row for row in timings}
        require(len(timings) == len(measured) and set(indexed) == set(measured), 'Missing/duplicate timing rows')
        magic, captures, acl_times, host_times = {}, [], [], []
        mapping_metadata = read_json(generated / f'rank{rank}' / 'dispatch.ticks.json')
        ready_probe = mapping_metadata.get('count_ready_probe') == 'first_seen.v1'
        require(bool(summary.get('ready_probe', False)) == ready_probe, 'Host/device probe ABI differs')
        mapping = mapping_metadata if profiling else None
        if mapping is not None:
            require(mapping['rank'] == rank and mapping['cores'] == cores, 'Mapping identity mismatch')
        for iteration in measured:
            magic[iteration] = check_outputs(root, fixture / f'rank{rank}', iteration, rank, cores)
            row = indexed[iteration]
            require(row['module'] == 'dispatch' and int(row['rank']) == rank and int(row['aiv_count']) == cores
                    and int(row['device']) == run['devices'][rank] and int(row['profiling']) == int(profiling)
                    and int(row['magic']) == magic[iteration] == int(rounds[iteration]['magic'])
                    and row['operator_correctness'] == 'PASS', 'Timing metadata mismatch')
            acl, host = float(row['acl_event_us']), float(row['host_launch_sync_us'])
            require(all(math.isfinite(x) and x > 0 for x in (acl, host)), 'Invalid time value')
            acl_times.append(acl)
            host_times.append(host)
            prefix = root / f'round{iteration}.dispatch'
            diagnostics = check_diagnostics(Path(str(prefix) + '.diagnostics.bin'), cores, ready_probe, tokens)
            if profiling:
                record = load_record_files([Path(str(prefix) + '.records')])[0]
                capture_id = str(record.capture_id)
                require(record.capture_id.int != 0 and row.get('capture_id') == capture_id,
                        'Capture ID does not match timing row or is zero')
                require(capture_id not in capture_ids, 'Duplicate capture ID across ranks/rounds')
                capture_ids.add(capture_id)
                capture = summarize_capture(record, mapping, diagnostics)
                capture['iteration'] = iteration
                captures.append(capture)
            else:
                require(row.get('capture_id') == '', 'Noncapture timing row must have empty capture ID')
        rank_magic.append(magic)
        ranks.append({'rank': rank, 'cores': cores, 'acl_event_us': stats(acl_times),
                      'acl_event_per_round_us': acl_times, 'host_launch_sync_us': stats(host_times),
                      'functions': equal_round_summary(captures, 'functions') if profiling else {},
                      'modules': equal_round_summary(captures, 'modules') if profiling else {},
                      'stages': equal_round_summary(captures, 'stages') if profiling else {}, 'captures': captures})
    require(rank_magic[0] == rank_magic[1], 'Ranks used different magic/banks')
    for rank in ranks:
        for capture in rank['captures']:
            capture['operator_correctness'] = 'PASS'
            capture['performance_sample_accepted'] = True
    return {'schema': 'tilelang_dispatch_integrated_analysis.v1', 'status': 'PASS',
            'operator_correctness': 'PASS', 'capture_checked': profiling,
            'correctness_scope': 'whole Dispatch outputs, sentinels, consumed flags, per-core diagnostics and workload',
            'observation': 'integrated single-kernel dispatch', 'capture_placement': run.get('capture_placement', 'after-k'),
            'diagnostic_probe': ready_probe, 'rounds': run['rounds'],
            'warmup_per_round': run['warmup'], 'cycles_per_us': None, 'rank_results': ranks,
            'aggregation': 'sum selected disjoint intervals within each core, participant-core mean/max per round, equal round weighting',
            'notes': ['Functional participation includes control-only cores; active-workload subsets are separate.',
                      'F0 is five scattered intervals, not a continuous envelope. Never add whole/parent intervals.',
                      'Internal ticks are uncalibrated. ACL event us measures the single kernel including instrumentation overhead.',
                      'Module sums are work on individual cores, not critical-path latency; do not add them to ACL time.']}


def compact_summary(result):
    """保留逐轮统计但不携带逐核原始区间；全量报告仍保留原始时间及工作量。"""
    ranks = []
    for rank in result['rank_results']:
        row = {key: rank[key] for key in ('rank', 'cores', 'acl_event_us', 'acl_event_per_round_us')}
        for field in ('modules', 'functions', 'stages'):
            row[field] = {}
            for name, group in rank[field].items():
                row[field][name] = {key: value for key, value in group.items() if key != 'per_round'}
                row[field][name]['per_round'] = [{key: value for key, value in per_round.items()
                    if key not in ('per_core_sum_ticks', 'participating_core_ids', 'active_workload_core_ids', 'selected_stages')}
                    for per_round in group['per_round']]
        ranks.append(row)
    return {**{key: value for key, value in result.items() if key != 'rank_results'}, 'rank_results': ranks}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('run', 'fixture', 'generated', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--compact-output', type=Path)
    args = parser.parse_args()
    result = analyze(args.run, args.fixture, args.generated)
    for path, value in ((args.output, result), (args.compact_output, compact_summary(result))):
        if path is not None:
            with path.open('x') as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
    print(json.dumps({'status': result['status'], 'rounds': result['rounds'],
                      'capture_checked': result['capture_checked']}))
