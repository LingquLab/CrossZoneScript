
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] 9.1/950整数归约：每repeat只比较32B槽首；Min和Max都为READY才全等。
// flags后的56个uint32保护区由TL初始化，末次repeat的整个256B读取范围均已分配。
// 两个结果独立32B对齐；950无需sharedTmpBuffer，按该版本文档传src。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_ready(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    constexpr uint32_t result = Capacity * 16 + 56;
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows), 1,
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(0);
    AscendC::ReduceMin<uint32_t>(dst[result], dst, dst, 1, rows, 1, false);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::ReduceMax<uint32_t>(dst[result + 8], dst, dst, 1, rows, 1, false);
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// [AI] assist保留uint32来源的全部位；GM输出仍是int32，不能用异型Tensor实例化同T模板。
template <uint32_t Capacity, uint32_t Pitch = 240>
__aicore__ inline void copy_ub_to_gm_assist(AscendC::GlobalTensor<int32_t> dst,
    AscendC::LocalTensor<uint32_t> src, uint32_t dstPitch, uint32_t rows,
    uint32_t width) {
    auto signedSrc = src.ReinterpretCast<int32_t>();
    // import_source位于common.h之前；直接提交DMA，不依赖尚未声明的后端模板。
    AscendC::DataCopyExtParams params{static_cast<uint16_t>(rows), width * 4,
        (Pitch * 4 - width * 4) / 32, dstPitch * 4 - width * 4, 0};
    AscendC::DataCopyPad(dst, signedSrc, params);
}

// [AI] 两段都以1024B GM行距/544B UB行距提交；末行最大读到GM字节575。
template <uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_compact(AscendC::LocalTensor<uint32_t> dst,
    AscendC::GlobalTensor<uint32_t> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, uint32_t unusedPad) {
    AscendC::DataCopyParams first{static_cast<uint16_t>(rows), 15, 17, 2};
    AscendC::DataCopyParams second{static_cast<uint16_t>(rows), 2, 30, 15};
    AscendC::DataCopy(dst, src, first);
    AscendC::DataCopy(dst[120], src[128], second);
}
// [AI] 32B种子含两份真实prefix；重复源步长0，奇数核尾部仅留在已分配UB。
template <uint32_t Cores>
__aicore__ inline void copy_ub_to_ub_prefix(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(8), uint8_t((Cores + 1) / 2), {1, 1, 1, 0});
}
// F4: vector equality masks are computed once for all four experts. Padding is
// -1 and excluded from prefix counts. Every predicate row starts on 32 bytes.
template <uint32_t Count>
__aicore__ inline void copy_ub_to_ub_send_masks(AscendC::LocalTensor<uint32_t> scratch,
    AscendC::LocalTensor<int32_t> route) {
    constexpr uint32_t padded = (Count + 63) / 64 * 64;
    constexpr uint32_t stride = ((padded / 32 + 7) / 8) * 8;
    auto values = scratch.ReinterpretCast<int32_t>();
    AscendC::Duplicate<int32_t>(values, -1, padded);
    AscendC::PipeBarrier<PIPE_V>();
    AscendC::DataCopy(values, route, Count);
    AscendC::PipeBarrier<PIPE_V>();
    for (int32_t expert = 0; expert < 4; ++expert) {
        auto predicate = scratch[padded + expert * stride].ReinterpretCast<uint8_t>();
        AscendC::Compares(predicate, values, expert, AscendC::CMPMODE::EQ, padded);
    }
    AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
    AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
}
// Compact 2x480-byte data rows -> 2x512-byte wire rows; preserve READY tails.
__aicore__ inline void copy_ub_to_ub_send_pack(AscendC::LocalTensor<uint32_t> dst,
    AscendC::LocalTensor<uint32_t> src) {
    AscendC::Copy(dst, src, uint64_t(64), uint8_t(2), {1, 1, 16, 15});
    AscendC::Copy(dst[64], src[64], uint64_t(56), uint8_t(2), {1, 1, 16, 15});
}
} }
#include "kernel_operator.h"
#include <tilexr/profiling.h>
#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void tilexr_tl_dispatch_r1_c64( GM_ADDR params_handle,  GM_ADDR x_handle,  GM_ADDR ids_handle,  GM_ADDR state0_handle,  GM_ADDR state1_handle,  GM_ADDR data0_handle,  GM_ADDR data1_handle,  GM_ADDR output_handle,  GM_ADDR assist_handle,  GM_ADDR counts_handle,  GM_ADDR expert_nums_handle,  GM_ADDR diagnostics_handle, uint64_t fftsAddr, GM_ADDR profileGM) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<uint64_t> params;
  params.SetGlobalBuffer((__gm__ uint64_t*)params_handle);
  AscendC::GlobalTensor<uint32_t> x;
  x.SetGlobalBuffer((__gm__ uint32_t*)x_handle);
  AscendC::GlobalTensor<int> ids;
  ids.SetGlobalBuffer((__gm__ int*)ids_handle);
  AscendC::GlobalTensor<uint32_t> state0;
  state0.SetGlobalBuffer((__gm__ uint32_t*)state0_handle);
  AscendC::GlobalTensor<uint32_t> state1;
  state1.SetGlobalBuffer((__gm__ uint32_t*)state1_handle);
  AscendC::GlobalTensor<uint32_t> data0;
  data0.SetGlobalBuffer((__gm__ uint32_t*)data0_handle);
  AscendC::GlobalTensor<uint32_t> data1;
  data1.SetGlobalBuffer((__gm__ uint32_t*)data1_handle);
  AscendC::GlobalTensor<uint32_t> output;
  output.SetGlobalBuffer((__gm__ uint32_t*)output_handle);
  AscendC::GlobalTensor<int> assist;
  assist.SetGlobalBuffer((__gm__ int*)assist_handle);
  AscendC::GlobalTensor<int> counts;
  counts.SetGlobalBuffer((__gm__ int*)counts_handle);
  AscendC::GlobalTensor<int64_t> expert_nums;
  expert_nums.SetGlobalBuffer((__gm__ int64_t*)expert_nums_handle);
  AscendC::GlobalTensor<int> diagnostics;
  diagnostics.SetGlobalBuffer((__gm__ int*)diagnostics_handle);

  // AIV适配：保留实际UB，生命周期到全部工作和Flush之后。
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;
  pipe.InitBuffer(ascend_ub, 160480);
  auto core = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    }
  auto diag = ascend_ub.GetWithOffset<int>(16, 0);
  auto p = ascend_ub.GetWithOffset<uint64_t>(16, 64);
  uint64_t experts = (uint64_t)0;
  uint64_t cores = (uint64_t)0;
  uint64_t cumsum = (uint64_t)0;
  uint64_t feature = (uint64_t)0;
  uint64_t workspace = (uint64_t)0;
  uint64_t state_address = (uint64_t)0;
  auto o = ascend_ub.GetWithOffset<uint64_t>(64, 192);
  auto route = ascend_ub.GetWithOffset<int>(512, 704);
  uint64_t worker = (uint64_t)0;
  uint64_t n = (uint64_t)0;
  uint64_t b = (uint64_t)0;
  uint64_t begin = (uint64_t)0;
  uint64_t size = (uint64_t)0;
  auto count_masks = ascend_ub.GetWithOffset<uint32_t>(576, 2752);
  auto amounts = ascend_ub.GetWithOffset<uint32_t>(4, 5056);
  auto small = ascend_ub.GetWithOffset<uint32_t>(8, 5088);
  int offset = 0;
  uint32_t amount = (uint32_t)0;
  uint32_t bits = (uint32_t)0;
  auto record = ascend_ub.GetWithOffset<uint32_t>(256, 5120);
  auto wire_b = ascend_ub.GetWithOffset<uint32_t>(256, 6144);
  auto compact = ascend_ub.GetWithOffset<uint32_t>(256, 7168);
  auto masks = ascend_ub.GetWithOffset<uint32_t>(576, 8192);
  int issued = 0;
  int offset_1 = 0;
  int offset_2 = 0;
  uint64_t worker_1 = (uint64_t)0;
  uint64_t n_1 = (uint64_t)0;
  uint64_t b_1 = (uint64_t)0;
  uint64_t begin_1 = (uint64_t)0;
  uint64_t size_1 = (uint64_t)0;
  int ready = 0;
  int attempts = 0;
  auto records = ascend_ub.GetWithOffset<uint32_t>(32, 10496);
  uint32_t total = (uint32_t)0;
  uint32_t running = (uint32_t)0;
  auto prefix = ascend_ub.GetWithOffset<int>(4, 10624);
  int workspace_word = 0;
  auto publish_buf = ascend_ub.GetWithOffset<uint32_t>(512, 10656);
  int route_index = 0;
  int expert = 0;
  int position = 0;
  int target = 0;
  int bucket = 0;
  int target_1 = 0;
  int bucket_1 = 0;
  uint32_t bits_1 = (uint32_t)0;
  uint64_t worker_2 = (uint64_t)0;
  uint64_t n_2 = (uint64_t)0;
  uint64_t b_2 = (uint64_t)0;
  uint64_t begin_2 = (uint64_t)0;
  int ready_1 = 0;
  int attempts_1 = 0;
  auto nums = ascend_ub.GetWithOffset<int64_t>(2, 12704);
  int begin_3 = 0;
  int size_2 = 0;
  int bucket_2 = 0;
  int consumed = 0;
  int batch_index = 0;
  int pending_a = 0;
  int pending_b = 0;
  auto batch_flags = ascend_ub.GetWithOffset<uint32_t>(2120, 12736);
  int batch_count = 0;
  int offset_3 = 0;
  int arrived = 0;
  int polls = 0;
  auto batch_data_a = ascend_ub.GetWithOffset<uint32_t>(17408, 21216);
  auto batch_data_b = ascend_ub.GetWithOffset<uint32_t>(17408, 90848);
  int cleared = 0;
  int clear_count = 0;
  auto vid = AscendC::GetSubBlockIdx();
  // Recorder初始化不计入module.whole；一个AIV核唯一拥有一条lane。
  TileXR::Profiling::Recorder<64> recorder;
  if ASCEND_IS_AIV {
    if ASCEND_IS_AIV {
      // 【开始 ID=1】module.whole：单kernel内观测包络，含功能及harness，不含TPipe/Recorder准备、Flush和Destroy；不是ACL完整kernel时间
      recorder.RecordMarker<0, 1>();
      // 【开始 ID=1000】harness.diag_init：每核诊断UB清零
      recorder.RecordMarker<1, 1000>();
      for (int32_t i = 0; i < 16; ++i) {
        diag.SetValue(i, 0);
      }
      // 【结束 ID=1001】harness.diag_init：每核诊断UB清零
      recorder.RecordMarker<2, 1001>();
      // 【开始 ID=1010】harness.params_init：运行时参数GM→UB，含MTE2_S完成等待
      recorder.RecordMarker<3, 1010>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<uint64_t, 16>(p[0], params[0], 16, 1, 16, (uint64_t)0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      // 【结束 ID=1011】harness.params_init：运行时参数GM→UB，含MTE2_S完成等待
      recorder.RecordMarker<4, 1011>();
      // 【开始 ID=10】F0.layout：计算实际使用的状态/工作区地址、记录/专家窗口尺寸和核角色；不输出独立描述符
      recorder.RecordMarker<5, 10>();
      experts = p.GetValue(3);
      cores = p.GetValue(6);
      cumsum = ((((experts + (uint64_t)31) / (uint64_t)32) > (uint64_t)1 ? ((experts + (uint64_t)31) / (uint64_t)32) : (uint64_t)1) < ((cores / (uint64_t)2) < (uint64_t)8 ? (cores / (uint64_t)2) : (uint64_t)8) ? (((experts + (uint64_t)31) / (uint64_t)32) > (uint64_t)1 ? ((experts + (uint64_t)31) / (uint64_t)32) : (uint64_t)1) : ((cores / (uint64_t)2) < (uint64_t)8 ? (cores / (uint64_t)2) : (uint64_t)8));
      feature = (p.GetValue(1) * (uint64_t)2);
      feature = ((((feature + (uint64_t)31) / (uint64_t)32) + (uint64_t)15) / (uint64_t)15);
      feature = (feature * (uint64_t)512);
      workspace = ((((cores * experts) + (uint64_t)7) / (uint64_t)8) * (uint64_t)32);
      state_address = ((p.GetValue(8) + ((p.GetValue(7) % (uint64_t)2) * (uint64_t)1073741824)) + (uint64_t)2097152);
      o.SetValue(5, experts);
      o.SetValue(6, cumsum);
      o.SetValue(7, (cores - cumsum));
      o.SetValue(8, cores);
      if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
        o.SetValue(8, cumsum);
      }
      o.SetValue(14, feature);
      o.SetValue(15, ((p.GetValue(10) / p.GetValue(4)) * feature));
      o.SetValue(22, state_address);
      o.SetValue(25, ((state_address + (uint64_t)786432) - workspace));
      // 【结束 ID=11】F0.layout：计算实际使用的状态/工作区地址、记录/专家窗口尺寸和核角色；不输出独立描述符
      recorder.RecordMarker<6, 11>();
      // 【开始 ID=100】F1.route_read：expertIds读入UB，含MTE2_S完成等待；无mask场景，不声称测了mask计算
      recorder.RecordMarker<7, 100>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<int, 512>(route[0], ids[0], 512, 1, 512, 0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      // 【结束 ID=101】F1.route_read：expertIds读入UB，含MTE2_S完成等待；无mask场景，不声称测了mask计算
      recorder.RecordMarker<8, 101>();
      // 【开始 ID=20】F0.send_round：发送轮数默认值与条件选择
      recorder.RecordMarker<9, 20>();
      o.SetValue(32, (uint64_t)1);
      if (((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) && ((p.GetValue(4) == (uint64_t)64) || (p.GetValue(4) == (uint64_t)128))) {
        o.SetValue(32, (uint64_t)2);
      }
      // 【结束 ID=21】F0.send_round：发送轮数默认值与条件选择
      recorder.RecordMarker<10, 21>();
      // 【开始 ID=30】F0.count_split：T<48时前部计数核分工；T>=48时仅cumsum末核计算全部4个专家的计数任务，发送核无计数任务
      recorder.RecordMarker<11, 30>();
      o.SetValue(34, (uint64_t)0);
      o.SetValue(35, (uint64_t)0);
      o.SetValue(36, (uint64_t)0);
      if (((p.GetValue(0) / (uint64_t)48) < (uint64_t)1) || (o.GetValue(7) <= ((uint64_t)core))) {
        worker = ((uint64_t)core);
        if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
          worker = (worker - o.GetValue(7));
        }
        n = p.GetValue(3);
        b = o.GetValue(8);
        begin = (((n / b) * worker) + (worker < (n % b) ? worker : (n % b)));
        size = ((n / b) + ((uint64_t)(worker < (n % b))));
        o.SetValue(34, begin);
        o.SetValue(35, (begin + size));
        o.SetValue(36, size);
      }
      // 【结束 ID=31】F0.count_split：T<48时前部计数核分工；T>=48时仅cumsum末核计算全部4个专家的计数任务，发送核无计数任务
      recorder.RecordMarker<12, 31>();
      if ((uint64_t)0 < o.GetValue(36)) {
        // 【开始 ID=200】F2.expert_count：扫描全部512条路由，计算本核全部专家任务的计数；区间覆盖整个专家循环
        recorder.RecordMarker<13, 200>();
        AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
        tl::ascend::copy_ub_to_ub_send_masks<512>(count_masks[0], route[0]);
        for (int32_t expert_1 = ((int32_t)o.GetValue(34)); expert_1 < ((int32_t)o.GetValue(35)); ++expert_1) {
          amount = (uint32_t)0;
          for (int32_t word = 0; word < 16; ++word) {
            bits = count_masks.GetValue((((((int64_t)expert_1) * (int64_t)16) + ((int64_t)word)) + (int64_t)512));
            bits = (bits - ((bits >> (uint32_t)1) & (uint32_t)1431655765));
            bits = ((bits & (uint32_t)858993459) + ((bits >> (uint32_t)2) & (uint32_t)858993459));
            bits = ((bits + (bits >> (uint32_t)4)) & (uint32_t)252645135);
            amount = (amount + ((bits * (uint32_t)16843009) >> (uint32_t)24));
          }
          amounts.SetValue(((int64_t)expert_1), amount);
        }
        diag.SetValue(4, ((int32_t)o.GetValue(36)));
        // 【结束 ID=201】F2.expert_count：扫描全部512条路由，计算本核全部专家任务的计数；区间覆盖整个专家循环
        recorder.RecordMarker<14, 201>();
        // 【开始 ID=300】F3.count_publish：发布本核全部专家的32B状态记录，逐项完成等待；区间覆盖整个专家发布循环
        recorder.RecordMarker<15, 300>();
        for (int32_t expert_2 = ((int32_t)o.GetValue(34)); expert_2 < ((int32_t)o.GetValue(35)); ++expert_2) {
          for (int32_t i_1 = 0; i_1 < 8; ++i_1) {
            small.SetValue(i_1, (uint32_t)0);
          }
          small.SetValue(0, (uint32_t)1065353216);
          small.SetValue(1, amounts.GetValue(((int64_t)expert_2)));
          offset = (((expert_2 % 2) * 16) + 8);
          if (expert_2 < 2) {
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            int32_t condval;
            if (offset <= 262136) {
              condval = 8;
            } else {
              int32_t condval_1;
              if (offset < 262144) {
                condval_1 = (262144 - offset);
              } else {
                condval_1 = 0;
              }
              condval = condval_1;
            }
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(state0[offset], small[0], 262144, 1, condval);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          } else {
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            int32_t condval_2;
            if (offset <= 262136) {
              condval_2 = 8;
            } else {
              int32_t condval_3;
              if (offset < 262144) {
                condval_3 = (262144 - offset);
              } else {
                condval_3 = 0;
              }
              condval_2 = condval_3;
            }
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(state1[offset], small[0], 262144, 1, condval_2);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          AscendC::PipeBarrier<PIPE_MTE3>();
        }
        // 【结束 ID=301】F3.count_publish：发布本核全部专家的32B状态记录，逐项完成等待；区间覆盖整个专家发布循环
        recorder.RecordMarker<16, 301>();
      }
      if (((uint64_t)core) < o.GetValue(7)) {
        if (o.GetValue(32) == (uint64_t)1) {
          // 【开始 ID=400】F4.pack_send：本核全部发送任务：向量专家掩码、稳定前缀位置、向量打包、两个wire槽轮转发送及最终排空；含初始化和全部完成等待
          recorder.RecordMarker<17, 400>();
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(record[0], (uint32_t)1065353216, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(wire_b[0], (uint32_t)1065353216, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill_experiment<uint32_t>(compact[0], (uint32_t)0, (~(uint64_t)0), 4, 1, 8);
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::copy_ub_to_ub_send_masks<512>(masks[0], route[0]);
          issued = 0;
          for (int32_t task = 0; task < ((511 / ((int32_t)o.GetValue(7))) + 1); ++task) {
            route_index = (core + (task * ((int32_t)o.GetValue(7))));
            if (route_index < 512) {
              expert = route.GetValue(route_index);
              if ((0 <= expert) && (expert < 4)) {
                position = 0;
                for (int32_t word_1 = 0; word_1 < ((route_index + 31) / 32); ++word_1) {
                  bits_1 = masks.GetValue((((expert * 16) + word_1) + 512));
                  int32_t valid = (32 < (route_index - (word_1 * 32)) ? 32 : (route_index - (word_1 * 32)));
                  if (valid < 32) {
                    bits_1 = (bits_1 & (((uint32_t)1 << ((uint32_t)valid)) - (uint32_t)1));
                  }
                  bits_1 = (bits_1 - ((bits_1 >> (uint32_t)1) & (uint32_t)1431655765));
                  bits_1 = ((bits_1 & (uint32_t)858993459) + ((bits_1 >> (uint32_t)2) & (uint32_t)858993459));
                  bits_1 = ((bits_1 + (bits_1 >> (uint32_t)4)) & (uint32_t)252645135);
                  position = (position + ((int32_t)((bits_1 * (uint32_t)16843009) >> (uint32_t)24)));
                }
                if ((issued % 2) == 0) {
                  if (2 <= issued) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 128, 1>(compact[0], x[((route_index / 2) * 128)], 128, 1, 128, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  compact.SetValue(128, (uint32_t)1);
                  compact.SetValue(129, ((uint32_t)(route_index / 2)));
                  compact.SetValue(130, ((uint32_t)(route_index % 2)));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::copy_ub_to_ub_send_pack(record[0], compact[0]);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  target = (expert / 2);
                  bucket = ((((target + 1) % 2) * 2) + (expert % 2));
                  offset_1 = ((bucket * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (position * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  if (expert < 2) {
                    int32_t condval_4;
                    if (offset_1 <= 261888) {
                      condval_4 = 256;
                    } else {
                      int32_t condval_5;
                      if (offset_1 < 262144) {
                        condval_5 = (262144 - offset_1);
                      } else {
                        condval_5 = 0;
                      }
                      condval_4 = condval_5;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data0[offset_1], record[0], 262144, 1, condval_4);
                  } else {
                    int32_t condval_6;
                    if (offset_1 <= 261888) {
                      condval_6 = 256;
                    } else {
                      int32_t condval_7;
                      if (offset_1 < 262144) {
                        condval_7 = (262144 - offset_1);
                      } else {
                        condval_7 = 0;
                      }
                      condval_6 = condval_7;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data1[offset_1], record[0], 262144, 1, condval_6);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                } else {
                  if (2 <= issued) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 128, 1>(compact[0], x[((route_index / 2) * 128)], 128, 1, 128, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  compact.SetValue(128, (uint32_t)1);
                  compact.SetValue(129, ((uint32_t)(route_index / 2)));
                  compact.SetValue(130, ((uint32_t)(route_index % 2)));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::copy_ub_to_ub_send_pack(wire_b[0], compact[0]);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  target_1 = (expert / 2);
                  bucket_1 = ((((target_1 + 1) % 2) * 2) + (expert % 2));
                  offset_2 = ((bucket_1 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (position * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  if (expert < 2) {
                    int32_t condval_8;
                    if (offset_2 <= 261888) {
                      condval_8 = 256;
                    } else {
                      int32_t condval_9;
                      if (offset_2 < 262144) {
                        condval_9 = (262144 - offset_2);
                      } else {
                        condval_9 = 0;
                      }
                      condval_8 = condval_9;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data0[offset_2], wire_b[0], 262144, 1, condval_8);
                  } else {
                    int32_t condval_10;
                    if (offset_2 <= 261888) {
                      condval_10 = 256;
                    } else {
                      int32_t condval_11;
                      if (offset_2 < 262144) {
                        condval_11 = (262144 - offset_2);
                      } else {
                        condval_11 = 0;
                      }
                      condval_10 = condval_11;
                    }
                    tl::ascend::copy_ub_to_gm<uint32_t, 256>(data1[offset_2], wire_b[0], 262144, 1, condval_10);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                }
                issued = (issued + 1);
                diag.SetValue(5, (diag.GetValue(5) + 1));
                diag.SetValue(9, (diag.GetValue(9) + ((int32_t)o.GetValue(14))));
              } else {
                diag.SetValue(0, 6);
              }
            }
          }
          if (0 < issued) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
          }
          if (1 < issued) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
          }
          // 【结束 ID=401】F4.pack_send：本核全部发送任务：向量专家掩码、稳定前缀位置、向量打包、两个wire槽轮转发送及最终排空；含初始化和全部完成等待
          recorder.RecordMarker<18, 401>();
        }
      } else {
        // 【开始 ID=40】F0.status_split：末核计算状态任务，状态工作量由该结果记录
        recorder.RecordMarker<19, 40>();
        worker_1 = (((uint64_t)core) - o.GetValue(7));
        n_1 = o.GetValue(5);
        b_1 = o.GetValue(6);
        begin_1 = (((n_1 / b_1) * worker_1) + (worker_1 < (n_1 % b_1) ? worker_1 : (n_1 % b_1)));
        size_1 = ((n_1 / b_1) + ((uint64_t)(worker_1 < (n_1 % b_1))));
        o.SetValue(38, begin_1);
        o.SetValue(39, (begin_1 + size_1));
        o.SetValue(40, size_1);
        // 【结束 ID=41】F0.status_split：末核计算状态任务，状态工作量由该结果记录
        recorder.RecordMarker<20, 41>();
        if (core == 63) {
          // 【开始 ID=500】F5.wait_count：整个有界计数轮询，含每次GM→UB及MTE2_S完成等待；失败也有此区间
          recorder.RecordMarker<21, 500>();
          ready = 0;
          attempts = 0;
          while (1) {
            if (!(((ready == 0) && (attempts < 100000)))) { break; }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 32>(records[0], state1[0], 262144, 1, 32, (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            ready = 1;
            for (int32_t q = ((int32_t)o.GetValue(38)); q < ((int32_t)o.GetValue(39)); ++q) {
              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {
                ready = 0;
              }
            }
            attempts = (attempts + 1);
          }
          diag.SetValue(1, attempts);
          diag.SetValue(6, ((int32_t)o.GetValue(40)));
          // 【结束 ID=501】F5.wait_count：整个有界计数轮询，含每次GM→UB及MTE2_S完成等待；失败也有此区间
          recorder.RecordMarker<22, 501>();
          if (ready == 0) {
            diag.SetValue(0, 1);
          } else {
            // 【开始 ID=510】F5.consume_clear：消费计数、局部求和及清ready状态，含MTE3_S完成等待
            recorder.RecordMarker<23, 510>();
            total = (uint32_t)0;
            for (int32_t q_1 = ((int32_t)o.GetValue(38)); q_1 < ((int32_t)o.GetValue(39)); ++q_1) {
              total = (total + records.GetValue(((((int64_t)q_1) * (int64_t)8) + (int64_t)1)));
              records.SetValue((((int64_t)q_1) * (int64_t)8), (uint32_t)0);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 32>(state1[0], records[0], 262144, 1, 32);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            // 【结束 ID=511】F5.consume_clear：消费计数、局部求和及清ready状态，含MTE3_S完成等待
            recorder.RecordMarker<24, 511>();
            // 【开始 ID=600】F6.prefix_publish：单cumsum记录发布/回读/清理、prefix计算、counts/workspace/gate发布；含本地copy完成等待，不是真实跨核cumsum等待
            recorder.RecordMarker<25, 600>();
            // 【开始 ID=620】F6.prepare：[AI] 单前缀和核直接使用UB真实计数，计算并发布counts；无自用GM汇总往返
            recorder.RecordMarker<26, 620>();
            running = (uint32_t)0;
            for (int32_t q_2 = 0; q_2 < 4; ++q_2) {
              running = (running + records.GetValue(((q_2 * 8) + 1)));
              prefix.SetValue(q_2, ((int32_t)running));
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int, 4>(counts[0], prefix[0], 4, 1, 4);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            // 【结束 ID=621】F6.prepare：[AI] 单前缀和核直接使用UB真实计数，计算并发布counts；无自用GM汇总往返
            recorder.RecordMarker<27, 621>();
            // 【开始 ID=630】F6.workspace_publish：[AI] 向量复制真实prefix至核数可配的workspace副本，保持原GM覆盖及完成等待
            recorder.RecordMarker<28, 630>();
            workspace_word = ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4));
            for (int32_t q_3 = 0; q_3 < 8; ++q_3) {
              small.SetValue(q_3, ((uint32_t)prefix.GetValue((q_3 % 4))));
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::copy_ub_to_ub_prefix<64>(publish_buf[0], small[0]);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            int32_t condval_12;
            if (workspace_word <= 261888) {
              condval_12 = 256;
            } else {
              int32_t condval_13;
              if (workspace_word < 262144) {
                condval_13 = (262144 - workspace_word);
              } else {
                condval_13 = 0;
              }
              condval_12 = condval_13;
            }
            tl::ascend::copy_ub_to_gm<uint32_t, 256>(state1[workspace_word], publish_buf[0], 262144, 1, condval_12);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            // 【结束 ID=631】F6.workspace_publish：[AI] 向量复制真实prefix至核数可配的workspace副本，保持原GM覆盖及完成等待
            recorder.RecordMarker<29, 631>();
            // 【开始 ID=640】F6.gate_publish：逐核32B gate提交，采用P1组尾MTE3_S完成等待；workspace已批量完成
            recorder.RecordMarker<30, 640>();
            for (int32_t i_2 = 0; i_2 < 8; ++i_2) {
              small.SetValue(i_2, (uint32_t)1);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            for (int32_t c = 0; c < 64; ++c) {
              tl::ascend::copy_ub_to_gm<uint32_t, 8>(state1[((c * 8) + 224256)], small[0], 262144, 1, 8);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            // 【结束 ID=641】F6.gate_publish：逐核32B gate提交，采用P1组尾MTE3_S完成等待；workspace已批量完成
            recorder.RecordMarker<31, 641>();
            // 【结束 ID=601】F6.prefix_publish：单cumsum记录发布/回读/清理、prefix计算、counts/workspace/gate发布；含本地copy完成等待，不是真实跨核cumsum等待
            recorder.RecordMarker<32, 601>();
          }
        }
      }
      // 【开始 ID=1100】role_pipeline_barrier：角色分支后的核内PIPE_ALL指令，无跨核barrier；单列而不分摊到模块
      recorder.RecordMarker<33, 1100>();
      AscendC::PipeBarrier<PIPE_ALL>();
      // 【结束 ID=1101】role_pipeline_barrier：角色分支后的核内PIPE_ALL指令，无跨核barrier；单列而不分摊到模块
      recorder.RecordMarker<34, 1101>();
      // 【开始 ID=50】F0.receive_split：全部核计算接收状态任务，驱动接收核分支
      recorder.RecordMarker<35, 50>();
      worker_2 = ((uint64_t)core);
      n_2 = o.GetValue(5);
      b_2 = p.GetValue(6);
      begin_2 = (((n_2 / b_2) * worker_2) + (worker_2 < (n_2 % b_2) ? worker_2 : (n_2 % b_2)));
      n_2 = ((n_2 / b_2) + ((uint64_t)(worker_2 < (n_2 % b_2))));
      o.SetValue(42, begin_2);
      o.SetValue(43, (begin_2 + n_2));
      o.SetValue(44, n_2);
      // 【结束 ID=51】F0.receive_split：全部核计算接收状态任务，驱动接收核分支
      recorder.RecordMarker<36, 51>();
      // 【开始 ID=700】F7.layout_wait：整个有界gate轮询，含GM→UB及MTE2_S完成等待；失败也有此区间
      recorder.RecordMarker<37, 700>();
      ready_1 = 0;
      attempts_1 = 0;
      while (1) {
        if (!(((ready_1 == 0) && (attempts_1 < 100000)))) { break; }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
        tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], state1[((core * 8) + 224256)], 262144, 1, 8, (uint32_t)0);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        ready_1 = 1;
        for (int32_t i_3 = 0; i_3 < 8; ++i_3) {
          if (small.GetValue(i_3) != (uint32_t)1) {
            ready_1 = 0;
          }
        }
        attempts_1 = (attempts_1 + 1);
      }
      diag.SetValue(2, attempts_1);
      // 【结束 ID=701】F7.layout_wait：整个有界gate轮询，含GM→UB及MTE2_S完成等待；失败也有此区间
      recorder.RecordMarker<38, 701>();
      if (ready_1 == 0) {
        if (diag.GetValue(0) == 0) {
          diag.SetValue(0, 2);
        }
      } else {
        // 【开始 ID=710】F7.gate_clear：清本核gate，含MTE3_S完成等待
        recorder.RecordMarker<39, 710>();
        for (int32_t i_4 = 0; i_4 < 8; ++i_4) {
          small.SetValue(i_4, (uint32_t)0);
        }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
        tl::ascend::copy_ub_to_gm<uint32_t, 8>(state1[((core * 8) + 224256)], small[0], 262144, 1, 8);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
        // 【结束 ID=711】F7.gate_clear：清本核gate，含MTE3_S完成等待
        recorder.RecordMarker<40, 711>();
        if ((uint64_t)0 < o.GetValue(44)) {
          // 【开始 ID=720】F7.receive_plan：读取prefix、生成有效接收任务；核0输出专家数量，含搬运完成等待
          recorder.RecordMarker<41, 720>();
          diag.SetValue(8, ((int32_t)o.GetValue(44)));
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval_14;
          if (-262140 <= ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4))) {
            condval_14 = 4;
          } else {
            int32_t condval_15;
            if (-262144 < ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4))) {
              condval_15 = ((262144 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 4));
            } else {
              condval_15 = 0;
            }
            condval_14 = condval_15;
          }
          tl::ascend::copy_gm_to_ub<uint32_t, 4>(small[0], state1[((core * 4) + ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4)))], 262144, 1, condval_14, (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
          for (int32_t i_5 = 0; i_5 < 4; ++i_5) {
            prefix.SetValue(i_5, ((int32_t)small.GetValue(i_5)));
          }
          if (core == 0) {
            nums.SetValue(0, ((int64_t)prefix.GetValue(1)));
            nums.SetValue(1, (((int64_t)prefix.GetValue(3)) - ((int64_t)prefix.GetValue(1))));
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int64_t, 2>(expert_nums[0], nums[0], 2, 1, 2);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          begin_3 = 0;
          if (0 < core) {
            begin_3 = prefix.GetValue((core - 1));
          }
          size_2 = (prefix.GetValue(core) - begin_3);
          bucket_2 = ((((core + 1) % 2) * 2) + (core / 2));
          // 【结束 ID=721】F7.receive_plan：读取prefix、生成有效接收任务；核0输出专家数量，含搬运完成等待
          recorder.RecordMarker<42, 721>();
          if ((((size_2 < 0) || (((int32_t)(o.GetValue(15) / o.GetValue(14))) < size_2)) || (begin_3 < 0)) || (((int32_t)(((uint64_t)4 * o.GetValue(15)) / o.GetValue(14))) < prefix.GetValue(core))) {
            if (diag.GetValue(0) == 0) {
              diag.SetValue(0, 5);
            }
          } else {
            // 【开始 ID=800】F8.payload_loop：完整接收循环：READY保护区初始化、整批uint32精确全等、A/B读取及feature/assist直接跨步写回、失败和正常退出排空；全部完成等待留在F8
            recorder.RecordMarker<43, 800>();
            consumed = 0;
            batch_index = 0;
            pending_a = 0;
            pending_b = 0;
            if (0 < size_2) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[0], (uint32_t)0, (~(uint64_t)0), 32, 1, 8);
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[2048], (uint32_t)0, (((uint64_t)1 << (uint64_t)56) - (uint64_t)1), 1, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
            }
            while (1) {
              if (!(((consumed < size_2) && (diag.GetValue(0) == 0)))) { break; }
              batch_count = (128 < (size_2 - consumed) ? 128 : (size_2 - consumed));
              offset_3 = ((bucket_2 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (consumed * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
              arrived = 0;
              polls = 0;
              while (1) {
                if (!(((arrived == 0) && (polls < 100000)))) { break; }
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                tl::ascend::copy_gm_to_ub_ready<128>(batch_flags[0], data1[(offset_3 + 120)], 128, (batch_count * 2), 8, (uint32_t)0);
                arrived = ((int32_t)((batch_flags.GetValue(2104) == (uint32_t)1065353216) && (batch_flags.GetValue(2112) == (uint32_t)1065353216)));
                polls = (polls + 1);
              }
              diag.SetValue(3, (diag.GetValue(3) + (polls * batch_count)));
              if (arrived == 0) {
                diag.SetValue(0, 3);
              } else {
                if ((batch_index % 2) == 0) {
                  if (pending_a != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_compact<128>(batch_data_a[0], data1[offset_3], 256, batch_count, 136, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 136, 128>(output[((begin_3 * 128) + (consumed * 128))], batch_data_a[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm_assist<128, 136>(assist[((begin_3 * 3) + (consumed * 3))], batch_data_a[128], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                  pending_a = 1;
                } else {
                  if (pending_b != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_compact<128>(batch_data_b[0], data1[offset_3], 256, batch_count, 136, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 136, 128>(output[((begin_3 * 128) + (consumed * 128))], batch_data_b[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm_assist<128, 136>(assist[((begin_3 * 3) + (consumed * 3))], batch_data_b[128], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                  pending_b = 1;
                }
                batch_index = (batch_index + 1);
                consumed = (consumed + batch_count);
              }
            }
            if (pending_a != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
            }
            if (pending_b != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
            }
            diag.SetValue(7, consumed);
            diag.SetValue(10, (consumed * ((int32_t)o.GetValue(14))));
            // 【结束 ID=801】F8.payload_loop：完整接收循环：READY保护区初始化、整批uint32精确全等、A/B读取及feature/assist直接跨步写回、失败和正常退出排空；全部完成等待留在F8
            recorder.RecordMarker<44, 801>();
            // 【开始 ID=900】F9.payload_clear：仅清已消费payload的两个32B尾标志，含各次MTE3_S完成等待
            recorder.RecordMarker<45, 900>();
            for (int32_t i_6 = 0; i_6 < ((128 < consumed ? 128 : consumed) * 16); ++i_6) {
              batch_flags.SetValue(i_6, (uint32_t)0);
            }
            cleared = 0;
            while (1) {
              if (!((cleared < consumed))) { break; }
              clear_count = (128 < (consumed - cleared) ? 128 : (consumed - cleared));
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8, 256>(data1[(((bucket_2 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (cleared * ((int32_t)(o.GetValue(14) / (uint64_t)4)))) + 120)], batch_flags[0], 128, (clear_count * 2), 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              cleared = (cleared + clear_count);
            }
            // 【结束 ID=901】F9.payload_clear：仅清已消费payload的两个32B尾标志，含各次MTE3_S完成等待
            recorder.RecordMarker<46, 901>();
          }
        }
        // 【开始 ID=910】F9.final_fence：保留现有PIPE_MTE3 fence；输出完成等待已在F8内，不称原生异步输出尾等待
        recorder.RecordMarker<47, 910>();
        AscendC::PipeBarrier<PIPE_MTE3>();
        // 【结束 ID=911】F9.final_fence：保留现有PIPE_MTE3 fence；输出完成等待已在F8内，不称原生异步输出尾等待
        recorder.RecordMarker<48, 911>();
      }
      // 【开始 ID=1030】harness.diag_write：诊断写回GM，含MTE3_S完成等待
      recorder.RecordMarker<49, 1030>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
      tl::ascend::copy_ub_to_gm<int, 16>(diagnostics[(core * 16)], diag[0], 1024, 1, 16);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
      // 【结束 ID=1031】harness.diag_write：诊断写回GM，含MTE3_S完成等待
      recorder.RecordMarker<50, 1031>();
      // 【结束 ID=2】module.whole：单kernel内观测包络，含功能及harness，不含TPipe/Recorder准备、Flush和Destroy；不是ACL完整kernel时间
      recorder.RecordMarker<51, 2>();
      // Flush位于module.whole之外；profileGM来自当前launch的AclCapture。
      recorder.Flush(profileGM, static_cast<uint32_t>(core));
    }
  }
  pipe.Destroy();
}
