"""Bounded, interleaved HCCL A/B rounds with independent per-round validation."""
import argparse
import copy
import json
from pathlib import Path

from ..analyze_a5 import equal_round_summary, fixture_shape, require, stats, validate_mapping
from ..analyze_native import analyze
from ..run_native import digest, run, save

MODES = {'A': 'none', 'B': 'allreduce'}


def execution_order(rounds):
    return [{'group': group, 'round': i, 'directory': f'{group}/round{i}'}
            for i in range(1, rounds + 1)
            for group in (('A', 'B') if i % 2 else ('B', 'A'))]


def candidate_identity(install, fixture, generated):
    case = json.loads((fixture / 'case.json').read_text())
    world = case['shape']['world']
    mappings = [json.loads((generated / f'rank{r}/dispatch.ticks.json').read_text()) for r in range(world)]
    shape = fixture_shape(fixture / 'rank0')
    cores = []
    for rank, mapping in enumerate(mappings):
        validate_mapping(mapping, shape, rank, mapping['cores'])
        cores.append(mapping['cores'])
    paths = [install / 'bin' / f'tilelang_dispatch_integrated_r{r}_profile{p}'
             for r in range(world) for p in (0, 1)]
    paths += [install / 'lib64/tilexr/kernels' / f'tilelang_dispatch_r{r}_c{c}_profile{p}.o'
              for r, c in enumerate(cores) for p in (0, 1)]
    actual = {name: digest(fixture / name) for name in case['hashes']}
    require(actual == case['hashes'], 'A/B fixture hashes differ from manifest')
    return {'install_hashes': {p.relative_to(install).as_posix(): digest(p) for p in paths},
            'fixture_hashes': actual,
            'mapping_hashes': {f'rank{r}/dispatch.ticks.json': digest(generated / f'rank{r}/dispatch.ticks.json')
                               for r in range(world)}}


def aggregate(mode, analyses):
    ranks = []
    expected_ranks = [(row['rank'], row['cores']) for row in analyses[0]['rank_results']]
    require([rank for rank, _ in expected_ranks] == list(range(len(expected_ranks))), 'Missing or duplicate rank result')
    for analysis in analyses:
        require([(row['rank'], row['cores']) for row in analysis['rank_results']] == expected_ranks, 'Rank configuration changed across rounds')
    for rank, cores in expected_ranks:
        pairs = [a['pairs'][0]['ranks'][rank] for a in analyses]
        captures = []
        for number, analysis in enumerate(analyses, 1):
            for cap in analysis['rank_results'][rank]['captures']:
                cap = copy.deepcopy(cap)
                cap['round'] = number
                captures.append(cap)
        events = [p['pre_allreduce'] for p in pairs]
        metrics = {name: [e[name] for e in events] for name in
                   ('segment_event_us', 'dispatch_event_us', 'pre_dispatch_event_us')}
        device = [p['device_task_us'] for p in pairs if 'device_task_us' in p]
        wait = [p['F5_wait_ticks'] for p in pairs if 'F5_wait_ticks' in p]
        ranks.append({'rank': rank, 'cores': cores,
                      **{name: {'per_round': values, 'stats': stats(values)}
                         for name, values in metrics.items()},
                      'device_task_us': {'per_round': device, 'stats': stats(device) if device else None},
                      'F5_wait_ticks': {'per_round': wait, 'stats': stats(wait) if wait else None},
                      **{name: equal_round_summary(captures, name) if captures else {}
                         for name in ('modules', 'functions', 'stages')},
                      'captures': captures, 'round_evidence': pairs})
    result = {'mode': mode, 'rank_results': ranks,
              'launch_rank_offsets_from_rank0_ns': [a['pairs'][0].get('launch_rank_offsets_from_rank0_ns') for a in analyses]}
    if len(ranks) > 1:
        result['launch_rank1_minus_rank0_ns'] = [a['pairs'][0]['launch_rank1_minus_rank0_ns'] for a in analyses]
    return result


def run_ab(args):
    expected_rounds = 3 if args.mode == 'correctness' else 5
    require(args.rounds == expected_rounds and args.warmup == 20,
            'Authorized schedule is each mode 3 correctness or 5 capture rounds, warmup 20')
    identity = candidate_identity(args.install, args.fixture, args.generated)
    if args.mode == 'capture':
        require(args.correctness is not None, 'Capture requires completed A/B correctness evidence')
        previous = json.loads((args.correctness / 'summary.json').read_text())
        require(previous['status'] == 'PASS' and previous['mode'] == 'correctness'
                and previous['rounds_per_group'] == 3 and previous['identity'] == identity
                and previous['devices'] == args.devices and previous['warmup'] == args.warmup
                and previous['execution_order'] == execution_order(3),
                'Correctness candidate/input/device identity mismatch')
        # Recheck saved results instead of trusting an editable PASS field.
        for item in previous['execution_order']:
            directory = args.correctness / item['directory']
            actual_run = json.loads((directory / 'run.json').read_text())
            require(actual_run['pre_allreduce'] == MODES[item['group']]
                    and actual_run['mode'] == 'correctness', 'Correctness A/B group mode mismatch')
            analyze(directory, args.fixture, args.generated)
    args.output.mkdir(parents=True, exist_ok=False)
    for name in MODES:
        (args.output / name).mkdir()
    order = execution_order(args.rounds)
    config = {'schema': 'tilelang_pre_allreduce_ab.v1', 'mode': args.mode,
              'rounds_per_group': args.rounds, 'warmup': args.warmup,
              'devices': args.devices, 'identity': identity, 'execution_order': order,
              'process_lifecycle': 'fresh rank group per individual A/B round',
              'comparison': 'same Host candidate; both initialize and warm HCCL once; B prepends AllReduce to each Dispatch',
              'device_clock': 'uncalibrated raw ticks; no cross-rank device subtraction'}
    save(args.output / 'experiment.json', config)
    analyses = {name: [] for name in MODES}
    completed, capture_ids = [], set()
    try:
        for item in order:
            require(candidate_identity(args.install, args.fixture, args.generated) == identity,
                    'Candidate or fixture changed during A/B experiment')
            current = copy.copy(args)
            current.output = args.output / item['directory']
            current.rounds = 1
            current.pre_allreduce = MODES[item['group']]
            run(current)  # Includes a fresh occupancy check directly before each rank pair.
            result = analyze(current.output, args.fixture, args.generated)
            for rank_result in result['rank_results']:
                for cap in rank_result['captures']:
                    require(cap['capture_id'] not in capture_ids, 'Duplicate capture across A/B rounds')
                    capture_ids.add(cap['capture_id'])
            save(current.output / 'analysis.json', result)
            analyses[item['group']].append(result)
            completed.append({**item, 'status': 'PASS'})
            save(args.output / 'completed.json', completed)
        result = {**config, 'status': 'PASS', 'groups': {
            name: aggregate(MODES[name], values) for name, values in analyses.items()}}
        save(args.output / 'summary.json', result)
        return result
    except BaseException as error:
        save(args.output / 'failure.json', {'status': 'FAIL', 'type': type(error).__name__,
             'detail': str(error), 'completed': completed})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('install', 'fixture', 'generated', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--correctness', type=Path)
    parser.add_argument('--devices', type=int, nargs='+', default=[0, 1])
    parser.add_argument('--cores', type=int, nargs='+')
    parser.add_argument('--comm-port', type=int, required=True)
    parser.add_argument('--mode', choices=('correctness', 'capture'), required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    for name in ('install', 'fixture', 'generated', 'output', 'correctness'):
        if getattr(args, name) is not None:
            setattr(args, name, getattr(args, name).resolve())
    result = run_ab(args)
    print(json.dumps({'status': result['status'], 'mode': result['mode'],
                      'rounds_per_group': result['rounds_per_group']}))


if __name__ == '__main__':
    main()
