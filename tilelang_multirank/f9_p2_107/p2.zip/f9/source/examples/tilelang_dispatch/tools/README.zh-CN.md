# 实验工具

常规 TL v2 使用上级 `run_native.py` / `analyze_native.py`。T4 的生成物位于上级 `generated/`，
T16/64/256 各有 `batch/bsT/generated/`。均通过 `python3 -m examples.tilelang_dispatch.tools.<模块>` 调用。

| 模块 | 用途 | 依赖/限制 |
|---|---|---|
| `run_batch` | T16/64/256 同输入三场景交错验收/采集 | 各 3 轮正确性后各 10 轮采集；每轮新进程 20+1、前置 AR；须提供 00 放行文件及 SHA，忙/未知/失败停止 |
| `run_a5` | 旧逐次 C/D/K/V 控制、capture 初始化位置 A/B | 使用调用者提供的安装/fixture/新输出目录，不是常规 native 调度 |
| `diagnose_f5` | 解析上项产生的 Host 时间线与 first-seen | 需自行用 `profile --ready-probe` 生成诊断源码并独立构建；见 [F5](../docs/F5_DIAGNOSTIC.zh-CN.md) |
| `run_pre_allreduce` | 同 Host 的 none/allreduce 交错 A/B | 使用上级 native runner；见 [AllReduce](../docs/PRE_ALLREDUCE.zh-CN.md) |
| `run_f6` | 三个指定 F6 变体交错实验 | 需显式提供三套生成/安装目录；本分支不再附带旧变体导出；见 [F6](../docs/F6_COMBINED.zh-CN.md) |
| `report_a5` | 旧 `analyze_a5` 格式生成 HTML/raw-tick JSON | 接受已验收的旧 capture 分析，不接受 `analyze_native` 格式；逐核独立归零，不是校准 Perfetto |

当前仍保留 `ready_probe.h` 和可选 `TL_READY_PROBE`，以支持有限 first-seen 诊断；默认不启用。
旧实验的既有结果、源码和 recipe 从 Git 历史及原实验归档查阅，不因目录精简重新实验。
