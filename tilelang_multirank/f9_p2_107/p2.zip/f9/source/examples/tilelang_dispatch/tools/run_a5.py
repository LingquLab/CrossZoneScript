"""多rank单kernel运行：Host仅准备/校验完整轮次，不调度核内五阶段。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time


from ..host_control import check_idle, rendezvous
from ..run_native import rank_configuration


def run_iteration(channels, measured, deadline):
    rendezvous(channels, b'C' if measured else b'N', b'D', deadline)
    sends = []
    for rank, channel in enumerate(channels):
        before = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        channel.sendall(b'K')
        after = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        sends.append({'rank': rank, 'before_ns': before, 'after_ns': after})
    rendezvous(channels, None, b'D', deadline)
    rendezvous(channels, b'V', b'D', deadline)
    return sends


def run(args):
    if os.name != 'posix' or not hasattr(socket, 'AF_UNIX'):
        raise RuntimeError('Linux with socketpair/pass_fds required')
    # 不能在未验证映射下把物理查卡号当作可见设备内的逻辑号。
    if os.environ.get('ASCEND_RT_VISIBLE_DEVICES'):
        raise ValueError('Unset ASCEND_RT_VISIBLE_DEVICES; runner uses explicitly checked physical IDs')
    if not 1 <= args.rounds <= 20 or not 0 <= args.warmup <= 100 or not 1 <= args.timeout <= 600:
        raise ValueError('Invalid bounded run configuration')
    if not 1024 <= args.comm_port <= 65535:
        raise ValueError('Choose a dedicated unprivileged bootstrap port')
    placement = getattr(args, 'capture_init', 'after-k')
    if placement not in ('before-k', 'after-k'):
        raise ValueError('Invalid capture placement')
    case = json.loads((args.fixture / 'case.json').read_text())
    world, args.cores = rank_configuration(case, args.devices, getattr(args, 'cores', None))
    for name, expected in case['hashes'].items():
        if hashlib.sha256((args.fixture / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Fixture hash mismatch: ' + name)
    args.output.mkdir(parents=True, exist_ok=False)
    profile = 1 if args.mode == 'capture' else 0
    binaries = [args.install / 'bin' / f'tilelang_dispatch_integrated_r{rank}_profile{profile}' for rank in range(world)]
    devices = [args.install / 'lib64/tilexr/kernels' / f'tilelang_dispatch_r{r}_c{c}_profile{profile}.o'
               for r, c in enumerate(args.cores)]
    identity = {'schema': 'tilelang_dispatch_integrated_run.v1', 'mode': args.mode, 'rounds': args.rounds, 'warmup': args.warmup, 'devices': args.devices,
                'cores': args.cores, 'world_size': world, 'experts': case['shape']['experts'], 'observation': 'integrated single-kernel dispatch',
                'comm_port': args.comm_port, 'fixture': str(args.fixture),
                'host_barriers_in_kernel_timing': False,
                'capture_placement': placement, 'host_clock': 'CLOCK_MONOTONIC',
                'device_binaries': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in devices},
                'binaries': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in binaries}}
    (args.output / 'run.json').write_text(json.dumps(identity, indent=2) + '\n')
    check_idle(args.devices, args.output)
    env = os.environ.copy()
    env['TILEXR_COMM_ID'] = f'127.0.0.1:{args.comm_port}'
    # peer-memory路径不要求UDMA；沿用runtime的能力探测，不更改系统配置。
    channels, processes, logs = [], [], []
    start = time.monotonic()
    deadline = start + args.timeout
    completed = []
    try:
        for rank in range(world):
            parent, child = socket.socketpair()
            channels.append(parent)
            log = (args.output / f'rank{rank}.log').open('wb')
            logs.append(log)
            try:
                process = subprocess.Popen([str(binaries[rank]), str(args.devices[rank]),
                    str(args.fixture / f'rank{rank}'), str(args.output / f'rank{rank}'), str(child.fileno()), placement],
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                    env=env, pass_fds=(child.fileno(),))
                processes.append(process)
            finally:
                child.close()
        rendezvous(channels, None, b'R', deadline)
        iteration = 0
        for round_id in range(args.rounds):
            for local_iteration in range(args.warmup + 1):
                measured = local_iteration == args.warmup
                sends = run_iteration(channels, measured, deadline)
                completed.append({'iteration': iteration, 'round': round_id, 'measured': measured, 'k_sends': sends})
                iteration += 1
        rendezvous(channels, b'Q', b'D', deadline)
        exits = [p.wait(timeout=max(0.01, deadline - time.monotonic())) for p in processes]
        if exits != [0] * world:
            raise RuntimeError('Rank process nonzero exit after final barrier')
        result = {'status': 'PASS', 'rank_exit_codes': exits, 'iterations': completed,
                  'measured_iterations': [row['iteration'] for row in completed if row['measured']],
                  'elapsed_seconds': time.monotonic() - start,
                  'scope': 'Host/runner correctness; capture structure and timings require subsequent analysis'}
        (args.output / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        return result
    except BaseException as error:
        (args.output / 'failure.json').write_text(json.dumps({'status': 'FAIL',
            'error_type': type(error).__name__, 'detail': str(error), 'completed_iterations': completed}, indent=2) + '\n')
        raise
    finally:
        # 只结束本启动器创建的子进程；不按名称杀进程，不重置NPU。
        for process in processes:
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        for channel in channels:
            channel.close()
        for log in logs:
            log.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install', type=Path, required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--devices', type=int, nargs='+', default=[0, 1])
    parser.add_argument('--cores', type=int, nargs='+')
    parser.add_argument('--comm-port', type=int, required=True)
    parser.add_argument('--mode', choices=('correctness', 'capture'), required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--warmup', type=int, required=True)
    parser.add_argument('--timeout', type=int, default=240)
    parser.add_argument('--capture-init', choices=('after-k', 'before-k'), default='after-k')
    args = parser.parse_args()
    for name in ('install', 'fixture', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    result = run(args)
    print(json.dumps({'status': result['status'], 'iterations': len(result['iterations']),
                      'measured_iterations': result['measured_iterations']}))


if __name__ == '__main__':
    main()
