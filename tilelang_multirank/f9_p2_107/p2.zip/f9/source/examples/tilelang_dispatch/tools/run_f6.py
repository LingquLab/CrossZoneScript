"""Run the baseline, P1, and P2 F6 variants under the same pre-AllReduce Host schedule."""
import argparse
import copy
import json
from pathlib import Path

from ..analyze_a5 import require
from ..analyze_native import analyze
from ..run_native import run, save
from .run_pre_allreduce import aggregate, candidate_identity


VARIANTS = ('baseline', 'p1', 'p2')
ROUND_ORDER = (
    ('baseline', 'p1', 'p2'),
    ('p1', 'p2', 'baseline'),
    ('p2', 'baseline', 'p1'),
    ('baseline', 'p2', 'p1'),
    ('p2', 'p1', 'baseline'),
)


def execution_order(rounds, variants=VARIANTS):
    return [{'variant': variant, 'round': number, 'directory': f'{variant}/round{number}'}
            for number, ordered in enumerate(ROUND_ORDER[:rounds], 1)
            for variant in (variants[VARIANTS.index(name)] for name in ordered)]


def variant_identity(root, fixture, variants=VARIANTS):
    identity = {}
    for variant in variants:
        base = root / variant
        generated = base / 'generated'
        for rank in (0, 1):
            mapping = json.loads((generated / f'rank{rank}/dispatch.ticks.json').read_text())
            require(mapping['variant'] == variant and mapping['rank'] == rank,
                    'F6 generated mapping is assigned to the wrong variant or rank')
            names = {stage['name'] for stage in mapping['stages']}
            require({'F6.prepare', 'F6.workspace_publish', 'F6.gate_publish'} <= names,
                    'F6 substage evidence missing from generated mapping')
        identity[variant] = candidate_identity(base / 'install', fixture, generated)
    return identity


def run_variants(args):
    variants = tuple(getattr(args, 'variants', VARIANTS))
    require(len(variants) == 3 and len(set(variants)) == 3, 'Select three distinct variants')
    expected_rounds = 3 if args.mode == 'correctness' else 5
    require(args.rounds == expected_rounds and args.warmup == 20,
            'F6 schedule requires 3 correctness or 5 capture rounds, each with 20 warmups')
    identity = variant_identity(args.variants_root, args.fixture, variants)
    order = execution_order(args.rounds, variants)
    if args.mode == 'capture':
        require(args.correctness is not None, 'Capture requires three-group correctness evidence')
        previous = json.loads((args.correctness / 'summary.json').read_text())
        require(previous['status'] == 'PASS' and previous['mode'] == 'correctness'
                and previous['rounds_per_variant'] == 3
                and previous['identity'] == identity and previous['devices'] == args.devices
                and previous['warmup'] == args.warmup
                and previous['execution_order'] == execution_order(3, variants),
                'Correctness candidate, input, or device identity differs')
        for item in previous['execution_order']:
            path = args.correctness / item['directory']
            actual = json.loads((path / 'run.json').read_text())
            require(actual['pre_allreduce'] == 'allreduce' and actual['mode'] == 'correctness',
                    'Correctness round did not run the fixed pre-AllReduce mode')
            analyze(path, args.fixture, args.variants_root / item['variant'] / 'generated')
    args.output.mkdir(parents=True, exist_ok=False)
    for variant in variants:
        (args.output / variant).mkdir()
    config = {'schema': 'tilelang_f6_variant_comparison.v1', 'status': 'RUNNING',
              'mode': args.mode, 'rounds_per_variant': args.rounds, 'warmup': args.warmup,
              'devices': args.devices, 'identity': identity, 'execution_order': order,
              'pre_allreduce': 'allreduce', 'process_lifecycle': 'fresh rank pair each round',
              'device_clock': 'uncalibrated ticks; no cross-rank subtraction'}
    save(args.output / 'experiment.json', config)
    results = {variant: [] for variant in variants}
    completed, capture_ids = [], set()
    try:
        for item in order:
            require(variant_identity(args.variants_root, args.fixture, variants) == identity,
                    'F6 candidate or fixture changed during the experiment')
            variant = item['variant']
            current = copy.copy(args)
            current.install = args.variants_root / variant / 'install'
            current.output = args.output / item['directory']
            current.rounds = 1
            current.pre_allreduce = 'allreduce'
            run(current)
            result = analyze(current.output, args.fixture,
                             args.variants_root / variant / 'generated')
            for rank_result in result['rank_results']:
                for capture in rank_result['captures']:
                    require(capture['capture_id'] not in capture_ids,
                            'Capture UUID repeated across F6 rounds')
                    capture_ids.add(capture['capture_id'])
            save(current.output / 'analysis.json', result)
            results[variant].append(result)
            completed.append({**item, 'status': 'PASS'})
            save(args.output / 'completed.json', completed)
        summary = {**config, 'status': 'PASS',
                   'variants': {variant: aggregate('allreduce', results[variant])
                                for variant in variants}}
        save(args.output / 'summary.json', summary)
        return summary
    except BaseException as error:
        save(args.output / 'failure.json', {'status': 'FAIL', 'type': type(error).__name__,
             'detail': str(error), 'completed': completed})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('variants-root', 'fixture', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--variants', nargs=3, choices=('baseline', 'p1', 'p2', 'p1p2'), default=VARIANTS)
    parser.add_argument('--correctness', type=Path)
    parser.add_argument('--devices', type=int, nargs=2, default=[0, 1])
    parser.add_argument('--comm-port', type=int, required=True)
    parser.add_argument('--mode', choices=('correctness', 'capture'), required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    for name in ('variants_root', 'fixture', 'output', 'correctness'):
        if getattr(args, name) is not None:
            setattr(args, name, getattr(args, name).resolve())
    result = run_variants(args)
    print(json.dumps({'status': result['status'], 'mode': result['mode'],
                      'rounds_per_variant': result['rounds_per_variant']}))


if __name__ == '__main__':
    main()
