"""F5诊断：验证共同Host时间线和逐槽first-seen；不拼接两个NPU的时钟。"""
import argparse
import json
from pathlib import Path
from ..analyze_a5 import analyze, read_csv, read_json, require, words, validate_probe


def validate_timeline(row, sends, placement, capture):
    require(row['clock'] == 'CLOCK_MONOTONIC' and row['placement'] == placement,
            'Wrong Host clock/placement')
    fields = ('prepare_received_ns', 'ready_reply_before_ns', 'k_received_ns',
              'event_start_enqueue_ns', 'launch_before_ns', 'launch_after_ns', 'sync_end_ns')
    t = {key: int(row[key]) for key in fields + ('capture_begin_ns', 'capture_end_ns')}
    require(all(t[key] > 0 for key in fields) and
            all(t[a] <= t[b] for a, b in zip(fields, fields[1:])), 'Host timeline out of order')
    require(t['ready_reply_before_ns'] <= sends['before_ns'] <= sends['after_ns'] and
            sends['before_ns'] <= t['k_received_ns'], 'Parent K precedes ready or follows child receipt')
    if capture:
        lower, upper = (('prepare_received_ns', 'ready_reply_before_ns') if placement == 'before-k'
                        else ('k_received_ns', 'event_start_enqueue_ns'))
        require(t[lower] <= t['capture_begin_ns'] <= t['capture_end_ns'] <= t[upper],
                'Capture initialization outside selected placement')
    else:
        require(t['capture_begin_ns'] == t['capture_end_ns'] == 0, 'Unexpected capture in correctness run')
    return t


def diagnose(directory, fixture, generated):
    directory = Path(directory)
    analysis = analyze(directory, fixture, generated)  # bitwise output/flags/records first
    require(analysis['diagnostic_probe'], 'Requires first_seen.v1 diagnostic binary')
    run, summary = read_json(directory / 'run.json'), read_json(directory / 'summary.json')
    placement = run['capture_placement']
    measured = summary['measured_iterations']
    iterations = {item['iteration']: item for item in summary['iterations']}
    timeline = []
    for rank in (0, 1):
        root = directory / f'rank{rank}'
        host_summary = read_json(root / 'summary.json')
        require(host_summary['capture_placement'] == placement, 'Host/run placement mismatch')
        rows = read_csv(root / 'host-timeline.csv')
        require(len(rows) == len(measured) and [int(x['round']) for x in rows] == measured,
                'Missing/duplicate Host timeline rows')
        rank_rows = {}
        timing = {int(x['round']): x for x in read_csv(root / 'timing.csv')}
        for row in rows:
            i = int(row['round'])
            require(int(row['rank']) == rank and row['magic'] == timing[i]['magic'] and
                    row['capture_id'] == timing[i]['capture_id'], 'Timeline/run/capture identity mismatch')
            sends = iterations[i]['k_sends']
            require([x['rank'] for x in sends] == [0, 1], 'Missing per-rank K send timestamps')
            rank_rows[i] = validate_timeline(row, sends[rank], placement, run['mode'] == 'capture')
        timeline.append(rank_rows)
    pairs = []
    for i in measured:
        rank_rows = []
        for rank, cores in ((0, 56), (1, 64)):
            t, peer = timeline[rank][i], timeline[1-rank][i]
            row = {'rank': rank, 'iteration': i, 'host_ns': t,
                   'peer_minus_self_launch_ns': peer['launch_before_ns'] - t['launch_before_ns'],
                   'capture_init_ns': t['capture_end_ns'] - t['capture_begin_ns'],
                   'k_to_launch_ns': t['launch_before_ns'] - t['k_received_ns']}
            if run['mode'] == 'capture':
                cap = next(x for x in analysis['rank_results'][rank]['captures'] if x['iteration'] == i)
                lanes = {x['core']: x for x in cap['lanes']}
                f5 = lanes[cores-1]['intervals']['F5.wait_count']
                diag = words(directory / f'rank{rank}/round{i}.dispatch.diagnostics.bin', 'i', cores * 16)
                first = list(diag[-5:-1]); mask = diag[-1]
                validate_probe(first, mask, f5['ticks'])
                producers = []
                for slot in range(4):
                    source_rank, source_core = slot % 2, rank * 2 + slot // 2
                    source_cap = next(x for x in analysis['rank_results'][source_rank]['captures']
                                      if x['iteration'] == i)
                    source_lane = next(x for x in source_cap['lanes'] if x['core'] == source_core)
                    intervals = source_lane['intervals']
                    f3 = intervals['F3.count_publish']
                    producers.append({'slot': slot, 'producer_rank': source_rank, 'producer_core': source_core,
                        'first_seen_relative_tick': first[slot], 'first_poll_ready': bool(mask & (1 << slot)),
                        'producer_F2': intervals['F2.expert_count'], 'producer_F3': f3,
                        'producer_whole_begin_tick': intervals['module.whole']['begin_tick'],
                        'producer_own_entry_to_F3end_ticks': f3['end_tick'] - intervals['module.whole']['begin_tick']})
                row.update(capture_id=cap['capture_id'], F5=f5, first_poll_mask=mask,
                    count_polls=diag[(cores-1)*16+1], slots=producers,
                    last_slots=[q for q in range(4) if first[q] == max(first)],
                    acl_us=analysis['rank_results'][rank]['acl_event_per_round_us'][measured.index(i)])
            rank_rows.append(row)
        pairs.append({'iteration': i, 'ranks': rank_rows})
    return {'schema': 'tilelang_f5_diagnostic.v1', 'status': 'PASS', 'placement': placement,
            'mode': run['mode'], 'rounds': run['rounds'], 'warmup': run['warmup'],
            'binaries': run['binaries'], 'device_binaries': run['device_binaries'],
            'pairs': pairs, 'time_boundaries': [
                'Host CLOCK_MONOTONIC is shared by these processes on the same Linux boot.',
                'First-seen ticks originate inside F5 after marker500, not at hardware arrival.',
                'F3 end includes local completion; raw ticks across cores/ranks are not subtracted.',
                'Diagnostic probe adds overhead; A and B must use identical binaries.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('run', 'fixture', 'generated', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    result = diagnose(args.run, args.fixture, args.generated)
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'placement': result['placement'], 'pairs': len(result['pairs'])}))


if __name__ == '__main__':
    main()
