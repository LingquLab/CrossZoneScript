"""把已审查的集成单kernel导出适配为纯 AIV TileXR 打点源码；不编译或运行设备。"""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path



ROOT = Path(__file__).resolve().parent
ARGS = ['params', 'x', 'ids', 'peers', 'local_state', 'local_data',
        'output', 'assist', 'counts', 'expert_nums', 'diagnostics',
        'fftsAddr_unused_u64', 'profileGM']


def recipe_for_export(raw, metadata, template):
    """[AI] 从实际ABI2 raw重建行坐标，再SHA锁定。锚点缺失/重复即拒绝。

    只识别当前TL宏生成的块结构，不接受模糊匹配。每个循环的完整花括号
    都在区间内，Recorder不在逐条或逐槽循环中被反复覆盖。
    """
    import copy
    import re
    lines = raw.splitlines()
    def find(predicate, begin=0):
        hits = [i for i in range(begin, len(lines)) if predicate(lines[i].strip())]
        if len(hits) != 1:
            raise ValueError('Unexpected generic export anchor: ' + str(hits))
        return hits[0]
    def has(text, begin=0):
        return find(lambda line: text in line, begin)
    def block(index):
        depth = 0
        for j in range(index, len(lines)):
            depth += lines[j].count('{') - lines[j].count('}')
            if depth == 0:
                return j
        raise ValueError('Unclosed raw block')
    whole_begin = has('diag.SetValue(i, 0);') - 1
    diag_end = block(whole_begin)
    layout_begin = has('experts = p.GetValue(3);')
    layout_end = find(lambda line: line.startswith('o.SetValue(25,'))
    route_copy = find(lambda line: 'copy_gm_to_ub<int,' in line and 'route[0]' in line)
    route_end = route_copy + 2
    round_line = has('o.SetValue(32, (uint64_t)1);')
    count_start = has('o.SetValue(34, (uint64_t)0);')
    count_if = find(lambda line: line.startswith('if (') and 'o.GetValue(7) <=' in line)
    count_end = block(count_if)
    count_if2 = has('if ((uint64_t)0 < o.GetValue(36))')
    expert_loop = count_if2 + 1
    expert_end = has('diag.SetValue(4,')
    publish_start = expert_end + 1
    publish_end = block(publish_start)
    pack_start = find(lambda line: line.startswith('if (') and 'o.GetValue(32)' in line)
    pack_end = block(pack_start)
    status_start = find(lambda line: line.startswith('worker_1 ='))
    status_end = has('o.SetValue(40,')
    wait_start = find(lambda line: line == 'attempts = 0;') - 1
    wait_end = has('diag.SetValue(6,')
    consume_start = find(lambda line: line == 'total = (uint32_t)0;')
    consume_copy = find(lambda line: 'copy_ub_to_gm<uint32_t,' in line and 'local_state[0], records[0]' in line)
    consume_end = consume_copy + 3
    prefix_start = consume_end + 1
    prefix_if = has('if (small.GetValue(1) !=')
    prefix_end = block(prefix_if)
    counts_copy = find(lambda line: 'copy_ub_to_gm<int,' in line and 'counts[0]' in line)
    # [AI] 四个F6变体保持同一模块边界；只有P2类使用publish_buf。
    workspace_start = counts_copy + 3
    gate_one = find(lambda line: line.startswith('small.SetValue(') and line.endswith('(uint32_t)1);'))
    gate_start = gate_one - 1
    workspace_end = gate_start - 1
    gate_end = prefix_end - 1
    role_barrier = has('AscendC::PipeBarrier<PIPE_ALL>();')
    receive_start = find(lambda line: line.startswith('worker_2 ='))
    receive_end = has('o.SetValue(44,')
    gate_wait_start = find(lambda line: line == 'attempts_1 = 0;') - 1
    gate_wait_end = has('diag.SetValue(2,')
    gate_clear_write = find(lambda line: 'copy_ub_to_gm<uint32_t,' in line and 'small[0]' in line and 'core * 8' in line)
    gate_clear_start = gate_clear_write - 5
    gate_clear_end = gate_clear_write + 2
    plan_start = has('diag.SetValue(8,')
    # [AI] q循环按UB语义区分；F9新版含最大需求扫描，旧导出仍只有clear。
    slot_loops = [i for i in range(plan_start,len(lines)) if lines[i].strip().startswith('for (') and 'o.GetValue(42)' in lines[i]]
    if len(slot_loops) not in (3, 4):
        raise ValueError('Expected validation/payload/[clear-size]/clear slot loops')
    validate_loop, payload_start, clear_loop = slot_loops[0], slot_loops[1], slot_loops[-1]
    plan_end = block(validate_loop)
    payload_end = block(payload_start)
    # [AI] 最大需求扫描、向量填零、V→MTE3及全部清理都归入F9，不挪到F8外计时。
    clear_start = payload_end + 1 if len(slot_loops) == 4 else clear_loop
    clear_end = block(clear_loop)
    final_fence = clear_end + 2
    if lines[final_fence].strip() != 'AscendC::PipeBarrier<PIPE_MTE3>();':
        raise ValueError('Final fence anchor differs')
    diag_write = find(lambda line: 'copy_ub_to_gm<int,' in line and 'diagnostics[' in line)
    diag_write_start, whole_end = diag_write - 2, diag_write + 2
    bounds = {
        'module.whole':(whole_begin,whole_end), 'harness.diag_init':(whole_begin,diag_end),
        'harness.params_init':(diag_end+1,layout_begin-1), 'F0.layout':(layout_begin,layout_end),
        'F1.route_read':(layout_end+1,route_end), 'F0.send_round':(round_line,round_line),
        'F0.count_split':(count_start,count_end), 'F2.expert_count':(expert_loop,expert_end),
        'F3.count_publish':(publish_start,publish_end), 'F4.pack_send':(pack_start,pack_end),
        'F0.status_split':(status_start,status_end), 'F5.wait_count':(wait_start,wait_end),
        'F5.consume_clear':(consume_start,consume_end), 'F6.prefix_publish':(prefix_start,prefix_end),
        'role_pipeline_barrier':(role_barrier,role_barrier), 'F0.receive_split':(receive_start,receive_end),
        'F7.layout_wait':(gate_wait_start,gate_wait_end), 'F7.gate_clear':(gate_clear_start,gate_clear_end),
        'F7.receive_plan':(plan_start,plan_end), 'F8.payload_loop':(payload_start,payload_end),
        'F9.payload_clear':(clear_start,clear_end), 'F9.final_fence':(final_fence,final_fence),
        'harness.diag_write':(diag_write_start,whole_end), 'F6.prepare':(prefix_start,counts_copy+2),
        'F6.workspace_publish':(workspace_start,workspace_end), 'F6.gate_publish':(gate_start,gate_end)}
    recipe = copy.deepcopy(template)
    spec = recipe['modules']['dispatch']
    spec['raw_sha256_by_rank'] = {str(metadata['rank']):sha(raw.encode())}
    views = re.findall(r'ascend_ub.GetWithOffset<([^>]+)>\((\d+), (\d+)\)', raw)
    widths = {'uint64_t':8,'int64_t':8,'uint32_t':4,'int32_t':4,'int':4,'float':4}
    if not views or any(dtype not in widths for dtype,_,_ in views):
        raise ValueError('Actual UB views missing or unknown dtype')
    ub_bytes = max(int(offset)+int(count)*widths[dtype] for dtype,count,offset in views)
    ub_bytes = (ub_bytes+31)//32*32
    if ub_bytes > metadata['receive_ub_plan']['ub_budget_bytes']:
        raise ValueError('Actual UB allocation exceeds budget')
    spec['ub_bytes'] = ub_bytes
    spec['ub_bytes_by_rank'] = {str(metadata['rank']):ub_bytes}
    for stage in spec['stages']:
        lo, hi = bounds[stage['name']]
        if not (0 <= lo <= hi < len(lines)):
            raise ValueError('Invalid stage bounds: ' + stage['name'])
        stage['raw_lines'] = [lo+1,hi+1]
        stage['participation'] = '按本次P/E/T及receive/count任务区间；见mapping与diagnostics'
        if stage['name'] == 'F2.expert_count':
            stage['description'] = '扫描本rank全部2T路由，统计分配到本核的全局专家；整个专家循环'
        elif stage['name'] == 'F0.count_split':
            stage['description'] = 'T<48按全核划分E个计数任务；T>=48仅末核处理全部E项'
        elif stage['name'] == 'F7.receive_plan':
            stage['description'] = '读取本核32B补齐prefix副本、验证全部已分配槽；核0写L项专家数量'
        elif stage['name'] == 'F8.payload_loop':
            stage['description'] = '完整接收槽循环：批量跨READY搬运、A/B输出与每槽排空；包含全部完成等待'
        elif stage['name'] == 'F9.payload_clear':
            stage['description'] = ('本核最大需求扫描、一次向量填零及按槽清已完成记录READY，含全部同步和逐批MTE3完成等待'
                                    if len(slot_loops) == 4 else
                                    '完整清理循环：按槽仅清已完成输出的记录READY，含MTE3完成等待')
    recipe.update(variant=metadata['variant'],tokens_per_rank=metadata['tokens_per_rank'],
                  world_size=metadata['world_size'],experts=metadata['experts'],abi_version=2)
    return recipe


def replace_once(source, old, new):
    """锁定导出适配锚点；缺失或重复时停止，防止错误插桩。"""
    if source.count(old) != 1:
        raise ValueError(f"Unexpected export: unique conversion anchor missing: {old[:90]!r}")
    return source.replace(old, new, 1)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def instrument(raw, spec, module, rank, cores, ready_probe=False):
    """行坐标仅适用于完整 SHA256 锁定的原样导出，不接受相似源码。"""
    if sha(raw.encode()) != spec['raw_sha256_by_rank'][str(rank)]:
        raise ValueError(f'{module}: source differs from reviewed export')
    lines = raw.splitlines(keepends=True)
    # 坐标为原始文件的行间隙：start-1之前，end之后。
    inserts = defaultdict(list)
    for stage in spec['stages']:
        start, end = stage['raw_lines']
        inserts[start - 1].append((stage, 'begin'))
        inserts[end].insert(0, (stage, 'end'))
    slot = 0
    result = []
    events = []
    for index, line in enumerate(lines):
        for stage, edge in inserts[index]:
            event = stage[edge]
            anchor = stage['raw_lines'][0 if edge == 'begin' else 1] - 1
            indent = lines[anchor][:len(lines[anchor]) - len(lines[anchor].lstrip())]
            label = '开始' if edge == 'begin' else '结束'
            result += [f'{indent}// 【{label} ID={event}】{stage["name"]}：{stage["description"]}\n',
                       f'{indent}recorder.RecordMarker<{slot}, {event}>();\n']
            events.append({'slot': slot, 'id': event, 'stage': stage['name'], 'edge': edge})
            slot += 1
        result.append(line)
    if slot > 64:
        raise ValueError('Recorder capacity exceeded')
    device = ''.join(result)
    delimiter = '\nvoid dispatch_kernel_tiling() {\n'
    if device.count(delimiter) != 1:
        raise ValueError('Missing unique Host wrapper boundary')
    device = device.split(delimiter)[0]
    device = replace_once(device, '#include "tl_templates/ascend/common.h"',
                          '#include "kernel_operator.h"\n#include <tilexr/profiling.h>\n#include "tl_templates/ascend/common.h"')
    device = replace_once(device, '#include <runtime/rt_ffts.h>\n', '')
    entry = f'tilexr_tl_dispatch_r{rank}_c{cores}'
    device = replace_once(device, 'void dispatch_kernel(', f'void {entry}(')
    device = replace_once(device, 'uint64_t fftsAddr) {', 'uint64_t fftsAddr, GM_ADDR profileGM) {')
    device = replace_once(device, 'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_1);',
                          'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);')
    # [AI] import_source可能增加声明行；在SHA锁定raw中定位完整TPipe缓冲段，保留实际UB偏移。
    setup_begin = raw.index('  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;')
    setup_end = raw.index('  pipe.Destroy();', setup_begin) + len('  pipe.Destroy();\n')
    setup = raw[setup_begin:setup_end]
    device = replace_once(device, setup,
        '  // AIV适配：保留实际UB，生命周期到全部工作和Flush之后。\n'
        '  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;\n'
        f'  pipe.InitBuffer(ascend_ub, {spec["ub_bytes"]});\n')
    device = replace_once(device, '  auto vid = AscendC::GetSubBlockIdx();',
        '  auto vid = AscendC::GetSubBlockIdx();\n'
        '  // Recorder初始化不计入module.whole；一个AIV核唯一拥有一条lane。\n'
        '  TileXR::Profiling::Recorder<64> recorder;')
    device = replace_once(device, '    }\n  }\n}\n',
        '      // Flush位于module.whole之外；profileGM来自当前launch的AclCapture。\n'
        '      recorder.Flush(profileGM, static_cast<uint32_t>(core));\n'
        '    }\n  }\n  pipe.Destroy();\n}\n')
    if ready_probe:
        device = add_ready_probe(device)
    return device, entry, events



def add_ready_probe(device):
    """仅对SHA锁定的原样导出添加有限诊断；不改业务原始TL或raw导出。"""
    device = replace_once(device, '#include <tilexr/profiling.h>\n',
                          '#include <tilexr/profiling.h>\n#include "ready_probe.h"\n')
    device = replace_once(device, '          ready = 0;\n          attempts = 0;',
        '          TileLangDiagnostic::ReadyProbe readyProbe(AscendC::GetSystemCycle());\n'
        '          ready = 0;\n          attempts = 0;')
    device = replace_once(device, '            ready = 1;\n',
                          '            ready = 1;\n            uint32_t readyMask = 0;\n')
    device = replace_once(device,
        '              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {\n'
        '                ready = 0;\n              }',
        '              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {\n'
        '                ready = 0;\n              } else {\n'
        '                readyMask |= 1U << static_cast<uint32_t>(q);\n              }')
    device = replace_once(device, '            attempts = (attempts + 1);\n',
        '            // Read the timer only when at least one previously unseen slot is ready.\n'
        '            readyProbe.Observe(readyMask, readyProbe.HasNew(readyMask) ?\n'
        '                AscendC::GetSystemCycle() : readyProbe.origin);\n'
        '            attempts = (attempts + 1);\n')
    device = replace_once(device, '          diag.SetValue(1, attempts);',
        '          for (int32_t slot = 0; slot < 4; ++slot)\n'
        '            diag.SetValue(11 + slot, readyProbe.first[slot]);\n'
        '          diag.SetValue(15, readyProbe.firstMask);\n'
        '          diag.SetValue(1, attempts);')
    return device

def adapt(source_dir, output_dir, ready_probe=False, recipe_path=None):
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    recipe_path = Path(recipe_path) if recipe_path is not None else ROOT / 'profile_recipe.json'
    recipe = json.loads(recipe_path.read_text())
    metadata = json.loads((source_dir / 'export.json').read_text())
    if any(metadata[key] != recipe[key] for key in ('backend_revision', 'backend_diff_sha256')):
        raise ValueError('Backend provenance differs from reviewed export')
    variant = metadata.get('variant', 'baseline')
    if recipe_path != ROOT / 'profile_recipe.json' and recipe.get('abi_version') == 2 and variant != recipe.get('variant', 'baseline'):
        raise ValueError('F6 variant differs from reviewed recipe')
    tokens = metadata.get('tokens_per_rank', 4)
    if recipe_path != ROOT / 'profile_recipe.json' and recipe.get('abi_version') == 2 and tokens != recipe.get('tokens_per_rank', 4):
        raise ValueError('Batch size differs from reviewed recipe')
    rank, cores = metadata['rank'], metadata['cores']
    from .contract import validate_dispatch_config
    validate_dispatch_config(world_size=metadata.get('world_size', 2), experts=metadata.get('experts', 4),
                             rank=rank, cores=cores, tokens=tokens)
    if metadata.get('abi_version') != 2:
        raise ValueError('This adapter requires peer-table ABI2 exports')
    if ready_probe and (metadata['world_size'],metadata['experts']) != (2,4):
        raise ValueError('Legacy four-slot ready probe is only P2/E4')
    outputs, rows = {}, []
    for item in metadata['modules']:
        module = item['module']
        raw_bytes = (source_dir / (module + '.raw.cpp')).read_bytes()
        if sha(raw_bytes) != item['source_sha256']:
            raise ValueError(f'{module}: export metadata hash mismatch')
        if recipe_path == ROOT / 'profile_recipe.json' or recipe.get('abi_version') != 2:
            recipe = recipe_for_export(raw_bytes.decode(), metadata, recipe)
        spec = recipe['modules'][module]
        if 'ub_bytes_by_rank' in spec:
            spec = dict(spec, ub_bytes=spec['ub_bytes_by_rank'][str(rank)])
        device, entry, events = instrument(raw_bytes.decode(), spec, module, rank, cores, ready_probe)
        mapping = {'schema': 'tilelang_dispatch_ticks.v1', 'contract': recipe['contract'],
                   'module': module, 'rank': rank, 'cores': cores, 'variant': variant, 'tokens_per_rank': tokens,
                   **{k: metadata[k] for k in ('world_size','experts','local_experts','workspace_stride_words','abi_version')},
                   'observation': 'integrated_single_kernel',
                   'clock': 'AscendC::GetSystemCycle', 'unit': 'ticks', 'cycles_per_us': None,
                   'record_capacity': 64, 'events': events, 'stages': spec['stages'], 'module_groups': recipe['module_groups'],
                   'excluded': ['TPipe/UB setup', 'Recorder construction', 'Flush', 'pipe.Destroy', 'Host time'],
                   'aggregation': '每轮按实际参与核统计均值/最大值；轮间等权。不跨rank相减、不跨核相加，不把module.whole当ACL完整kernel时间。',
                   'validation_required': '所有核diagnostics[core*16]错误码为0且业务输出通过；诊断列1–10为轮询及工作量；11–15保留为0。'}
        if ready_probe:
            mapping['count_ready_probe'] = 'first_seen.v1'
            mapping['validation_required'] = ('Only prefix core uses diagnostics 11–14: first-seen relative ticks, '
                '-1 unseen, -2 overflow; 15 first-poll mask. Other cores retain zero. '
                'Origin is inside F5 after marker500; observations are not peer arrival timestamps.')
        outputs[module + '.raw.cpp'] = raw_bytes
        outputs[module + '.device.cpp'] = device.encode()
        outputs[module + '.ticks.json'] = (json.dumps(mapping, ensure_ascii=False, indent=2) + '\n').encode()
        rows.append({'module': module, 'entry': entry, 'ub_bytes': spec['ub_bytes'],
                     'marker_slots': len(events), 'record_capacity': 64,
                     'raw_sha256': sha(raw_bytes), 'device_sha256': sha(device.encode())})
    # 先验证全部输入，避免源不匹配留下部分生成结果；禁止覆写已有目录。
    output_dir.mkdir(parents=True, exist_ok=False)
    outputs['profile_recipe.json'] = (json.dumps(recipe,ensure_ascii=False,indent=2)+'\n').encode()
    outputs['export.json'] = (source_dir / 'export.json').read_bytes()
    summary = {'schema': 'tilelang_dispatch_instrumentation.v1', 'rank': rank, 'cores': cores,
               'variant': variant, 'tokens_per_rank': tokens,
               **{k: metadata[k] for k in ('world_size','experts','local_experts','workspace_stride_words','abi_version')},
               'abi': {'version': 2, 'args_size': 104}, 'mode': 'AIV_ONLY', 'observation': 'integrated_single_kernel', 'args': ARGS, 'args_bytes_aarch64': 104,
               'recipe_sha256': sha(outputs['profile_recipe.json']),
               'adapter_sha256': sha(Path(__file__).read_bytes()),
               'modules': rows, 'device_compile': 'NOT_RUN', 'device_execution': 'NOT_RUN',
               'changes': ['删除未使用Cube缓冲及Host三尖括号包装', '实际UB大小并延后Destroy',
                           '唯一纯AIV入口，追加profileGM', '加入Recorder/Marker/Flush；不增加流水同步'],
               'hashes': {name: sha(data) for name, data in outputs.items()}}
    if ready_probe:
        summary['count_ready_probe'] = 'first_seen.v1'
        summary['ready_probe_header_sha256'] = sha((ROOT / 'ready_probe.h').read_bytes())
        summary['changes'].append('F5 bounded first-seen diagnostics; diagnostic overhead, not optimization')
    for name, data in outputs.items():
        (output_dir / name).write_bytes(data)
    (output_dir / 'adaptation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ready-probe', action='store_true')
    parser.add_argument('--recipe', type=Path)
    args = parser.parse_args()
    result = adapt(args.source, args.output, args.ready_probe, args.recipe)
    print(json.dumps({'rank': result['rank'], 'modules': len(result['modules']),
                      'instrumentation': 'GENERATED', 'device_compile': 'NOT_RUN',
                      'device_execution': 'NOT_RUN'}))


if __name__ == '__main__':
    main()
