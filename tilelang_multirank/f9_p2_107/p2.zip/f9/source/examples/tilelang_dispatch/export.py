"""导出集成kernel原样Ascend C/TIR；不会编译CANN .o或启动设备。"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rank', type=int, required=True)
    parser.add_argument('--world-size', type=int, default=2)
    parser.add_argument('--experts', type=int, default=4)
    parser.add_argument('--cores', type=int, required=True)
    parser.add_argument('--tokens', type=int, choices=(4, 16, 64, 256), default=4)
    parser.add_argument('--variant', choices=('baseline', 'p1', 'p2', 'p1p2'), default='p1p2')
    parser.add_argument('--backend-provenance', type=Path,
                        help='Verified backend Python snapshot manifest when the source has no .git')
    args = parser.parse_args()
    import tilelang as tl
    from tilelang.transform.pass_config import process_default_pass_config
    from tilelang.jit.adapter.libgen import resolve_compile_flags
    from .kernel import make_kernel, receive_ub_plan
    from .contract import validate_dispatch_config
    validate_dispatch_config(world_size=args.world_size, experts=args.experts, rank=args.rank, cores=args.cores, tokens=args.tokens)
    # 五模块全部为scalar/GM↔UB操作，copy_words显式同步；禁用自动分配事件避免冲突。
    PASS_CONFIGS = {'tl.ascend_auto_sync': False, 'tl.ascend_memory_planning': True, 'tir.merge_static_smem': True}
    backend = Path(tl.__file__).resolve().parent
    if args.backend_provenance is None:
        backend_revision = subprocess.check_output(['git', '-C', str(backend), 'rev-parse', 'HEAD'], text=True).strip()
        backend_diff = hashlib.sha256(subprocess.check_output(['git', '-C', str(backend), 'diff', 'HEAD', '--binary'])).hexdigest()
        backend_dirty = bool(subprocess.check_output(['git', '-C', str(backend), 'status', '--porcelain'], text=True).strip())
        backend_snapshot = None
    else:
        manifest = json.loads(args.backend_provenance.read_text())
        if backend != (args.backend_provenance.resolve().parent / 'tilelang').resolve():
            raise ValueError('Imported TileLang does not match backend snapshot path')
        for name, expected in manifest['files'].items():
            source = backend / name
            if source.resolve().is_relative_to(backend) is False:
                raise ValueError('Backend Python snapshot path escapes package: ' + name)
            actual = hashlib.sha256(source.read_bytes()).hexdigest()
            if actual != expected:
                raise ValueError('Backend Python snapshot mismatch: ' + name)
        backend_revision = manifest['backend_revision']
        backend_diff = manifest['backend_diff_sha256']
        backend_dirty = manifest['backend_dirty']
        backend_snapshot = hashlib.sha256(args.backend_provenance.read_bytes()).hexdigest()
    provenance = {'backend_revision': backend_revision,
                  'backend_diff_sha256': backend_diff,
                  'rank': args.rank, 'cores': args.cores,
                  'world_size': args.world_size, 'experts': args.experts,
                  'local_experts': args.experts // args.world_size, 'abi_version': 2,
                  'workspace_stride_words': ((args.experts + 7) // 8) * 8,
                  'variant': args.variant, 'tokens_per_rank': args.tokens,
                  'backend_python_snapshot_sha256': backend_snapshot,
                  'device_compile': 'NOT_RUN', 'device_execution': 'NOT_RUN', 'timings': None,
                  'scope': 'integrated single Dispatch kernel source export; no device execution',
                  'receive_ub_plan': receive_ub_plan(args.tokens, args.cores, args.world_size, args.experts)}
    configs = process_default_pass_config('ascendc', PASS_CONFIGS)
    provenance['compiler_flags_if_device_compiled'] = resolve_compile_flags('ascendc', configs)
    provenance['pass_configs'] = configs
    provenance['backend_dirty'] = backend_dirty
    root = Path(__file__).resolve().parents[2]
    dependencies = [Path(__file__).with_name(name) for name in
                    ('export.py', 'kernel.py', 'contract.py', 'layout_reference.py')]
    provenance['source_hashes'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in sorted(dependencies)}
    rows = []
    for stage in ('dispatch',):
        primitive = make_kernel(args.rank, args.cores, tokens=args.tokens,
                                world_size=args.world_size, experts=args.experts,
                                variant={'baseline': 0, 'p1': 1, 'p2': 2, 'p1p2': 3}[args.variant])
        with tl.tvm.transform.PassContext(opt_level=3, config=configs):
            artifact = tl.lower(primitive, target='ascendc', platform='A5',
                                enable_host_codegen=False, enable_device_compile=False)
        source = artifact.kernel_source
        if not source:
            raise RuntimeError('No generated source for ' + stage)
        args.output.mkdir(parents=True, exist_ok=False)
        (args.output / (stage + '.raw.cpp')).write_text(source)
        (args.output / (stage + '.tir')).write_text(primitive.script())
        rows.append({'module': stage, 'functions': ['F' + str(i) for i in range(10)], 'source_generation': 'PASS',
                     'source_sha256': hashlib.sha256(source.encode()).hexdigest()})
        print(stage + ' source export PASS', flush=True)
    provenance['modules'] = rows
    (args.output / 'export.json').write_text(json.dumps(provenance, indent=2) + '\n')


if __name__ == '__main__':
    main()
