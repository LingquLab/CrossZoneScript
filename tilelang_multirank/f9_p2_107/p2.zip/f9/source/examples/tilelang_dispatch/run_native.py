"""原生式Host采集：每轮新进程、连续预热、rank barrier后一次测量。"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shlex
import shutil
import signal
import socket
import subprocess
import time

from .host_control import check_idle
from .contract import validate_dispatch_config


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rank_configuration(case, devices, cores=None):
    """[AI] Fixture owns P; physical devices and block dimensions are explicit per rank.

    Historical P2 invocations retain 56/64. Other worlds must specify their
    actual core counts; no inference from rank ID or physical device ID.
    """
    shape = case['shape']
    world = shape['world']
    experts = shape['experts']
    if type(world) is not int or world < 1 or type(experts) is not int or experts < 2 or experts % world:
        raise ValueError('Invalid fixture world/expert partition')
    if len(devices) != world or len(set(devices)) != world or any(type(d) is not int or d < 0 for d in devices):
        raise ValueError('One distinct nonnegative physical device ID required per rank')
    if cores is None:
        if world != 2:
            raise ValueError('Specify --cores for every rank outside the historical P2 configuration')
        cores = [56, 64]
    if len(cores) != world or any(type(c) is not int or c < 2 for c in cores):
        raise ValueError('One core count >= 2 required per rank')
    return world, list(cores)


def profiler_task(directory, symbol, warmup):
    files = list(directory.rglob('op_summary*.csv'))
    if len(files) != 1:
        raise ValueError('Expected one msprof op_summary per rank')
    with files[0].open(newline='') as stream:
        rows = [r for r in csv.DictReader(stream) if r['Op Name'] == symbol]
    if len(rows) != warmup + 1:
        raise ValueError(f'Expected {warmup + 1} tasks for {symbol}, got {len(rows)}')
    rows.sort(key=lambda r: float(r['Task Start Time(us)']))
    row = rows[-1]
    duration = float(row['Task Duration(us)'])
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('Invalid msprof task duration')
    return {'device_task_us': duration, 'csv': files[0].relative_to(directory).as_posix(), 'op_name': symbol,
            'dispatch_tasks': len(rows), 'task_id': row['Task ID'],
            'stream_id': row['Stream ID'], 'measured_iteration': warmup}


def group_exists(pid):
    try:
        os.killpg(pid, 0)
        return True
    except ProcessLookupError:
        return False


def finish_groups(processes, directory):
    # msprof may exit before its application; terminate only groups we created.
    for sig in (signal.SIGTERM, signal.SIGKILL):
        for process in processes:
            process.poll()
            if group_exists(process.pid):
                try:
                    os.killpg(process.pid, sig)
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            for process in processes:
                process.poll()
            if not any(group_exists(p.pid) for p in processes):
                break
            time.sleep(.05)
    states = [{'pid': p.pid, 'exit_code': p.poll(), 'group_remaining': group_exists(p.pid)}
              for p in processes]
    save(directory / 'process-exits.json', states)
    if any(r['exit_code'] is None or r['group_remaining'] for r in states):
        raise RuntimeError('Own process termination unknown; inspect before further execution')


def run_round(args, directory, binaries, profiler):
    directory.mkdir()
    check_idle(args.devices, directory)
    # Port selection is not a reservation. Bind conflicts fail visibly.
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    env = os.environ.copy()
    env['TILEXR_COMM_ID'] = f'127.0.0.1:{args.comm_port}'
    processes, logs, commands = [], [], []
    try:
        for rank, binary in enumerate(binaries):
            command = [str(binary), '--native', str(args.devices[rank]),
                       str(args.fixture / f'rank{rank}'), str(directory / f'rank{rank}'),
                       str(args.warmup), str(port)]
            if getattr(args, 'pre_allreduce', None) is not None:
                command.append(args.pre_allreduce)
            if profiler:
                command = [profiler, '--application=' + shlex.join(command),
                           '--output=' + str(directory / f'prof-rank-{rank}'), '--task-time=on']
            commands.append({'rank': rank, 'argv': command, 'comm_id': env['TILEXR_COMM_ID'],
                             'barrier_port': port})
            log = (directory / f'rank{rank}.log').open('wb')
            logs.append(log)
            processes.append(subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True))
        save(directory / 'commands.json', commands)
        deadline = time.monotonic() + args.timeout
        while any(p.poll() is None for p in processes):
            if any(p.poll() not in (None, 0) for p in processes):
                raise RuntimeError('Rank/application/profiler failed')
            if time.monotonic() >= deadline:
                raise TimeoutError('Native round exceeded bounded timeout')
            time.sleep(.05)
        if any(p.returncode != 0 for p in processes):
            raise RuntimeError('Rank/application/profiler failed')
    finally:
        finish_groups(processes, directory)
        for log in logs:
            log.close()
    profiles = [profiler_task(directory / f'prof-rank-{r}',
                f'tilexr_tl_dispatch_r{r}_c{cores}', args.warmup)
                for r, cores in enumerate(args.cores)] if profiler else []
    result = {'status': 'PASS', 'profiler': profiles,
              'scope': 'process completion; operator/capture validation requires analyze_native'}
    save(directory / 'execution.json', result)
    return result


def run(args):
    if os.name != 'posix':
        raise ValueError('Linux process groups required')
    if os.environ.get('ASCEND_RT_VISIBLE_DEVICES') or os.environ.get('ASCEND_VISIBLE_DEVICES'):
        raise ValueError('Unset visible-device remapping before physical occupancy checks')
    if not (1 <= args.rounds <= 20 and 1 <= args.warmup <= 100 and 1 <= args.timeout <= 600):
        raise ValueError('Invalid bounded schedule')
    if not 1024 <= args.comm_port <= 65535:
        raise ValueError('Dedicated unprivileged communication port required')
    pre_allreduce = getattr(args, 'pre_allreduce', None)
    if pre_allreduce not in (None, 'none', 'allreduce'):
        raise ValueError('Invalid pre-AllReduce mode')
    profiler = shutil.which('msprof') if args.mode == 'capture' else None
    if args.mode == 'capture' and not profiler:
        raise RuntimeError('msprof required; no silent ACL-only fallback')
    case = json.loads((args.fixture / 'case.json').read_text())
    world, args.cores = rank_configuration(case, args.devices, getattr(args, 'cores', None))
    for rank, cores in enumerate(args.cores):
        validate_dispatch_config(world_size=world, experts=case['shape']['experts'], rank=rank,
                                 cores=cores, tokens=case['shape']['tokens_per_rank'])
    for name, expected in case['hashes'].items():
        if digest(args.fixture / name) != expected:
            raise ValueError('Fixture SHA mismatch: ' + name)
    profile = int(args.mode == 'capture')
    binaries = [args.install / 'bin' / f'tilelang_dispatch_integrated_r{r}_profile{profile}' for r in range(world)]
    kernels = [args.install / 'lib64/tilexr/kernels' /
               f'tilelang_dispatch_r{r}_c{c}_profile{profile}.o' for r, c in enumerate(args.cores)]
    identity = {'schema': 'tilelang_dispatch_native_run.v1', 'mode': args.mode,
                'rounds': args.rounds, 'warmup': args.warmup, 'devices': args.devices, 'cores': args.cores,
                'world_size': world, 'experts': case['shape']['experts'],
                'process_lifecycle': 'fresh rank group per round',
                'warmup_schedule': 'continuous submission then stream synchronization',
                'capture_placement': 'before measured rank barrier',
                'primary_time_source': 'msprof device task' if profiler else None,
                'binaries': {str(p): digest(p) for p in binaries},
                'device_binaries': {str(p): digest(p) for p in kernels},
                'fixture_hashes': case['hashes']}
    if pre_allreduce is not None:
        identity['pre_allreduce'] = pre_allreduce
        identity['common_hccl_warmup'] = True
    args.output.mkdir(parents=True, exist_ok=False)
    save(args.output / 'run.json', identity)
    completed = []
    try:
        for index in range(args.rounds):
            result = run_round(args, args.output / f'round{index + 1}', binaries, profiler)
            completed.append({'round': index + 1, **result})
        result = {'status': 'PASS', 'rounds': completed}
        save(args.output / 'execution.json', result)
        return result
    except BaseException as error:
        save(args.output / 'failure.json', {'status': 'FAIL', 'error_type': type(error).__name__,
             'detail': str(error), 'completed_rounds': completed})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('install', 'fixture', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--devices', type=int, nargs='+', default=[0, 1])
    parser.add_argument('--cores', type=int, nargs='+', help='Block dimensions in rank order; default 56/64 only for P2')
    parser.add_argument('--comm-port', type=int, required=True)
    parser.add_argument('--mode', choices=('correctness', 'capture'), required=True)
    parser.add_argument('--rounds', type=int, required=True)
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--timeout', type=int, default=180, help='seconds per independent round')
    parser.add_argument('--pre-allreduce', choices=('none', 'allreduce'),
                        help='Opt-in HCCL A/B experiment; both modes initialize and warm up HCCL')
    args = parser.parse_args()
    for name in ('install', 'fixture', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    result = run(args)
    print(json.dumps({'status': result['status'], 'completed_rounds': len(result['rounds'])}))


if __name__ == '__main__':
    main()
