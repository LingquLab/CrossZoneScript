"""[AI] 可配置P/E/T的确定性输入及独立逐token golden；默认保留原P2/E4/T4输入字节。"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
from .contract import Config, F, reference as f0_reference, validate_dispatch_config


def fixture_routes(tokens, world_size, experts):
    """[AI] 返回[T,2]全局专家ID。P2/E4与既有均衡fixture逐字节相同。

    P>2按token组轮转目标rank；P=1在本地选两个不同专家。不是生产router。
    """
    local = experts // world_size
    if world_size == 1:
        return tuple((t % experts, (t + 1) % experts) for t in range(tokens))
    return tuple((((t // local * 2) % world_size) * local + t % local,
                  ((t // local * 2 + 1) % world_size) * local + t % local)
                 for t in range(tokens))


def make_fixture(directory, *, tokens=4, world_size=2, experts=4, cores=None, routes=None):
    """[AI] 各rank分别生成CPU侧输入文件，Host随后拷到该rank设备GM。

    cores是长度P的实际启动核数；未知多rank硬件不得套用2卡的核数。
    routes可传P组[T,2]以构造偏斜/空槽；golden不复用设备bucket公式。
    """
    if cores is None:
        if world_size != 2:
            raise ValueError('Explicit cores per rank required for non-default world size')
        cores = (56, 64)
    validate_dispatch_config(world_size=world_size, experts=experts, rank=0, cores=cores[0] if cores else 2, tokens=tokens)
    if len(cores) != world_size:
        raise ValueError('cores must contain exactly P entries')
    for rank, count in enumerate(cores):
        validate_dispatch_config(world_size=world_size, experts=experts, rank=rank, cores=count, tokens=tokens)
    ids = routes if routes is not None else [fixture_routes(tokens, world_size, experts) for _ in range(world_size)]
    if len(ids) != world_size or any(len(rows) != tokens or any(len(row) != 2 or len(set(row)) != 2 or
          any(type(v) is not int or not 0 <= v < experts for v in row) for row in rows) for rows in ids):
        raise ValueError('routes must be P distinct-expert int32[T,2] arrays')
    xs = [[[0x3f80 + rank * 0x80 + token * 0x10 + h % 32 for h in range(256)]
           for token in range(tokens)] for rank in range(world_size)]
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    hashes, valid_rows = {}, []
    local = experts // world_size
    for rank in range(world_size):
        target = directory / f'rank{rank}'
        target.mkdir()
        features, triples, counts, expert_nums = [], [], [], []
        for expert in range(rank * local, (rank + 1) * local):
            before = len(triples) // 3
            for source in range(world_size):
                for token, row in enumerate(ids[source]):
                    for k, destination in enumerate(row):
                        if destination == expert:
                            features.extend(xs[source][token])
                            triples.extend((source, token, k))
                counts.append(len(triples) // 3)
            expert_nums.append(len(triples) // 3 - before)
        valid_rows.append(len(triples) // 3)
        files = {'x.bin': ('H', [x for row in xs[rank] for x in row]),
                 'ids.bin': ('i', [x for row in ids[rank] for x in row]),
                 'expected_output.bin': ('H', features), 'expected_assist.bin': ('i', triples),
                 'expected_counts.bin': ('i', counts), 'expected_expert_nums.bin': ('q', expert_nums)}
        for name, (fmt, values) in files.items():
            data = struct.pack('<' + fmt * len(values), *values)
            (target / name).write_bytes(data)
            hashes[f'rank{rank}/{name}'] = hashlib.sha256(data).hexdigest()
        descriptors = f0_reference(Config(tokens=tokens, world_size=world_size, experts=experts,
             rank=rank, block_dim=cores[rank], peer_base=32, magic=0))
        for row in descriptors:
            for field in ('state_address', 'payload_address', 'dispatch_address', 'workspace_address'):
                row[F[field]] -= 32
        data = struct.pack('<' + 'Q' * (cores[rank] * 64), *(x for row in descriptors for x in row))
        (target / 'expected_desc.bin').write_bytes(data)
        hashes[f'rank{rank}/expected_desc.bin'] = hashlib.sha256(data).hexdigest()
    manifest = {'shape': {'world': world_size, 'experts': experts, 'tokens_per_rank': tokens, 'hidden': 256, 'topk': 2},
                'cores_per_rank': list(cores), 'dtype': 'BF16 raw little-endian bits',
                'expert_ids_by_rank': ids, 'expert_ids_both_ranks': ids[0] if world_size == 2 and ids[0] == ids[1] else None,
                'x_formula': '0x3f80 + rank*0x80 + token*0x10 + hidden_index%32',
                'expected_valid_rows_by_rank': valid_rows,
                'expected_valid_rows_per_rank': valid_rows[0] if len(set(valid_rows)) == 1 else None, 'hashes': hashes}
    (directory / 'case.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--tokens', type=int, choices=(4,16,64,256), default=4)
    parser.add_argument('--world-size', type=int, default=2)
    parser.add_argument('--experts', type=int, default=4)
    parser.add_argument('--cores', type=int, nargs='+')
    args = parser.parse_args()
    make_fixture(args.output, tokens=args.tokens, world_size=args.world_size, experts=args.experts, cores=args.cores)
