# The CANN 9.1 HCCL build used by this experiment exports old-ABI std::regex
# internals. Some internal symbol names do not distinguish the string ABI.
function(tl_check_pre_allreduce_abi comm_library)
    include(CheckCXXSourceCompiles)
    unset(TL_PRE_ALLREDUCE_HOST_ABI0 CACHE)
    check_cxx_source_compiles("
        #include <string>
        static_assert(_GLIBCXX_USE_CXX11_ABI == 0, \"HCCL experiment requires ABI 0\");
        int main() { return 0; }
    " TL_PRE_ALLREDUCE_HOST_ABI0)
    if(NOT TL_PRE_ALLREDUCE_HOST_ABI0)
        message(FATAL_ERROR "Pre-AllReduce requires Host and TileXR core built with -D_GLIBCXX_USE_CXX11_ABI=0; use separate build/install directories.")
    endif()
    execute_process(COMMAND "${CMAKE_NM}" -D --defined-only "${comm_library}"
        RESULT_VARIABLE nm_status OUTPUT_VARIABLE comm_symbols ERROR_VARIABLE nm_error TIMEOUT 10)
    if(NOT nm_status STREQUAL "0")
        message(FATAL_ERROR "Cannot inspect TileXR core ABI: ${nm_error}")
    endif()
    if(comm_symbols MATCHES "__cxx1112regex_traits")
        message(FATAL_ERROR "TileXR core exports new-ABI std::regex symbols that conflict with this HCCL build. Rebuild the isolated core with -D_GLIBCXX_USE_CXX11_ABI=0.")
    endif()
endfunction()
