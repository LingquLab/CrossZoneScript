# P1、P2-safe-gate、P1+P2对照

通过历史工具 `python3 -m examples.tilelang_dispatch.tools.run_f6` 的`--variants p1 p2 p1p2`显式选择三组。三组使用同一Host、前置AllReduce、fixture、F0–F9与F6/F7子段边界；各3正确性通过后各5轮20预热+1采集，顺序交错。失败停止，不丢弃长尾。

| 名称 | workspace | gate |
|---|---|---|
| p1 | 逐核小搬运，组尾完成等待 | 逐核32B，组尾完成等待 |
| p2 | 连续UB批量搬运，等待完成 | 逐核32B，每次完成等待 |
| p1p2 | 连续UB批量搬运，等待完成 | 逐核32B，组尾完成等待 |

组合版保证workspace批量完成后才填充/发布gate；gate小块提交期间不改写UB源，所有提交后等待完成，再离开F6。沿用P2的UB容量。未修改F8、poll_limit、bank/magic或设备输入。当前默认是 p1p2（TL v2），只随分支保留这一套导出。其他候选仍可通过 `export --variant` 显式导出；专用 recipe 和旧实验材料从 Git 历史 `d46e96bb` 找回并逐项核对 raw SHA/UB/边界后使用。`tools.run_f6` 要求调用者提供三个已独立构建、验收的目录，不会自动恢复已移除的导出。

相同频率规格只用于duration换算，不代表跨核/跨rank时钟校准。本批不包含clock分支。数据交00整理，新结果不替换指定的2026-11-09 TLXR默认比较基线。
