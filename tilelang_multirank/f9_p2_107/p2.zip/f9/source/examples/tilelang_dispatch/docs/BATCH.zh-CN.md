# T16/64/256 均衡 Dispatch

`kernel.py` 的 `tokens` 参数和 `export --tokens` 支持每 rank T4/16/64/256，
固定 P2/E4/K2/H256/BF16、rank0/56 和 rank1/64 AIV 核。默认仍为 T4。
本扩展保留 P1+P2：workspace 连续 UB 批量写回并完成等待，gate 逐核 32B 提交后组尾等待。

每个 batch 有独立真实导出、SHA 锁定的打点 recipe 和生成物，位于 `batch/bsT/`。
构建时同时指定 `-DTL_TOKENS_PER_RANK=T`、`-DTL_GENERATED_ROOT=.../batch/bsT/generated`；
默认 T4 使用上级 `generated/`。CMake 拒绝 Host 与导出 T 不一致及原始源码/生成物 SHA 不匹配。
前置 AR 构建仍启用 `TL_PRE_ALLREDUCE_SUPPORT=ON`，Host/核心库同为 ABI0；HCCL 参数不变。

## 扩容行为与计时

- 所有核读取 2T 条 expertIds。T<48 时前 4 核各计数 1 专家；T>=48 时末核计数全部 4 专家。
  F2 覆盖全部计数任务，F3 覆盖全部发布任务，各记录一次。
- 前 `min(2T, cores-1)` 核发送，第 c 核处理 `c, c+send_cores, ...` 的全部路由，
  每条仍按稳定专家位置打包 1024B，并完成等待。F4 包住整个任务循环。
- 末核执行 F5/F6，前 4 核各接收 T/2 条记录。payload、output/assist 容量与布局参数同 T 扩容，
  [AI] 本工作树的 F8 改为下述单缓冲批量跨步接收。T>=48 的角色切换是原生分工规则的扩容，不是新增 F6 优化。
- F0–F9、五模块及 F6/F7 子段按真实参与核统计 mean/max；模块均值不能相加为 kernel 时长。
  原始 tick 未校准，不做跨核/跨 rank 起止相减；ACL/msprof 四类时间独立保留。

## 输入与执行

使用 `dispatch-balanced-batch-20261110-v1` 的实际 fixture 字节，不重新生成或只核对 shape。
suite 根目录含 `suite.json` 和 `bs16/bs64/bs256/case.json`；每个 case 列出所有二进制 SHA。
Host 先核对输入字节及黄金输出，再上传，初始化阶段单存 `input-readback.x.bin` 和
`input-readback.ids.bin`；分析器逐字节核对设备回读与 fixture。设备回读是独立证据，不替代 fixture SHA。

将各 case 的安装与打点文件放到 `CASES_ROOT/bsT/{install,generated}`，调用：

```bash
python3 -m examples.tilelang_dispatch.tools.run_batch \
  --cases-root CASES_ROOT --suite-root SUITE_ROOT --output NEW_CORRECTNESS_DIR \
  --start-release RELEASE_JSON --start-release-sha256 RELEASE_SHA \
  --mode correctness --rounds 3 --comm-port PORT
python3 -m examples.tilelang_dispatch.tools.run_batch \
  --cases-root CASES_ROOT --suite-root SUITE_ROOT --output NEW_CAPTURE_DIR \
  --start-release RELEASE_JSON --start-release-sha256 RELEASE_SHA \
  --mode capture --rounds 10 --correctness NEW_CORRECTNESS_DIR --comm-port PORT
```

放行文件由协调方核验原生正式交付后提供，状态须为 `READY_AFTER_NATIVE_FORMAL_DELIVERY`；
执行前还须收到放行通知。工具将文件内容及 SHA 绑定到批次，不生成放行文件。
各轮顺序 bs16→bs64→bs256；每轮新双 rank 进程、20 连续预热+1 正式测量，
实时查卡，忙/未知/错误立即停止且不重试。无 msprof 不降级采集。采集前重验同身份正确性原始证据。
JSON/CSV 保留每轮四计时、五模块/F 段/子段 mean/max、参与核、有效工作核、并列最慢核及工作量。

## 维护要点与验证边界

扩容不能只放大 Tensor shape：需同步 route 循环、发送核多任务、计数任务范围、窗口步长、
Host warmup/正式输出容量和验收。T>=48 时发送核不得对计数范围做无符号负数减法。
固定后端的 `T.alloc_var(init=...)` 不接受另一个 `T.uint32(0)` IntImm；使用声明后赋值，
并运行真实导出，不能只由 Python 语法通过推断可编译。
循环内反复写同一 marker 槽会丢任务：打点需包住本核整个任务循环，更新真实导出 SHA 和行坐标。

CPU 测试执行真实 TL 宏的串行 C 版本，对照独立 oracle，覆盖完整路由、输出、工作量与轮次复用；
它不验证 MTE 并发、设备调度或 A5 性能。真实导出及离线验算通过也不等于 CANN 构建或 NPU 验收通过。

## [AI] 模块⑤：按UB预算计算批容量与双缓冲接收

`kernel.py:receive_ub_plan(tokens, cores)`在构造kernel时计算批容量，运行时每批取
`min(capacity,remaining)`。使用190KiB保守逻辑UB预算，先扣除其他显式UB分配的32B对齐总量，
每条接收记录另外计入A/B数据2×960B、A/B来源信息2×32B、READY 64B，共2048B。
容量由预算计算，不能直接复制原生本场景的97条。真实导出还需核对全部UB视图末地址和预算。

F7仍读取本核gate与prefix。F8的A/B分别拥有数据和assist缓冲；READY缓冲独立共用。
每批先等齐有效2N个READY，再选择A或B；首次使用不等待，复用前等待本槽MTE3完成。
GM每条两段480B有效数据通过跨步DMA压紧为960B UB；512B特征批量写出，来源三项仍经过
标量复制到32B对齐行再批量写12B/条。两次输出后设置本槽完成事件，但不立即等待。
A的MTE3输出与B的MTE2读入具备重叠条件，实际重叠/收益仍以设备验证为准。

固定后端通用GM→UB模板的尾批补零会等待MTE3，普通AscendC外部调用又不会被该后端生成。
因此kernel.py通过已有`T.import_source`提供一个最小`copy_gm_to_ub_valid`适配函数，
由TL宏传入张量、地址、有效行数与32B对齐宽度，内部使用DataCopyParams跨步DMA。
不补未用尾行，后续只访问有效行；不修改共享后端，也不手改导出的C++。该适配函数为
Ascend C API桥接，批容量/轮转/依赖/输出布局仍由TileLang源码控制。

A/B分别使用MTE3→S事件2/3，S→MTE3和同步MTE2读取仍用事件0（不同方向事件独立）。
所有正常或READY超限退出路径先在F8内排空已提交槽，再统计成功消费并进入F9；
F9只清此前成功记录的READY，保留失败批现场。没有新增跨核/rank屏障。
不能通过把完成等待移到F9来报告F8加速；须同时比较F8、模块⑤工作核和完整Dispatch。

输入/输出/计数/诊断张量ABI、四接收核分工、Host、AR和发送端保持原有协议。
`payload_polls`仍按每次检查的记录数累计，首次全就绪时等于接收记录数。
空桶、尾批、第三批缓冲复用及两种缺READY由真实TL宏CPU测试覆盖；CPU分支不验证MTE并发。
维护时必须重导出T4/16/64/256两rank、核对DMA与UB范围、更新recipe坐标/SHA/52槽打点。
本候选的CANN编译、事件及实际重叠/性能由A5实验验证，离线通过不等同实机通过。
