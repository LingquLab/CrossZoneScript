# F5 计数 ready 等待诊断

本诊断定位“F5到底在等谁，以及双方Host启动是否错位”，不优化F6/F8。当前默认是 TL v2。此处的历史 Host A/B 使用 `tools.run_a5`，需用下列命令在新目录生成可选 first-seen 设备源码；不再保留旧诊断导出副本。不能把新增插桩的耗时直接称为原版性能。

## 两组只改变什么

- A `--capture-init after-k`：双方完成C准备并应答D后，父进程发送K；子进程收到K后创建capture，再launch。
- B `--capture-init before-k`：capture创建在C准备阶段，完成后应答D；父进程等双方D再发送K。

两组使用相同Host二进制和设备ELF，仅改变运行参数。每轮仍各rank一个kernel；计数/payload并行、F6/F8实现、flags清理、双bank复用、F0–F9边界不改，不加设备全核barrier。两组分别启动一对进程，各自5轮20次预热+1次采集，记录全部长尾。

## 新观测的含义

`host-timeline.csv`使用同一Linux主机的`CLOCK_MONOTONIC`纳秒，记录C/N接收、D回复前、K接收、capture初始化开始/完成、ACL start入队前、kernel launch调用前/后、stream同步完成。`summary.json`记录父进程每次K发送前/后的同源时间。日志在V完成后落盘，观测调用本身仍有成本。Host launch调用时刻不是设备kernel开始时刻。

设备仍由TileXR Recorder保留F2/F3/F5原始tick。F5在完成四槽GM→UB读取和MTE2_S后生成ready mask，只对首次出现的新bit取一次`GetSystemCycle`。最多4次first-seen采样，无逐poll GM日志。`diagnostics[core,11:15]`仅末核记录slot0–3首次软件观测相对probe起点的tick；字段15是首轮mask。起点在F5 marker500之后，**不等于marker500**。-1表示未观测，-2表示倒退/超过INT32_MAX，均使验收失败；其他核这些字段仍为0。`first_seen.v1`元数据和CMake `TL_READY_PROBE`须匹配。

|接收rank|F5核|slot0来源|slot1来源|slot2来源|slot3来源|
|---|---|---|---|---|---|
|0|55|r0c0|r1c0|r0c1|r1c1|
|1|63|r0c2|r1c2|r0c3|r1c3|

F3结束含发布端本地MTE3完成，不证明peer可见瞬间。first-seen是轮询完成后软件首次看到，不是数据到达瞬间。每核独立归零的trace不能当公共时间线；不能用不同NPU计数器直接相减，也不能把Host ns减去NPU tick。950DT按官方1GHz规格可以对**持续时间**做ticks/1000得到μs，频率一致不证明跨rank相位一致。

## 生成与构建

在仓库根目录，首次生成新的输出目录（诊断导出不再随当前分支重复保存）：

```bash
python3 -m examples.tilelang_dispatch.profile \
  --source examples/tilelang_dispatch/reference_exports/rank0 \
  --output /tmp/f5-export/rank0 --ready-probe
python3 -m examples.tilelang_dispatch.profile \
  --source examples/tilelang_dispatch/reference_exports/rank1 \
  --output /tmp/f5-export/rank1 --ready-probe
cmake -S examples/tilelang_dispatch -B build-f5 \
  -DTL_CANN_ROOT="$CANN_ROOT" -DTL_BACKEND_ROOT="$BACKEND_ROOT" \
  -DTL_COMM_PREFIX="$COMM_INSTALL" -DTL_READY_PROBE=ON \
  -DTL_GENERATED_ROOT=/tmp/f5-export \
  -DCMAKE_INSTALL_LIBDIR=lib64 -DCMAKE_INSTALL_PREFIX="$PWD/install-f5"
cmake --build build-f5 --parallel 2 --verbose
cmake --install build-f5
```

运行沿用README固定输入与查卡、超时规则。每组先`--mode correctness --rounds 3 --warmup 0`，然后`--mode capture --rounds 5 --warmup 20`；使用 `python3 -m examples.tilelang_dispatch.tools.run_a5`，A/B分别加`--capture-init after-k`/`before-k`，使用新输出目录和独立通信端口。probe在两个profile构建中都存在，profile0仅关闭TileXR记录，不能据此测插桩开销。

每个运行目录独立验收（含正确性组）：

```bash
python3 -m examples.tilelang_dispatch.tools.diagnose_f5 \
  --run "$RUN_DIR" --fixture "$FIXTURE_DIR" \
  --generated /tmp/f5-export \
  --output "$DIAGNOSTIC_JSON"
```

输出按轮、rank保留共同Host时间、启动差、capture耗时、F5完整区间、四槽来源和first-seen、对应生产核F2/F3 raw区间及同核whole→F3end。先检查两组Host/ELF哈希一致，再逐轮比较；不按均值推断原因。

## 判别与验证边界

若A的长等待只缺对端槽、对端Host capture/launch更迟，且B将初始化纳入双方ready后该偏差和等待同步缩小，支持启动错位解释。A没复现长尾时，B也无长尾不是因果证明。Host launch接近但仍缺对端槽，还需区分设备调度、发布可见性和轮询成本；不能直接归因网络。诊断不能证明两设备时钟对齐。

离线测试覆盖实际C++探针的首见/重复/溢出、Host时间顺序与放置、双rank控制失败停机、默认导出回归；NPU构建与结果另存实验记录，未运行不能填写真实耗时。

可复用经验：诊断ABI保留字段转为有效字段时，必须同时版本化生成映射、Host校验和分析器；只放宽reserved检查会把不匹配二进制的零值误当有效观测。双rank实验的初始化必须明确在ready之前还是之后，耗时CSV只有持续时间无法事后重建启动错位。
