# 前置小数据 AllReduce 与历史 A/B 对照

常规 TL v2 测试使用 `run_native --pre-allreduce allreduce`，见 [主入口](../README.zh-CN.md)。下面的 `tools.run_pre_allreduce` 是显式历史 A/B 工具，不作为常规默认。

本实验检查双 rank 的 Host 启动错位是否会在 Dispatch 的 F5/F7 中形成等待，以及在同一 stream 上前置 HCCL AllReduce 后，等待是否只是转移到通信操作。保留所有长尾，同时观察 Dispatch 和整段开销。

## A/B 行为

两组使用同一份 Host 和 Dispatch ELF、相同的 X/expertIds、56/64 AIV。共同执行 HCCL 通信域初始化、独立 int32 发送值 1 的一次 AllReduce 热身并校验 SUM=2。独立接收缓冲与打点、参数、输出准备都在测量 barrier 前完成。

- A（`none`）：20 次 Dispatch 预热，测量一次 Dispatch。
- B（`allreduce`）：20 次 `AllReduce → Dispatch` 预热，测量一次相同序列。每次 AllReduce 使用独立接收缓冲，完成后检查结果 2。

B 的测量提交顺序是：整段起始事件、AllReduce、Dispatch 起始事件、Dispatch、结束事件。它们共用 `aclrtStream`，中间不调用 Host 同步、D2H、分配或打印；整段同步完成后才验收结果。HCCL API 返回成功只证明提交成功，顺序依赖由同 stream 执行语义提供，结果必须经设备运行验证。

原 `--native ... WARMUP PORT` 用法继续可用，不初始化 HCCL。显式追加 `none` 或 `allreduce` 才进入本实验，两者都需要开启构建选项 `TL_PRE_ALLREDUCE_SUPPORT=ON` 并链接目标 CANN 的 HCCL。

## 构建和运行

使用独立的 core 和 integrated 构建、安装目录。在两次 CMake 配置中都增加 Host ABI 参数；integrated 另启用 AllReduce：

```bash
# core 和 integrated 均需要
-DCMAKE_CXX_FLAGS=-D_GLIBCXX_USE_CXX11_ABI=0
# 仅 integrated
-DTL_PRE_ALLREDUCE_SUPPORT=ON
```

默认沿用当前 `generated/`，无需开启 `TL_READY_PROBE`。只有明确做 first-seen 诊断时才按 [F5 说明](F5_DIAGNOSTIC.zh-CN.md) 生成并选择诊断目录，不修改设备算法或 F0–F9 边界。依赖 CANN 9.1 的 `hccl/hccl.h`、`hccl/hccl_comm.h`、`libhccl.so`，以及现有 ACL、Runtime 和 TileXR 通信库。通信根信息只在初始化时通过本机 TCP 交换，不写入结果包。

这里的 ABI 设置针对本实验实际使用的 CANN 9.1 HCCL 库，不修改 TileXR 默认构建。不能只改 runner 而复用先前 ABI 1 的 core。配置检查会拒绝 Host ABI 1，以及仍导出新版 `regex_traits` 的 core；这项检查针对已观察到的符号冲突，不替代运行验证。

运行命令使用当前机器上的实际路径：

```bash
python3 -m examples.tilelang_dispatch.tools.run_pre_allreduce \
  --install /path/to/install --fixture /path/to/fixture \
  --generated examples/tilelang_dispatch/generated \
  --output /path/to/new-correctness --devices 0 1 --comm-port 39090 \
  --mode correctness --rounds 3 --warmup 20

python3 -m examples.tilelang_dispatch.tools.run_pre_allreduce \
  --install /path/to/install --fixture /path/to/fixture \
  --generated examples/tilelang_dispatch/generated \
  --output /path/to/new-capture --devices 0 1 --comm-port 39090 \
  --correctness /path/to/new-correctness --mode capture --rounds 5 --warmup 20
```

每轮使用新进程对，A/B 顺序交错为 AB、BA、AB……。每次启动前查询所选设备是否有进程，失败或状态不明确停止。每轮结束即重新验收原始 Dispatch 输出、预热输出、计数诊断、打点和 AllReduce 结果；正式采集还要求相同候选、设备、输入的 A/B 正确性记录通过。

## 产物和计时口径

`summary.json` 保存两组逐 rank 的五模块/F0–F9 汇总及逐轮原始统计，mean 是每轮参与核均值再等权平均；max 保留跨轮最慢核区间。原始 lane、工作量、Host 时间线及 msprof CSV 保留在各轮目录。

| 指标 | 含义 |
|---|---|
| `device_task_us` | msprof 精确匹配的最后一次 Dispatch 设备任务，排除预热 |
| `dispatch_event_us` | Dispatch 起止事件区间，属于辅助 ACL 时间，不等同 msprof 任务时间 |
| `segment_event_us` | 整段起始事件到结束事件；B 包含前置 AllReduce 与 Dispatch，A 是对应基准 |
| `pre_dispatch_event_us` | B 为 AllReduce 所在事件区间，含事件边界开销；A 只有事件边界间隔，不能叫 AllReduce 耗时 |
| `F5_wait_ticks` | 计数管理核等待 ready 的区间，不是整个 F5 |

HCCL 可能产生多个设备任务或辅助 stream，保留非 Dispatch 任务和通信 CSV 的索引，不将子任务耗时相加冒充墙钟时间。单独的通信区间由同 stream 事件界定，最终报告应明确其包含等待和事件开销。

`allreduce-results.bin` 保存实际 D2H 的 int32：A 仅公共通信热身结果；B 为公共热身、20 次前置热身、1 次测量结果。分析器检查所有值为 2；`allreduce-send.bin` 检查实际发送值为 1。SUM 正确不能替代 X/ids 的独立 SHA 核验。

Host 时间使用同机 `CLOCK_MONOTONIC`。设备 raw tick 未做跨核/跨 rank 时钟校准，不生成伪公共时间轴。本实验不合并时钟分支或 F6/F8 优化。

## 验证边界与维护要点

本地合成测试验证调度、验收和失败停止；桩头编译验证 C++ 语法。它们不能证明真实 HCCL 与 TileXR peer 窗口共存、通信完成依赖或性能。CANN 构建和 A5 正确性/采集结果必须独立记录。

计时区间内的检查函数只在失败时构造异常消息，避免成功路径的字符串分配混入 Host 提交间隔。所有接收缓冲提前分配，并保存逐次结果，避免一次正确的结果掩盖后续调用错误或复用污染。

9c80aee2 的 A5 双 rank 在 `HcclCommInitRootInfo` 的地址解析阶段崩溃，尚未提交 AllReduce 或 Dispatch。已有 core 的 GOT 表确认，HCCL 的旧 ABI `std::regex` 调用了 TileXR 新 ABI `_Scanner` 构造函数和 `_State` 析构函数。相同内部符号名不保证对象布局一致。隔离构建统一 Host/core ABI，保留原失败产物，再验证通信初始化和完整 A/B；不要通过更换系统库、调整加载顺序或关闭正确性检查掩盖问题。
