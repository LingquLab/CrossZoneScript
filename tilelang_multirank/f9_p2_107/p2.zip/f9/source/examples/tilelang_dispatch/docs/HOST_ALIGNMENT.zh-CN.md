# 与原生 TLXR 对齐的 Host 测试流程

用户于 2026-11-06 批准一次性完成此前提出的完整对齐方案。设备算法、输入公式、56/64 AIV 与 F0–F9 打点不变。

## 实施计划与验收边界

1. C++ runner 增加 native 独立运行入口，按原生 DemoBarrier 的 rank0 server/rank1 client 字节握手执行 Host barrier。保留旧父进程诊断入口。
2. 所有预热参数使用稳定独立 GM；预热连续提交，同 stream 最后同步。预热期间不做逐次父进程指令、校验、D2H 或同步。不可直接复用会被覆盖的 params GM。逐次输出/诊断需要保留独立 backing 后再校验；共享窗口仅在双方完成批次后检查，不能宣称逐次观测其状态。
3. 测量参数、输出准备、capture 初始化在测量前 barrier 之前完成。barrier 之后提交一次 Dispatch，结束同步、双方完成 barrier 后校验并导出。
4. Python 启动器每轮创建全新两个 rank 进程；5 轮各20预热+1测量，正确性另行3轮。capture 模式使用 msprof 的设备任务时长为主，ACL event 为辅助，匹配每 rank 的第21个指定 kernel 任务。
5. 新分析器显式接受批量预热的验证范围，复用原有逐核 F0–F9 解析，不伪造旧的逐次验证记录。核验每rank输入SHA，实际跨实现输入对比仍需读取原生归档完成。
6. 本地行为测试、C++14编译检查与独立审查后冻结源码，再恢复Bridge状态、检查设备占用，执行已授权实机流程。原aligned任务状态未知时不重放。

## 结果口径

这是对齐Host调度与采样方式，不声称TL与原生Host逐指令相同；原生包装API仍有参数准备路径。Host barrier只保证准备完成，不保证跨卡同时开始。此次组合修改检验整体流程，不将收益归因于唯一一处改变。未完成设备验证前不声明F5长尾已修复。

## 使用方式

沿用该目录 CMake 构建；默认使用 `generated/`；常规测试显式传 `--pre-allreduce allreduce`（构建配置见 [前置 AllReduce](PRE_ALLREDUCE.zh-CN.md)）。可选 F5 诊断版先按 [F5 诊断](F5_DIAGNOSTIC.zh-CN.md) 生成新目录，再设置 `TL_READY_PROBE=ON`、`TL_GENERATED_ROOT=/tmp/f5-export`。Host 修改不改变生成的设备源码，实际设备 ELF 哈希在构建后记录。

```bash
# 先单独做正确性，3轮新进程，每轮20预热+1正式验证（不采集）。
python3 -m examples.tilelang_dispatch.run_native \
  --install /path/to/install --fixture /path/to/fixture --output /path/to/new-correctness \
  --devices 0 1 --comm-port 39401 --mode correctness --rounds 3 --warmup 20 --pre-allreduce allreduce
# 再采集5轮。要求msprof可用；缺失直接失败，不退化成ACL-only结果。
python3 -m examples.tilelang_dispatch.run_native \
  --install /path/to/install --fixture /path/to/fixture --output /path/to/new-capture \
  --devices 0 1 --comm-port 39402 --mode capture --rounds 5 --warmup 20 --pre-allreduce allreduce
python3 -m examples.tilelang_dispatch.analyze_native \
  --run /path/to/new-capture --fixture /path/to/fixture \
  --generated examples/tilelang_dispatch/generated --output /path/to/analysis.json
```

启动器每轮临近启动检查指定物理卡；任一失败停止后续轮次。只终止本启动器创建的进程组，包含msprof及其子应用，不终止其他用户进程。

## 实际对齐范围与保留差异

- 对齐：每轮独立rank进程、20次连续预热提交、预热末stream同步、测量前rank0 server/rank1 client的一字节arrival/release barrier、1次正式kernel、msprof设备任务计时。
- TL额外准备：为保存逐预热正确性证据，预先分配独立参数/输出/诊断缓冲，预热后批量D2H校验；这些在测量barrier之前完成。原生Host调用仍有自己的参数校验/tiling路径，不能称两者逐指令一致。
- barrier为原生两rank协议的有界loopback特化，不承诺同时launch。连接重试间隔与socket关闭/进程调度仍可影响Host提交差；记录共同Host时钟下的实际barrier退出与launch时刻。
- `rounds.csv` 的预热 `flags_cleared=NOT_OBSERVED`：只在批末检查两个共享bank，未观察每次kernel结束的窗口。每次预热的输出和diagnostics独立保存并复核，任何错误拒绝整批。
- 历史 `host-timeline.csv` 的 `k_received_ns` 在native模式表示barrier退出后的采样点，没有父进程K指令；`native-schedule.json`明示该兼容列含义。分析使用`native-barriers.csv`的实际barrier时刻。
- F0–F9沿用设备原始tick，跨核/跨rank时钟未校准；F5 first-seen仍是本核软件首次观察，不能等同网络到达。

## 验证与经验

旧runner的单份params GM与逐轮同步绑定。改为异步批量预热时，必须预建并保留每次launch的参数存储，否则后轮Host写入可能覆盖尚未读取的参数。仅删除stream sync既不保证正确性，也可能把同步成本藏到H2D里。

本地测试覆盖新进程生命周期、失败停止、msprof任务身份与数量、capture在barrier前完成、预热输出与批末flag的重新验收。C++临时桩头语法检查和本地TCP barrier检查不证明CANN ABI或NPU通信正确性；最终以实际A5构建及3轮正确性、5轮采集结果为准。
