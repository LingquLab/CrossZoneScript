"""Host控制链测试，不运行NPU、不替代算子正确性验证。"""
from pathlib import Path
from types import SimpleNamespace
import json
import tempfile
import unittest
from unittest.mock import patch

from ..hardware_fixture import make_fixture
from ..tools.run_a5 import run


class IntegratedControlTests(unittest.TestCase):
    def execute(self, root, fail=False, placement='after-k'):
        fixture = root / 'fixture'
        make_fixture(fixture)
        install = root / 'install'
        (install / 'bin').mkdir(parents=True)
        kernels = install / 'lib64/tilexr/kernels'
        kernels.mkdir(parents=True)
        for rank in (0, 1):
            (kernels / f'tilelang_dispatch_r{rank}_c{56 if rank == 0 else 64}_profile0.o').write_bytes(b'mock-ELF')
            binary = install / 'bin' / f'tilelang_dispatch_integrated_r{rank}_profile0'
            # A child only emulates the control protocol. It performs no kernel
            # work and cannot produce a device correctness/capture certificate.
            binary.write_text('''#!/usr/bin/env python3
import os, socket, sys
from pathlib import Path
p = Path(sys.argv[3]); p.mkdir()
(p/'placement.txt').write_text(sys.argv[5])
s = socket.socket(fileno=int(sys.argv[4]))
s.sendall(b'R')
with (p/'commands.bin').open('wb', buffering=0) as log:
    while True:
        c = s.recv(1)
        if not c: break
        log.write(c)
        if c == b'K' and ''' + repr(fail and rank == 0) + ''':
            s.sendall(b'E'); sys.exit(1)
        s.sendall(b'D')
        if c == b'Q': break
''')
            binary.chmod(0o750)
        args = SimpleNamespace(fixture=fixture, install=install, output=root/'run',
                               devices=[0, 1], rounds=2, warmup=1, timeout=10,
                               comm_port=39089, mode='correctness', capture_init=placement)
        with patch('examples.tilelang_dispatch.tools.run_a5.check_idle'), \
                patch.dict('os.environ', {'ASCEND_RT_VISIBLE_DEVICES': ''}):
            return run(args)

    def test_one_launch_per_iteration_on_both_ranks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            result = self.execute(root)
            self.assertEqual(result['rank_exit_codes'], [0, 0])
            self.assertEqual(result['measured_iterations'], [1, 3])
            for rank in (0, 1):
                self.assertEqual((root/f'run/rank{rank}/commands.bin').read_bytes(),
                                 b'NKVCKVNKVCKVQ')
            run_info = json.loads((root/'run/run.json').read_text())
            self.assertEqual(run_info['observation'], 'integrated single-kernel dispatch')

    def test_before_k_forwarding_and_common_clock_k_send(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            result = self.execute(root, placement='before-k')
            for rank in (0, 1):
                self.assertEqual((root/f'run/rank{rank}/placement.txt').read_text(), 'before-k')
            for row in result['iterations']:
                self.assertEqual([x['rank'] for x in row['k_sends']], [0, 1])
                self.assertTrue(all(x['before_ns'] <= x['after_ns'] for x in row['k_sends']))

    def test_failed_kernel_stops_before_validation_or_next_round(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with self.assertRaises(RuntimeError):
                self.execute(root, fail=True)
            self.assertFalse((root/'run/summary.json').exists())
            self.assertEqual(json.loads((root/'run/failure.json').read_text())['completed_iterations'], [])
            for rank in (0, 1):
                self.assertEqual((root/f'run/rank{rank}/commands.bin').read_bytes(), b'NK')


if __name__ == '__main__':
    unittest.main()
