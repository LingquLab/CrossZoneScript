"""Dispatch 离线测试；从仓库根目录通过 unittest 模块入口运行。"""
