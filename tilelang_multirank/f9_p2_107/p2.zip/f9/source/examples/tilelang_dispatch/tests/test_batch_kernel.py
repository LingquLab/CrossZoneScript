"""Execute the real TL data-path macros as serialized C on CPU.

Tests arithmetic, offsets, complete route coverage and round reuse against an
independent token/expert oracle. MTE overlap, scheduling, and performance still
require the A5 correctness/capture rounds; CPU execution is not device evidence.
"""
import importlib.util
from pathlib import Path
import tempfile
import unittest


def compile_cpu(primitive, directory, name):
    """[AI] 执行真实TL宏的串行分支；不模拟设备DMA/跨流水时序。"""
    import tilelang as tl
    def without_regions(node):
        if isinstance(node, tl.tvm.tir.Block):
            return tl.tvm.tir.Block(node.iter_vars, [], [], node.name_hint, node.body,
                node.init, node.alloc_buffers, node.match_buffers, node.annotations)
    primitive = primitive.with_body(tl.tvm.tir.stmt_functor.ir_transform(primitive.body, None, without_regions))
    primitive = tl.tvm.script.from_source(primitive.script().replace('"local.var"', '"local"')
                                         .replace('"shared.ub"', '"local"'))
    def unsigned_div(node):
        if isinstance(node, tl.tvm.tir.For) and not tl.tvm.arith.Analyzer().can_prove(node.min == 0):
            body = tl.tvm.tir.stmt_functor.substitute(node.body, {node.loop_var: node.loop_var + node.min})
            return tl.tvm.tir.For(node.loop_var, 0, node.extent, node.kind, body,
                                  node.thread_binding, node.annotations)
        if isinstance(node, tl.tvm.tir.FloorDiv) and node.dtype == 'uint64':
            return tl.tvm.tir.truncdiv(node.a, node.b)
        if isinstance(node, tl.tvm.tir.FloorMod) and node.dtype == 'uint64':
            return tl.tvm.tir.truncmod(node.a, node.b)
    primitive = primitive.with_body(tl.tvm.tir.stmt_functor.ir_transform(primitive.body, None, unsigned_div))
    lib = Path(directory) / (name + '.so')
    tl.tvm.build(primitive, target='c', name=name).export_library(str(lib))
    return tl.tvm.runtime.load_module(str(lib))


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class BatchKernelTests(unittest.TestCase):
    def run_case(self, world, experts, tokens, cores_by_rank, route_mode='mixed'):
        """[AI] 三阶段执行真实TL宏；阶段切换模拟完整发布后的串行可见性。

        CPU peers使用uint32等宽虚拟窗口，不把Host地址当NPU地址。此检查
        覆盖数据内容/协议清理；不证明DMA重叠、跨核调度或跨rank硬件时钟。
        """
        import numpy as np
        import tilelang as tl
        import tilelang.language as T
        from ..contract import Config, STATE_WORDS, CUMSUM_WORD, GATE_WORD, workspace_stride_words
        from ..kernel import (layout, send_round, count_split, status_split, receive_split,
                              count_publish, pack_send, count_prefix, receive_output, receive_ub_plan)
        local = experts // world
        stride = workspace_stride_words(experts)
        payload_words = experts * tokens * 256
        slot_words = max(STATE_WORDS, payload_words)
        heap_words = 2 * world * slot_words
        implementations = {}
        for cores in sorted(set(cores_by_rank)):
            receive_capacity = receive_ub_plan(tokens, cores, world, experts)['batch_capacity']
            @T.prim_func
            def phase(params: T.Tensor((16,), 'uint64'), x: T.Tensor((tokens * 128,), 'uint32'),
                      ids: T.Tensor((tokens * 2,), 'int32'),
                      peers: T.Tensor((heap_words,), 'uint32'),
                      state: T.Tensor((STATE_WORDS,), 'uint32'),
                      payload: T.Tensor((payload_words,), 'uint32'),
                      output: T.Tensor((experts * tokens * 128,), 'uint32'),
                      assist: T.Tensor((experts * tokens * 3,), 'int32'),
                      counts: T.Tensor((experts,), 'int32'), nums_out: T.Tensor((local,), 'int64'),
                      diagnostics: T.Tensor((cores * 16,), 'int32'), rank: T.int32, step: T.int32):
                for core in T.serial(cores):
                    with T.block('core'):
                        p = T.alloc_buffer((16,), 'uint64', scope='local')
                        o = T.alloc_buffer((64,), 'uint64', scope='local')
                        route = T.alloc_buffer((tokens * 2,), 'int32', scope='local')
                        amounts = T.alloc_buffer((experts,), 'uint32', scope='local')
                        record = T.alloc_buffer((256,), 'uint32', scope='local')
                        feature = T.alloc_buffer((128,), 'uint32', scope='local')
                        records = T.alloc_buffer((experts * 8,), 'uint32', scope='local')
                        prefix = T.alloc_buffer((stride,), 'int32', scope='local')
                        small = T.alloc_buffer((stride,), 'uint32', scope='local')
                        nums = T.alloc_buffer((local,), 'int64', scope='local')
                        diag = T.alloc_buffer((16,), 'int32', scope='local')
                        for i in T.serial(16):
                            p[i] = params[i]
                            diag[i] = diagnostics[core * 16 + i]
                        for i in T.serial(tokens * 2):
                            route[i] = ids[i]
                        layout(p, o)
                        send_round(p, o)
                        count_split(p, o, core)
                        if step == 0:
                            count_publish(route, peers, rank, small, amounts, diag, o,
                                          tokens * 2, True, world, experts)
                            if core < cores - 1:
                                pack_send(x, route, peers, record, feature, core, rank, diag, o,
                                          tokens * 2, True, world, experts)
                        elif step == 1:
                            if core == cores - 1:
                                status_split(p, o, core)
                                count_prefix(state, counts, core, cores, 100, records, prefix,
                                             small, diag, o, True, 3, experts, stride)
                        else:
                            receive_split(p, o, core)
                            receive_output(state, payload, output, assist, nums_out, core, rank,
                                           cores, 100, small, prefix, nums, diag, o, True,
                                           receive_capacity, world, experts, stride)
                        for i in T.serial(16):
                            diagnostics[core * 16 + i] = diag[i]
            with tempfile.TemporaryDirectory() as directory:
                implementations[cores] = compile_cpu(phase, directory, 'phase')

        if route_mode == 'balanced-p2':
            ids = [np.array([(t % 2, t % 2 + 2) for t in range(tokens)], dtype=np.int32)
                   for _ in range(world)]
        elif route_mode == 'skew':
            ids = [np.tile(np.array([0, 1], dtype=np.int32), (tokens, 1)) for _ in range(world)]
        else:
            # [AI] 来源rank的路由不同；奇数world与L!=2均不退化为两rank模板。
            ids = [np.array([((source + t) % experts, (source + t + local) % experts)
                             for t in range(tokens)], dtype=np.int32) for source in range(world)]
        xs = [np.array([[0x3f80 + source * 0x80 + t * 0x10 + h % 32 for h in range(256)]
                        for t in range(tokens)], dtype=np.uint16) for source in range(world)]
        goldens = []
        for rank in range(world):
            features, triples, counts, expert_nums = [], [], [], []
            # [AI] Golden直接枚举专家/来源/token，不调用设备bucket/接收分工公式。
            for expert in range(rank * local, (rank + 1) * local):
                before = len(triples) // 3
                for source in range(world):
                    for token in range(tokens):
                        for choice in range(2):
                            if ids[source][token, choice] == expert:
                                features.extend(xs[source][token])
                                triples.extend((source, token, choice))
                    counts.append(len(triples) // 3)
                expert_nums.append(len(triples) // 3 - before)
            goldens.append((np.array(features, dtype=np.uint16).view(np.uint32),
                            np.array(triples, dtype=np.int32), np.array(counts, dtype=np.int32),
                            np.array(expert_nums, dtype=np.int64)))
        array = tl.tvm.nd.array
        heap = array(np.zeros(heap_words, dtype=np.uint32))
        # [AI] 刻意复用同一虚拟通信窗口，旧workspace/计数值不清零，检验READY消费与复用。
        # 实际双bank物理地址与并发可见性仍须A5验证。
        for magic in (1, 2, 3):
            args = []
            for rank, cores in enumerate(cores_by_rank):
                params = Config(tokens=tokens, world_size=world, experts=experts,
                                rank=rank, block_dim=cores, magic=magic).words()
                args.append([array(np.array(params, dtype=np.uint64)),
                    array(xs[rank].reshape(-1).view(np.uint32)), array(ids[rank].reshape(-1)), heap,
                    array(np.zeros(STATE_WORDS, dtype=np.uint32)),
                    array(np.zeros(payload_words, dtype=np.uint32)),
                    array(np.full(experts * tokens * 128, 0xa5a5a5a5, dtype=np.uint32)),
                    array(np.full(experts * tokens * 3, -1515870811, dtype=np.int32)),
                    array(np.zeros(experts, dtype=np.int32)), array(np.zeros(local, dtype=np.int64)),
                    array(np.zeros(cores * 16, dtype=np.int32))])
            for step in range(3):
                for rank, cores in enumerate(cores_by_rank):
                    if step:
                        shared = heap.numpy()
                        begin = rank * 2 * slot_words
                        args[rank][4].copyfrom(shared[begin:begin + STATE_WORDS])
                        begin += slot_words
                        args[rank][5].copyfrom(shared[begin:begin + payload_words])
                    implementations[cores]['phase'](*args[rank], rank, step)
                    if step:
                        shared = heap.numpy()
                        begin = rank * 2 * slot_words
                        shared[begin:begin + STATE_WORDS] = args[rank][4].numpy()
                        begin += slot_words
                        shared[begin:begin + payload_words] = args[rank][5].numpy()
                        heap.copyfrom(shared)
            for rank, cores in enumerate(cores_by_rank):
                actual = args[rank]
                want_x, want_assist, want_counts, want_nums = goldens[rank]
                self.assertFalse(actual[10].numpy().reshape(cores, 16)[:, 0].any(),
                                 f"P{world}/E{experts}/rank{rank}: {actual[10].numpy().reshape(cores, 16)}")
                np.testing.assert_array_equal(actual[6].numpy()[:len(want_x)], want_x)
                np.testing.assert_array_equal(actual[6].numpy()[len(want_x):], 0xa5a5a5a5)
                np.testing.assert_array_equal(actual[7].numpy()[:len(want_assist)], want_assist)
                np.testing.assert_array_equal(actual[7].numpy()[len(want_assist):], -1515870811)
                np.testing.assert_array_equal(actual[8].numpy(), want_counts)
                np.testing.assert_array_equal(actual[9].numpy(), want_nums)
                state = actual[4].numpy()
                np.testing.assert_array_equal(state[:experts * 8:8], 0)
                np.testing.assert_array_equal(state[CUMSUM_WORD:CUMSUM_WORD + 8], 0)
                np.testing.assert_array_equal(state[GATE_WORD:GATE_WORD + cores * 8], 0)
                payload = actual[5].numpy().reshape(experts, tokens, 2, 128)
                np.testing.assert_array_equal(payload[:, :, :, 120:128], 0)
                workspace = 786432 // 4 - cores * stride
                for core in range(cores):
                    np.testing.assert_array_equal(state[workspace + core * stride:workspace + core * stride + experts], want_counts)
                    np.testing.assert_array_equal(state[workspace + core * stride + experts:workspace + (core + 1) * stride], 0)
                # [AI] 工作量独立从golden槽差及静态分配规则计算，不要求均衡T/2。
                receive_counts = np.diff(np.concatenate((np.array([0], dtype=np.int32), want_counts)))
                diagnostics = actual[10].numpy().reshape(cores, 16)
                for core in range(cores):
                    workers = cores if tokens < 48 else 1
                    count_worker = core if tokens < 48 else 0
                    count_tasks = (experts // workers + int(count_worker < experts % workers)
                                   if tokens < 48 or core == cores - 1 else 0)
                    sent = len(range(core, tokens * 2, cores - 1)) if core < cores - 1 else 0
                    begin = experts // cores * core + min(core, experts % cores)
                    tasks = experts // cores + int(core < experts % cores)
                    received = int(receive_counts[begin:begin + tasks].sum())
                    expected = [0, int(core == cores - 1), 1, received, count_tasks, sent,
                                experts if core == cores - 1 else 0, received, tasks,
                                sent * 1024, received * 1024]
                    np.testing.assert_array_equal(diagnostics[core, :11], expected)
                    np.testing.assert_array_equal(diagnostics[core, 11:], 0)

    def test_complete_data_path_and_reuse(self):
        for tokens in (4, 16, 64, 256):
            with self.subTest(tokens=tokens):
                self.run_case(2, 4, tokens, (56, 64), 'balanced-p2')

    def test_odd_world_and_one_local_expert(self):
        self.run_case(3, 3, 4, (3,) * 3)

    def test_four_ranks_multiple_slots_per_core(self):
        self.run_case(4, 8, 16, (3,) * 4)

    def test_five_ranks_skew_empty_outputs_and_three_local_experts(self):
        self.run_case(5, 15, 4, (4,) * 5, 'skew')

    def test_six_ranks_multiple_slots_per_core(self):
        self.run_case(6, 12, 4, (4,) * 6)

    def test_eight_ranks_three_local_experts(self):
        self.run_case(8, 24, 4, (5,) * 8)

    def test_three_batches_large_skew_and_window_reuse(self):
        self.run_case(3, 3, 256, (3,) * 3, 'skew')


if __name__ == '__main__':
    unittest.main()
