"""Batch gate, fail-stop control and lossless per-round reporting; no NPU."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from ..tools.run_batch import run_batch, write_tables


class BatchControlTests(unittest.TestCase):
    def test_gate_and_occupancy_failure_stop_before_next_case(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            release = root / 'release.json'
            release.write_text(json.dumps({'status': 'NOT_RELEASED'}))
            args = SimpleNamespace(mode='correctness', rounds=3, warmup=20, devices=[0, 1],
                start_release=release, start_release_sha256=hashlib.sha256(release.read_bytes()).hexdigest(),
                cases_root=root/'cases', suite_root=root/'suite', output=root/'run', comm_port=39090)
            with patch('examples.tilelang_dispatch.tools.run_batch.run') as device:
                with self.assertRaisesRegex(ValueError, 'released'):
                    run_batch(args)
                device.assert_not_called()
            release.write_text(json.dumps({'status': 'READY_AFTER_NATIVE_FORMAL_DELIVERY'}))
            args.start_release_sha256 = hashlib.sha256(release.read_bytes()).hexdigest()
            with patch('examples.tilelang_dispatch.tools.run_batch.batch_identity', return_value={}), \
                    patch('examples.tilelang_dispatch.tools.run_batch.run',
                          side_effect=RuntimeError('busy or unknown occupancy')) as device:
                with self.assertRaisesRegex(RuntimeError, 'occupancy'):
                    run_batch(args)
                self.assertEqual(device.call_count, 1)
                self.assertEqual(device.call_args.args[0].fixture.name, 'bs16')
                failure = json.loads((args.output / 'failure.json').read_text())
                self.assertEqual(failure['completed'], [])
                self.assertFalse((args.output / 'bs64/round1').exists())

    def test_tables_preserve_long_tail_and_maximum_ties(self):
        metric = dict(mean_ticks=6, max_ticks=9, per_core_sum_ticks={0: 9, 1: 9, 2: 0},
                      participating_cores=3, active_workload_cores=2, workload={'received_records': 8})
        captures = [dict(capture_id=str(number), **{field: {'F6': copy.deepcopy(metric)}
                    for field in ('modules', 'functions', 'stages')}) for number in (1, 2)]
        evidence = [dict(device_task_us=value, F5_wait_ticks=10,
                        pre_allreduce=dict(dispatch_event_us=value+1, pre_dispatch_event_us=100,
                                           segment_event_us=value+101)) for value in (20, 200)]
        summary = {'cases': {'bs64': {'rank_results': [dict(rank=0, cores=56,
                    captures=captures, round_evidence=evidence)]}}}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            write_tables(summary, root)
            timing = json.loads((root/'timing-rounds.json').read_text())
            self.assertEqual([row['device_task_us'] for row in timing], [20, 200])
            self.assertEqual(timing[1]['T'], 64)
            with (root/'substage-rounds.csv').open() as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(json.loads(rows[0]['max_core_ids']), [0, 1])
            self.assertEqual(json.loads(rows[0]['workload']), {'received_records': 8})
            self.assertEqual([row['round'] for row in rows], ['1', '2'])


class MultiRankRunConfigurationTests(unittest.TestCase):
    def test_config_uses_fixture_world_and_requires_physical_mapping(self):
        from ..run_native import rank_configuration
        case = dict(shape=dict(world=3, experts=6))
        self.assertEqual(rank_configuration(case, [5,2,4], [32,40,48]), (3, [32,40,48]))
        for devices, cores, message in (([0,1], [32,32], 'device'),
                                         ([0,0,1], [32]*3, 'device'),
                                         ([0,1,2], None, '--cores'),
                                         ([0,1,2], [32,32], 'core count')):
            with self.subTest(devices=devices, cores=cores), self.assertRaisesRegex(ValueError, message):
                rank_configuration(case, devices, cores)
        self.assertEqual(rank_configuration(dict(shape=dict(world=2, experts=4)), [0,1]),
                         (2,[56,64]))

    def test_run_round_launches_and_profiles_every_configured_rank(self):
        from ..run_native import run_round
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            args = SimpleNamespace(devices=[5,2,4], cores=[32,40,48], fixture=root/'fixture',
                                   warmup=20, comm_port=39090, timeout=1, pre_allreduce='allreduce')
            processes = [Mock(returncode=0) for _ in range(3)]
            for process in processes:
                process.poll.return_value = 0
            with patch('examples.tilelang_dispatch.run_native.check_idle') as occupancy, \
                 patch('examples.tilelang_dispatch.run_native.finish_groups'), \
                 patch('examples.tilelang_dispatch.run_native.subprocess.Popen', side_effect=processes) as spawn, \
                 patch('examples.tilelang_dispatch.run_native.profiler_task', return_value={}) as profiler:
                result = run_round(args, root/'round', [root/f'binary{r}' for r in range(3)], 'msprof')
            self.assertEqual(result['status'],'PASS')
            self.assertEqual(spawn.call_count,3)
            occupancy.assert_called_once_with([5,2,4],root/'round')
            self.assertEqual([call.args[1] for call in profiler.call_args_list],
                             ['tilexr_tl_dispatch_r0_c32','tilexr_tl_dispatch_r1_c40','tilexr_tl_dispatch_r2_c48'])
            commands = json.loads((root/'round/commands.json').read_text())
            self.assertEqual([row['rank'] for row in commands],[0,1,2])
            self.assertTrue(all('allreduce' in row['argv'][1] for row in commands))

    def test_aggregate_preserves_every_rank_and_rejects_missing_rank(self):
        from ..tools.run_pre_allreduce import aggregate
        pairs = [dict(rank=r, cores=32, pre_allreduce=dict(segment_event_us=100+r,
                       dispatch_event_us=10+r, pre_dispatch_event_us=90), device_task_us=10+r,
                       F5_wait_ticks=100*r) for r in range(3)]
        analysis = dict(rank_results=[dict(rank=r,cores=32,captures=[]) for r in range(3)],
                        pairs=[dict(ranks=pairs, launch_rank1_minus_rank0_ns=30,
                                    launch_rank_offsets_from_rank0_ns={'0':0,'1':30,'2':-10})])
        result = aggregate('allreduce',[analysis])
        self.assertEqual(len(result['rank_results']),3)
        self.assertEqual(result['rank_results'][2]['device_task_us']['per_round'],[12])
        self.assertEqual(result['launch_rank_offsets_from_rank0_ns'][0]['2'],-10)
        missing = copy.deepcopy(analysis)
        missing['rank_results'].pop(1)
        with self.assertRaisesRegex(ValueError,'Missing or duplicate'):
            aggregate('allreduce',[missing])


if __name__ == '__main__':
    unittest.main()
