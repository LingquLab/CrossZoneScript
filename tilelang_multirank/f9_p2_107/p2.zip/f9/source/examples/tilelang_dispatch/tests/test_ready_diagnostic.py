"""F5有限探针与时间线验证；不替代CANN/NPU验证。"""
from pathlib import Path
import json
import struct
import subprocess
import tempfile
import unittest
from ..tools.diagnose_f5 import diagnose, validate_probe, validate_timeline


class ReadyProbeTests(unittest.TestCase):
    def test_actual_cpp_probe_first_observation_and_overflow(self):
        source = r'''
#include "ready_probe.h"
#include <cassert>
using TileLangDiagnostic::ReadyProbe;
int main() {
  ReadyProbe p(100);
  p.Observe(0,100); assert(p.firstMask==0 && p.first[0]==-1);
  assert(p.HasNew(5)); p.Observe(5,110);
  assert(p.first[0]==10 && p.first[2]==10 && p.first[1]==-1);
  assert(!p.HasNew(5)); p.Observe(5,999);
  assert(p.first[0]==10);
  p.Observe(15,120); assert(p.seen==15 && p.first[1]==20 && p.first[3]==20);
  ReadyProbe simultaneous(40); simultaneous.Observe(15,42);
  assert(simultaneous.firstMask==15 && simultaneous.first[3]==2);
  ReadyProbe boundary(10); boundary.Observe(1,10+UINT64_C(2147483647));
  assert(boundary.first[0]==2147483647);
  boundary.Observe(3,10+UINT64_C(2147483648));
  assert(boundary.first[1]==-2 && !boundary.HasNew(3));
  ReadyProbe backwards(100); backwards.Observe(1,99); assert(backwards.first[0]==-2);
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); cpp = root/'test.cpp'; cpp.write_text(source)
            subprocess.run(['g++', '-std=c++14', '-Wall', '-Wextra', '-Werror', '-I',
                            str(Path(__file__).resolve().parents[1]), str(cpp), '-o', str(root/'test')], check=True)
            subprocess.run([str(root/'test')], check=True)

    def test_first_poll_and_stage_bounds(self):
        validate_probe([10,30,10,30], 5, 40)
        for first, mask, end in (([-1,2,2,2],0,10), ([-2,2,2,2],0,10),
                                ([1,2,3,4],5,10), ([1,1,2,12],3,10)):
            with self.assertRaises(ValueError): validate_probe(first,mask,end)

    def test_diagnostic_evidence_round_trip_and_slot_ownership(self):
        from .test_analyze_a5 import AnalyzeIntegratedTests, write_csv
        fixture = AnalyzeIntegratedTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        def update(path, **changes):
            data = json.loads(path.read_text()); data.update(changes)
            path.write_text(json.dumps(data))
        update(fixture.run/'run.json', capture_placement='after-k', binaries={'host':'abc'},
               device_binaries={'elf':'def'})
        update(fixture.run/'summary.json', iterations=[{'iteration':0,'round':0,'measured':True,
            'k_sends':[{'rank':r,'before_ns':3,'after_ns':7} for r in (0,1)]}])
        for rank, cores in ((0,56),(1,64)):
            root = fixture.run/f'rank{rank}'
            update(root/'summary.json', ready_probe=True, capture_placement='after-k')
            update(fixture.generated/f'rank{rank}/dispatch.ticks.json', count_ready_probe='first_seen.v1')
            path = root/'round0.dispatch.diagnostics.bin'
            data = bytearray(path.read_bytes())
            struct.pack_into('<5i', data, ((cores-1)*16+11)*4, 1,5,1,5,5)
            path.write_bytes(data)
            from uuid import UUID
            write_csv(root/'host-timeline.csv', [dict(round=0,magic=1,rank=rank,
                placement='after-k',clock='CLOCK_MONOTONIC',prepare_received_ns=1,
                ready_reply_before_ns=2,k_received_ns=5,capture_begin_ns=6,capture_end_ns=10,
                event_start_enqueue_ns=11,launch_before_ns=12,launch_after_ns=13,
                sync_end_ns=20,capture_id=str(UUID(int=1+rank)))])
        result = diagnose(fixture.run, fixture.fixture, fixture.generated)
        slots = result['pairs'][0]['ranks'][1]['slots']
        self.assertEqual([(x['producer_rank'], x['producer_core']) for x in slots],
                         [(0,2),(1,2),(0,3),(1,3)])
        self.assertEqual(result['pairs'][0]['ranks'][0]['last_slots'], [1,3])
        path = fixture.run/'rank1/round0.dispatch.diagnostics.bin'
        data = bytearray(path.read_bytes()); struct.pack_into('<i',data,((64-1)*16+11)*4,-2)
        path.write_bytes(data)
        with self.assertRaisesRegex(ValueError, 'Ready probe'):
            diagnose(fixture.run, fixture.fixture, fixture.generated)

    def test_timeline_placement_rejects_mislabelled_ab(self):
        row = dict(clock='CLOCK_MONOTONIC', placement='after-k', prepare_received_ns=1,
                   ready_reply_before_ns=2, k_received_ns=5, capture_begin_ns=6,
                   capture_end_ns=10, event_start_enqueue_ns=11, launch_before_ns=12,
                   launch_after_ns=13, sync_end_ns=20)
        sends = dict(before_ns=3, after_ns=7) # child can receive before send returns
        validate_timeline(row,sends,'after-k',True)
        with self.assertRaises(ValueError): validate_timeline(row,sends,'before-k',True)
        row.update(placement='before-k', capture_begin_ns=1, capture_end_ns=2)
        validate_timeline(row,sends,'before-k',True)
        row.update(capture_begin_ns=0,capture_end_ns=0)
        validate_timeline(row,sends,'before-k',False)


if __name__ == '__main__': unittest.main()
