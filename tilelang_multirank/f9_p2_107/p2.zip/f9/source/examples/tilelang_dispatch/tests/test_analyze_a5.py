"""Synthetic acceptance evidence; these tests are not hardware performance measurements."""
import csv
import json
from pathlib import Path
import struct
import tempfile
import unittest
from uuid import UUID

from ..analyze_a5 import analyze, aggregate, check_diagnostics, compact_summary, equal_round_summary, summarize_capture
from ..hardware_fixture import make_fixture
from ..contract import Config
from tilexr_profiling.records import FILE_HEADER, STREAM_HEADER, RECORD, load_record_files


# Fixed expected stage contract, independent of the implementation's participation helper.
PAIRS = [('harness.diag_init',1000), ('harness.params_init',1010), ('F0.layout',10),
         ('F1.route_read',100), ('F0.send_round',20), ('F0.count_split',30),
         ('F2.expert_count',200), ('F3.count_publish',300), ('F4.pack_send',400),
         ('F0.status_split',40), ('F5.wait_count',500), ('F5.consume_clear',510),
         ('F6.prefix_publish',600), ('role_pipeline_barrier',1100), ('F0.receive_split',50),
         ('F7.layout_wait',700), ('F7.gate_clear',710), ('F7.receive_plan',720),
         ('F8.payload_loop',800), ('F9.payload_clear',900), ('F9.final_fence',910),
         ('harness.diag_write',1030)]


def write_json(path, value):
    path.write_text(json.dumps(value))


def write_csv(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def mapping(rank, cores, f6_children=False):
    events = [{'id':1, 'slot':0}]
    stages = [{'name':'module.whole', 'begin':1, 'end':2}]
    for name, begin in PAIRS:
        ids = [begin, begin+1]
        if begin == 600 and f6_children:
            ids = [600,620,621,630,631,640,641,601]
            stages.extend({'name':name, 'begin':event, 'end':event+1} for name,event in
                          [('F6.prepare',620),('F6.workspace_publish',630),('F6.gate_publish',640)])
        slot_start = len(events)
        events.extend({'id':event, 'slot':slot_start+index} for index,event in enumerate(ids))
        stages.append({'name':name, 'begin':begin, 'end':begin+1})
    events.append({'id':2, 'slot':len(events)})
    return {'schema':'tilelang_dispatch_ticks.v1', 'cycles_per_us':None,
            'module':'dispatch', 'rank':rank, 'cores':cores,
            'record_capacity':64, 'events':events, 'stages':stages}


def synthetic_records(rank, cores, omit=None, missing_lane=None, overflow=None, capture_id=None,
                      f6_children=False, tokens=4, abi_version=1, f4_coordinator=False):
    blocks = []
    send_cores = cores - 1 if abi_version == 2 else min(tokens * 2, cores - 1)
    for core in range(cores):
        if core == missing_lane:
            continue
        ids = [1]
        for name, begin in PAIRS:
            if begin in (40,500,510,600) and core != cores-1:
                continue
            if begin in (200,300,720,800,900) and core >= 4:
                continue
            if begin == 400 and core >= send_cores and not f4_coordinator:
                continue
            ids += [600,620,621,630,631,640,641,601] if begin == 600 and f6_children else [begin,begin+1]
        ids += [2]
        if omit and core == omit[0]:
            ids = [event for event in ids if event not in omit[1]]
        records = b''.join(RECORD.pack(100+i*10, event, 0) for i,event in enumerate(ids))
        blocks.append(STREAM_HEADER.pack((rank << 16) | core, len(ids), 0, 3 if core == overflow else 1,
                                         STREAM_HEADER.size+len(records))+records)
    body = b''.join(blocks)
    return FILE_HEADER.pack(b'TXRPRF1\0',1,0,48,16,24,1,0,len(blocks),
                            UUID(int=1+rank if capture_id is None else capture_id).bytes,48+len(body))+body


def diagnostic_bytes(cores, tokens=4):
    values = []
    for core in range(cores):
        sent = len(range(core, tokens*2, cores-1)) if core < cores-1 else 0
        received = (tokens//2)*int(core < 4)
        values.extend((0, int(core == cores-1), 1, received,
                       int(core < 4), sent, 4*int(core == cores-1),
                       received, int(core < 4), 1024*sent,
                       1024*received, 0,0,0,0,0))
    return struct.pack('<'+'i'*len(values), *values)


class AnalyzeIntegratedTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        self.fixture, self.run, self.generated = root/'fixture', root/'run', root/'generated'
        make_fixture(self.fixture)
        self.run.mkdir()
        self.generated.mkdir()
        write_json(self.run/'run.json', {'schema':'tilelang_dispatch_integrated_run.v1',
            'observation':'integrated single-kernel dispatch', 'mode':'capture',
            'rounds':1, 'warmup':0, 'devices':[0,1]})
        write_json(self.run/'summary.json', {'status':'PASS', 'rank_exit_codes':[0,0],
            'measured_iterations':[0], 'iterations':[{'iteration':0,'round':0,'measured':True}]})
        for rank, cores in ((0,56),(1,64)):
            directory = self.run/f'rank{rank}'
            directory.mkdir()
            generated = self.generated/f'rank{rank}'
            generated.mkdir()
            write_json(generated/'dispatch.ticks.json', mapping(rank,cores))
            write_json(directory/'summary.json', {'observation':'integrated',
                'operator_correctness':'PASS', 'flags_cleared':'PASS', 'rank':rank,
                'device':rank, 'cores':cores, 'profiling':True, 'verified_iterations':1,
                'iterations':1, 'measured_iterations':1, 'capture_count':1})
            write_csv(directory/'rounds.csv', [{'round':0,'magic':1,'measured':1,'profiling':1,
                'operator_correctness':'PASS','flags_cleared':'PASS'}])
            write_csv(directory/'timing.csv', [{'round':0,'magic':1,'device':rank,'rank':rank,
                'aiv_count':cores,'profiling':1,'module':'dispatch','acl_event_us':1.25,
                'host_launch_sync_us':25,'capture_id':str(UUID(int=1+rank)),
                'operator_correctness':'PASS'}])
            (directory/'round0.params.bin').write_bytes(struct.pack('<16Q',*Config(rank=rank,block_dim=cores).words()))
            for name,length in (('output',8192),('assist',192),('counts',16),('expert_nums',16)):
                expected = (self.fixture/f'rank{rank}/expected_{name}.bin').read_bytes()
                (directory/f'round0.actual_{name}.bin').write_bytes(expected+b'\xa5'*(length-len(expected)))
            (directory/'round0.state.bin').write_bytes(bytes(1<<20))
            (directory/'round0.payload.bin').write_bytes(bytes(16384))
            (directory/'round0.dispatch.diagnostics.bin').write_bytes(diagnostic_bytes(cores))
            (directory/'round0.dispatch.records').write_bytes(synthetic_records(rank,cores))

    def result(self):
        return analyze(self.run,self.fixture,self.generated)

    def test_abi2_idle_send_roles_have_intervals_but_no_workload(self):
        for rank, cores in ((0,56),(1,64)):
            with self.subTest(rank=rank):
                m = mapping(rank, cores)
                m.update(abi_version=2, world_size=2, experts=4, local_experts=2,
                         workspace_stride_words=8, tokens_per_rank=16)
                root = self.run/f'rank{rank}'
                diag_path, record_path = root/'t16.diagnostics.bin', root/'t16.records'
                diag_path.write_bytes(diagnostic_bytes(cores, tokens=16))
                diagnostics = check_diagnostics(diag_path, cores, tokens=16)

                def capture(**kwargs):
                    record_path.write_bytes(synthetic_records(rank, cores, tokens=16, abi_version=2, **kwargs))
                    return summarize_capture(load_record_files([record_path])[0], m, diagnostics)

                result = capture()['functions']['F4']
                self.assertEqual(result['participating_core_ids'], list(range(cores-1)))
                self.assertEqual(result['active_workload_core_ids'], list(range(32)))
                self.assertEqual(result['workload'], dict(sent_records=32, sent_wire_bytes=32768))
                self.assertEqual(result['mean_ticks'], 10)
                self.assertEqual(result['all_launch_core_normalized_ticks'], 10*(cores-1)/cores)
                for kwargs, error in ((dict(omit=(32,{400,401})), 'missing or unexpected'),
                                      (dict(omit=(32,{401})), 'Unpaired interval'),
                                      (dict(f4_coordinator=True), 'missing or unexpected')):
                    with self.subTest(kwargs=kwargs), self.assertRaisesRegex(ValueError, error):
                        capture(**kwargs)

    def test_historical_mapping_rejects_extra_idle_send_interval(self):
        path = self.run/'rank0/round0.dispatch.records'
        path.write_bytes(synthetic_records(0,56,abi_version=2))
        with self.assertRaisesRegex(ValueError, 'missing or unexpected: F4.pack_send'):
            self.result()

    def test_actual_same_core_sum_and_separate_work_participation(self):
        result = self.result()
        self.assertIsNone(result['cycles_per_us'])
        rank = result['rank_results'][0]
        self.assertEqual(rank['acl_event_us']['mean'],1.25)
        prepare = rank['modules']['prepare']['per_round'][0]
        self.assertEqual(prepare['max_ticks'],60)
        self.assertEqual(prepare['mean_ticks'],(55*50+60)/56)
        receive = rank['modules']['receive_output']['per_round'][0]
        self.assertEqual(receive['participating_cores'],56)
        self.assertEqual(receive['active_workload_cores'],4)
        self.assertEqual(receive['workload']['received_records'],8)
        self.assertEqual(receive['workload']['received_wire_bytes'],8192)
        self.assertEqual(rank['functions']['F5']['mean_ticks'],20)
        self.assertEqual(rank['functions']['F0']['per_round'][0]['per_core_sum_ticks'][55],50)
        compact = compact_summary(result)
        self.assertNotIn('captures',compact['rank_results'][0])
        self.assertIn('workload',compact['rank_results'][0]['modules']['receive_output']['per_round'][0])

    def test_f6_children_reported_without_double_counting_parent(self):
        for rank,cores in ((0,56),(1,64)):
            write_json(self.generated/f'rank{rank}/dispatch.ticks.json', mapping(rank,cores,True))
            (self.run/f'rank{rank}/round0.dispatch.records').write_bytes(
                synthetic_records(rank,cores,f6_children=True))
        result = self.result()['rank_results'][0]
        self.assertEqual(result['functions']['F6']['mean_ticks'],70)
        self.assertEqual(result['modules']['count_prefix']['mean_ticks'],90)
        capture = result['captures'][0]
        for name in ('F6.prepare','F6.workspace_publish','F6.gate_publish'):
            self.assertEqual(capture['stages'][name]['participating_core_ids'],[55])
            self.assertEqual(capture['stages'][name]['mean_ticks'],10)
        path = self.run/'rank0/round0.dispatch.records'
        path.write_bytes(synthetic_records(0,56,omit=(55,{630,631}),f6_children=True))
        with self.assertRaisesRegex(ValueError,'missing or unexpected'):
            self.result()

    def test_partial_f6_child_mapping_rejected(self):
        value = mapping(0,56,True)
        value['stages'] = [s for s in value['stages'] if s['name'] != 'F6.gate_publish']
        write_json(self.generated/'rank0/dispatch.ticks.json',value)
        with self.assertRaisesRegex(ValueError,'Incomplete F6'):
            self.result()

    def test_rejects_semantic_output_sentinel_flag_and_diagnostic_corruption(self):
        for name,offset in [('actual_output',0),('actual_output',4096),('actual_assist',0),
                            ('state',0),('payload',480),('dispatch.diagnostics',0),
                            ('dispatch.diagnostics',4*4),('dispatch.diagnostics',11*4)]:
            path = self.run/f'rank0/round0.{name}.bin'
            original = path.read_bytes()
            changed = bytearray(original)
            changed[offset] ^= 1
            path.write_bytes(changed)
            with self.subTest(name=name,offset=offset),self.assertRaises(ValueError):
                self.result()
            path.write_bytes(original)

    def test_missing_branch_pair_missing_lane_and_overflow_rejected(self):
        path = self.run/'rank0/round0.dispatch.records'
        for options in ({'omit':(55,{500,501})},{'omit':(0,{800})},
                        {'missing_lane':12},{'overflow':0}):
            path.write_bytes(synthetic_records(0,56,**options))
            with self.subTest(options=options),self.assertRaises(ValueError):
                self.result()

    def test_raw_timestamp_regression_is_rejected(self):
        path = self.run/'rank0/round0.dispatch.records'
        data = bytearray(path.read_bytes())
        # Third event occurs before the second event while event IDs remain unchanged.
        struct.pack_into('<Q',data,FILE_HEADER.size+STREAM_HEADER.size+2*RECORD.size,105)
        path.write_bytes(data)
        with self.assertRaises(ValueError):
            self.result()

    def add_second_measurement(self):
        path = self.run/'run.json'
        data = json.loads(path.read_text())
        data['rounds'] = 2
        write_json(path,data)
        write_json(self.run/'summary.json', {'status':'PASS','rank_exit_codes':[0,0],
            'measured_iterations':[0,1], 'iterations':[
                {'iteration':i,'round':i,'measured':True} for i in (0,1)]})
        for rank,cores in ((0,56),(1,64)):
            root = self.run/f'rank{rank}'
            path = root/'summary.json'
            data = json.loads(path.read_text())
            data.update(iterations=2,verified_iterations=2,measured_iterations=2,capture_count=2)
            write_json(path,data)
            for path in list(root.glob('round0.*')):
                (root/path.name.replace('round0.','round1.')).write_bytes(path.read_bytes())
            (root/'round1.params.bin').write_bytes(struct.pack('<16Q',*Config(rank=rank,block_dim=cores,magic=2).words()))
            (root/'round1.dispatch.records').write_bytes(synthetic_records(rank,cores,capture_id=3+rank))
            for name in ('rounds.csv','timing.csv'):
                with (root/name).open() as stream:
                    rows = list(csv.DictReader(stream))
                new = dict(rows[0],round=1,magic=2)
                if name == 'timing.csv':
                    new['capture_id'] = str(UUID(int=3+rank))
                write_csv(root/name,rows+[new])

    def test_swapped_and_duplicated_records_cannot_be_assigned_to_another_round(self):
        self.add_second_measurement()
        self.assertTrue(self.result()['capture_checked'])
        first,second = [self.run/f'rank0/round{i}.dispatch.records' for i in (0,1)]
        original = (first.read_bytes(),second.read_bytes())
        first.write_bytes(original[1])
        second.write_bytes(original[0])
        with self.assertRaisesRegex(ValueError,'Capture ID does not match'):
            self.result()
        first.write_bytes(original[0])
        with self.assertRaisesRegex(ValueError,'Capture ID does not match'):
            self.result()
        # Updating the timing CSV cannot make a duplicate capture into a new measurement.
        path = self.run/'rank0/timing.csv'
        with path.open() as stream:
            rows = list(csv.DictReader(stream))
        rows[1]['capture_id'] = rows[0]['capture_id']
        write_csv(path,rows)
        with self.assertRaisesRegex(ValueError,'Duplicate capture ID'):
            self.result()

    def test_capture_id_is_nonzero_and_unique_across_ranks(self):
        path = self.run/'rank1/timing.csv'
        with path.open() as stream:
            rows = list(csv.DictReader(stream))
        for capture_id,error in ((0,'or is zero'),(1,'Duplicate capture ID')):
            rows[0]['capture_id'] = str(UUID(int=capture_id))
            write_csv(path,rows)
            (self.run/'rank1/round0.dispatch.records').write_bytes(synthetic_records(1,64,capture_id=capture_id))
            with self.subTest(capture_id=capture_id),self.assertRaisesRegex(ValueError,error):
                self.result()

    def test_generated_mapping_accepts_independent_synthetic_role_events(self):
        generated = Path(__file__).resolve().parents[1]/'generated'
        # 当前 v2 映射含 F6 三个子段，独立合成的生产/消费事件也须覆盖它们。
        for rank, cores in ((0, 56), (1, 64)):
            (self.run/f'rank{rank}/round0.dispatch.records').write_bytes(
                synthetic_records(rank, cores, f6_children=True, abi_version=2))
        result = analyze(self.run,self.fixture,generated)
        self.assertTrue(result['capture_checked'])
        self.assertEqual(result['rank_results'][1]['functions']['F0']['per_round'][0]['participating_cores'],64)

    def test_undeclared_parent_child_overlap_is_not_summed(self):
        path = self.generated/'rank0/dispatch.ticks.json'
        data = json.loads(path.read_text())
        # A mapped parent enclosing F0.send_round must not be added to that child.
        layout = next(s for s in data['stages'] if s['name'] == 'F0.layout')
        layout['end'] = 21
        write_json(path,data)
        with self.assertRaises(ValueError):
            self.result()
        lanes = [{'core':0,'workload':{},'intervals':{
            'parent':{'begin_tick':0,'end_tick':30,'ticks':30},
            'child':{'begin_tick':10,'end_tick':20,'ticks':10}}}]
        with self.assertRaisesRegex(ValueError,'overlap'):
            aggregate(lanes,['parent','child'],[],{0})

    def test_equal_round_weighting_not_pooled_core_mean(self):
        captures = [{'modules':{'sample':{'mean_ticks':10,'max_ticks':20,'participating_cores':2}}},
                    {'modules':{'sample':{'mean_ticks':100,'max_ticks':100,'participating_cores':1}}}]
        result = equal_round_summary(captures,'modules')['sample']
        self.assertEqual(result['mean_ticks'],55)
        self.assertEqual(result['mean_of_core_max_ticks'],60)

    def test_warmup_is_validated_but_not_recorded_or_timed(self):
        path = self.run/'run.json'
        data = json.loads(path.read_text())
        data['warmup'] = 1
        write_json(path,data)
        write_json(self.run/'summary.json', {'status':'PASS','rank_exit_codes':[0,0],
            'measured_iterations':[1],'iterations':[{'iteration':0,'round':0,'measured':False},
                                                   {'iteration':1,'round':0,'measured':True}]})
        for rank in (0,1):
            root = self.run/f'rank{rank}'
            path = root/'summary.json'
            data = json.loads(path.read_text())
            data.update(iterations=2,verified_iterations=2)
            write_json(path,data)
            for path in list(root.glob('round0.*')):
                path.rename(root/path.name.replace('round0.','round1.'))
            write_csv(root/'rounds.csv', [{'round':0,'magic':0,'measured':0,'profiling':0,
                'operator_correctness':'PASS','flags_cleared':'PASS'},
                {'round':1,'magic':1,'measured':1,'profiling':1,
                 'operator_correctness':'PASS','flags_cleared':'PASS'}])
            with (root/'timing.csv').open() as stream:
                rows = list(csv.DictReader(stream))
            rows[0]['round'] = 1
            write_csv(root/'timing.csv',rows)
        self.assertTrue(self.result()['capture_checked'])

    def test_fixture_hash_and_schedule_corruption_rejected(self):
        path = self.fixture/'rank1/x.bin'
        original = path.read_bytes()
        path.write_bytes(bytes(2048))
        with self.assertRaisesRegex(ValueError,'Fixture hash'):
            self.result()
        path.write_bytes(original)
        path = self.run/'summary.json'
        data = json.loads(path.read_text())
        data['iterations'][0]['measured'] = False
        write_json(path,data)
        with self.assertRaisesRegex(ValueError,'iteration identity'):
            self.result()

    def test_correctness_mode_requires_outputs_and_workload_but_not_capture(self):
        path = self.run/'run.json'
        data = json.loads(path.read_text())
        data['mode'] = 'correctness'
        write_json(path,data)
        for rank in (0,1):
            root = self.run/f'rank{rank}'
            path = root/'summary.json'
            data = json.loads(path.read_text())
            data.update(profiling=False,capture_count=0)
            write_json(path,data)
            for name in ('rounds.csv','timing.csv'):
                with (root/name).open() as stream:
                    rows = list(csv.DictReader(stream))
                for row in rows:
                    row['profiling'] = 0
                    if name == 'timing.csv':
                        row['capture_id'] = ''
                write_csv(root/name,rows)
            (root/'round0.dispatch.records').unlink()
        result = self.result()
        self.assertFalse(result['capture_checked'])
        self.assertEqual(result['rank_results'][0]['modules'],{})
        path = self.run/'rank0/timing.csv'
        with path.open() as stream:
            rows = list(csv.DictReader(stream))
        rows[0]['capture_id'] = str(UUID(int=1))
        write_csv(path,rows)
        with self.assertRaisesRegex(ValueError,'empty capture ID'):
            self.result()


class MultiRankAnalysisTests(unittest.TestCase):
    def test_saved_three_rank_capture_and_rank_identity(self):
        from ..analyze_a5 import output_sizes, fixture_shape
        from ..layout_reference import split_range
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            fixture, run, generated = root/'fixture', root/'run', root/'generated'
            core_counts = [4,5,6]
            make_fixture(fixture, world_size=3, experts=6, cores=core_counts)
            run.mkdir()
            generated.mkdir()
            write_json(run/'run.json', dict(schema='tilelang_dispatch_integrated_run.v1',
                observation='integrated single-kernel dispatch', mode='capture', rounds=1,
                warmup=0, devices=[2,4,5], cores=core_counts, world_size=3, experts=6))
            write_json(run/'summary.json', dict(status='PASS', rank_exit_codes=[0]*3,
                measured_iterations=[0], iterations=[dict(iteration=0, round=0, measured=True)]))
            for rank, cores in enumerate(core_counts):
                out, source = run/f'rank{rank}', fixture/f'rank{rank}'
                out.mkdir()
                (generated/f'rank{rank}').mkdir()
                m = mapping(rank, cores)
                m.update(abi_version=2,world_size=3,experts=6,local_experts=2,
                         workspace_stride_words=8,tokens_per_rank=4)
                write_json(generated/f'rank{rank}/dispatch.ticks.json',m)
                write_json(out/'summary.json', dict(observation='integrated',operator_correctness='PASS',
                    flags_cleared='PASS',rank=rank,device=[2,4,5][rank],cores=cores,profiling=True,
                    iterations=1,verified_iterations=1,measured_iterations=1,capture_count=1))
                write_csv(out/'rounds.csv',[dict(round=0,magic=1,measured=1,profiling=1,
                    operator_correctness='PASS',flags_cleared='PASS')])
                write_csv(out/'timing.csv',[dict(round=0,magic=1,device=[2,4,5][rank],rank=rank,
                    aiv_count=cores,profiling=1,module='dispatch',acl_event_us=10+rank,
                    host_launch_sync_us=20,capture_id=str(UUID(int=rank+1)),operator_correctness='PASS')])
                cfg = Config(world_size=3,experts=6,rank=rank,block_dim=cores)
                (out/'round0.params.bin').write_bytes(struct.pack('<16Q',*cfg.words()))
                shape = fixture_shape(source)
                for name,size in output_sizes(shape,2).items():
                    golden = (source/f'expected_{name}.bin').read_bytes()
                    (out/f'round0.actual_{name}.bin').write_bytes(golden+b'\xa5'*(size-len(golden)))
                (out/'round0.state.bin').write_bytes(bytes(1<<20))
                (out/'round0.payload.bin').write_bytes(bytes(6*4*1024))
                prefix = struct.unpack('<6i',(source/'expected_counts.bin').read_bytes())
                amounts = [prefix[0]]+[b-a for a,b in zip(prefix,prefix[1:])]
                rows, blocks = [], []
                for core in range(cores):
                    begin,end = split_range(6,cores,core)
                    received = sum(amounts[begin:end])
                    sent = len(range(core,8,cores-1)) if core < cores-1 else 0
                    rows += [0,int(core==cores-1),1,received,end-begin,sent,6*int(core==cores-1),
                             received,end-begin,sent*1024,received*1024,0,0,0,0,0]
                    ids = [1]
                    for _,event in PAIRS:
                        if event in (40,500,510,600) and core != cores-1:
                            continue
                        if event == 400 and core >= min(8,cores-1):
                            continue
                        ids.extend([event,event+1])
                    ids.append(2)
                    raw = b''.join(RECORD.pack(100+i*10,event,0) for i,event in enumerate(ids))
                    blocks.append(STREAM_HEADER.pack((rank<<16)|core,len(ids),0,1,STREAM_HEADER.size+len(raw))+raw)
                (out/'round0.dispatch.diagnostics.bin').write_bytes(struct.pack('<'+'i'*len(rows),*rows))
                body = b''.join(blocks)
                data = FILE_HEADER.pack(b'TXRPRF1\0',1,0,48,16,24,1,0,cores,
                                        UUID(int=rank+1).bytes,48+len(body))+body
                (out/'round0.dispatch.records').write_bytes(data)
            result = analyze(run,fixture,generated)
            self.assertEqual([r['rank'] for r in result['rank_results']],[0,1,2])
            self.assertEqual(result['rank_results'][2]['acl_event_us']['mean'],12)
            value = json.loads((run/'rank2/summary.json').read_text())
            value['rank'] = 1
            write_json(run/'rank2/summary.json',value)
            with self.assertRaisesRegex(ValueError,'Rank summary'):
                analyze(run,fixture,generated)

    def test_odd_world_multi_slot_cores_and_empty_slots(self):
        from ..analyze_a5 import check_diagnostics, fixture_workload, stage_executes, summarize_capture, validate_mapping
        from ..layout_reference import split_range
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            shape = dict(world=3, experts=6, tokens_per_rank=4, hidden=256, topk=2)
            write_json(root/'case.json', dict(shape=shape, hashes={}))
            for rank in range(3):
                (root/f'rank{rank}').mkdir()
                # Distinct TopK, entirely targeting rank0: other destinations have empty slots.
                (root/f'rank{rank}/ids.bin').write_bytes(struct.pack('<8i', *([0,1]*4)))
            context = fixture_workload(root/'rank0', 0)
            self.assertEqual(context['slot_records'], [4]*6)
            empty = fixture_workload(root/'rank2', 2)
            self.assertEqual(empty['slot_records'], [0]*6)
            cores = 4
            rows = []
            for core in range(cores):
                begin, end = split_range(6, cores, core)
                sent = len(range(core, 8, cores-1)) if core < cores-1 else 0
                received = 4*(end-begin)
                rows += [0, int(core==cores-1), 1, received, end-begin, sent,
                         6*int(core==cores-1), received, end-begin, sent*1024,
                         received*1024, 0,0,0,0,0]
            path = root/'diagnostics.bin'
            path.write_bytes(struct.pack('<64i', *rows))
            diagnostics = check_diagnostics(path, cores, tokens=4, context=context)
            self.assertEqual([d['received_records'] for d in diagnostics], [8,8,4,4])
            m = mapping(0, cores)
            m.update(abi_version=2, world_size=3, experts=6, local_experts=2,
                     workspace_stride_words=8, tokens_per_rank=4)
            self.assertEqual(validate_mapping(m, context, 0, cores), 2)
            old = dict(m)
            old.pop('abi_version')
            with self.assertRaisesRegex(ValueError, 'Historical artifact'):
                validate_mapping(old, context, 0, cores)
            blocks = []
            for core in range(cores):
                ids = [1]
                for name, event in PAIRS:
                    if stage_executes(name, core, cores, 4, 6, 2):
                        ids.extend([event, event+1])
                ids.append(2)
                raw = b''.join(RECORD.pack(100+i*10, event, 0) for i,event in enumerate(ids))
                blocks.append(STREAM_HEADER.pack(core, len(ids), 0, 1, STREAM_HEADER.size+len(raw))+raw)
            body = b''.join(blocks)
            raw = FILE_HEADER.pack(b'TXRPRF1\0',1,0,48,16,24,1,0,cores,UUID(int=42).bytes,48+len(body))+body
            record_path = root/'capture.records'
            record_path.write_bytes(raw)
            from tilexr_profiling.records import load_record_files
            capture = summarize_capture(load_record_files([record_path])[0], m, diagnostics)
            self.assertEqual(capture['functions']['F8']['workload']['received_records'], 24)
            self.assertEqual(capture['functions']['F8']['participating_cores'], 4)
            self.assertEqual(capture['functions']['F5']['participating_core_ids'], [3])
            empty_rows = list(rows)
            for core in range(cores):
                for offset in (3, 7, 10):
                    empty_rows[core*16+offset] = 0
            path.write_bytes(struct.pack('<64i', *empty_rows))
            empty_diagnostics = check_diagnostics(path, cores, tokens=4, context=empty)
            empty_capture = summarize_capture(load_record_files([record_path])[0], m, empty_diagnostics)
            self.assertEqual(empty_capture['functions']['F8']['active_workload_cores'], 0)
            self.assertIsNone(empty_capture['functions']['F8']['active_workload_mean_ticks'])
            with self.assertRaisesRegex(ValueError, 'only valid'):
                check_diagnostics(path, cores, ready_probe=True, tokens=4, context=context)


if __name__ == '__main__':
    unittest.main()
