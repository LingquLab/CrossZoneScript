"""Reject the observed mixed-ABI regex boundary before loading HCCL."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


@unittest.skipUnless(all(shutil.which(x) for x in ("g++", "cmake", "nm")),
                     "GNU C++ and CMake are required")
class PreAllReduceAbiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="tilelang-abi-test-")
        cls.root = Path(cls.temp.name)
        source = cls.root / "regex.cpp"
        source.write_text('#include <regex>\nextern "C" int match() {\n'
                          'return std::regex_match("123", std::regex("[0-9]+"));\n}\n')
        for abi in (0, 1):
            subprocess.run(["g++", "-std=c++14", "-O2", "-shared", "-fPIC",
                            f"-D_GLIBCXX_USE_CXX11_ABI={abi}", str(source), "-o",
                            str(cls.root / f"libcore{abi}.so")],
                           check=True, capture_output=True, timeout=60)
        guard = (Path(__file__).resolve().parents[1] / "pre_allreduce_abi.cmake").resolve()
        (cls.root / "CMakeLists.txt").write_text(
            'cmake_minimum_required(VERSION 3.19)\nproject(AbiRegression LANGUAGES CXX)\n'
            f'include("{guard.as_posix()}")\n'
            'tl_check_pre_allreduce_abi("${TEST_CORE}")\n')

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def configure(self, host_abi, core_abi):
        return subprocess.run([
            "cmake", "-S", str(self.root), "-B", str(self.root / f"b{host_abi}{core_abi}"),
            "-DCMAKE_CXX_COMPILER=g++", f"-DCMAKE_CXX_FLAGS=-D_GLIBCXX_USE_CXX11_ABI={host_abi}",
            f"-DTEST_CORE={self.root / f'libcore{core_abi}.so'}"],
            capture_output=True, text=True, timeout=30)

    def test_matching_old_abi_is_accepted(self):
        result = self.configure(0, 0)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_new_abi_core_is_rejected(self):
        result = self.configure(0, 1)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("TileXR core exports new-ABI", result.stderr)

    def test_new_abi_host_is_rejected(self):
        result = self.configure(1, 0)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Pre-AllReduce requires Host", result.stderr)


if __name__ == "__main__":
    unittest.main()
