"""[AI] 参数边界和fixture业务语义；不把离线结果当多NPU验证。"""
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest
from ..contract import Config, F, reference, validate_dispatch_config, workspace_stride_words
from ..hardware_fixture import make_fixture


class MultiRankContractTests(unittest.TestCase):
    def test_partition_and_addresses_for_odd_and_many_ranks(self):
        for world, local, cores in ((1,3,4),(3,1,4),(3,3,4),(4,2,8),(5,1,4),(6,2,8),(8,1,4),(128,1,64)):
            experts = world * local
            for rank in (0, world-1):
                rows = reference(Config(world_size=world,experts=experts,rank=rank,block_dim=cores))
                chunks = [list(range(row[F['receive_begin']],row[F['receive_end']])) for row in rows]
                self.assertEqual([x for chunk in chunks for x in chunk],list(range(experts)))
                self.assertEqual(rows[-1][F['status_tasks']],experts)
                self.assertEqual(rows[0][F['cumsum_cores']],1)
                self.assertEqual(rows[0][F['workspace_bytes']], cores*workspace_stride_words(experts)*4)
                self.assertEqual(rows[0][F['send_rounds']],1)

    def test_invalid_parameters_and_explicit_capacity_rejected(self):
        base=dict(world_size=3,experts=6,rank=0,cores=4,tokens=16)
        for patch in (dict(world_size=0),dict(world_size=129),dict(experts=7),dict(rank=3),dict(cores=1),
                      dict(world_size=True),dict(world_size=128,experts=256,cores=64)):
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                validate_dispatch_config(**dict(base,**patch))

    def test_old_x_ids_preserved_for_all_existing_batches(self):
        for tokens in (4,16,64,256):
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)/'fixture'
                manifest=make_fixture(root,tokens=tokens)
                for rank in range(2):
                    old_ids=struct.pack('<'+'i'*(tokens*2),*(v for t in range(tokens) for v in (t%2,t%2+2)))
                    old_x=struct.pack('<'+'H'*(tokens*256),*(0x3f80+rank*0x80+t*0x10+h%32 for t in range(tokens) for h in range(256)))
                    self.assertEqual((root/f'rank{rank}/ids.bin').read_bytes(),old_ids)
                    self.assertEqual((root/f'rank{rank}/x.bin').read_bytes(),old_x)
                    self.assertEqual(manifest['hashes'][f'rank{rank}/ids.bin'],hashlib.sha256(old_ids).hexdigest())

    def test_skewed_fixture_zero_output_and_all_rank_golden(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'fixture'
            make_fixture(root,tokens=16,world_size=3,experts=9,cores=[4,5,6],
                         routes=[[(0,1)]*16,[(0,1)]*16,[(0,1)]*16])
            self.assertEqual((root/'rank0/expected_expert_nums.bin').read_bytes(),struct.pack('<qqq',48,48,0))
            for rank in (1,2):
                self.assertEqual((root/f'rank{rank}/expected_output.bin').stat().st_size,0)
                self.assertEqual((root/f'rank{rank}/expected_assist.bin').stat().st_size,0)
                self.assertEqual((root/f'rank{rank}/expected_counts.bin').read_bytes(),bytes(9*4))


if __name__=='__main__':
    unittest.main()
