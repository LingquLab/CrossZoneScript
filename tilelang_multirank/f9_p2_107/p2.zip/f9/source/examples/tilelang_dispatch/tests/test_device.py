"""离线来源/打点契约和实际F0宏算术；不证明NPU并发或设备性能。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from ..profile import ROOT, adapt, instrument


class ProvenanceTests(unittest.TestCase):
    def test_source_dependencies_and_reproducible_adaptation(self):
        repo = ROOT.parents[1]
        with tempfile.TemporaryDirectory() as directory:
            for tokens, rank in ((t, r) for t in (4, 16, 64, 256) for r in (0, 1)):
                base = ROOT if tokens == 4 else ROOT / f'batch/bs{tokens}'
                source = base / 'reference_exports' / f'rank{rank}'
                metadata = json.loads((source / 'export.json').read_text())
                for relative, expected in metadata['source_hashes'].items():
                    self.assertEqual(hashlib.sha256((repo / relative).read_bytes()).hexdigest(), expected, relative)
                self.assertTrue(metadata['pass_configs']['tir.merge_static_smem'])
                out = Path(directory) / f'bs{tokens}-rank{rank}'
                result = adapt(source, out, recipe_path=base / 'profile_recipe.json')
                self.assertEqual(result['args_bytes_aarch64'], 104)
                self.assertEqual(result['modules'][0]['marker_slots'], 52)
                self.assertEqual(result['modules'][0]['record_capacity'], 64)
                for name in ('dispatch.device.cpp', 'dispatch.ticks.json'):
                    self.assertEqual((out / name).read_bytes(), (base / f'generated/rank{rank}' / name).read_bytes())
                with self.assertRaises(FileExistsError):
                    adapt(source, out, recipe_path=base / 'profile_recipe.json')

    def test_changed_export_rejected_before_output(self):
        recipe = json.loads((ROOT / 'profile_recipe.json').read_text())
        raw = (ROOT / 'reference_exports/rank0/dispatch.raw.cpp').read_text()
        with self.assertRaisesRegex(ValueError, 'reviewed export'):
            instrument(raw + '\n', recipe['modules']['dispatch'], 'dispatch', 0, 56)

    def test_selected_intervals_are_disjoint_and_capacity_sufficient(self):
        recipe = json.loads((ROOT / 'profile_recipe.json').read_text())
        intervals = sorted((s['raw_lines'][0], s['raw_lines'][1])
                           for s in recipe['modules']['dispatch']['stages'] if s['name'].startswith('F') and s['name'] not in
                           ('F6.prepare', 'F6.workspace_publish', 'F6.gate_publish'))
        self.assertTrue(all(left[1] < right[0] for left, right in zip(intervals, intervals[1:])))
        stages = {s['name']: s['raw_lines'] for s in recipe['modules']['dispatch']['stages']}
        parent = stages['F6.prefix_publish']
        children = [stages[name] for name in ('F6.prepare', 'F6.workspace_publish', 'F6.gate_publish')]
        self.assertTrue(all(parent[0] <= lo <= hi <= parent[1] for lo, hi in children))
        self.assertTrue(all(a[1] < b[0] for a, b in zip(children, children[1:])))
        self.assertLessEqual(2 * len(recipe['modules']['dispatch']['stages']), recipe['capacity'])


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Use pinned TileLang export environment for actual macro arithmetic')
class LayoutMacroTests(unittest.TestCase):
    def test_real_layout_and_split_macros_against_independent_reference(self):
        import numpy as np
        import tilelang as tl
        import tilelang.language as T
        from ..kernel import layout, send_round, count_split, status_split, receive_split
        from ..contract import Config, F, reference
        for rank, cores in ((0, 56), (1, 64)):
            @T.prim_func
            def layout_phase(params: T.Tensor((16,), 'uint64'), output: T.Tensor((cores, 64), 'uint64')):
                T.func_attr({'global_symbol': 'layout_phase', 'tir.noalias': True})
                for core in T.serial(cores):
                    with T.block('core'):
                        p = T.alloc_buffer((16,), 'uint64', scope='local')
                        o = T.alloc_buffer((64,), 'uint64', scope='local')
                        for i in T.serial(16):
                            p[i] = params[i]
                        for i in T.serial(64):
                            o[i] = T.uint64(0)
                        layout(p, o)
                        send_round(p, o)
                        count_split(p, o, core)
                        if T.cast(core, 'uint64') >= o[F['send_cores']]:
                            status_split(p, o, core)
                        receive_split(p, o, core)
                        for i in T.serial(64):
                            output[core, i] = o[i]
            primitive = tl.tvm.script.from_source(layout_phase.script().replace('"local.var"', '"local"'))
            def unsigned_div(node):
                if isinstance(node, tl.tvm.tir.FloorDiv) and node.dtype == 'uint64':
                    return tl.tvm.tir.truncdiv(node.a, node.b)
                if isinstance(node, tl.tvm.tir.FloorMod) and node.dtype == 'uint64':
                    return tl.tvm.tir.truncmod(node.a, node.b)
            primitive = primitive.with_body(tl.tvm.tir.stmt_functor.ir_transform(primitive.body, None, unsigned_div))
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / 'layout.so'
                tl.tvm.build(primitive, target='c', name='layout_phase').export_library(str(path))
                module = tl.tvm.runtime.load_module(str(path))
                for tokens, magic in ((4, 0), (16, 1), (64, 2), (256, 1)):
                    config = Config(tokens=tokens, rank=rank, block_dim=cores, peer_base=1 << 36, magic=magic)
                    actual = tl.tvm.nd.array(np.zeros((cores, 64), dtype=np.uint64))
                    module['layout_phase'](tl.tvm.nd.array(np.array(config.words(), dtype=np.uint64)), actual)
                    expected = np.array(reference(config), dtype=np.uint64)
                    fields = [5, 6, 7, 8, 14, 15, 22, 25, 32, 34, 35, 36, 42, 43, 44]
                    np.testing.assert_array_equal(actual.numpy()[:, fields], expected[:, fields])
                    np.testing.assert_array_equal(actual.numpy()[-1, [38, 39, 40]], expected[-1, [38, 39, 40]])


if __name__ == '__main__':
    unittest.main()
