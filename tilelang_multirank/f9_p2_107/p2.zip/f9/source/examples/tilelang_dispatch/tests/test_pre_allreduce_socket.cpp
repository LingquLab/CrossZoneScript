/* Copyright (c) 2026 TileXR Project. CANN Open Software License Agreement v2.0. */
// Host-only transport test: synthetic bytes, no HCCL runtime, no NPU calls.
#define TL_PRE_ALLREDUCE_SUPPORT 0
#include "pre_allreduce.h"
#include <sys/wait.h>
#include <array>
#include <iostream>

int main(int argc, char **argv)
{
    using TileLangNativeHost::Check;
    try {
        // Bind to choose a local ephemeral port. This is not a reservation;
        // another listener racing us will make this test fail visibly.
        TileLangNativeHost::Socket pick(socket(AF_INET, SOCK_STREAM, 0));
        sockaddr_in address {}; address.sin_family = AF_INET;
        address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        Check(pick.fd >= 0 && bind(pick.fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)) == 0,
              "test bind failed");
        socklen_t size = sizeof(address);
        Check(getsockname(pick.fd, reinterpret_cast<sockaddr *>(&address), &size) == 0, "test port failed");
        const int port = ntohs(address.sin_port);
        close(pick.fd); pick.fd = -1;
        if (argc > 1 && std::string(argv[1]) == "missing") {
            bool rejected = false;
            try { TileLangNativeHost::BarrierAll(0, port, 2, 80); }
            catch (const std::runtime_error &) { rejected = true; }
            Check(rejected, "missing participant was accepted");
            return 0;
        }
        if (argc > 1 && (std::string(argv[1]) == "failed-peer" || std::string(argv[1]) == "duplicate")) {
            const bool duplicate = std::string(argv[1]) == "duplicate";
            std::vector<pid_t> children;
            for (int index = 0; index < (duplicate ? 2 : 1); ++index) {
                const pid_t child = fork(); Check(child >= 0, "failure test fork failed");
                if (child == 0) {
                    TileLangNativeHost::Socket peer(TileLangNativeHost::Connect(
                        TileLangNativeHost::Address(port), 500));
                    TileLangNativeHost::SendRank(peer.fd, 1);
                    return 0; // participant disappears before arrival
                }
                children.push_back(child);
            }
            bool rejected = false;
            try { TileLangNativeHost::BarrierAll(0, port, duplicate ? 3 : 2, 1000); }
            catch (const std::runtime_error &) { rejected = true; }
            for (pid_t child : children) {
                int status = 0;
                Check(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0,
                      "failure test child failed");
            }
            Check(rejected, "failed or duplicate participant was accepted");
            return 0;
        }
        const int world = argc > 1 ? std::stoi(argv[1]) : 2;
        Check(world > 0, "invalid test world");
        int rank = 0;
        std::vector<pid_t> children;
        for (int peer = 1; peer < world; ++peer) {
            const pid_t child = fork(); Check(child >= 0, "test fork failed");
            if (child == 0) { rank = peer; break; }
            children.push_back(child);
        }
        for (int step = 0; step < 2; ++step) {
            std::array<uint8_t, 8197> bytes {};
            if (rank == 0)
                for (size_t i = 0; i < bytes.size(); ++i) bytes[i] = uint8_t((i * 7 + step) % 251);
            TileLangPreAllReduce::ExchangeRoot(rank, port, bytes.data(), bytes.size(), world);
            for (size_t i = 0; i < bytes.size(); ++i)
                Check(bytes[i] == uint8_t((i * 7 + step) % 251), "opaque exchange bytes mismatch");
            // Same endpoint transitions to the unchanged native barrier.
            TileLangNativeHost::BarrierAll(rank, port, world);
        }
        if (rank != 0) return 0;
        for (pid_t child : children) {
            int status = 0;
            Check(waitpid(child, &status, 0) == child && WIFEXITED(status) && WEXITSTATUS(status) == 0,
                  "test child failed");
        }
        int pair[2] {};
        Check(socketpair(AF_UNIX, SOCK_STREAM, 0, pair) == 0, "test socketpair failed");
        TileLangNativeHost::Socket reader(pair[0]), writer(pair[1]);
        uint8_t byte = 17;
        TileLangPreAllReduce::Transfer(writer.fd, &byte, 1, true);
        close(writer.fd); writer.fd = -1;
        bool rejected = false;
        std::array<uint8_t, 2> truncated {};
        try { TileLangPreAllReduce::Transfer(reader.fd, truncated.data(), truncated.size(), false); }
        catch (const std::runtime_error &) { rejected = true; }
        Check(rejected, "truncated root exchange was accepted");
        std::cout << "opaque exchange, barrier transition and truncated-input rejection PASS\n";
        return 0;
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
