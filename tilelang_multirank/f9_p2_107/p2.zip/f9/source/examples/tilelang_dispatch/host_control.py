"""集成Dispatch测试共用的查卡与多rank控制通道；不搬运业务payload。"""
from datetime import datetime, timezone
import json
import selectors
import subprocess
import time


def check_idle(devices, output):
    rows = []
    for device in devices:
        p = subprocess.run(['npu-smi', 'info', '-t', 'proc-mem', '-i', str(device)],
                           capture_output=True, timeout=15)
        (output / f'device{device}.stdout.log').write_bytes(p.stdout)
        (output / f'device{device}.stderr.log').write_bytes(p.stderr)
        idle = p.returncode == 0 and 'No process in device.' in p.stdout.decode(errors='replace')
        rows.append({'device': device, 'query_exit': p.returncode, 'idle': idle})
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'devices': rows}
    (output / 'occupancy.json').write_text(json.dumps(result, indent=2) + '\n')
    if not all(row['idle'] for row in rows):
        raise RuntimeError('Selected devices busy or occupancy query indeterminate')


def rendezvous(channels, command, expected, deadline):
    if command is not None:
        for channel in channels:
            channel.sendall(command)
    with selectors.DefaultSelector() as selector:
        for rank, channel in enumerate(channels):
            selector.register(channel, selectors.EVENT_READ, rank)
        while selector.get_map():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Multi-rank run deadline exceeded')
            events = selector.select(remaining)
            if not events:
                raise TimeoutError('Multi-rank control response timeout')
            for key, _ in events:
                response = key.fileobj.recv(1)
                if response != expected:
                    raise RuntimeError(f'Rank {key.data} failed/closed control channel during {command!r}')
                selector.unregister(key.fileobj)
