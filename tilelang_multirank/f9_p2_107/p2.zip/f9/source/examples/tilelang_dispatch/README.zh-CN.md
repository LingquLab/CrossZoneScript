# TileLang Dispatch：通用rank候选（保留TL v2优化）

五个功能模块在同一个 Dispatch kernel 中执行，每 rank 每次只启动一次 Dispatch。
当前默认 `p1p2`：F6 的 workspace 连续构造后批量写 GM 并等待完成，gate 保留逐核32B提交、组尾等待。
F8 按190KiB UB预算计算每批接收条数，使用A/B双缓冲；读feature时跨过READY标识，assist单独批量搬运，输出完成后再复用对应缓冲。
F9 先扫描本核已完成的接收量，按最大有效批一次向量填零，再供各槽跨步清理READY；每槽将消费数读入scalar，保留原清理批容量和逐批完成等待。
常规测试在同一 stream 显式前置 AllReduce，不改变 Dispatch 的 X/ids 输入。
默认 T4；T16/64/256 的独立导出、角色差异、输入与执行方式见 [Batch 扩容](docs/BATCH.zh-CN.md)。

当前代码P/E可配置，近期实机用例仍P2/E4。配置/ABI、槽位公式、限制及离线验证边界见
[多rank说明](docs/MULTIRANK.zh-CN.md)。

## 先看哪些代码

| 文件/目录 | 内容 |
|---|---|
| `kernel.py` | 全部设备业务逻辑：F0–F9、搬运同步、五模块调度，均在一个文件 |
| `contract.py`、`layout_reference.py` | 参数和布局字段约定、独立 CPU 布局参考；供导出、Host fixture、验收共用 |
| `hardware_fixture.py` | 不依赖 TileLang 的P/E/T输入与独立语义golden生成器 |
| `export.py`、`backend.lock.json` | 固定 TileLang 后端，将 kernel 导出为 Ascend C/TIR；默认 p1p2 |
| `reference_exports/rank*/` | 当前 v2 的原样 Ascend C、TIR、导出来源清单 |
| `profile.py`、`profile_recipe.json` | 固定 raw SHA、UB 和区间边界的 AIV 适配/TileXR 插桩 |
| `generated/rank*/` | 当前 v2 的打点 Ascend C、ticks 映射与来源清单；CMake 默认使用这里 |
| `runner.cpp`、`pre_allreduce.h`、`native_host_barrier.h` | Host 注册/启动纯设备 ELF、真实 peer 窗口、可选 HCCL 前置任务与 rank 握手 |
| `run_native.py`、`host_control.py` | 常规运行入口、每轮新进程、临启动查卡及超时处理 |
| `analyze_native.py`、`analyze_a5.py`、`analyze_pre_allreduce.py` | 常规/共用业务与打点验收、AllReduce 结果与计时检查 |
| `tests/` | Python 行为测试、真实 TL 宏算术及 C++14/ABI 检查 |
| `docs/` | [Host 流程](docs/HOST_ALIGNMENT.zh-CN.md)、[AllReduce](docs/PRE_ALLREDUCE.zh-CN.md)、[F5 诊断](docs/F5_DIAGNOSTIC.zh-CN.md)、[F6 变体](docs/F6_COMBINED.zh-CN.md) |
| `tools/` | 历史逐次诊断、A/B、多变体调度和旧格式 HTML 工具，见 [工具说明](tools/README.zh-CN.md) |

宏是编译时展开的代码片段。`count_publish`、`pack_send` 等宏帮助按模块阅读；它们不会成为五个独立 kernel，也没有引入额外 launch。
Host 配置、输入生成、参考验收保留在独立文件，避免 A5 上仅生成 fixture 就必须安装 TileLang/TVM。

## 五模块及核角色

| 模块 | kernel.py 入口 | 核分工 |
|---|---|---|
| ① 公共准备 F0＋F1 | `layout`、`send_round`、三个 `*_split`；`dispatch_body` 中路由读取 | 全核；部分 F0 仅在相应角色分支计算 |
| ② 专家计数与发布 F2＋F3 | `count_publish` | T<48：全核切分E个专家；T>=48：末核处理E专家 |
| ③ Token 打包发送 F4 | `pack_send` | 前 min(2T,cores−1) 核循环处理路由；T4为核0–7各一项 |
| ④ 接收计数与生成布局 F5＋F6 | `count_prefix` | 每rank末核（原两rank为55/63） |
| ⑤ 接收数据与完成输出 F7＋F8＋F9 | `receive_output` | 全核等待/清理自己的 gate；按E个槽分配接收，单核可多槽（原两rank为核0–3） |

`dispatch_body` 保持原调度顺序：计数发布后，payload 发送与末核前缀和路径可以并行；各核通过自己的 gate 进入接收。
F0 保留在实际使用布局/分工的位置，不强行提前；`PIPE_ALL` 是核内流水屏障，不是全核 barrier。

## 固定用例与接口

两 rank、4 专家（每 rank 2 专家），每 rank `X[4,256]` BF16、`expertIds[4,2]` INT32。
两 rank 路由均为 `[[0,2],[1,3],[0,2],[1,3]]`；X 的 BF16 位模式是
`0x3f80 + rank*0x80 + token*0x10 + hidden%32`，因此两 rank 的 X 按公式不同。
无 mask、量化、共享专家，有效 TP=1。rank0/1 分别启动56/64个 AIV。

每 rank 有效输出8条 token，按本地专家、来源 rank、来源 token 排序；assist 为
`[source_rank, token_index, topk_index]`，累计计数 `[2,4,6,8]`、专家数量 `[4,4]`。
Host 验收有效输出、assist、未使用尾部哨兵、窗口清理及复用；输入跨实现一致性以实际文件 SHA 核验，不能由 AllReduce 的 SUM=2 代替。

设备ABI v2是11个GM指针，依次为`params,x,ids,peers,local_state,local_data,output,assist,counts,expert_nums,diagnostics`，
再接`fftsAddr`占位u64和`profileGM`，AArch64共104B。`peers:uint64[2P]`由本进程通信映射生成；
每次launch的表随真实magic/bank生成并保留到stream结束。旧112B产物不可与新Host混用。
`x` 的设备形参是 `uint32[512]`，用于按位搬运 BF16[4,256]；不表示输入改成 FP32。

## 导出与打点

在匹配 `backend.lock.json` 的后端环境、仓库根目录执行，输出目录必须是新目录：

```bash
python3 -m examples.tilelang_dispatch.export --rank 0 --cores 56 --output /tmp/tl-v2-raw/rank0
python3 -m examples.tilelang_dispatch.export --rank 1 --cores 64 --output /tmp/tl-v2-raw/rank1
python3 -m examples.tilelang_dispatch.profile --source /tmp/tl-v2-raw/rank0 --output /tmp/tl-v2-generated/rank0
python3 -m examples.tilelang_dispatch.profile --source /tmp/tl-v2-raw/rank1 --output /tmp/tl-v2-generated/rank1
```

默认 `make_kernel`、导出器、recipe 和随分支生成物均为 TL v2。
`--variant baseline|p1|p2`仅供显式对照，适配器按本次raw生成SHA锁定recipe，保留五模块/F0–F9和52个marker槽。
每批容量由P/E/T/核数共同决定，详情见`export.json.receive_ub_plan`；UB实际范围见对应recipe，不能套用旧布局大小。
固定后端需完整匹配源码修订、差异哈希、TVM 和动态库；不要重置已有后端或用另一个同名安装替代。
生成清单中的 `NOT_RUN` 只描述源码生成阶段，实机结果须另绑定候选提交、二进制及输入/records 身份。

## 构建与常规测试

`CANN_ROOT`、`BACKEND_ROOT`、`COMM_INSTALL` 为已验证的 CANN9.1、匹配后端头文件与 TileXR 安装目录。
前置 HCCL 要求本实验的 Host 和 core 均以 ABI0 构建，不能仅重编 runner；见 [ABI 经验](docs/PRE_ALLREDUCE.zh-CN.md)。

本实验 Host 采用已在 950/CANN9.1 四 rank 功能验收通过的生命周期：先初始化 HCCL 并完成公共热身，
再让 TileXR 附着已有 RA；退出时先销毁 TileXR，经 rank 屏障后关闭 HCCL。
前置 HCCL 使用安装版官方 `aiv_only` 对应的配置值 `4`，该数值只按已验证的目标版本解释。
启用前置 AllReduce 时须显式设置 `TILEXR_UDMA_ATTACH_EXISTING_RA=1`；不要把初始化顺序问题归因于 Dispatch kernel。
这次组合还需重新完成 CANN 编译与设备验收，旧 Host 和旧设备各自通过不能代替组合验证。

```bash
cmake -S examples/tilelang_dispatch -B build-tl-integrated \
  -DTL_CANN_ROOT="$CANN_ROOT" -DTL_BACKEND_ROOT="$BACKEND_ROOT" -DTL_COMM_PREFIX="$COMM_INSTALL" \
  -DTL_PRE_ALLREDUCE_SUPPORT=ON -DCMAKE_CXX_FLAGS=-D_GLIBCXX_USE_CXX11_ABI=0 \
  -DCMAKE_INSTALL_PREFIX="$PWD/install-tl-integrated"
cmake --build build-tl-integrated --parallel 2 --verbose
cmake --install build-tl-integrated
python3 -m examples.tilelang_dispatch.hardware_fixture --output fixture-integrated
export TILEXR_UDMA_ATTACH_EXISTING_RA=1
python3 -m examples.tilelang_dispatch.run_native \
  --install install-tl-integrated --fixture fixture-integrated --output correctness-integrated \
  --devices 0 1 --comm-port 39185 --mode correctness --rounds 3 --warmup 20 --pre-allreduce allreduce
python3 -m examples.tilelang_dispatch.analyze_native \
  --run correctness-integrated --fixture fixture-integrated \
  --generated examples/tilelang_dispatch/generated --output correctness-analysis.json
```

正确性验收通过后，使用新的输出目录/端口运行 `--mode capture --rounds 5 --warmup 20 --pre-allreduce allreduce` 并重新分析。
每轮新建两个 rank 进程，连续20次预热后一次正式测量；缺少 msprof 则采集失败，不退化为 ACL-only。
临启动实时查卡，忙/未知/失败停止，不自动重跑或重置设备。
`--pre-allreduce none` 只用于显式对照，仍初始化并公共热身 HCCL；省略参数才完全不启用 HCCL，CLI 语义保持。

## 统计与维护边界

每轮先在同核累计不重叠功能片段，再按真实参与核统计 mean/max、核数和工作量，最后轮间等权。
F6 三个子段用于细分观察，不能与 F6 父包络重复相加；⑤的等待核集合与搬运核集合也不能混为一谈。
内部为未校准 raw ticks；msprof Dispatch 设备任务、ACL Dispatch 事件、前段与整段 ACL 分列。
模块重叠且不同核并行，不能把模块均值求和当作完整 Dispatch 延迟。此分支没有证明跨核/跨 rank 共同时钟。

清理历史实验时必须先检查现有 Host/分析器仍用的辅助函数，并迁移共用依赖。
只保留一套当前版本的 raw/TIR/recipe/generated，旧导出和旧 mapping 可从 Git 历史 `d46e96bb` 找回。
移动代码或提取宏后必须真实重导出，核验 raw、适配后的 device、mapping 及 fixture 字节一致；不能只更新清单哈希假装验证过。
当前目录与 Python 模块名统一为 `examples/tilelang_dispatch` / `examples.tilelang_dispatch`；改名时需同步命令、测试导入和导出来源路径。
给 kernel 增加注释也会改变来源 SHA，须真实重导出并复核生成物；保留现有 Host 可执行文件名和证据 schema，以便读取旧实验。
F9共用零缓冲必须等F8的读取/输出完成后再填充，向量填零后建立V→MTE3依赖；所有扫描、填零和等待均计入F9。
固定后端使用已有`fill_experiment`接口：uint32完整64元素repeat批量提交，尾部16/32/48元素用位掩码；须真实核验生成的`Fill_experiment<uint32_t>`及其`Duplicate`实现。不能因Python存在普通`fill`就假定固定AscendC后端已支持其lower。
接收优化的A5验证绑定候选`046f9b47`：T16/64/256各3轮正确性和各10轮20预热+1测量通过。均衡输入至多触发两批，尚未覆盖第三批复用同一缓冲的硬件路径；未证明跨核/跨rank共同时钟。
本次发布保留用户已有注释；真实重导出核对后再更新来源清单，不因发布重新运行A5实验。

离线测试从仓库根目录运行（真实宏算术需匹配 TileLang 环境）：

```bash
python3 -m unittest discover -s examples/tilelang_dispatch/tests -t . -v
```
