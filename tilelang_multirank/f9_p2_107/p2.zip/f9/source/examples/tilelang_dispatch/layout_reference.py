"""Dispatch layout reference: unsigned 64-bit words, byte offsets, half-open task ranges.

The peer bases are address *values*. The reference never dereferences a peer window.
Host validation must run before the device kernel; no invalid-input launch.
"""

from dataclasses import dataclass

ABI_VERSION = 1
ROUND_STRIDE = 1 << 30
REQUIRED_PEER_BYTES = 2 * ROUND_STRIDE
DATA_OFFSET = 2 << 20
STATE_BYTES = 1 << 20
DFX_OFFSET = 768 << 10
CUMSUM_OFFSET = 868 << 10
CUMSUM_FLAG_OFFSET = 876 << 10
ROUND_PAYLOAD_BYTES = (1022 << 20) - STATE_BYTES
UB_BYTES = 190 << 10

# 16 words, padded to a multiple of 32 bytes. These values are runtime inputs.
PARAM_NAMES = (
    "tokens", "hidden", "top_k", "experts", "world_size", "rank", "block_dim",
    "magic", "peer_base", "peer_bytes", "global_tokens", "reserved_11",
    "reserved_12", "reserved_13", "reserved_14", "reserved_15",
)

# One 512-byte descriptor per logical AIV. Reserved words must remain zero.
FIELD_NAMES = (
    "abi_version", "rank", "world_size", "core", "block_dim", "local_experts",
    "receive_states", "cumsum_cores", "send_cores", "count_workers", "small_batch",
    "sender_role", "route_start", "route_stride", "route_count",
    "count_begin", "count_end", "cumsum_begin", "cumsum_end",
    "receive_begin", "receive_end", "feature_bytes", "feature_aligned_bytes",
    "assist_offset_bytes", "record_blocks", "packed_payload_bytes", "record_bytes",
    "expert_window_bytes", "combine_reserve_bytes", "dispatch_bytes", "workspace_bytes",
    "status_bytes", "required_round_payload_bytes", "round_payload_capacity_bytes",
    "round_index", "round_offset_bytes", "round_data_offset_bytes", "state_address",
    "payload_address", "dispatch_address", "workspace_address", "cumsum_address",
    "cumsum_flags_address", "native_profile_address", "peer_capacity_bytes",
    "required_peer_bytes", "expert_ids_aligned_bytes", "status_count_aligned",
    "histogram_offset_bytes", "status_buffer_bytes", "ub_budget_bytes",
    "sender_ub_bytes", "count_ub_bytes", "receive_fixed_ub_bytes", "receive_token_ub_bytes",
) + tuple(f"reserved_{i}" for i in range(55, 64))
FIELDS = {name: i for i, name in enumerate(FIELD_NAMES)}


@dataclass(frozen=True)
class Config:
    tokens: int = 4
    hidden: int = 256
    top_k: int = 2
    experts: int = 4
    world_size: int = 2
    rank: int = 0
    block_dim: int = 64
    magic: int = 1
    # Synthetic address for arithmetic-only testing, not an allocation claim.
    peer_base: int = 0x100000000
    peer_bytes: int = REQUIRED_PEER_BYTES

    def words(self):
        return [self.tokens, self.hidden, self.top_k, self.experts, self.world_size,
                self.rank, self.block_dim, self.magic, self.peer_base, self.peer_bytes,
                self.tokens * self.world_size, 0, 0, 0, 0, 0]


def align_up(value, alignment):
    return (value + alignment - 1) // alignment * alignment


def split_range(length, workers, worker):
    """Native SplitToCore, returning [begin, end)."""
    quotient, remainder = divmod(length, workers)
    begin = quotient * worker + min(worker, remainder)
    return begin, begin + quotient + int(worker < remainder)


def reference(config, *, single_cumsum=False, native_capacity=True):
    """CPU oracle for the M0 descriptor, independently checked against native C++.

    v1 supports BF16, no shared experts, no mask, no quantization, TP=1.
    Capacity checks model the native Host reference for this restricted scope.
    Address overflow is rejected before any device launch.
    """
    c = config
    if any(type(v) is not int for v in vars(c).values()):
        raise ValueError("M0 parameters must be integers")
    if not (1 <= c.world_size <= 128 and 0 <= c.rank < c.world_size
            and 2 <= c.block_dim <= 200 and 1 <= c.top_k <= c.experts
            and c.experts % c.world_size == 0 and c.tokens > 0 and c.hidden > 0):
        raise ValueError("Invalid shape, rank, expert count or block_dim")
    if not (0 <= c.magic < 2**63 and c.peer_base > 0 and c.peer_base % 32 == 0
            and REQUIRED_PEER_BYTES <= c.peer_bytes < 2**64
            and c.peer_base <= 2**64 - 1 - c.peer_bytes):
        raise ValueError("Invalid window address, capacity or magic")
    # Native Init narrows the shape to uint32; prevent silent truncation.
    if max(c.tokens * c.top_k * 4, c.tokens * c.world_size, c.hidden * 2,
           c.experts) >= 2**32:
        raise ValueError("Native uint32 shape arithmetic would overflow")

    states = c.experts
    small = c.tokens < 48
    count = min(max((states + 31) // 32 if small else c.experts // 16, 1),
                c.block_dim // 2, 8, states)
    if single_cumsum:
        count = 1
    send = c.block_dim - count
    count_workers = c.block_dim if small else count
    features = c.hidden * 2
    aligned_features = align_up(features, 32)
    blocks = (aligned_features + 32 + 479) // 480
    packed = blocks * 480
    record = blocks * 512
    combine = c.tokens * c.top_k * ((features + 479) // 480) * 512
    expert_window = c.tokens * record
    dispatch_bytes = states * expert_window
    workspace = align_up(c.block_dim * states * 4, 32)
    expert_ids = align_up(c.tokens * c.top_k * 4, 32)
    expert_vec = align_up(c.tokens * c.top_k * 4, 256)
    status_count = align_up((c.experts + count_workers - 1) // count_workers, 8)
    sender_status = align_up((c.experts + c.block_dim - 1) // c.block_dim, 8) * 32 if small else 0
    sender_ub = (64 + 2 * (packed + aligned_features) + 2 * expert_vec
                 + 3 * expert_ids + sender_status + record)
    per_count = (states + count - 1) // count
    # Deliberately matches the native Host conservative bound (large-batch
    # status reserve is all experts, not only the actual per-core shard).
    count_status = align_up((c.experts + c.block_dim - 1) // c.block_dim if small else c.experts, 8)
    count_ub = (32 + 2 * expert_ids + 2 * expert_vec + count_status * 32
                + align_up(per_count * 32, 256) + align_up(per_count * 4, 32)
                + per_count * 32 + 2 * c.block_dim * 32 + align_up(c.block_dim * 4, 32)
                + 96 + states * 32 + align_up((c.experts // c.world_size) * 8, 32)
                + align_up(c.world_size * 4, 32))
    per_recv = (states + c.block_dim - 1) // c.block_dim
    receive_fixed = 32 + align_up(states * 4, 32) + 2 * count * 32 + 3 * align_up(per_recv * 4, 32)
    receive_token = 2 * packed + blocks * 32 + align_up(blocks * 4, 256)
    if (workspace > DFX_OFFSET or states * 32 > DFX_OFFSET - workspace
            or combine + dispatch_bytes > ROUND_PAYLOAD_BYTES
            or (native_capacity and (expert_ids >= UB_BYTES or sender_ub > UB_BYTES or count_ub > UB_BYTES
            or receive_fixed + receive_token > UB_BYTES))):
        raise ValueError("Native window or UB capacity exceeded")
    # The native vector copy uses uint8 repeat counts.
    if blocks > 255:
        raise ValueError("Native record exceeds uint8 copy repeat count")

    round_index = c.magic % 2
    round_offset = round_index * ROUND_STRIDE
    data_offset = round_offset + DATA_OFFSET
    state = c.peer_base + data_offset
    common = dict(
        abi_version=ABI_VERSION, rank=c.rank, world_size=c.world_size, block_dim=c.block_dim,
        local_experts=c.experts // c.world_size, receive_states=states, cumsum_cores=count,
        send_cores=send, count_workers=count_workers, small_batch=int(small),
        feature_bytes=features, feature_aligned_bytes=aligned_features, assist_offset_bytes=aligned_features,
        record_blocks=blocks, packed_payload_bytes=packed, record_bytes=record,
        expert_window_bytes=expert_window, combine_reserve_bytes=combine,
        dispatch_bytes=dispatch_bytes, workspace_bytes=workspace, status_bytes=states * 32,
        required_round_payload_bytes=combine + dispatch_bytes,
        round_payload_capacity_bytes=ROUND_PAYLOAD_BYTES, round_index=round_index,
        round_offset_bytes=round_offset, round_data_offset_bytes=data_offset,
        state_address=state, payload_address=state + STATE_BYTES,
        dispatch_address=state + STATE_BYTES + combine,
        workspace_address=state + DFX_OFFSET - workspace,
        cumsum_address=state + CUMSUM_OFFSET, cumsum_flags_address=state + CUMSUM_FLAG_OFFSET,
        peer_capacity_bytes=c.peer_bytes, required_peer_bytes=REQUIRED_PEER_BYTES,
        expert_ids_aligned_bytes=expert_ids, status_count_aligned=status_count,
        histogram_offset_bytes=status_count * 32,
        status_buffer_bytes=status_count * 32 + align_up(status_count * 4, 32),
        ub_budget_bytes=UB_BYTES, sender_ub_bytes=sender_ub, count_ub_bytes=count_ub,
        receive_fixed_ub_bytes=receive_fixed, receive_token_ub_bytes=receive_token,
    )
    rows = []
    for core in range(c.block_dim):
        values = dict(common, core=core, sender_role=int(core < send))
        values["native_profile_address"] = c.peer_base + DATA_OFFSET + DFX_OFFSET + core * 512
        values["route_start"] = core if core < send else 0
        values["route_stride"] = send if core < send else 0
        values["route_count"] = max(0, (c.tokens * c.top_k - 1 - core) // send + 1) if core < send else 0
        values["count_begin"], values["count_end"] = (
            split_range(c.experts, count_workers, core if small else core - send)
            if small or core >= send else (0, 0))
        values["cumsum_begin"], values["cumsum_end"] = (
            split_range(states, count, core - send) if core >= send else (0, 0))
        values["receive_begin"], values["receive_end"] = split_range(states, c.block_dim, core)
        rows.append([values.get(name, 0) for name in FIELD_NAMES])
    return rows
