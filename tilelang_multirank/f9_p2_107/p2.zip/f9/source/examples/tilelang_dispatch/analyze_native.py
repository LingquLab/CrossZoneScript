"""验收原生式Host批次；不把批末窗口检查伪装为逐次Host检查。"""
import argparse
import hashlib
import json
import math
from pathlib import Path
from .analyze_a5 import (check_diagnostics, check_outputs, equal_round_summary,
    load_record_files, read_csv, read_json, require, stats, summarize_capture, words,
    check_windows, Config, validate_config, validate_probe, fixture_shape, fixture_workload,
    output_sizes, validate_mapping)
from .run_native import profiler_task
from .analyze_pre_allreduce import check_pre_allreduce, profiler_context


def host_timeline(root, rank, iteration, profiling):
    rows = read_csv(root / 'host-timeline.csv')
    require(len(rows) == 1 and int(rows[0]['rank']) == rank and int(rows[0]['round']) == iteration,
            'Missing or duplicate measured Host timeline')
    row = rows[0]
    require(row['clock'] == 'CLOCK_MONOTONIC', 'Expected common Host clock')
    times = {k: int(v) for k, v in row.items() if k.endswith('_ns')}
    barriers = read_csv(root / 'native-barriers.csv')
    measured = [r for r in barriers if r['step'] == 'measured_ready']
    require(len(measured) == 1, 'Measured rank barrier missing')
    b = measured[0]
    enter, leave = int(b['enter_ns']), int(b['exit_ns'])
    require(b['clock'] == 'CLOCK_MONOTONIC' and int(b['rank']) == rank
            and 0 < enter <= leave <= times['event_start_enqueue_ns']
            <= times['launch_before_ns'] <= times['launch_after_ns'] <= times['sync_end_ns'],
            'Measured barrier/launch chronology invalid')
    if profiling:
        require(0 < times['capture_begin_ns'] <= times['capture_end_ns'] <= enter,
                'Capture initialization not completed before measured barrier')
    else:
        require(times['capture_begin_ns'] == times['capture_end_ns'] == 0,
                'Unexpected capture in correctness mode')
    return {'clock': 'CLOCK_MONOTONIC', 'barrier_enter_ns': enter, 'barrier_exit_ns': leave,
            **times, 'capture_id': row['capture_id']}


def check_warmup(root, fixture, warmup, rank, cores, probe, abi_version=1):
    shape = fixture_shape(fixture)
    tokens = shape['tokens']
    context = fixture_workload(fixture, rank)
    generations = []
    for i in range(warmup):
        prefix = root / f'round{i}'
        p = words(Path(str(prefix) + '.params.bin'), 'Q', 16)
        cfg = Config(tokens=p[0], hidden=p[1], top_k=p[2], experts=p[3], world_size=p[4],
                     rank=p[5], block_dim=p[6], magic=p[7], peer_base=p[8], peer_bytes=p[9])
        require(validate_config(cfg) == list(p) and p[:7] == (tokens, shape['hidden'], shape['topk'], shape['experts'], shape['world'], rank, cores),
                'Warmup parameter contract mismatch')
        generations.append(p[7])
        for name, size in output_sizes(shape, abi_version).items():
            actual = Path(str(prefix) + f'.actual_{name}.bin').read_bytes()
            expected = (fixture / f'expected_{name}.bin').read_bytes()
            require(len(actual) == size and actual[:len(expected)] == expected
                    and actual[len(expected):] == b'\xa5' * (size - len(expected)),
                    'Warmup output/sentinel mismatch')
        check_diagnostics(Path(str(prefix) + '.dispatch.diagnostics.bin'), cores, probe, tokens, context)
    require(all(b == a + 1 for a, b in zip(generations, generations[1:])),
            'Warmup generation progression mismatch')
    for bank in (0, 1):
        state = words(root / f'warmup.bank{bank}.state.bin', 'I', 262144)
        payload = words(root / f'warmup.bank{bank}.payload.bin', 'I', shape['experts'] * tokens * 256)
        check_windows(state, payload, cores, tokens, context)
    return generations


def analyze(directory, fixture, generated):
    directory, fixture, generated = map(Path, (directory, fixture, generated))
    run, execution = read_json(directory / 'run.json'), read_json(directory / 'execution.json')
    require(run['schema'] == 'tilelang_dispatch_native_run.v1' and execution['status'] == 'PASS',
            'Native execution not complete')
    require(run['process_lifecycle'] in ('fresh rank pair per round', 'fresh rank group per round'), 'Wrong process lifecycle')
    require(run['mode'] in ('capture', 'correctness') and run['warmup'] >= 1
            and len(run['devices']) == len(set(run['devices'])), 'Invalid native run configuration')
    require(run['rounds'] == len(execution['rounds']) and run['rounds'] > 0, 'Incomplete rounds')
    require([row.get('round') for row in execution['rounds']] == list(range(1, run['rounds']+1)),
            'Missing or duplicate execution round')
    case = read_json(fixture / 'case.json')
    require(run['fixture_hashes'] == case['hashes'], 'Run/fixture identity mismatch')
    for name, sha in case['hashes'].items():
        require(hashlib.sha256((fixture / name).read_bytes()).hexdigest() == sha, 'Fixture changed')
    shape = fixture_shape(fixture / 'rank0')
    tokens, world = shape['tokens'], shape['world']
    cores_by_rank = run.get('cores', [56, 64] if world == 2 else None)
    require(cores_by_rank is not None and len(cores_by_rank) == len(run['devices']) == world, 'Rank configuration mismatch')
    require(run.get('world_size', world) == world and run.get('experts', shape['experts']) == shape['experts'],
            'Run/fixture dimensions differ')
    profiling, warmup = run['mode'] == 'capture', run['warmup']
    all_captures, acl, device_us = ([[] for _ in range(world)] for _ in range(3))
    pairs, capture_ids = [], set()
    for number in range(1, run['rounds'] + 1):
        batch = directory / f'round{number}'
        status = read_json(batch / 'execution.json')
        require(status['status'] == 'PASS', 'Round execution failed')
        pair, magics, warmup_magics = [], [], []
        for rank, cores in enumerate(cores_by_rank):
            root = batch / f'rank{rank}'
            summary = read_json(root / 'summary.json')
            schedule = read_json(root / 'native-schedule.json')
            require(schedule['schema'] == 'tilelang_native_host_schedule.v1'
                    and schedule['rank'] == rank and schedule['warmup_iterations'] == warmup
                    and schedule['measured_round'] == warmup and schedule['launches'] == warmup + 1
                    and schedule['parent_per_iteration_control'] is False
                    and schedule['warmup_stream_syncs'] == 1, 'Native schedule mismatch')
            require(summary['rank'] == rank and summary['cores'] == cores
                    and summary['device'] == run['devices'][rank]
                    and summary['profiling'] == profiling
                    and summary['operator_correctness'] == summary['flags_cleared'] == 'PASS'
                    and summary['iterations'] == summary['verified_iterations'] == warmup + 1
                    and summary['measured_iterations'] == 1
                    and summary['capture_count'] == int(profiling), 'Rank summary invalid')
            warm = read_json(root / 'warmup-summary.json')
            require(warm['stream_syncs_during_batch'] == 1
                    and warm['per_iteration_flags'] == 'NOT_OBSERVED'
                    and warm['warmup_iterations'] == warmup and warm['validated_outputs'] == warmup
                    and warm['validated_diagnostics'] == warmup and warm['flags_cleared'] == 'PASS',
                    'Warmup output/diagnostic or batch-end window validation failed')
            rounds = read_csv(root / 'rounds.csv')
            require(len(rounds) == warmup + 1, 'Incomplete iteration records')
            for i, row in enumerate(rounds):
                require(int(row['round']) == i and int(row['measured']) == int(i == warmup)
                        and row['operator_correctness'] == 'PASS'
                        and row['flags_cleared'] == ('PASS' if i == warmup else 'NOT_OBSERVED'),
                        'Warmup window-check scope or measured result invalid')
            mapping = read_json(generated / f'rank{rank}/dispatch.ticks.json')
            abi_version = validate_mapping(mapping, shape, rank, cores)
            context = fixture_workload(fixture / f'rank{rank}', rank)
            magics.append(check_outputs(root, fixture / f'rank{rank}', warmup, rank, cores, abi_version))
            timings = read_csv(root / 'timing.csv')
            require(len(timings) == 1, 'Expected one measured timing per independent process')
            timing = timings[0]
            require(int(timing['round']) == warmup and int(timing['rank']) == rank
                    and int(timing['device']) == run['devices'][rank]
                    and int(timing['aiv_count']) == cores and int(timing['profiling']) == int(profiling)
                    and timing['module'] == 'dispatch'
                    and int(timing['magic']) == magics[-1] and timing['operator_correctness'] == 'PASS',
                    'Measured timing identity mismatch')
            event_us = float(timing['acl_event_us'])
            require(math.isfinite(event_us) and event_us > 0, 'Invalid ACL event duration')
            acl[rank].append(event_us)
            mapping = read_json(generated / f'rank{rank}/dispatch.ticks.json')
            require(mapping['rank'] == rank and mapping['cores'] == cores, 'Mapping identity mismatch')
            require(mapping.get('tokens_per_rank', 4) == tokens
                    and summary.get('tokens_per_rank', 4) == tokens, 'Host/export batch mismatch')
            if tokens != 4:
                for name in ('x', 'ids'):
                    require((root / f'input-readback.{name}.bin').read_bytes() ==
                            (fixture / f'rank{rank}/{name}.bin').read_bytes(),
                            'Uploaded device input readback differs from fixture')
            probe = mapping.get('count_ready_probe') == 'first_seen.v1'
            require(summary['ready_probe'] == probe, 'Probe ABI mismatch')
            warmup_magics.append(check_warmup(root, fixture / f'rank{rank}', warmup, rank, cores, probe, abi_version))
            barriers = read_csv(root / 'native-barriers.csv')
            require([b['step'] for b in barriers] == ['startup', 'warmup_ready', 'warmup_complete',
                    'measured_ready', 'measured_complete', 'validated'], 'Native barrier sequence mismatch')
            previous_exit = 0
            for barrier in barriers:
                enter, leave = int(barrier['enter_ns']), int(barrier['exit_ns'])
                require(barrier['clock'] == 'CLOCK_MONOTONIC' and int(barrier['rank']) == rank
                        and previous_exit <= enter <= leave and leave > 0, 'Barrier chronology mismatch')
                previous_exit = leave
            require(int(barriers[1]['exit_ns']) <= warm['batch_enqueue_begin_ns']
                    <= warm['batch_sync_end_ns'] <= int(barriers[2]['enter_ns']),
                    'Warmup batch outside its rank barriers')
            require(magics[-1] == warmup_magics[-1][-1] + 1, 'Measured generation mismatch')
            prefix = root / f'round{warmup}.dispatch'
            diagnostic_path = Path(str(prefix) + '.diagnostics.bin')
            diagnostics = check_diagnostics(diagnostic_path, cores, probe, tokens, context)
            host = host_timeline(root, rank, warmup, profiling)
            require(host['capture_id'] == timing['capture_id'], 'Host/capture identity mismatch')
            require(host['sync_end_ns'] <= int(barriers[4]['enter_ns']),
                    'Measured completion barrier preceded stream completion')
            row = {'rank': rank, 'cores': cores, 'acl_event_us': event_us, 'host_ns': host}
            if 'pre_allreduce' in run:
                require(run.get('common_hccl_warmup') is True, 'Missing common HCCL warmup')
                row['pre_allreduce'] = check_pre_allreduce(root, rank, warmup, magics[-1],
                    run['pre_allreduce'], host, event_us, world)
            if profiling:
                record = load_record_files([Path(str(prefix) + '.records')])[0]
                cid = str(record.capture_id)
                require(record.capture_id.int and cid not in capture_ids and cid == timing['capture_id'],
                        'Duplicate or invalid capture identity')
                capture_ids.add(cid)
                cap = summarize_capture(record, mapping, diagnostics)
                cap.update(iteration=warmup, round=number, operator_correctness='PASS',
                           performance_sample_accepted=True)
                all_captures[rank].append(cap)
                task = profiler_task(batch / f'prof-rank-{rank}', f'tilexr_tl_dispatch_r{rank}_c{cores}', warmup)
                require(task == status['profiler'][rank], 'Saved msprof match differs from actual CSV')
                device_us[rank].append(task['device_task_us'])
                row['device_task_us'] = task['device_task_us']
                if 'pre_allreduce' in run:
                    row['profiler_context'] = profiler_context(batch / f'prof-rank-{rank}',
                        f'tilexr_tl_dispatch_r{rank}_c{cores}')
                f5 = cap['lanes'][-1]['intervals']['F5.wait_count']
                row['F5_wait_ticks'] = f5['ticks']
                if probe:
                    raw = words(diagnostic_path, 'i', cores * 16)
                    first, mask = list(raw[-5:-1]), raw[-1]
                    validate_probe(first, mask, f5['ticks'])
                    row.update(first_seen_ticks=first, first_mask=mask,
                               count_polls=raw[(cores - 1) * 16 + 1])
            pair.append(row)
        require(all(value == magics[0] for value in magics) and all(value == warmup_magics[0] for value in warmup_magics),
                'Rank generation mismatch')
        reference = pair[0]['host_ns']['launch_before_ns']
        offsets = {str(row['rank']): row['host_ns']['launch_before_ns'] - reference for row in pair}
        pair_result = {'round': number, 'launch_rank_offsets_from_rank0_ns': offsets, 'ranks': pair}
        if world > 1:
            pair_result['launch_rank1_minus_rank0_ns'] = offsets['1']
        pairs.append(pair_result)
    ranks = []
    for rank, cores in enumerate(cores_by_rank):
        caps = all_captures[rank]
        ranks.append({'rank': rank, 'cores': cores, 'acl_event_us': stats(acl[rank]),
                      'acl_event_per_round_us': acl[rank],
                      'device_task_us': stats(device_us[rank]) if profiling else None,
                      'device_task_per_round_us': device_us[rank], 'captures': caps,
                      **{field: equal_round_summary(caps, field) if profiling else {}
                         for field in ('modules', 'functions', 'stages')}})
    return {'schema': 'tilelang_dispatch_native_analysis.v1', 'status': 'PASS',
            'mode': run['mode'], 'rounds': run['rounds'], 'warmup': warmup,
            'capture_checked': profiling, 'world_size': world, 'experts': shape['experts'],
            'warmup_validation': 'per-iteration outputs and diagnostics; shared flags only at batch end',
            'primary_time_source': run['primary_time_source'], 'rank_results': ranks, 'pairs': pairs,
            'device_clock_alignment': 'not calibrated; no subtraction across ranks/cores',
            'binaries': run['binaries'], 'device_binaries': run['device_binaries']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('run', 'fixture', 'generated', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.run, args.fixture, args.generated)
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'rounds': result['rounds'], 'mode': result['mode']}))


if __name__ == '__main__':
    main()
