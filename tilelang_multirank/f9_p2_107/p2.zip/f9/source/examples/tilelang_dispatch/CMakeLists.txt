cmake_minimum_required(VERSION 3.19)
project(TileLangDispatchIntegrated LANGUAGES CXX)
include(GNUInstallDirs)
if(NOT CMAKE_SYSTEM_NAME STREQUAL "Linux")
    message(FATAL_ERROR "The direct-launch runner requires Linux")
endif()
set(TL_CANN_ROOT "$ENV{ASCEND_HOME_PATH}" CACHE PATH "CANN 9.1 toolkit")
set(TL_BACKEND_ROOT "" CACHE PATH "Pinned TileLang Ascend backend with template submodules")
set(TL_COMM_PREFIX "" CACHE PATH "TileXR installation built from this source revision")
option(TL_PRE_ALLREDUCE_SUPPORT "Build optional Host pre-Dispatch HCCL A/B support" OFF)
option(TL_READY_PROBE "F5 first-seen diagnostic ABI, not performance optimization" OFF)
set(TL_TOKENS_PER_RANK 4 CACHE STRING "Balanced BF16 tokens per rank (4,16,64,256)")
if(NOT TL_TOKENS_PER_RANK MATCHES "^(4|16|64|256)$")
    message(FATAL_ERROR "Unsupported TL_TOKENS_PER_RANK")
endif()
# [AI] P/E are configuration values. Core counts are explicit physical-device
# launch choices, never inferred from a logical rank number.
set(TL_DISPATCH_WORLD_SIZE 2 CACHE STRING "Communicator world size")
set(TL_DISPATCH_EXPERTS 4 CACHE STRING "Global expert count")
set(TL_DISPATCH_CORES_PER_RANK "56;64" CACHE STRING "Semicolon-separated AIV counts in rank order")
if(NOT TL_DISPATCH_WORLD_SIZE MATCHES "^[1-9][0-9]*$" OR
   NOT TL_DISPATCH_EXPERTS MATCHES "^[1-9][0-9]*$")
    message(FATAL_ERROR "World size and expert count must be positive integers")
endif()
math(EXPR local_expert_remainder "${TL_DISPATCH_EXPERTS} % ${TL_DISPATCH_WORLD_SIZE}")
if(NOT local_expert_remainder EQUAL 0 OR TL_DISPATCH_EXPERTS LESS 2)
    message(FATAL_ERROR "Experts must divide evenly across ranks and support TopK=2")
endif()
list(LENGTH TL_DISPATCH_CORES_PER_RANK core_count)
if(NOT core_count EQUAL TL_DISPATCH_WORLD_SIZE)
    message(FATAL_ERROR "TL_DISPATCH_CORES_PER_RANK must provide exactly one count per rank")
endif()
if(TL_READY_PROBE AND (NOT TL_DISPATCH_WORLD_SIZE EQUAL 2 OR NOT TL_DISPATCH_EXPERTS EQUAL 4))
    message(FATAL_ERROR "Historical first_seen.v1 diagnostics require P2/E4")
endif()
math(EXPR last_rank "${TL_DISPATCH_WORLD_SIZE} - 1")
set(TL_GENERATED_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/generated" CACHE PATH "Reviewed instrumented exports")
get_filename_component(tilexr_root "${CMAKE_CURRENT_SOURCE_DIR}/../.." ABSOLUTE)
if(CMAKE_SYSTEM_PROCESSOR MATCHES "^(aarch64|arm64)$")
    set(host_arch aarch64)
elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "^(x86_64|AMD64)$")
    set(host_arch x86_64)
else()
    message(FATAL_ERROR "Unsupported Host architecture")
endif()
set(cann_arch "${TL_CANN_ROOT}/${host_arch}-linux")
find_path(acl_include acl/acl.h HINTS "${TL_CANN_ROOT}/include" "${cann_arch}/include" REQUIRED)
find_path(runtime_include runtime/kernel.h HINTS "${TL_CANN_ROOT}/include"
    "${cann_arch}/pkg_inc" "${cann_arch}/pkg_inc/runtime" REQUIRED)
find_library(acl_library ascendcl HINTS "${TL_CANN_ROOT}/lib64" "${cann_arch}/lib64" REQUIRED)
find_library(runtime_library runtime HINTS "${TL_CANN_ROOT}/lib64" "${cann_arch}/lib64" REQUIRED)
if(TL_PRE_ALLREDUCE_SUPPORT)
    find_path(hccl_include hccl/hccl.h HINTS "${TL_CANN_ROOT}/include" "${cann_arch}/include" REQUIRED)
    find_library(hccl_library hccl HINTS "${TL_CANN_ROOT}/lib64" "${cann_arch}/lib64" REQUIRED)
endif()
find_library(comm_library tile-comm HINTS "${TL_COMM_PREFIX}/lib64" "${TL_COMM_PREFIX}/lib" NO_DEFAULT_PATH REQUIRED)
if(TL_PRE_ALLREDUCE_SUPPORT)
    include("${CMAKE_CURRENT_SOURCE_DIR}/pre_allreduce_abi.cmake")
    tl_check_pre_allreduce_abi("${comm_library}")
endif()
find_program(bisheng bisheng HINTS "${TL_CANN_ROOT}/bin" "${TL_CANN_ROOT}/tools/bisheng_compiler/bin" REQUIRED)
find_program(device_linker NAMES ld.lld cce-ld HINTS "${TL_CANN_ROOT}/bin" "${TL_CANN_ROOT}/tools/bisheng_compiler/bin" REQUIRED)
foreach(header src/tl_templates/ascend/common.h 3rdparty/catlass/include/catlass/catlass.hpp 3rdparty/shmem/include/shmem.h)
    if(NOT EXISTS "${TL_BACKEND_ROOT}/${header}")
        message(FATAL_ERROR "Missing matching backend dependency: ${header}")
    endif()
endforeach()
if(IS_ABSOLUTE "${CMAKE_INSTALL_BINDIR}" OR IS_ABSOLUTE "${CMAKE_INSTALL_LIBDIR}")
    message(FATAL_ERROR "Relative installation directories are required")
endif()
file(RELATIVE_PATH kernel_relative "${CMAKE_INSTALL_FULL_BINDIR}" "${CMAKE_INSTALL_FULL_LIBDIR}/tilexr/kernels")
file(GLOB_RECURSE profile_headers CONFIGURE_DEPENDS "${tilexr_root}/src/include/tilexr/profiling/*.h")
file(GLOB_RECURSE backend_headers CONFIGURE_DEPENDS
    "${TL_BACKEND_ROOT}/src/tl_templates/*.h" "${TL_BACKEND_ROOT}/src/tl_templates/*.hpp"
    "${TL_BACKEND_ROOT}/3rdparty/catlass/include/*.h" "${TL_BACKEND_ROOT}/3rdparty/catlass/include/*.hpp"
    "${TL_BACKEND_ROOT}/3rdparty/shmem/include/*.h" "${TL_BACKEND_ROOT}/3rdparty/shmem/include/*.hpp"
    "${TL_BACKEND_ROOT}/3rdparty/shmem/src/device/*.h" "${TL_BACKEND_ROOT}/3rdparty/shmem/src/device/*.hpp")
foreach(rank RANGE ${last_rank})
    list(GET TL_DISPATCH_CORES_PER_RANK ${rank} cores)
    if(NOT cores MATCHES "^[1-9][0-9]*$" OR cores LESS 2)
        message(FATAL_ERROR "Each rank requires at least two explicitly configured AIV cores")
    endif()
    set(generated "${TL_GENERATED_ROOT}/rank${rank}")
    file(READ "${generated}/adaptation.json" adaptation)
    file(READ "${generated}/export.json" export_metadata)
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
        "${generated}/adaptation.json" "${generated}/export.json")
    string(JSON probe_mode ERROR_VARIABLE probe_error GET "${adaptation}" count_ready_probe)
    if(TL_READY_PROBE)
        if(probe_error OR NOT probe_mode STREQUAL "first_seen.v1")
            message(FATAL_ERROR "Diagnostic Host requires first_seen.v1 generated device code")
        endif()
        string(JSON expected_probe GET "${adaptation}" ready_probe_header_sha256)
        file(SHA256 "${CMAKE_CURRENT_SOURCE_DIR}/ready_probe.h" actual_probe)
        if(NOT actual_probe STREQUAL expected_probe)
            message(FATAL_ERROR "Ready probe header changed; regenerate diagnostic exports")
        endif()
    elseif(NOT probe_error)
        message(FATAL_ERROR "Diagnostic exports require TL_READY_PROBE=ON")
    endif()
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/ready_probe.h")
    string(JSON export_tokens ERROR_VARIABLE tokens_error GET "${export_metadata}" tokens_per_rank)
    if(tokens_error)
        set(export_tokens 4) # Historical T4 exports predate this specialization field.
    endif()
    if(NOT export_tokens EQUAL TL_TOKENS_PER_RANK)
        message(FATAL_ERROR "Host batch size differs from actual TileLang export")
    endif()
    foreach(field world_size experts rank cores)
        string(JSON export_${field} ERROR_VARIABLE field_error GET "${export_metadata}" ${field})
        if(field_error)
            message(FATAL_ERROR "Multirank ABI requires export metadata field: ${field}")
        endif()
    endforeach()
    if(NOT export_world_size EQUAL TL_DISPATCH_WORLD_SIZE OR
       NOT export_experts EQUAL TL_DISPATCH_EXPERTS OR
       NOT export_rank EQUAL rank OR NOT export_cores EQUAL cores)
        message(FATAL_ERROR "Configured P/E/rank/cores differ from actual TileLang export")
    endif()
    string(JSON abi_version ERROR_VARIABLE abi_version_error GET "${adaptation}" abi version)
    string(JSON abi_bytes ERROR_VARIABLE abi_error GET "${adaptation}" abi args_size)
    if(abi_error OR abi_version_error OR NOT abi_bytes EQUAL 104 OR NOT abi_version EQUAL 2)
        message(FATAL_ERROR "Host requires the reviewed 104-byte peer-table kernel ABI")
    endif()
    string(JSON source_count LENGTH "${export_metadata}" source_hashes)
    math(EXPR source_last "${source_count}-1")
    foreach(index RANGE ${source_last})
        string(JSON source MEMBER "${export_metadata}" source_hashes ${index})
        string(JSON expected GET "${export_metadata}" source_hashes "${source}")
        file(SHA256 "${tilexr_root}/${source}" actual)
        set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${tilexr_root}/${source}")
        if(NOT actual STREQUAL expected)
            message(FATAL_ERROR "TileLang source changed: ${source}; regenerate and review exports")
        endif()
    endforeach()
    foreach(profile 0 1)
        set(runner "tilelang_dispatch_integrated_r${rank}_profile${profile}")
        add_executable(${runner} runner.cpp)
        target_include_directories(${runner} PRIVATE "${tilexr_root}/src/include" "${acl_include}" "${runtime_include}" "${cann_arch}/pkg_inc")
        target_link_libraries(${runner} PRIVATE "${comm_library}" "${acl_library}" "${runtime_library}")
        if(TL_PRE_ALLREDUCE_SUPPORT)
            target_include_directories(${runner} PRIVATE "${hccl_include}")
            target_link_libraries(${runner} PRIVATE "${hccl_library}")
        endif()
        target_compile_definitions(${runner} PRIVATE TL_DISPATCH_RANK=${rank} TL_DISPATCH_CORES=${cores}
            TL_DISPATCH_TOKENS=${TL_TOKENS_PER_RANK}
            TL_DISPATCH_WORLD_SIZE=${TL_DISPATCH_WORLD_SIZE} TL_DISPATCH_EXPERTS=${TL_DISPATCH_EXPERTS}
            TL_PRE_ALLREDUCE_SUPPORT=$<BOOL:${TL_PRE_ALLREDUCE_SUPPORT}>
            TL_DISPATCH_PROFILE=${profile} TL_READY_PROBE=$<BOOL:${TL_READY_PROBE}> "TL_DISPATCH_KERNEL_DIR_RELATIVE=\"${kernel_relative}\"")
        get_filename_component(comm_libdir "${comm_library}" DIRECTORY)
        set_target_properties(${runner} PROPERTIES CXX_STANDARD 14 CXX_STANDARD_REQUIRED YES CXX_EXTENSIONS NO
            RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/${CMAKE_INSTALL_BINDIR}"
            INSTALL_RPATH "${comm_libdir};${TL_CANN_ROOT}/lib64;${cann_arch}/lib64")
        install(TARGETS ${runner} RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}")
        foreach(stage dispatch)
            foreach(suffix raw.cpp device.cpp)
                string(JSON expected GET "${adaptation}" hashes "${stage}.${suffix}")
                file(SHA256 "${generated}/${stage}.${suffix}" actual)
                set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${generated}/${stage}.${suffix}")
                if(NOT actual STREQUAL expected)
                    message(FATAL_ERROR "Generated source provenance mismatch: ${stage}.${suffix}")
                endif()
            endforeach()
            set(name "tilelang_${stage}_r${rank}_c${cores}_profile${profile}")
            set(kernel_dir "${CMAKE_CURRENT_BINARY_DIR}/${CMAKE_INSTALL_LIBDIR}/tilexr/kernels")
            set(kernel "${kernel_dir}/${name}.o")
            add_custom_command(OUTPUT "${kernel}"
                BYPRODUCTS "${kernel_dir}/${name}_rel.o"
                COMMAND ${CMAKE_COMMAND} -E make_directory "${kernel_dir}"
                COMMAND "${bisheng}" -xcce --cce-aicore-arch=dav-c310-vec --cce-aicore-only -std=gnu++17
                    -mllvm -cce-aicore-stack-size=0x8000 -mllvm -cce-aicore-function-stack-size=0x8000
                    -mllvm -cce-aicore-record-overflow=true -mllvm -cce-aicore-addr-transform
                    -mllvm -cce-aicore-dcci-insert-for-scalar=false
                    "-DTILEXR_ENABLE_PROFILING=${profile}" -DBACKEND_HYBM
                    "-I${tilexr_root}/src/include" "-I${TL_BACKEND_ROOT}/src" "-I${CMAKE_CURRENT_SOURCE_DIR}"
                    "-I${TL_BACKEND_ROOT}/3rdparty/catlass/include"
                    "-I${TL_BACKEND_ROOT}/3rdparty/shmem/include" "-I${TL_BACKEND_ROOT}/3rdparty/shmem/src/device"
                    "-I${TL_CANN_ROOT}/include" "-I${TL_CANN_ROOT}/pkg_inc" "-I${TL_CANN_ROOT}/pkg_inc/runtime"
                    "-I${TL_CANN_ROOT}/include/experiment/runtime" "-I${TL_CANN_ROOT}/include/experiment/msprof"
                    "-I${TL_CANN_ROOT}/pkg_inc/profiling"
                    "-I${TL_CANN_ROOT}/compiler/tikcpp" "-I${TL_CANN_ROOT}/compiler/tikcpp/tikcfw"
                    "-I${TL_CANN_ROOT}/compiler/tikcpp/tikcfw/impl" "-I${TL_CANN_ROOT}/compiler/tikcpp/tikcfw/interface"
                    "-I${cann_arch}/tikcpp" "-I${cann_arch}/tikcpp/tikcfw"
                    "-I${cann_arch}/tikcpp/tikcfw/impl" "-I${cann_arch}/tikcpp/tikcfw/interface"
                    "-I${cann_arch}/pkg_inc" "-I${cann_arch}/pkg_inc/runtime" "-I${cann_arch}/include"
                    "-I${cann_arch}/asc/include" "-I${cann_arch}/ascendc/include"
                    -O2 -c "${generated}/${stage}.device.cpp" -o "${kernel_dir}/${name}_rel.o"
                COMMAND "${device_linker}" -m aicorelinux -Ttext=0 "${kernel_dir}/${name}_rel.o"
                    --static --allow-multiple-definition -o "${kernel}"
                DEPENDS "${generated}/${stage}.device.cpp" "${CMAKE_CURRENT_SOURCE_DIR}/ready_probe.h" ${profile_headers} ${backend_headers}
                    "${tilexr_root}/src/include/tilexr/profiling.h"
                COMMAND_EXPAND_LISTS VERBATIM)
            add_custom_target(${name} DEPENDS "${kernel}")
            add_dependencies(${runner} ${name})
            install(FILES "${kernel}" "${kernel_dir}/${name}_rel.o" DESTINATION "${CMAKE_INSTALL_LIBDIR}/tilexr/kernels")
        endforeach()
    endforeach()
endforeach()
