/* Copyright (c) 2026 TileXR Project. CANN Open Software License Agreement v2.0. */
#ifndef TILEXR_TL_PRE_ALLREDUCE_H
#define TILEXR_TL_PRE_ALLREDUCE_H
#include "native_host_barrier.h"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
#ifndef TL_PRE_ALLREDUCE_SUPPORT
#define TL_PRE_ALLREDUCE_SUPPORT 0
#endif
#if TL_PRE_ALLREDUCE_SUPPORT
#include <hccl/hccl.h>
#include <hccl/hccl_comm.h>
#endif

namespace TileLangPreAllReduce {
// Initialization-only opaque bytes exchange. No root-info is logged or saved.
inline void Transfer(int fd, void *data, size_t size, bool sending)
{
    auto *bytes = static_cast<uint8_t *>(data);
    while (size) {
        ssize_t n;
        do { n = sending ? send(fd, bytes, size, MSG_NOSIGNAL) : recv(fd, bytes, size, 0); }
        while (n < 0 && errno == EINTR);
        TileLangNativeHost::Check(n > 0, "HCCL root exchange closed or timed out");
        bytes += n; size -= size_t(n);
    }
}
// [AI] Broadcast the same opaque root to all P-1 peers. These bytes never
// enter logs. world is a runtime communicator size, not an enumerated rank set.
inline void ExchangeRoot(int rank, int port, void *data, size_t size, int world = 2, int timeoutMs = 60000)
{
    using namespace TileLangNativeHost;
    Check(world > 0 && rank >= 0 && rank < world && data && size > 0 && timeoutMs > 0,
          "Invalid HCCL root exchange arguments");
    const auto address = Address(port);
    if (world == 1) return;
    if (rank == 0) {
        auto clients = AcceptRanks(port, world, timeoutMs);
        for (auto &peer : clients) {
            Transfer(peer->fd, data, size, true);
            uint8_t ack = 0; Transfer(peer->fd, &ack, 1, false);
            Check(ack == 1, "HCCL root exchange acknowledgement failed");
        }
    } else {
        Socket peer(Connect(address, timeoutMs)); SendRank(peer.fd, rank);
        Transfer(peer.fd, data, size, false);
        uint8_t ack = 1; Transfer(peer.fd, &ack, 1, true);
    }
}

#if TL_PRE_ALLREDUCE_SUPPORT
inline void Hccl(HcclResult result, const char *operation)
{
    if (result != HCCL_SUCCESS)
        throw std::runtime_error(std::string(operation) + ": " + std::to_string(int(result)));
}
inline void Acl(aclError result, const char *operation)
{
    if (result != ACL_SUCCESS)
        throw std::runtime_error(std::string(operation) + ": " + std::to_string(int(result)));
}
class Context {
public:
    void Initialize(int rank, int port, size_t warmup, int world = 2)
    {
        // CANN marks these entry points weak. Fail explicitly if unsupported.
        TileLangNativeHost::Check(HcclGetRootInfo && HcclCommInitRootInfoConfig && HcclCommDestroy,
                                 "CANN HCCL communicator entry points unavailable");
        HcclRootInfo root {};
        if (rank == 0) Hccl(HcclGetRootInfo(&root), "HcclGetRootInfo");
        ExchangeRoot(rank, port, &root, sizeof(root), world);
        HcclCommConfig config; HcclCommConfigInit(&config);
        config.hcclWorldRankID = uint32_t(rank);
        // Installed 107/950 official aiv_only config; qualified commEngine[4].
        config.hcclOpExpansionMode = 4;
        Hccl(HcclCommInitRootInfoConfig(uint32_t(world), &root, uint32_t(rank), &config, &comm_),
             "HcclCommInitRootInfoConfig AIV_ONLY4");
        Acl(aclrtMalloc(&send_, sizeof(int32_t), ACL_MEM_MALLOC_HUGE_FIRST), "HCCL send allocate");
        const int32_t one = 1;
        Acl(aclrtMemcpy(send_, sizeof(one), &one, sizeof(one), ACL_MEMCPY_HOST_TO_DEVICE), "HCCL send H2D");
        receives_.resize(warmup + 2, nullptr); // common warmup, per-launch warmups, measurement
        for (void *&receive : receives_) {
            Acl(aclrtMalloc(&receive, sizeof(int32_t), ACL_MEM_MALLOC_HUGE_FIRST), "HCCL receive allocate");
            Acl(aclrtMemset(receive, sizeof(int32_t), 0xA5, sizeof(int32_t)), "HCCL receive sentinel");
        }
    }
    void Submit(size_t index, aclrtStream stream)
    {
        Hccl(HcclAllReduce(send_, receives_.at(index), 1, HCCL_DATA_TYPE_INT32, HCCL_REDUCE_SUM,
                          comm_, stream), "HcclAllReduce enqueue");
    }
    int32_t Read(size_t index) const { return Download(receives_.at(index)); }
    int32_t ReadSend() const { return Download(send_); }
    void Close()
    {
        Hccl(HcclCommDestroy(comm_), "HcclCommDestroy"); comm_ = nullptr;
        for (void *receive : receives_) Acl(aclrtFree(receive), "HCCL receive free");
        receives_.clear(); Acl(aclrtFree(send_), "HCCL send free"); send_ = nullptr;
    }
private:
    static int32_t Download(void *ptr)
    {
        int32_t result = 0;
        Acl(aclrtMemcpy(&result, sizeof(result), ptr, sizeof(result), ACL_MEMCPY_DEVICE_TO_HOST),
            "HCCL validation D2H");
        return result;
    }
    HcclComm comm_ = nullptr;
    void *send_ = nullptr;
    std::vector<void *> receives_;
};
#endif
} // namespace TileLangPreAllReduce
#endif
