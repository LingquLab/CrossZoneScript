/* Copyright (c) 2026 TileXR Project. CANN Open Software License Agreement v2.0. */
#ifndef TILEXR_TL_NATIVE_HOST_BARRIER_H
#define TILEXR_TL_NATIVE_HOST_BARRIER_H
#include <arpa/inet.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <stdexcept>
#include <thread>
#include <vector>
#include <memory>
#include <cstdint>

// [AI] P-rank rendezvous: rank0 collects every distinct participant before release.
// A common readiness rendezvous, NOT simultaneous device kernel launch.
// Endpoint is explicit loopback+port; bounded socket waits preserve wire protocol.
namespace TileLangNativeHost {
class Socket {
public:
    explicit Socket(int value = -1) : fd(value) {}
    ~Socket() { if (fd >= 0) close(fd); }
    Socket(const Socket &) = delete;
    Socket &operator=(const Socket &) = delete;
    int fd;
};
inline void Check(bool ok, const char *operation)
{
    if (!ok) throw std::runtime_error(operation);
}
inline void Bound(int fd, int timeoutMs = 60000)
{
    timeval limit {}; limit.tv_sec = timeoutMs / 1000; limit.tv_usec = (timeoutMs % 1000) * 1000;
    Check(setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &limit, sizeof(limit)) == 0,
          "native barrier receive timeout setup");
    Check(setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &limit, sizeof(limit)) == 0,
          "native barrier send timeout setup");
}
inline void Exchange(int fd, bool server)
{
    char value = 1;
    ssize_t count;
    if (server) {
        do { count = recv(fd, &value, 1, MSG_WAITALL); } while (count < 0 && errno == EINTR);
        Check(count == 1 && value == 1, "native barrier arrival failed");
        do { count = send(fd, &value, 1, MSG_NOSIGNAL); } while (count < 0 && errno == EINTR);
        Check(count == 1, "native barrier release failed");
    } else {
        do { count = send(fd, &value, 1, MSG_NOSIGNAL); } while (count < 0 && errno == EINTR);
        Check(count == 1, "native barrier arrival send failed");
        value = 0;
        do { count = recv(fd, &value, 1, MSG_WAITALL); } while (count < 0 && errno == EINTR);
        Check(count == 1 && value == 1, "native barrier release receive failed");
    }
}
// [AI] Each accepted connection carries its logical rank, preventing duplicate
// clients from satisfying a missing rank. The endpoint is same-host loopback.
inline int Connect(const sockaddr_in &address, int timeoutMs)
{
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    do {
        Socket peer(socket(AF_INET, SOCK_STREAM, 0));
        Check(peer.fd >= 0, "rendezvous client socket failed");
        Bound(peer.fd, timeoutMs);
        if (connect(peer.fd, reinterpret_cast<const sockaddr *>(&address), sizeof(address)) == 0) {
            int result = peer.fd; peer.fd = -1; return result;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);
    throw std::runtime_error("rendezvous connect deadline");
}
inline sockaddr_in Address(int port)
{
    Check(port > 0 && port <= 65535, "Invalid rendezvous port");
    sockaddr_in address {}; address.sin_family = AF_INET;
    address.sin_port = htons(static_cast<uint16_t>(port));
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK); return address;
}
inline void SendRank(int fd, int rank)
{
    const uint32_t value = htonl(uint32_t(rank));
    const auto *bytes = reinterpret_cast<const uint8_t *>(&value);
    size_t remaining = sizeof(value);
    while (remaining) {
        ssize_t count;
        do { count = send(fd, bytes, remaining, MSG_NOSIGNAL); } while (count < 0 && errno == EINTR);
        Check(count > 0, "rendezvous rank send failed");
        bytes += count; remaining -= size_t(count);
    }
}
inline std::vector<std::unique_ptr<Socket>> AcceptRanks(int port, int world, int timeoutMs)
{
    const auto address = Address(port);
    Socket listener(socket(AF_INET, SOCK_STREAM, 0));
    Check(listener.fd >= 0, "rendezvous server socket failed");
    int reuse = 1;
    Check(setsockopt(listener.fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) == 0,
          "rendezvous server reuse failed");
    Check(bind(listener.fd, reinterpret_cast<const sockaddr *>(&address), sizeof(address)) == 0 &&
          listen(listener.fd, world) == 0, "rendezvous server listen failed");
    std::vector<std::unique_ptr<Socket>> clients(size_t(world - 1));
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    for (int accepted = 0; accepted < world - 1; ++accepted) {
        const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(
            deadline - std::chrono::steady_clock::now()).count();
        Check(remaining > 0, "rendezvous accept deadline");
        pollfd pending {listener.fd, POLLIN, 0}; int result;
        do { result = poll(&pending, 1, int(remaining)); } while (result < 0 && errno == EINTR);
        Check(result == 1 && (pending.revents & POLLIN), "rendezvous accept deadline");
        std::unique_ptr<Socket> peer(new Socket(accept(listener.fd, nullptr, nullptr)));
        Check(peer->fd >= 0, "rendezvous accept failed"); Bound(peer->fd, int(remaining));
        uint32_t identity = 0; ssize_t received;
        do { received = recv(peer->fd, &identity, sizeof(identity), MSG_WAITALL); }
        while (received < 0 && errno == EINTR);
        const uint32_t rank = ntohl(identity);
        Check(received == sizeof(identity) && rank > 0 && rank < uint32_t(world) && !clients[rank - 1],
              "rendezvous invalid or duplicate rank");
        clients[rank - 1] = std::move(peer);
    }
    // Close before releasing any participant, so its next stage cannot enter
    // this stage's backlog. Retained accepted sockets keep the peers alive.
    return clients;
}
inline void BarrierAll(int rank, int port, int world = 2, int timeoutMs = 60000)
{
    Check(world > 0 && rank >= 0 && rank < world && timeoutMs > 0, "Invalid native barrier ranks");
    const auto address = Address(port);
    if (world == 1) return;
    if (rank == 0) {
        auto clients = AcceptRanks(port, world, timeoutMs);
        // [AI] All clients send their arrival first. Release only after every
        // connection has arrived; releasing inside the accept loop is unsafe.
        for (auto &peer : clients) {
            char value = 0; ssize_t count;
            do { count = recv(peer->fd, &value, 1, MSG_WAITALL); } while (count < 0 && errno == EINTR);
            Check(count == 1 && value == 1, "native barrier arrival failed");
        }
        for (auto &peer : clients) {
            const char value = 1; ssize_t count;
            do { count = send(peer->fd, &value, 1, MSG_NOSIGNAL); } while (count < 0 && errno == EINTR);
            Check(count == 1, "native barrier release failed");
        }
    } else {
        Socket client(Connect(address, timeoutMs)); SendRank(client.fd, rank); Exchange(client.fd, false);
    }
}
} // namespace TileLangNativeHost
#endif
