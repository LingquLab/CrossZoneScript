"""集成 Dispatch 的布局字段、配置校验与 Host 描述符参考。

参数格式为 uint64[16]，参考描述符为 uint64[核数,64]；供 Host 验收与核内字段索引使用。
没有 X/expertIds 输入；地址只是数值，不表示已分配或映射通信窗口。
"""
from .layout_reference import (
    Config, FIELD_NAMES as M0_FIELDS, reference as m0_reference, align_up, split_range,
    DFX_OFFSET, CUMSUM_OFFSET, CUMSUM_FLAG_OFFSET, STATE_BYTES, ROUND_PAYLOAD_BYTES,
)

ABI_VERSION = 2
NATIVE_REVISION = "423a36f9cc126be7484b3d38f638fccfbf4da072"
CONTRACT = "dispatch-functional-v1"
FIELD_NAMES = (
    "abi_version", "rank", "core", "block_dim", "local_experts", "receive_states",
    "cumsum_cores", "send_cores", "count_workers", "small_batch", "feature_bytes",
    "feature_aligned_bytes", "record_blocks", "packed_payload_bytes", "record_bytes",
    "expert_window_bytes", "combine_reserve_bytes", "dispatch_bytes", "workspace_bytes",
    "status_count_aligned", "histogram_offset_bytes", "status_buffer_bytes",
    "state_address", "payload_address", "dispatch_address", "workspace_address",
    "hcopy_bytes", "expert_ids_aligned_bytes", "round_index", "peer_capacity_bytes",
    "required_round_payload_bytes", "round_payload_capacity_bytes", "send_rounds",
    "count_executed", "count_begin", "count_end", "count_tasks",
    "status_executed", "status_begin", "status_end", "status_tasks",
    "receive_executed", "receive_begin", "receive_end", "receive_tasks",
    "layout_executed", "send_round_executed", "required_peer_bytes", "ub_budget_bytes",
) + tuple(f"reserved_{i}" for i in range(49, 64))
F = {name: i for i, name in enumerate(FIELD_NAMES)}
STAGES = ("layout", "send_round", "count_split", "status_split", "receive_split")


def reference(config):
    """[AI] TL单前缀核布局，独立于原生多cumsum性能策略；不改变原生参考函数。"""
    # [AI] 基础地址/数据类型检查复用原生参考；TL本身的容量和分工见以下显式计算。
    old = m0_reference(config, single_cumsum=True, native_capacity=False)
    world, experts, cores = config.world_size, config.experts, config.block_dim
    stride = workspace_stride_words(experts)
    workspace = cores * stride * 4
    if workspace > 65504 or experts * 32 > 65504:
        raise ValueError('TL single-copy DMA byte capacity exceeded; split required for larger workspace/counts')
    if experts * 32 > DFX_OFFSET - workspace or CUMSUM_FLAG_OFFSET + cores * 32 > STATE_BYTES:
        raise ValueError('TL state/workspace/gate capacity exceeded')
    rows = []
    for row in old:
        m = dict(zip(M0_FIELDS, row))
        core = m['core']
        small = config.tokens < 48
        send = cores - 1
        workers = cores if small else 1
        count_begin, count_end = split_range(experts, workers, core if small else core - send) if small or core == send else (0, 0)
        recv_begin, recv_end = split_range(experts, cores, core)
        m.update(abi_version=ABI_VERSION, hcopy_bytes=m['feature_bytes'],
                 cumsum_cores=1, send_cores=send, count_workers=workers,
                 local_experts=experts // world, workspace_bytes=workspace,
                 workspace_address=m['state_address'] + DFX_OFFSET - workspace,
                 send_rounds=1, count_executed=int(count_end > count_begin),
                 count_begin=count_begin, count_end=count_end, count_tasks=count_end-count_begin,
                 status_executed=int(core == send), status_begin=0,
                 status_end=experts if core == send else 0, status_tasks=experts if core == send else 0,
                 receive_begin=recv_begin, receive_end=recv_end,
                 receive_executed=1, receive_tasks=recv_end-recv_begin,
                 layout_executed=1, send_round_executed=1)
        rows.append([m.get(name, 0) for name in FIELD_NAMES])
    return rows


def workspace_stride_words(experts):
    """[AI] 每核prefix副本32B对齐，GM行距与UB源行距使用同一值。"""
    return align_up(experts, 8)


def validate_dispatch_config(*, world_size, experts, rank, cores, tokens):
    """[AI] 不枚举rank数；按原生参数上限、整除、窗口和整数范围检查。"""
    cfg = Config(world_size=world_size, experts=experts, rank=rank, block_dim=cores, tokens=tokens)
    if cfg.hidden != 256 or cfg.top_k != 2:
        raise ValueError('This TL implementation is BF16 H256 Top-2')
    reference(cfg)
    # [AI] 当前DMA地址偏移与diagnostic字段为有符号int32，不允许静默截断。
    if max(experts * tokens * 256, experts * tokens * 3, experts * tokens * 1024) >= 2**31:
        raise ValueError('TL signed offset/diagnostic capacity exceeded')
    return cfg


def validate(config):
    reference(config)
    return config.words()


# [AI] 通信状态区使用原生固定分区；P/E变化通过容量校验，偏移以uint32元素为单位。
STATE_WORDS = 1024 * 1024 // 4
PAYLOAD_WORDS = 16384 // 4
CUMSUM_WORD = 868 * 1024 // 4
GATE_WORD = 876 * 1024 // 4
READY = 0x3F800000
