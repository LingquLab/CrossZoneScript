// Diagnostic only: first successful software observation, not peer arrival time.
#pragma once
#include <cstdint>
#if defined(__CCE_AICORE__)
#define TL_READY_INLINE __aicore__ inline
#else
#define TL_READY_INLINE inline
#endif
namespace TileLangDiagnostic {
struct ReadyProbe {
    uint64_t origin;
    uint32_t seen = 0;
    int32_t first[4] = {-1, -1, -1, -1};
    int32_t firstMask = -1;
    TL_READY_INLINE explicit ReadyProbe(uint64_t start) : origin(start) {}
    TL_READY_INLINE bool HasNew(uint32_t mask) const { return (mask & ~seen & 15U) != 0; }
    TL_READY_INLINE void Observe(uint32_t mask, uint64_t now)
    {
        if (firstMask < 0) firstMask = static_cast<int32_t>(mask & 15U);
        const uint32_t added = mask & ~seen & 15U;
        if (added) {
            const uint64_t delta = now - origin;
            const int32_t value = (now < origin || delta > UINT64_C(2147483647))
                ? -2 : static_cast<int32_t>(delta);
            for (uint32_t slot = 0; slot < 4; ++slot)
                if (added & (1U << slot)) first[slot] = value;
            seen |= added;
        }
    }
};
} // namespace TileLangDiagnostic
#undef TL_READY_INLINE
