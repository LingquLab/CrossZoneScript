/* Copyright (c) 2026 TileXR Project. CANN Open Software License Agreement v2.0. */
// One process/rank and exactly one registered Dispatch launch per iteration.
// Parent rendezvous only prepares rounds, validates completed kernels and ends
// both ranks safely; count/payload dependencies live inside the device kernel.
#include "native_host_barrier.h"
#include <tilexr_api.h>
#include <tilexr_types.h>
#include <tilexr/profiling.h>
#include <runtime/kernel.h>
#include "pre_allreduce.h"
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {
constexpr int kRank = TL_DISPATCH_RANK;
constexpr uint32_t kCores = TL_DISPATCH_CORES;
constexpr bool kProfile = TL_DISPATCH_PROFILE != 0;
constexpr bool kReadyProbe = TL_READY_PROBE != 0;
constexpr size_t kStateBytes = 1U << 20;
#ifndef TL_DISPATCH_TOKENS
#define TL_DISPATCH_TOKENS 4
#endif
#ifndef TL_DISPATCH_WORLD_SIZE
#define TL_DISPATCH_WORLD_SIZE 2
#endif
#ifndef TL_DISPATCH_EXPERTS
#define TL_DISPATCH_EXPERTS 4
#endif
constexpr size_t kWorld = TL_DISPATCH_WORLD_SIZE;
constexpr size_t kExperts = TL_DISPATCH_EXPERTS;
static_assert(kWorld > 0 && kWorld <= TileXR::TILEXR_MAX_RANK_SIZE,
              "World size exceeds the TileXR communicator interface");
static_assert(kExperts >= 2 && kExperts % kWorld == 0, "Experts must divide evenly across ranks");
constexpr size_t kLocalExperts = kExperts / kWorld;
constexpr size_t kPrefixStride = (kExperts + 7) / 8 * 8;
constexpr size_t kWorkspaceBytes = kCores * kPrefixStride * sizeof(uint32_t);
static_assert(kWorkspaceBytes <= 768 * 1024 && kExperts * 32 <= 768 * 1024 - kWorkspaceBytes,
              "Count slots overlap the prefix workspace");
static_assert(868 * 1024 + 32 <= 876 * 1024 && 876 * 1024 + kCores * 32 <= kStateBytes,
              "Cumsum/gate regions exceed the state window");
constexpr size_t kTokens = TL_DISPATCH_TOKENS;
static_assert(kTokens == 4 || kTokens == 16 || kTokens == 64 || kTokens == 256,
              "Supported balanced per-rank batch sizes: 4,16,64,256");
static_assert(kExperts <= size_t(INT32_MAX) / (kTokens * 256),
              "Payload word offsets exceed signed INT32 capacity");
constexpr size_t kXBytes = kTokens * 512;
constexpr size_t kIdsBytes = kTokens * 2 * sizeof(int32_t);
constexpr size_t kOutputBytes = kTokens * kWorld * kLocalExperts * 512;
constexpr size_t kAssistBytes = kTokens * kWorld * kLocalExperts * 3 * sizeof(int32_t);
constexpr size_t kCombineBytes = kTokens * 2048;
constexpr size_t kPayloadBytes = kTokens * kExperts * 1024;
constexpr uint64_t kGiB = UINT64_C(1) << 30;
constexpr uint8_t kSentinel = 0xA5;
constexpr const char *kStage = "dispatch";
constexpr uint32_t kRecordCapacity = 64;
constexpr size_t kDiagnosticWords = 16;
static_assert(kRank >= 0 && size_t(kRank) < kWorld && kCores >= 2,
              "Invalid configured rank/core count");
static_assert(!kReadyProbe || (kWorld == 2 && kExperts == 4),
              "Historical first-seen diagnostics require P2/E4");
static_assert((2U << 20) + kStateBytes + kCombineBytes + kPayloadBytes <= kGiB,
              "Dispatch windows exceed a communicator bank");

void Require(bool condition, const std::string &message)
{
    if (!condition) throw std::runtime_error(message);
}
void Require(bool condition, const char *message)
{
    if (!condition) throw std::runtime_error(message);
}
void Acl(aclError code, const char *operation)
{
    if (code != ACL_SUCCESS) throw std::runtime_error(std::string(operation) + ": " + std::to_string(code));
}
void Comm(int code, const char *operation)
{
    Require(code == TileXR::TILEXR_SUCCESS, std::string(operation) + ": " + std::to_string(code));
}
void Runtime(rtError_t code, const char *operation)
{
    if (code != RT_ERROR_NONE) throw std::runtime_error(std::string(operation) + ": " + std::to_string(code));
}
void Profile(const TileXR::Profiling::Status &status, const char *operation)
{
    Require(bool(status), std::string(operation) + ": " + status.message);
}
int Integer(const char *text)
{
    char *end = nullptr;
    errno = 0;
    const long value = std::strtol(text, &end, 10);
    Require(!errno && text != end && *end == '\0' && value >= 0 &&
            value <= std::numeric_limits<int>::max(), "Invalid nonnegative integer argument");
    return static_cast<int>(value);
}
void Reply(int fd, char value)
{
    ssize_t result;
    do { result = send(fd, &value, 1, MSG_NOSIGNAL); } while (result < 0 && errno == EINTR);
    Require(result == 1, "Control reply failed");
}
char Command(int fd)
{
    char value = 0;
    ssize_t result;
    do { result = recv(fd, &value, 1, 0); } while (result < 0 && errno == EINTR);
    Require(result == 1, "Control channel closed or failed");
    return value;
}
std::vector<uint8_t> Read(const std::string &path, size_t maximum, size_t exact = 0, bool allowEmpty = false)
{
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    const std::streamoff size = file ? std::streamoff(file.tellg()) : std::streamoff(-1);
    Require(size >= 0 && (size > 0 || allowEmpty) && uint64_t(size) <= maximum && (!exact || uint64_t(size) == exact),
            "Invalid file size: " + path);
    std::vector<uint8_t> bytes(static_cast<size_t>(size));
    if (bytes.empty()) return bytes;
    file.seekg(0);
    Require(bool(file.read(reinterpret_cast<char *>(bytes.data()), size)), "Read failed: " + path);
    return bytes;
}
void Write(const std::string &path, const void *data, size_t bytes)
{
    std::ofstream file(path, std::ios::binary);
    Require(bool(file.write(static_cast<const char *>(data), bytes)), "Write failed: " + path);
    file.close();
    Require(bool(file), "Close failed: " + path);
}
std::string KernelDirectory()
{
    std::array<char, 8192> buffer {};
    const ssize_t count = readlink("/proc/self/exe", buffer.data(), buffer.size());
    Require(count > 0 && size_t(count) < buffer.size(), "Executable path unavailable");
    const std::string path(buffer.data(), size_t(count));
    return path.substr(0, path.find_last_of('/') + 1) + TL_DISPATCH_KERNEL_DIR_RELATIVE;
}
template<class T> std::vector<T> Download(const void *device, size_t elements)
{
    std::vector<T> result(elements);
    Acl(aclrtMemcpy(result.data(), elements * sizeof(T), device, elements * sizeof(T),
                    ACL_MEMCPY_DEVICE_TO_HOST), "validation D2H");
    return result;
}

struct Args {
    void *params = nullptr, *x = nullptr, *ids = nullptr;
    void *peers = nullptr, *localState = nullptr, *localData = nullptr;
    void *output = nullptr, *assist = nullptr, *counts = nullptr, *expertNums = nullptr;
    void *diagnostics = nullptr;
    uint64_t fftsAddr = 0;
    void *profileGM = nullptr;
};
static_assert(sizeof(void *) == 8 && sizeof(Args) == 104 &&
              offsetof(Args, fftsAddr) == 88 && offsetof(Args, profileGM) == 96,
              "The registered kernel requires 11 GM pointers, uint64, and profile GM");
struct Kernel {
    uint8_t signature = 0;
    void *registration = nullptr;
    std::vector<uint8_t> binary;
    std::string symbol;
};
struct Timing { double eventUs = 0, hostUs = 0; };

uint64_t MonotonicNs()
{
    timespec value {};
    if (clock_gettime(CLOCK_MONOTONIC, &value) != 0) throw std::runtime_error("CLOCK_MONOTONIC failed");
    return uint64_t(value.tv_sec) * UINT64_C(1000000000) + uint64_t(value.tv_nsec);
}
struct Timeline {
    uint64_t prepareReceived = 0, readyReplyBefore = 0, launchCommandReceived = 0;
    uint64_t captureBegin = 0, captureEnd = 0, eventStartEnqueue = 0;
    uint64_t launchBefore = 0, launchAfter = 0, syncEnd = 0;
};

std::string CaptureId(const std::array<uint8_t, 16> &bytes)
{
    const char *digits = "0123456789abcdef";
    std::string result;
    for (size_t i = 0; i < bytes.size(); ++i) {
        if (i == 4 || i == 6 || i == 8 || i == 10) result += '-';
        result += digits[bytes[i] >> 4];
        result += digits[bytes[i] & 15];
    }
    return result;
}

class Runner {
public:
    Runner(int device, const std::string &fixture, const std::string &directory,
           const std::string &capturePlacement)
        : device_(device), fixture_(fixture), directory_(directory),
          captureBeforeReady_(capturePlacement == "before-k")
    {
        Require(capturePlacement == "before-k" || capturePlacement == "after-k", "Invalid capture placement");
    }

    void Initialize()
    {
        const uint16_t endian = 1;
        Require(*reinterpret_cast<const uint8_t *>(&endian) == 1, "Little-endian Host required");
        x_ = Read(fixture_ + "/x.bin", kXBytes, kXBytes);
        ids_ = Read(fixture_ + "/ids.bin", kIdsBytes, kIdsBytes);
        // [AI] Golden lengths follow the actual cumulative counts, including
        // empty destinations. Balanced two-rank 2T output is not a capacity rule.
        expected_[2] = Read(fixture_ + "/expected_counts.bin", kExperts * 4, kExperts * 4);
        expected_[3] = Read(fixture_ + "/expected_expert_nums.bin", kLocalExperts * 8, kLocalExperts * 8);
        slotRecords_.resize(kExperts);
        int32_t previous = 0;
        for (size_t slot = 0; slot < kExperts; ++slot) {
            int32_t total = 0; std::memcpy(&total, expected_[2].data() + slot * 4, 4);
            Require(total >= previous && size_t(total - previous) <= kTokens,
                    "Invalid golden cumulative receive counts");
            slotRecords_[slot] = size_t(total - previous); previous = total;
        }
        const size_t records = size_t(previous);
        Require(records <= kTokens * kWorld * kLocalExperts, "Golden output exceeds receive capacity");
        expected_[0] = Read(fixture_ + "/expected_output.bin", kOutputBytes, records * 512, records == 0);
        expected_[1] = Read(fixture_ + "/expected_assist.bin", kAssistBytes, records * 12, records == 0);
        Require(expected_[0].size() == records * 512 && expected_[1].size() == records * 12,
                "Golden feature/assist lengths differ from counts");
        for (size_t expert = 0; expert < kLocalExperts; ++expert) {
            int64_t actual = 0; std::memcpy(&actual, expected_[3].data() + expert * 8, 8);
            size_t count = 0;
            for (size_t source = 0; source < kWorld; ++source) count += slotRecords_[expert * kWorld + source];
            Require(actual >= 0 && uint64_t(actual) == count, "Golden per-expert counts disagree");
        }
        for (size_t token = 0; token < kTokens; ++token) {
            int32_t pair[2];
            std::memcpy(pair, ids_.data() + token * 2 * sizeof(int32_t), sizeof(pair));
            Require(pair[0] >= 0 && pair[1] >= 0 && size_t(pair[0]) < kExperts &&
                    size_t(pair[1]) < kExperts && pair[0] != pair[1],
                    "Expert IDs must be valid and TopK entries distinct");
        }
        Require(mkdir(directory_.c_str(), 0750) == 0, "Output directory must be new");
        timings_.open(directory_ + "/timing.csv");
        rounds_.open(directory_ + "/rounds.csv");
        timelineLog_.open(directory_ + "/host-timeline.csv");
        Require(bool(timelineLog_), "Cannot open host timeline");
        timelineLog_ << "round,magic,rank,placement,clock,prepare_received_ns,ready_reply_before_ns,"
            "k_received_ns,capture_begin_ns,capture_end_ns,event_start_enqueue_ns,"
            "launch_before_ns,launch_after_ns,sync_end_ns,capture_id\n";
        Require(bool(timings_) && bool(rounds_), "Cannot open timing/round logs");
        timings_ << "round,magic,device,rank,aiv_count,profiling,module,acl_event_us,host_launch_sync_us,capture_id,operator_correctness\n";
        rounds_ << "round,magic,measured,profiling,operator_correctness,flags_cleared\n";
        Acl(aclInit(nullptr), "aclInit");
        Acl(aclrtSetDevice(device_), "aclrtSetDevice");
        const char *soc = aclrtGetSocName();
        Require(soc && std::strncmp(soc, "Ascend950", 9) == 0, "Ascend950 required");
        Write(directory_ + "/soc.txt", soc, std::strlen(soc));
        int64_t cores = 0;
        Acl(aclrtGetDeviceInfo(uint32_t(device_), ACL_DEV_ATTR_VECTOR_CORE_NUM, &cores), "vector core count");
        Require(cores >= kCores, "Requested AIV count exceeds available device cores");
        Acl(aclrtCreateStream(&stream_), "create stream");
        Acl(aclrtCreateEvent(&start_), "create start event");
        Acl(aclrtCreateEvent(&end_), "create end event");
        Comm(TileXRCommInitRankLocal(kWorld, kRank, &comm_), "TileXRCommInitRankLocal");
        Comm(TileXRGetCommArgsHost(comm_, hostArgs_), "TileXRGetCommArgsHost");
        Require(hostArgs_ && hostArgs_->rank == kRank && hostArgs_->rankSize == kWorld &&
                hostArgs_->peerMemBytes >= 2 * kGiB, "Invalid communicator rank or peer capacity");
        for (size_t rank = 0; rank < kWorld; ++rank) {
            const uintptr_t base = reinterpret_cast<uintptr_t>(hostArgs_->peerMems[rank]);
            Require(base && base % 32 == 0 && base <= UINT64_MAX - hostArgs_->peerMemBytes,
                    "Invalid communicator peer mapping");
        }
        // Only initialize our own banks. Legacy mode waits for both R replies;
        // native mode uses its startup barrier before either rank can launch.
        for (int bank = 0; bank < 2; ++bank) {
            auto *state = hostArgs_->peerMems[kRank] + bank * kGiB + (2U << 20);
            Acl(aclrtMemset(state, kStateBytes, 0, kStateBytes), "initial own state clear");
            Acl(aclrtMemset(state + kStateBytes + kCombineBytes, kPayloadBytes, 0, kPayloadBytes),
                "initial own payload clear");
        }
        args_.params = Allocate(128);
        args_.peers = Allocate(kWorld * 2 * sizeof(uint64_t));
        args_.x = Allocate(kXBytes);
        args_.ids = Allocate(kIdsBytes);
        args_.output = Allocate(kOutputBytes);
        args_.assist = Allocate(kAssistBytes);
        args_.counts = Allocate(kExperts * sizeof(int32_t));
        args_.expertNums = Allocate(kLocalExperts * sizeof(int64_t));
        args_.diagnostics = Allocate(kCores * kDiagnosticWords * 4);
        Acl(aclrtMemcpy(args_.x, kXBytes, x_.data(), x_.size(), ACL_MEMCPY_HOST_TO_DEVICE), "X H2D");
        Acl(aclrtMemcpy(args_.ids, kIdsBytes, ids_.data(), ids_.size(), ACL_MEMCPY_HOST_TO_DEVICE), "expertIds H2D");
        {
            Kernel &kernel = kernel_;
            const std::string suffix = std::string(kStage) + "_r" + std::to_string(kRank) +
                                       "_c" + std::to_string(kCores);
            kernel.symbol = "tilexr_tl_" + suffix;
            kernel.binary = Read(KernelDirectory() + "/tilelang_" + suffix + "_profile" +
                                 std::to_string(int(kProfile)) + ".o", 67108864);
            rtDevBinary_t descriptor {};
            descriptor.magic = RT_DEV_BINARY_MAGIC_ELF_AIVEC;
            descriptor.data = kernel.binary.data();
            descriptor.length = kernel.binary.size();
            Runtime(rtDevBinaryRegister(&descriptor, &kernel.registration), "register device ELF");
            Runtime(rtFunctionRegister(kernel.registration, &kernel.signature,
                    kernel.symbol.c_str(), kernel.symbol.c_str(), 0), "register device function");
        }
        Acl(aclrtSynchronizeStream(stream_), "initialize synchronization");
        const auto xReadback = Download<uint8_t>(args_.x, kXBytes);
        const auto idsReadback = Download<uint8_t>(args_.ids, kIdsBytes);
        Write(directory_ + "/input-readback.x.bin", xReadback.data(), xReadback.size());
        Write(directory_ + "/input-readback.ids.bin", idsReadback.data(), idsReadback.size());
        Require(xReadback == x_ && idsReadback == ids_, "Uploaded input readback mismatch");
    }

    void NewRound(bool measured, uint64_t received)
    {
        Require(!active_ || verified_, "Previous iteration must pass V before a new round");
        PrepareRound(measured, received);
    }

    void PrepareRound(bool measured, uint64_t received)
    {
        timeline_ = Timeline{};
        timeline_.prepareReceived = received;
        Comm(TileXRCommNextMagic(comm_, &magic_), "TileXRCommNextMagic");
        Require(magic_ >= 0, "Negative communicator magic");
        round_ = started_++;
        measured_ = measured;
        active_ = true;
        verified_ = false;
        launched_ = false;
        pendingCaptureId_.clear();
        for (size_t rank = 0; rank < kWorld; ++rank) {
            state_[rank] = hostArgs_->peerMems[rank] + (uint64_t(magic_) % 2) * kGiB + (2U << 20);
            data_[rank] = state_[rank] + kStateBytes + kCombineBytes;
        }
        // [AI] Only addresses mapped in this process are exported. Each launch
        // owns its immutable GM table, because warmup kernels queue without sync.
        std::array<uint64_t, kWorld * 2> peers {};
        for (size_t rank = 0; rank < kWorld; ++rank) {
            peers[rank * 2] = reinterpret_cast<uintptr_t>(state_[rank]);
            peers[rank * 2 + 1] = reinterpret_cast<uintptr_t>(data_[rank]);
        }
        Acl(aclrtMemcpy(args_.peers, sizeof(peers), peers.data(), sizeof(peers), ACL_MEMCPY_HOST_TO_DEVICE),
            "peer address table H2D");
        args_.localState = state_[kRank]; args_.localData = data_[kRank];
        params_ = {{kTokens, 256, 2, kExperts, kWorld, uint64_t(kRank), kCores, uint64_t(magic_),
                    reinterpret_cast<uintptr_t>(hostArgs_->peerMems[kRank]),
                    hostArgs_->peerMemBytes, kTokens * kWorld, 0, 0, 0, 0, 0}};
        Acl(aclrtMemcpy(args_.params, 128, params_.data(), 128, ACL_MEMCPY_HOST_TO_DEVICE), "params H2D");
        for (const auto &item : std::array<std::pair<void *, size_t>, 5> {{{args_.output, kOutputBytes},
                {args_.assist, kAssistBytes}, {args_.counts, kExperts * 4}, {args_.expertNums, kLocalExperts * 8},
                {args_.diagnostics, kCores * kDiagnosticWords * 4}}}) {
            Acl(aclrtMemset(item.first, item.second, kSentinel, item.second), "local output sentinel");
        }
        if (measured_) Write(Prefix() + ".params.bin", params_.data(), 128);
        if (captureBeforeReady_) InitializeCapture();
        std::cout << "round=" << round_ << " magic=" << magic_ << " measured=" << measured_ << std::endl;
        timeline_.readyReplyBefore = MonotonicNs();
    }

    void RunDispatch(uint64_t received)
    {
        timeline_.launchCommandReceived = received;
        Require(active_ && !verified_ && !launched_, "Dispatch requires N/C then exactly one K then V");
        const bool captureEnabled = measured_ && kProfile;
        if (!captureBeforeReady_) InitializeCapture();
        Require(bool(capture_) == captureEnabled, "Capture preparation state mismatch");
        args_.profileGM = captureEnabled ? capture_->DeviceArgs() : nullptr;
        BeginMeasuredSegment();
        SubmitPreAllReduce(preAllReduceWarmup_ + 1, true);
        timeline_.eventStartEnqueue = MonotonicNs();
        if (measured_) Acl(aclrtRecordEvent(start_, stream_), "start event");
        const auto begin = std::chrono::steady_clock::now();
        rtArgsEx_t launchArgs {};
        launchArgs.args = &args_; launchArgs.argsSize = sizeof(args_);
        rtTaskCfgInfo_t config {}; config.schemMode = 1;
        timeline_.launchBefore = MonotonicNs();
        Runtime(rtKernelLaunchWithFlagV2(&kernel_.signature, kCores, &launchArgs,
                nullptr, static_cast<rtStream_t>(stream_), 0, &config), "launch integrated Dispatch");
        timeline_.launchAfter = MonotonicNs();
        if (measured_) Acl(aclrtRecordEvent(end_, stream_), "end event");
        Acl(aclrtSynchronizeStream(stream_), "Dispatch synchronization");
        timeline_.syncEnd = MonotonicNs();
        pendingTiming_.hostUs = std::chrono::duration<double, std::micro>(
            std::chrono::steady_clock::now() - begin).count();
        if (nativeMode_) NativeBarrier("measured_complete");
        if (measured_) {
            float milliseconds = 0;
            Acl(aclrtEventElapsedTime(&milliseconds, start_, end_), "event elapsed time");
            Require(std::isfinite(milliseconds) && milliseconds > 0, "Invalid ACL event interval");
            pendingTiming_.eventUs = double(milliseconds) * 1000;
        }
        ValidateMeasuredAllReduce();
        const std::string prefix = Prefix() + "." + kStage;
        const auto diagnostics = Download<int32_t>(args_.diagnostics, kCores * kDiagnosticWords);
        const bool passed = DiagnosticsPass(diagnostics);
        if (measured_ || !passed)
            Write(prefix + ".diagnostics.bin", diagnostics.data(), diagnostics.size() * sizeof(int32_t));
        if (captureEnabled) {
            Profile(capture_->Save(prefix + ".records"), "capture save");
            CheckCapture(capture_->Snapshot());
            pendingCaptureId_ = CaptureId(capture_->Snapshot()->captureId);
            Profile(capture_->Close(), "capture close");
            capture_.reset();
            ++captures_;
        }
        args_.profileGM = nullptr;
        if (!passed) {
            SaveActual();
            throw std::runtime_error(std::string(kStage) + ": device diagnostics/workload validation failed");
        }
        launched_ = true;
    }

    void Verify()
    {
        Require(active_ && !verified_ && launched_, "V requires one completed Dispatch kernel");
        const auto actual = Actual();
        const auto state = Download<uint32_t>(state_[kRank], kStateBytes / 4);
        const auto payload = Download<uint32_t>(data_[kRank], kPayloadBytes / 4);
        bool passed = true;
        for (size_t i = 0; i < actual.size(); ++i) {
            passed = std::equal(expected_[i].begin(), expected_[i].end(), actual[i].begin()) && passed;
            passed = std::all_of(actual[i].begin() + expected_[i].size(), actual[i].end(),
                                [](uint8_t byte) { return byte == kSentinel; }) && passed;
        }
        passed = FlagsCleared(state, payload) && passed;
        if (measured_ || !passed) SaveActual(actual, state, payload);
        Require(passed, "Output/golden, output tail, or consumed window flag validation failed; actual retained");
        verified_ = true;
        ++verifiedCount_;
        if (measured_) {
            ++measuredCount_;
            timelineLog_ << round_ << ',' << magic_ << ',' << kRank << ','
                << (captureBeforeReady_ ? "before-k" : "after-k") << ",CLOCK_MONOTONIC,"
                << timeline_.prepareReceived << ',' << timeline_.readyReplyBefore << ','
                << timeline_.launchCommandReceived << ',' << timeline_.captureBegin << ','
                << timeline_.captureEnd << ',' << timeline_.eventStartEnqueue << ','
                << timeline_.launchBefore << ',' << timeline_.launchAfter << ','
                << timeline_.syncEnd << ',' << pendingCaptureId_ << '\n';
            timelineLog_.flush();
            Require(bool(timelineLog_), "Host timeline write failed");
            timings_ << std::setprecision(17) << round_ << ',' << magic_ << ',' << device_ << ','
                     << kRank << ',' << kCores << ',' << int(kProfile) << ',' << kStage << ','
                     << pendingTiming_.eventUs << ',' << pendingTiming_.hostUs << ','
                     << pendingCaptureId_ << ",PASS\n";
            timings_.flush();
            Require(bool(timings_), "Timing log write failed");
        }
        rounds_ << round_ << ',' << magic_ << ',' << int(measured_) << ',' << int(measured_ && kProfile)
                << ",PASS,PASS\n";
        rounds_.flush();
        Require(bool(rounds_), "Round log write failed");
        std::cout << "round=" << round_ << " output=PASS flags=PASS" << std::endl;
    }

    void RunNative(int warmup, int barrierPort, const std::string &preAllReduce = "")
    {
        Require(warmup >= 1 && warmup <= 1000, "Native warmup count must be in [1,1000]");
        Require(barrierPort > 0 && barrierPort <= 65535, "Native barrier port outside TCP range");
        Require(captureBeforeReady_, "Native schedule requires capture before measured barrier");
        Require(preAllReduce.empty() || preAllReduce == "none" || preAllReduce == "allreduce",
                "Invalid pre-AllReduce mode");
        nativeMode_ = true; nativePort_ = barrierPort;
        preAllReduceMode_ = preAllReduce;
        preAllReduceWarmup_ = size_t(warmup);
        nativeStamps_.reserve(6);
        nativeBarriers_.open(directory_ + "/native-barriers.csv");
        Require(bool(nativeBarriers_), "Cannot open native barrier log");
        nativeBarriers_ << "step,rank,clock,enter_ns,exit_ns\n";
        InitializePreAllReduce();
        NativeBarrier("startup");
        struct Prepared {
            Args args;
            std::array<uint64_t, 16> params;
            std::array<uint8_t *, kWorld> state, data;
            int64_t magic;
            uint64_t round;
        };
        const Args measuredArgs = args_;
        std::vector<Prepared> batch;
        batch.reserve(size_t(warmup));
        // Every enqueued kernel owns immutable GM parameters, output and
        // diagnostics. No H2D, memset, D2H or per-iteration sync in the batch.
        for (int index = 0; index < warmup; ++index) {
            args_ = measuredArgs;
            args_.params = Allocate(128);
            args_.peers = Allocate(kWorld * 2 * sizeof(uint64_t));
            args_.output = Allocate(kOutputBytes);
            args_.assist = Allocate(kAssistBytes);
            args_.counts = Allocate(kExperts * sizeof(int32_t));
            args_.expertNums = Allocate(kLocalExperts * sizeof(int64_t));
            args_.diagnostics = Allocate(kCores * kDiagnosticWords * 4);
            PrepareRound(false, MonotonicNs());
            batch.push_back({args_, params_, state_, data_, magic_, round_});
        }
        NativeBarrier("warmup_ready");
        const uint64_t batchBegin = MonotonicNs();
        size_t preAllReduceIndex = 1;
        for (Prepared &iteration : batch) {
            SubmitPreAllReduce(preAllReduceIndex++, false);
            rtArgsEx_t launchArgs {};
            launchArgs.args = &iteration.args; launchArgs.argsSize = sizeof(Args);
            rtTaskCfgInfo_t config {}; config.schemMode = 1;
            Runtime(rtKernelLaunchWithFlagV2(&kernel_.signature, kCores, &launchArgs,
                    nullptr, static_cast<rtStream_t>(stream_), 0, &config), "native warmup launch");
        }
        Acl(aclrtSynchronizeStream(stream_), "native warmup batch synchronization");
        const uint64_t batchEnd = MonotonicNs();
        NativeBarrier("warmup_complete");
        ValidateWarmupAllReduce();
        for (const Prepared &iteration : batch) {
            args_ = iteration.args; params_ = iteration.params;
            state_ = iteration.state; data_ = iteration.data;
            magic_ = iteration.magic; round_ = iteration.round;
            const auto diagnostics = Download<int32_t>(args_.diagnostics, kCores * kDiagnosticWords);
            const auto actual = Actual();
            bool passed = DiagnosticsPass(diagnostics);
            for (size_t i = 0; i < actual.size(); ++i) {
                passed = std::equal(expected_[i].begin(), expected_[i].end(), actual[i].begin()) && passed;
                passed = std::all_of(actual[i].begin() + expected_[i].size(), actual[i].end(),
                                    [](uint8_t byte) { return byte == kSentinel; }) && passed;
            }
            Write(Prefix() + ".params.bin", params_.data(), 128);
            Write(Prefix() + ".dispatch.diagnostics.bin", diagnostics.data(), diagnostics.size() * 4);
            const std::array<const char *, 4> names {{"output", "assist", "counts", "expert_nums"}};
            for (size_t i = 0; i < names.size(); ++i)
                Write(Prefix() + ".actual_" + names[i] + ".bin", actual[i].data(), actual[i].size());
            Require(passed, "Native warmup output or diagnostics validation failed; batch evidence retained");
            ++verifiedCount_;
            rounds_ << round_ << ',' << magic_ << ",0,0,PASS,NOT_OBSERVED\n";
        }
        // These are batch-end observations, not invented per-iteration checks.
        for (int bank = 0; bank < 2; ++bank) {
            auto *state = hostArgs_->peerMems[kRank] + uint64_t(bank) * kGiB + (2U << 20);
            const auto stateWords = Download<uint32_t>(state, kStateBytes / 4);
            const auto payloadWords = Download<uint32_t>(state + kStateBytes + kCombineBytes, kPayloadBytes / 4);
            Write(directory_ + "/warmup.bank" + std::to_string(bank) + ".state.bin",
                  stateWords.data(), kStateBytes);
            Write(directory_ + "/warmup.bank" + std::to_string(bank) + ".payload.bin",
                  payloadWords.data(), kPayloadBytes);
            Require(FlagsCleared(stateWords, payloadWords), "Native warmup batch-end flags not cleared");
        }
        rounds_.flush(); Require(bool(rounds_), "Native warmup round log write failed");
        std::ofstream warmupSummary(directory_ + "/warmup-summary.json");
        warmupSummary << "{\"warmup_iterations\":" << warmup
            << ",\"validated_outputs\":" << warmup << ",\"validated_diagnostics\":" << warmup
            << ",\"flags_cleared\":\"PASS\",\"flag_scope\":\"both banks at batch end\","
            "\"per_iteration_flags\":\"NOT_OBSERVED\",\"params_storage\":\"immutable per launch\","
            "\"output_storage\":\"separate per iteration\",\"stream_syncs_during_batch\":1,"
            "\"batch_enqueue_begin_ns\":" << batchBegin << ",\"batch_sync_end_ns\":" << batchEnd << "}\n";
        warmupSummary.close(); Require(bool(warmupSummary), "Native warmup summary write failed");
        args_ = measuredArgs; verified_ = true;
        NewRound(true, MonotonicNs());
        NativeBarrier("measured_ready");
        RunDispatch(MonotonicNs()); // sync then measured_complete barrier before any D2H
        Verify();
        NativeBarrier("validated");
        FlushNativeBarriers();
        std::ofstream schedule(directory_ + "/native-schedule.json");
        schedule << "{\"schema\":\"tilelang_native_host_schedule.v1\",\"rank\":" << kRank
            << ",\"warmup_iterations\":" << warmup << ",\"measured_round\":" << warmup
            << ",\"world_size\":" << kWorld << ",\"experts\":" << kExperts
            << ",\"launches\":" << warmup + 1
            << ",\"barrier_protocol\":\"rank-tagged P-party arrival/release\","
            "\"barrier_endpoint\":\"loopback TCP\",\"capture_placement\":\"before measured_ready barrier\","
            "\"parent_per_iteration_control\":false,\"warmup_stream_syncs\":1,"
            "\"warmup_window_validation\":\"both banks at batch end only\","
            "\"measured_window_validation\":\"after measured_complete barrier\","
            "\"timeline_legacy_columns\":{\"placement\":\"before-k means before measured_ready\","
            "\"k_received_ns\":\"timestamp after measured_ready; no K command exists\"},"
            "\"remaining_differences\":[\"immutable per-launch params and separate warmup outputs\","
            "\"TileXR capture and ACL auxiliary events\",\"full TL kernel implementation remains unchanged\"]}\n";
        schedule.close(); Require(bool(schedule), "Native schedule write failed");
        SaveAllReduceEvidence();
        Finish();
    }

    void SaveFailureBarrierEvidence() noexcept
    {
        if (!nativeMode_) return;
        try { FlushNativeBarriers(); } catch (...) { /* preserve original failure */ }
    }

    void Finish()
    {
        Require(active_ && verified_ && verifiedCount_ == started_, "Q requires all iterations verified");
        Acl(aclrtSynchronizeStream(stream_), "final synchronization");
        ClosePreAllReduce();
        // Legacy Q or native validated barrier ensures both ranks have finished.
        // Never destroy peer mappings on an error while a peer may use them.
        for (void *buffer : allocations_) Acl(aclrtFree(buffer), "free local buffer");
        Runtime(rtDevBinaryUnRegister(kernel_.registration), "unregister ELF");
        Comm(TileXRCommDestroy(comm_), "destroy communicator");
        Acl(aclrtDestroyEvent(start_), "destroy start event");
        Acl(aclrtDestroyEvent(end_), "destroy end event");
        Acl(aclrtDestroyStream(stream_), "destroy stream");
        Acl(aclFinalize(), "aclFinalize");
        timings_.close(); rounds_.close(); timelineLog_.close();
        if (nativeMode_) { nativeBarriers_.close(); Require(bool(nativeBarriers_), "Barrier log close failed"); }
        Require(bool(timelineLog_), "Host timeline close failed");
        Require(bool(timings_) && bool(rounds_), "Log close failed");
        std::ofstream summary(directory_ + "/summary.json");
        summary << "{\n  \"ready_probe\": " << (kReadyProbe ? "true" : "false")
                << ", \"capture_placement\": \"" << (captureBeforeReady_ ? "before-k" : "after-k")
                << "\",\n  \"rank\": " << kRank << ", \"device\": " << device_
                << ", \"world_size\": " << kWorld << ", \"experts\": " << kExperts
                << ", \"tokens_per_rank\": " << kTokens << ", \"cores\": " << kCores << ", \"profiling\": " << (kProfile ? "true" : "false")
                << ",\n  \"iterations\": " << started_ << ", \"verified_iterations\": " << verifiedCount_
                << ", \"measured_iterations\": " << measuredCount_
                << ", \"warmup_iterations\": " << started_ - measuredCount_
                << ",\n  \"capture_count\": " << captures_
                << ", \"operator_correctness\": \"PASS\", \"flags_cleared\": \"PASS\","
                << "\n  \"observation\": \"integrated\", \"transport\": \"TileXR IPC device peer transfer\","
                << "\n  \"schedule\": \"" << (nativeMode_ ?
                    "native Host barriers; continuous warmup queue then one measured kernel" :
                    "one kernel per rank; only round-level Host rendezvous") << "\""
                << ",\n  \"flags_validation_scope\": \"" << (nativeMode_ ?
                    "both banks at warmup batch end; measured bank after completion barrier" :
                    "each completed iteration") << "\"\n}\n";
        summary.close();
        Require(bool(summary), "Summary write failed");
    }

private:
    void InitializePreAllReduce()
    {
        if (preAllReduceMode_.empty()) return;
#if TL_PRE_ALLREDUCE_SUPPORT
        preAllReduce_.Initialize(kRank, nativePort_, preAllReduceWarmup_, kWorld);
        Acl(aclrtCreateEvent(&segmentStart_), "segment event create");
        allReduceResults_.reserve(preAllReduceWarmup_ + 2);
        // Both A and B pay the same initial HCCL warmup before Dispatch warmups.
        preAllReduce_.Submit(0, stream_);
        Acl(aclrtSynchronizeStream(stream_), "common HCCL warmup synchronize");
        const int32_t value = preAllReduce_.Read(0);
        allReduceResults_.push_back(value);
        Write(directory_ + "/allreduce-results.bin", allReduceResults_.data(), sizeof(int32_t));
        const int32_t sent = preAllReduce_.ReadSend();
        Write(directory_ + "/allreduce-send.bin", &sent, sizeof(sent));
        Require(sent == 1 && value == int32_t(kWorld), "Common HCCL warmup/send result mismatch");
        commonWarmupCompleted_ = MonotonicNs();
        allReducePrepared_ = MonotonicNs();
#else
        throw std::runtime_error("TL_PRE_ALLREDUCE_SUPPORT is disabled");
#endif
    }
    void SubmitPreAllReduce(size_t index, bool measured)
    {
        if (preAllReduceMode_ != "allreduce") return;
#if TL_PRE_ALLREDUCE_SUPPORT
        if (measured) allReduceBefore_ = MonotonicNs();
        preAllReduce_.Submit(index, stream_);
        if (measured) allReduceAfter_ = MonotonicNs();
#else
        (void)index; (void)measured;
#endif
    }
    void ValidateWarmupAllReduce()
    {
        if (preAllReduceMode_ != "allreduce") return;
#if TL_PRE_ALLREDUCE_SUPPORT
        bool passed = true;
        for (size_t i = 1; i <= preAllReduceWarmup_; ++i) {
            const int32_t value = preAllReduce_.Read(i);
            allReduceResults_.push_back(value);
            passed = (value == int32_t(kWorld)) && passed;
        }
        Write(directory_ + "/allreduce-results.bin", allReduceResults_.data(),
              allReduceResults_.size() * sizeof(int32_t));
        Require(passed, "Pre-Dispatch warmup AllReduce result mismatch");
#endif
    }
    void BeginMeasuredSegment()
    {
        if (preAllReduceMode_.empty()) return;
        segmentStartEnqueue_ = MonotonicNs();
        Acl(aclrtRecordEvent(segmentStart_, stream_), "segment start event");
    }
    void ValidateMeasuredAllReduce()
    {
        if (preAllReduceMode_.empty()) return;
#if TL_PRE_ALLREDUCE_SUPPORT
        float milliseconds = 0, beforeDispatch = 0;
        Acl(aclrtEventElapsedTime(&milliseconds, segmentStart_, end_), "segment elapsed time");
        Acl(aclrtEventElapsedTime(&beforeDispatch, segmentStart_, start_), "pre-Dispatch elapsed time");
        Require(std::isfinite(milliseconds) && milliseconds > 0 &&
                std::isfinite(beforeDispatch) && beforeDispatch >= 0, "Invalid segment event interval");
        segmentEventUs_ = double(milliseconds) * 1000;
        preDispatchEventUs_ = double(beforeDispatch) * 1000;
        if (preAllReduceMode_ == "allreduce") {
            const int32_t value = preAllReduce_.Read(preAllReduceWarmup_ + 1);
            allReduceResults_.push_back(value);
            Write(directory_ + "/allreduce-results.bin", allReduceResults_.data(),
                  allReduceResults_.size() * sizeof(int32_t));
            Require(value == int32_t(kWorld), "Measured pre-Dispatch AllReduce result mismatch");
        }
        Require(preAllReduce_.ReadSend() == 1, "AllReduce send input changed");
        allReduceValidation_ = MonotonicNs();
#endif
    }
    void SaveAllReduceEvidence()
    {
        if (preAllReduceMode_.empty()) return;
        const bool enabled = preAllReduceMode_ == "allreduce";
        std::ofstream csv(directory_ + "/allreduce.csv");
        csv << "round,magic,rank,mode,segment_event_us,dispatch_event_us,pre_dispatch_event_us,"
            "segment_start_enqueue_ns,allreduce_before_ns,allreduce_after_ns,dispatch_launch_before_ns,"
            "dispatch_launch_after_ns,segment_sync_end_ns,validation_ns,allreduce_result\n";
        csv << std::setprecision(17) << round_ << ',' << magic_ << ',' << kRank << ',' << preAllReduceMode_
            << ',' << segmentEventUs_ << ',' << pendingTiming_.eventUs << ',' << preDispatchEventUs_
            << ',' << segmentStartEnqueue_ << ',' << allReduceBefore_ << ',' << allReduceAfter_
            << ',' << timeline_.launchBefore << ',' << timeline_.launchAfter << ',' << timeline_.syncEnd
            << ',' << allReduceValidation_ << ',' << (enabled ? std::to_string(kWorld) : "NOT_RUN") << '\n';
        csv.close(); Require(bool(csv), "AllReduce CSV write failed");
        std::ofstream schedule(directory_ + "/allreduce-schedule.json");
        schedule << "{\"schema\":\"tilelang_pre_allreduce.v1\",\"mode\":\"" << preAllReduceMode_
            << "\",\"rank\":" << kRank << ",\"world_size\":" << kWorld << ",\"count\":1,\"dtype\":\"INT32\",\"reduction\":\"SUM\","
            "\"send_value\":1,\"expected_sum\":" << kWorld << ",\"common_warmup_result\":" << kWorld << ","
            "\"warmup_pre_allreduce_launches\":" << (enabled ? preAllReduceWarmup_ : 0)
            << ",\"validated_warmup_results\":" << (enabled ? preAllReduceWarmup_ : 0)
            << ",\"measured_pre_allreduce_launches\":" << int(enabled)
            << ",\"same_stream\":true,\"common_warmup_completed_ns\":" << commonWarmupCompleted_
            << ",\"preparation_completed_ns\":" << allReducePrepared_
            << ",\"result_order\":\"common, then B warmups and measurement\","
            "\"pre_dispatch_event_scope\":\"segment start to Dispatch start; A contains marker overhead only\"}\n";
        schedule.close(); Require(bool(schedule), "AllReduce schedule write failed");
    }
    void ClosePreAllReduce()
    {
        if (preAllReduceMode_.empty()) return;
#if TL_PRE_ALLREDUCE_SUPPORT
        preAllReduce_.Close();
        Acl(aclrtDestroyEvent(segmentStart_), "segment event destroy"); segmentStart_ = nullptr;
#endif
    }

    struct BarrierStamp { std::string step; uint64_t enter, exit; };
    void NativeBarrier(const std::string &step)
    {
        // Keep the measured barrier-to-launch path free of file I/O. On
        // failure, exit=0 records an entered but uncompleted rendezvous.
        nativeStamps_.push_back({step, MonotonicNs(), 0});
        TileLangNativeHost::BarrierAll(kRank, nativePort_, kWorld);
        nativeStamps_.back().exit = MonotonicNs();
    }
    void FlushNativeBarriers()
    {
        for (const auto &stamp : nativeStamps_)
            nativeBarriers_ << stamp.step << ',' << kRank << ",CLOCK_MONOTONIC,"
                            << stamp.enter << ',' << stamp.exit << '\n';
        nativeBarriers_.flush();
        Require(bool(nativeBarriers_), "Native barrier log write failed");
    }
    bool FlagsCleared(const std::vector<uint32_t> &state, const std::vector<uint32_t> &payload) const
    {
        bool passed = true;
        for (size_t slot = 0; slot < kExperts; ++slot) passed = (state[slot * 8] == 0) && passed;
        for (size_t i = 0; i < 8; ++i) passed = (state[868 * 1024 / 4 + i] == 0) && passed;
        for (size_t i = 0; i < kCores * 8; ++i) passed = (state[876 * 1024 / 4 + i] == 0) && passed;
        // [AI] q orders expert then source; payload buckets rotate by destination.
        // Validate consumed records only; unconsumed tail bytes are not flags.
        for (size_t q = 0; q < kExperts; ++q) {
            const size_t source = q % kWorld, localExpert = q / kWorld;
            const size_t bucket = ((source + kRank) % kWorld) * kLocalExperts + localExpert;
            for (size_t token = 0; token < slotRecords_[q]; ++token)
                for (size_t block = 0; block < 2; ++block)
                    for (size_t word = 0; word < 8; ++word)
                        passed = (payload[bucket * kTokens * 256 + token * 256 + block * 128 + 120 + word] == 0) && passed;
        }
        return passed;
    }
    bool DiagnosticsPass(const std::vector<int32_t> &diagnostics) const
    {
        bool passed = true;
        for (uint32_t core = 0; core < kCores; ++core) {
            const size_t row = core * kDiagnosticWords;
            const size_t workers = kTokens < 48 ? kCores : 1;
            const size_t worker = kTokens < 48 ? core : 0;
            const uint32_t countTasks = kTokens < 48 || core == kCores - 1 ?
                uint32_t(kExperts / workers + (worker < kExperts % workers)) : 0;
            const uint32_t sent = core < kCores - 1 && core < kTokens * 2 ?
                uint32_t((kTokens * 2 - 1 - core) / (kCores - 1) + 1) : 0U;
            const bool prefixWorker = core == kCores - 1;
            const size_t receiveBegin = kExperts / kCores * core + std::min(size_t(core), kExperts % kCores);
            const size_t receiveTasks = kExperts / kCores + (core < kExperts % kCores);
            size_t received = 0;
            for (size_t q = receiveBegin; q < receiveBegin + receiveTasks; ++q) received += slotRecords_[q];
            bool valid = diagnostics[row] == 0 &&
                diagnostics[row + 4] == int(countTasks) &&
                diagnostics[row + 5] == int(sent) &&
                diagnostics[row + 6] == (prefixWorker ? int(kExperts) : 0) &&
                diagnostics[row + 7] == int(received) &&
                diagnostics[row + 8] == int(receiveTasks) &&
                diagnostics[row + 9] == int(sent * 1024) &&
                diagnostics[row + 10] == int(received * 1024) &&
                (prefixWorker ? diagnostics[row + 1] > 0 : diagnostics[row + 1] == 0) &&
                diagnostics[row + 2] > 0 &&
                (received ? diagnostics[row + 3] > 0 : diagnostics[row + 3] == 0);
            if (kReadyProbe && prefixWorker) {
                for (size_t field = 11; field < 15; ++field)
                    valid = (diagnostics[row + field] >= 0) && valid; // -1 unseen / -2 overflow fails
                valid = (diagnostics[row + 15] >= 0 && diagnostics[row + 15] <= 15) && valid;
            } else {
                for (size_t field = 11; field < kDiagnosticWords; ++field)
                    valid = (diagnostics[row + field] == 0) && valid;
            }
            if (!valid) {
                std::cerr << "dispatch core=" << core << " error=" << diagnostics[row]
                          << " diagnostics/workload mismatch\n";
                passed = false;
            }
        }
        return passed;
    }
    void InitializeCapture()
    {
        Require(!capture_, "Capture from previous round still active");
        if (!(measured_ && kProfile)) return;
        timeline_.captureBegin = MonotonicNs();
        capture_.reset(new TileXR::Profiling::AclCapture);
        TileXR::Profiling::CaptureConfig config;
        config.rank = kRank;
        config.logicalStreamCount = kCores;
        config.recordsPerStream = kRecordCapacity;
        // Initialize performs synchronous preparation; before-k's D follows its completion.
        Profile(capture_->Initialize(config, stream_), "capture initialize");
        timeline_.captureEnd = MonotonicNs();
    }
    using ActualBuffers = std::array<std::vector<uint8_t>, 4>;
    void *Allocate(size_t size)
    {
        void *ptr = nullptr;
        Acl(aclrtMalloc(&ptr, size, ACL_MEM_MALLOC_HUGE_FIRST), "allocate local buffer");
        allocations_.push_back(ptr);
        return ptr;
    }
    std::string Prefix() const { return directory_ + "/round" + std::to_string(round_); }
    ActualBuffers Actual() const
    {
        return {{Download<uint8_t>(args_.output, kOutputBytes), Download<uint8_t>(args_.assist, kAssistBytes),
                 Download<uint8_t>(args_.counts, kExperts * 4), Download<uint8_t>(args_.expertNums, kLocalExperts * 8)}};
    }
    void SaveActual()
    {
        SaveActual(Actual(), Download<uint32_t>(state_[kRank], kStateBytes / 4),
                   Download<uint32_t>(data_[kRank], kPayloadBytes / 4));
    }
    void SaveActual(const ActualBuffers &actual, const std::vector<uint32_t> &state,
                    const std::vector<uint32_t> &payload)
    {
        const std::array<const char *, 4> names {{"output", "assist", "counts", "expert_nums"}};
        Write(Prefix() + ".params.bin", params_.data(), 128);
        for (size_t i = 0; i < names.size(); ++i)
            Write(Prefix() + ".actual_" + names[i] + ".bin", actual[i].data(), actual[i].size());
        Write(Prefix() + ".state.bin", state.data(), state.size() * 4);
        Write(Prefix() + ".payload.bin", payload.data(), payload.size() * 4);
    }
    void CheckCapture(const TileXR::Profiling::CaptureSnapshot *snapshot) const
    {
        Require(snapshot && snapshot->streams.size() == kCores, "Missing capture lanes");
        for (uint32_t core = 0; core < kCores; ++core) {
            const auto &lane = snapshot->streams[core];
            Require(lane.id == ((uint32_t(kRank) << 16) | core) && lane.complete && lane.dropped == 0 &&
                    lane.records.size() >= 2 && lane.records.size() <= kRecordCapacity, "Invalid capture lane");
            Require(lane.records.front().eventId == 1 && lane.records.back().eventId == 2 &&
                    lane.records.back().timestamp > lane.records.front().timestamp, "Invalid Dispatch interval");
            for (size_t i = 1; i < lane.records.size(); ++i)
                Require(lane.records[i].timestamp >= lane.records[i - 1].timestamp, "Nonmonotonic raw ticks");
        }
    }
    int device_;
    std::string fixture_, directory_;
    TileXRCommPtr comm_ = nullptr;
    TileXR::CommArgs *hostArgs_ = nullptr;
    aclrtStream stream_ = nullptr;
    aclrtEvent start_ = nullptr, end_ = nullptr;
    Args args_;
    Kernel kernel_;
    std::vector<void *> allocations_;
    std::vector<uint8_t> x_, ids_;
    ActualBuffers expected_;
    std::array<uint64_t, 16> params_ {};
    std::array<uint8_t *, kWorld> state_ {}, data_ {};
    std::vector<size_t> slotRecords_;
    std::unique_ptr<TileXR::Profiling::AclCapture> capture_;
    Timing pendingTiming_;
    std::string pendingCaptureId_;
    std::ofstream timings_, rounds_, timelineLog_;
    Timeline timeline_;
    std::string preAllReduceMode_;
    size_t preAllReduceWarmup_ = 0;
    aclrtEvent segmentStart_ = nullptr;
    uint64_t commonWarmupCompleted_ = 0, allReducePrepared_ = 0;
    uint64_t segmentStartEnqueue_ = 0, allReduceBefore_ = 0, allReduceAfter_ = 0, allReduceValidation_ = 0;
    double segmentEventUs_ = 0, preDispatchEventUs_ = 0;
    std::vector<int32_t> allReduceResults_;
#if TL_PRE_ALLREDUCE_SUPPORT
    TileLangPreAllReduce::Context preAllReduce_;
#endif
    bool captureBeforeReady_;
    bool nativeMode_ = false;
    int nativePort_ = 0;
    std::ofstream nativeBarriers_;
    std::vector<BarrierStamp> nativeStamps_;
    int64_t magic_ = 0;
    uint64_t round_ = 0, started_ = 0, verifiedCount_ = 0, measuredCount_ = 0, captures_ = 0;
    bool launched_ = false;
    bool active_ = false, verified_ = false, measured_ = false;
};
} // namespace

int main(int argc, char **argv)
{
    const bool native = (argc == 7 || argc == 8) && std::strcmp(argv[1], "--native") == 0;
    if (!native && argc != 5 && argc != 6) {
        std::cerr << "usage: runner DEVICE FIXTURE_RANK_DIR NEW_OUTPUT_DIR CONTROL_FD [after-k|before-k]\n"
                  << "   or: runner --native DEVICE FIXTURE_RANK_DIR NEW_OUTPUT_DIR WARMUP BARRIER_PORT [none|allreduce]\n";
        return 2;
    }
    int control = -1;
    // On failure retain resources until process exit: parent terminates the
    // sibling before attempting recovery; no early comm destruction or reset.
    std::unique_ptr<Runner> runner;
    try {
        if (native) {
            const std::string mode = argc == 8 ? argv[7] : "";
            Require(argc == 7 || mode == "none" || mode == "allreduce", "Invalid pre-AllReduce mode");
#if !TL_PRE_ALLREDUCE_SUPPORT
            Require(mode.empty(), "This runner was built without TL_PRE_ALLREDUCE_SUPPORT");
#endif
            runner.reset(new Runner(Integer(argv[2]), argv[3], argv[4], "before-k"));
            runner->Initialize();
            runner->RunNative(Integer(argv[5]), Integer(argv[6]), mode);
            return 0;
        }
        control = Integer(argv[4]);
        runner.reset(new Runner(Integer(argv[1]), argv[2], argv[3], argc == 6 ? argv[5] : "after-k"));
        runner->Initialize();
        Reply(control, 'R');
        while (true) {
            const char command = Command(control);
            const uint64_t received = MonotonicNs();
            if (command == 'N' || command == 'C') runner->NewRound(command == 'C', received);
            else if (command == 'K') runner->RunDispatch(received);
            else if (command == 'V') runner->Verify();
            else if (command == 'Q') {
                runner->Finish();
                Reply(control, 'D');
                close(control);
                return 0;
            } else throw std::runtime_error("Unknown control command");
            Reply(control, 'D');
        }
    } catch (const std::exception &error) {
        if (runner) runner->SaveFailureBarrierEvidence();
        std::cerr << "rank=" << kRank << " runner error: " << error.what() << std::endl;
        if (control >= 0) {
            const char failure = 'E';
            (void)send(control, &failure, 1, MSG_NOSIGNAL);
        }
        // Skip C++ capture cleanup after failed stream synchronization. Parent
        // owns the process-group deadline and handles the other rank's shutdown.
        std::_Exit(1);
    }
}
