"""每rank一个集成Dispatch kernel；P/E可配置、H256/K2 BF16；T=4/16/64/256编译期专化。

默认 TL v2（variant=3 / p1p2）：workspace 批量完成，gate 逐核32B提交后组尾等待。
小batch全部核、大batch末核计数分工；末核前缀和与发送核并行；每核由自己的gate进入接收。
只有核内流水依赖，无全核barrier。参数/路由留在UB，不输出中间描述符。

阅读顺序（F编号对应profile_recipe.json中的观测片段，不是独立kernel）：
① prepare：F0计算窗口地址与本核任务范围；F1将expertIds读入本核UB。
② count_publish：F2统计专家路由数；F3将计数与READY标志发给目标rank。
③ pack_send：F4按路由打包BF16特征、来源信息及READY标志并发送。
④ count_prefix：F5等齐并消费计数；F6计算前缀和，发布workspace及gate。
⑤ receive_output：F7等待布局并规划输出；F8接收特征；F9清理已消费标志。
发送路径与末核的前缀和路径并行；所有核随后等待各自的gate进入接收。
"""
import tilelang.language as T
from .contract import (F, READY, CUMSUM_WORD, GATE_WORD, STATE_WORDS,
                       workspace_stride_words, validate_dispatch_config)

# [AI] A5接收UB逻辑预算采用与原生相同的保守190KiB；不是整机内存或每rank输入大小。
# 本TL版本另保留显式分配的共用UB，不能直接照搬原生97条容量。
RECEIVE_UB_BYTES = 190 * 1024


def receive_ub_plan(tokens, cores, world_size=2, experts=4):
    """[AI] 每核保守UB预算。E=P*L，prefix每核副本按32B补齐。

    公共缓冲与F6发布区逐块对齐相加；不依赖跨阶段UB复用。A/B每条
    各960B数据和32B assist，另共用64B READY，合计2048B/条。
    至少容纳一条，实际导出还须检查UB末地址。P不限定为偶数。
    """
    validate_dispatch_config(world_size=world_size, experts=experts, rank=0,
                             cores=cores, tokens=tokens)
    stride = workspace_stride_words(experts)
    align = lambda size: (size + 31) // 32 * 32
    common_sizes = (128, 512, tokens * 8, experts * 4, 1024, 512,
                    experts * 32, stride * 4, stride * 4,
                    (experts // world_size) * 8, 64,
                    cores * stride * 4, experts * 4)
    common_bytes = sum(align(size) for size in common_sizes)
    bytes_per_record = 2048
    capacity = (RECEIVE_UB_BYTES - common_bytes) // bytes_per_record
    if capacity < 1 or capacity * 2 > 4095:
        raise ValueError('TL UB/DMA row capacity exceeded')
    return {'ub_budget_bytes': RECEIVE_UB_BYTES, 'common_bytes': common_bytes,
            'bytes_per_record': bytes_per_record, 'batch_capacity': capacity,
            'planned_bytes': common_bytes + capacity * bytes_per_record,
            'data_buffers': 2, 'data_bytes_per_record': 960,
            'assist_bytes_per_record_per_buffer': 32, 'flag_bytes_per_record': 64}


# [AI] 固定后端只生成tl::ascend::copy*外部调用；通用GM→UB模板会补零并等待MTE3。
# 通过TileLang已有import_source接口提供此最小适配：对齐DMA只搬有效行，不写未用尾部。
# 形状/地址/事件由下面TL宏传入；不依赖C++生成变量名，不修改后端或导出后的文件。
RECEIVE_COPY_SOURCE = r"""
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] peer表是在本进程设备地址空间内有效的uint64地址，不是另一进程的裸指针。
// CopyCodegen把真实GM表作为dst、真实UB作为src传入；此桥接只绑定目标地址并提交对齐DMA。
__aicore__ inline void copy_ub_to_gm_peer(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint32_t slot, uint32_t wordOffset,
    uint32_t words) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue(slot)));
    AscendC::DataCopy(dst[wordOffset], src, words);
}
} }
"""


@T.macro
def copy_peer_words(src, peers, target, kind, src_offset, dst_offset, size, world_size, cpu):
    # [AI] kind=0计数窗口、kind=1数据窗口；所有offset/size以uint32为单位。
    # 设备peers是GM uint64[2*P]。CPU串行测试使用等宽虚拟窗口，不解引用设备地址。
    if cpu:
        for i in T.serial(size):
            peers[(target * 2 + kind) * (peers.shape[0] // (2 * world_size)) + dst_offset + i] = src[src_offset + i]
    else:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
        T.call_extern('handle', 'tl::ascend::copy_ub_to_gm_peer',
                      src.access_ptr('r', offset=src_offset), peers.access_ptr('r'),
                      target * 2 + kind, dst_offset, size)
        T.set_flag('MTE3', 'S', 0)
        T.wait_flag('MTE3', 'S', 0)


@T.macro
def read_receive_rows(src, dst, src_offset, width, rows, capacity, cpu):
    # [AI] GM→UB跨步读：src为uint32 GM，dst为uint32 UB；offset/width以uint32为单位。
    # GM行距固定128 words=512B，UB紧排width words；rows是本批有效行数，capacity是UB行容量。
    # READY读取width=8（32B）；数据读取width=120（480B），均跳过各自GM行的剩余部分。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[row * width + col] = src[src_offset + row * 128 + col]
    else:
        T.set_flag('S', 'MTE2', 0)
        T.wait_flag('S', 'MTE2', 0)
        # [AI] 全部地址/width均32B对齐，DataCopyParams单位为32B块。
        # 只搬有效rows，不调用会在尾批Duplicate并等待MTE3的通用补零模板。
        # 未搬行不被读取；从而上一批MTE3写出可与本次MTE2读取重叠。
        T.call_extern('handle', f'tl::ascend::copy_gm_to_ub_valid<uint32_t, {width}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w'),
                      128, rows, width, T.uint32(0))
        T.set_flag('MTE2', 'S', 0)
        T.wait_flag('MTE2', 'S', 0)


@T.macro
def write_receive_rows(src, dst, src_offset, dst_offset, src_pitch, dst_pitch,
                       width, rows, capacity, cpu):
    # [AI] UB→GM批量跨步提交；offset/pitch/width均以src/dst的32位元素为单位。
    # src_pitch必须是8 words（32B）的整数倍；dst_pitch可为3 words，使assist紧排为12B/条。
    # 此宏只提交DMA。调用者须先S→MTE3，并在整组提交后MTE3→S，期间不得改写src。
    if cpu:
        for row in T.serial(rows):
            for col in T.serial(width):
                dst[dst_offset + row * dst_pitch + col] = src[src_offset + row * src_pitch + col]
    else:
        T.call_extern('handle', f'tl::ascend::copy_ub_to_gm<{src.dtype}_t, {src_pitch}, {capacity}>',
                      src.access_ptr('r', offset=src_offset), dst.access_ptr('w', offset=dst_offset),
                      dst_pitch, rows, width)


@T.macro
def copy_words(src, dst, src_offset, dst_offset, size, cpu):
    # offset/size以缓冲区元素为单位。GM→UB使用MTE2，UB→GM使用MTE3；
    # copy返回前等待搬运完成，后面的scalar代码才可读结果或改写同一UB。
    if cpu:
        for i in T.serial(size):
            dst[dst_offset + i] = src[src_offset + i]
    else:
        if src.scope() == 'global':
            T.set_flag('S', 'MTE2', 0)
            T.wait_flag('S', 'MTE2', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE2', 'S', 0)
            T.wait_flag('MTE2', 'S', 0)
        else:
            T.set_flag('S', 'MTE3', 0)
            T.wait_flag('S', 'MTE3', 0)
            T.copy(src[src_offset:src_offset + size], dst[dst_offset:dst_offset + size])
            T.set_flag('MTE3', 'S', 0)
            T.wait_flag('MTE3', 'S', 0)


@T.macro
def fence(cpu):
    if not cpu:
        # 所有copy已建立scalar完成依赖；本地MTE3排序，不是跨核/rank barrier。
        T.pipe_barrier('MTE3')


@T.macro
def send_round(p, o):
    # F0.send_round：无共享专家版本的CalSendRound；不消费F1路由结果。
    o[F["send_rounds"]] = 1
    # [AI] 通用peer直接写路径一次覆盖全部路由，不套用原生特殊组网两轮调度。


@T.macro
def count_split(p, o, core):
    # F0.count_split：小batch全部核；大batch仅末尾count/cumsum核调用。
    o[F["count_begin"]] = 0
    o[F["count_end"]] = 0
    o[F["count_tasks"]] = 0
    if p[0] < 48 or T.cast(core, "uint64") >= o[F["send_cores"]]:
        worker = T.alloc_var("uint64")
        worker = T.cast(core, "uint64")
        if p[0] >= 48:
            worker = worker - o[F["send_cores"]]
        n = T.alloc_var("uint64")
        n = p[3]
        b = T.alloc_var("uint64")
        b = o[F["count_workers"]]
        begin = T.alloc_var("uint64")
        begin = n // b * worker + T.min(worker, n % b)
        size = T.alloc_var("uint64")
        size = n // b + T.cast(worker < n % b, "uint64")
        o[F["count_begin"]] = begin
        o[F["count_end"]] = begin + size
        o[F["count_tasks"]] = size


@T.macro
def status_split(p, o, core):
    # F0.status_split：输入是接收状态槽数量，不是接收token数量。
    worker = T.alloc_var("uint64")
    worker = T.cast(core, "uint64") - o[F["send_cores"]]
    n = T.alloc_var("uint64")
    n = o[F["receive_states"]]
    b = T.alloc_var("uint64")
    b = o[F["cumsum_cores"]]
    begin = T.alloc_var("uint64")
    begin = n // b * worker + T.min(worker, n % b)
    size = T.alloc_var("uint64")
    size = n // b + T.cast(worker < n % b, "uint64")
    o[F["status_begin"]] = begin
    o[F["status_end"]] = begin + size
    o[F["status_tasks"]] = size


@T.macro
def receive_split(p, o, core):
    """
    给 解包核分配接收地址槽位，起始地址、结束地址等
    p:在本核 UB 中,用于记录token数量、隐藏维度、top-k、专家数、rank 数量及编号、启动核数、轮次编号、通信窗口地址和容量等
    o:在本核 UB 中，用于存储布局和任务信息
    core: 本核编号
    """
    # worker 获取当前的核编号
    worker = T.alloc_var("uint64")
    worker = T.cast(core, "uint64")
    # 表示有n个接收的槽位，槽位 = 某个rank的某个专家gm存储空间
    n = T.alloc_var("uint64")
    n = o[F["receive_states"]]
    # b可以被分配任务的核数, p[6] 表示本rank的核数
    b = T.alloc_var("uint64")
    b = p[6]
    # 以下开始对本核要计算的gm槽位地址进行分配，计算本核负责的接收任务的起点和终点
    begin = T.alloc_var("uint64")
    begin = n // b * worker + T.min(worker, n % b)
    #  计算接收的槽位地址信息
    size = T.alloc_var("uint64")
    size = n // b + T.cast(worker < n % b, "uint64")
    o[F["receive_begin"]] = begin
    o[F["receive_end"]] = begin + size
    o[F["receive_tasks"]] = size


@T.macro
def layout(p, o):
    # 固定BF16用例；保留真实被后续地址/任务计算使用的布局，不构造独立测试描述符。
    # F0.layout：p是Host传入的uint64[16]参数，o是本核使用的字段表，F提供字段索引。
    # [AI] p[3]=E、p[4]=P、p[6]=本rank核数；本TL策略固定一个末核做prefix。
    experts = T.alloc_var('uint64')
    experts = p[3]
    cores = T.alloc_var('uint64')
    cores = p[6]
    cumsum = T.alloc_var('uint64')
    cumsum = 1
    feature = T.alloc_var('uint64')
    feature = p[1] * 2
    blocks = T.alloc_var('uint64')
    blocks = (((feature + 31) // 32 * 32) + 32 + 479) // 480
    record_bytes = T.alloc_var('uint64')
    record_bytes = blocks * 512
    workspace = T.alloc_var('uint64')
    workspace = cores * ((experts + 7) // 8 * 8) * 4
    state_address = T.alloc_var('uint64')
    state_address = p[8] + (p[7] % 2) * T.uint64(1073741824) + 2097152
    o[F['receive_states']] = experts
    o[F['cumsum_cores']] = cumsum
    o[F['send_cores']] = cores - cumsum
    o[F['count_workers']] = cores
    if p[0] >= 48:
        o[F['count_workers']] = cumsum
    o[F['record_bytes']] = record_bytes
    o[F['expert_window_bytes']] = (p[10] // p[4]) * record_bytes
    o[F['state_address']] = state_address
    o[F['workspace_address']] = state_address + 786432 - workspace


# ② F2＋F3：每核读取完整route[2*T]。T<48由前4核各计一个专家，
# [AI] T>=48由末核统计全部E个专家；先完成本核计数，再逐专家发布32B READY槽。
# 分开两个循环使F2/F3各有一个完整观测区间，不能在循环内覆盖同一Recorder槽。
@T.macro
def count_publish(route, peers, rank, small, amounts, diag, o, route_count, cpu, world_size, experts):
    if o[F['count_tasks']] > T.uint64(0):
        # F2.expert_count：统计本核负责的全部专家；4项amounts是核内UB，不跨核。
        for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
            amount = T.alloc_var('uint32')
            amount = T.uint32(0)
            for i in T.serial(route_count):
                if route[i] == expert:
                    amount = amount + T.uint32(1)
            amounts[expert] = amount
        diag[4] = T.cast(o[F['count_tasks']], 'int32')
        # F3.count_publish：即使计数为0也发布READY；copy完成后才重用small。
        for expert in T.serial(T.cast(o[F['count_begin']], 'int32'), T.cast(o[F['count_end']], 'int32')):
            for i in T.serial(8):
                small[i] = T.uint32(0)
            small[0] = T.uint32(READY)
            small[1] = amounts[expert]
            offset = T.alloc_var('int32')
            offset = ((expert % (experts // world_size)) * world_size + rank) * 8
            copy_peer_words(small, peers, expert // (experts // world_size), 0,
                            0, offset, 8, world_size, cpu)
            fence(cpu)


# ③ F4：发送核按core, core+send_cores,...覆盖2*T条路由，末核不发送。
# 每条1024B记录包含512B BF16特征、来源三元组和两个32B READY尾槽。
# 在整段循环外打一次F4点；不把单条的耗时当作整核发送耗时。
@T.macro
def pack_send(x, route, peers, record, feature, core, rank, diag, o, route_count, cpu, world_size, experts):
    # [AI] 直接peer地址表路径send_rounds=1，按全局专家映射任意目标rank。
    if core < route_count and o[F['send_rounds']] == T.uint64(1):
        for task in T.serial((route_count + T.cast(o[F['send_cores']], 'int32') - 1) // T.cast(o[F['send_cores']], 'int32')):
            route_index = T.alloc_var('int32')
            route_index = core + task * T.cast(o[F['send_cores']], 'int32')
            if route_index < route_count:
                expert = T.alloc_var('int32')
                expert = route[route_index]
                if expert >= 0 and expert < experts:
                    position = T.alloc_var('int32')
                    position = 0
                    for i in T.serial(route_index):
                        if route[i] == expert:
                            position = position + 1
                    copy_words(x, feature, (route_index // 2) * 128, 0, 128, cpu)
                    for i in T.serial(256):
                        record[i] = T.uint32(0)
                    for i in T.serial(128):
                        record[(i // 120) * 128 + i % 120] = feature[i]
                    record[136] = T.uint32(rank)
                    record[137] = T.cast(route_index // 2, 'uint32')
                    record[138] = T.cast(route_index % 2, 'uint32')
                    for block in T.serial(2):
                        for i in T.serial(8):
                            record[block * 128 + 120 + i] = T.uint32(READY)
                    target = T.alloc_var('int32')
                    target = expert // (experts // world_size)
                    bucket = T.alloc_var('int32')
                    bucket = ((rank + target) % world_size) * (experts // world_size) + expert % (experts // world_size)
                    offset = T.alloc_var('int32')
                    offset = bucket * T.cast(o[F["expert_window_bytes"]] // 4, "int32") + position * T.cast(o[F["record_bytes"]] // 4, "int32")
                    copy_peer_words(record, peers, target, 1, 0, offset, 256, world_size, cpu)
                    fence(cpu)
                    diag[5] = diag[5] + 1
                    diag[9] = diag[9] + T.cast(o[F["record_bytes"]], "int32")
                else:
                    diag[0] = 6


@T.macro
def count_prefix(state, counts, core, cores, poll_limit, records, prefix, small, diag, o, cpu, variant, experts, stride):
    # ④ F5＋F6：仅本rank末核执行，rank0为核55、rank1为核63。
    # [AI] state为本rank GM状态窗口；records接收E个32B计数槽，prefix保存E项累计计数。
    if core == cores - 1:
        ready = T.alloc_var('int32')
        ready = 0
        attempts = T.alloc_var('int32')
        attempts = 0
        # [AI] F5.wait_count：等齐P个来源rank×L个本地专家的全部E槽，0计数也须READY。
        while ready == 0 and attempts < poll_limit:
            copy_words(state, records, 0, 0, experts * 8, cpu)
            ready = 1
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                if records[q * 8] != T.uint32(READY):
                    ready = 0
            attempts = attempts + 1
        diag[1] = attempts
        diag[6] = T.cast(o[F["status_tasks"]], "int32")
        if ready == 0:
            diag[0] = 1  # 计数未就绪：不构造/发布虚假输出布局。
        else:
            # F5.consume_clear：汇总本核负责的计数并清READY，保留计数值供F6使用。
            total = T.alloc_var('uint32')
            total = 0
            for q in T.serial(T.cast(o[F["status_begin"]], "int32"), T.cast(o[F["status_end"]], "int32")):
                total = total + records[q * 8 + 1]
                records[q * 8] = T.uint32(0)
            copy_words(records, state, 0, 0, experts * 8, cpu)
            fence(cpu)
            # F6.prefix_publish / F6.prepare：发布并回读局部汇总槽，计算inclusive prefix。
            # 当前只有一个cumsum核，保留其32B局部汇总槽的发布/消费/清理。
            for i in T.serial(8):
                small[i] = T.uint32(0)
            small[0] = total
            small[1] = T.uint32(READY)
            copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
            fence(cpu)
            copy_words(state, small, CUMSUM_WORD, 0, 8, cpu)
            if small[1] != T.uint32(READY):
                diag[0] = 4
            else:
                for q in T.serial(stride):
                    prefix[q] = 0
                running = T.alloc_var('uint32')
                running = 0
                for q in T.serial(experts):
                    running = running + records[q * 8 + 1]
                    prefix[q] = T.cast(running, 'int32')
                # 均衡输入得到[T/2,T,3*T/2,2*T]，每项是对应接收槽的输出结束位置。
                for i in T.serial(8):
                    small[i] = T.uint32(0)
                copy_words(small, state, 0, CUMSUM_WORD, 8, cpu)
                copy_words(prefix, counts, 0, 0, experts, cpu)
                #  分配计数槽位，用于记录rank 给某专家的token数量 等信息 [READY标志，token数量，预留空间……]
                # workspace为每个接收核保留同一份4项prefix；gate为每核独立的32B通知槽。
                # 必须先完成workspace发布再通知gate；复用small前也必须完成其前一批搬运。
                if variant == 0:
                    # baseline：workspace、gate均逐核搬运，每次copy都等待完成。
                    for q in T.serial(stride):
                        small[q] = T.cast(prefix[q], 'uint32')
                    for c in T.serial(cores):
                        copy_words(small, state, 0, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + c * stride, stride, cpu)
                    fence(cpu)
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    for c in T.serial(cores):
                        copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    fence(cpu)
                elif variant == 2 or variant == 3:
                    # F6.workspace_publish（P2）：在连续UB中排列cores份prefix，一次写GM。
                    # 每份内容和目标地址与baseline一致，减少小块copy次数，未减少数据量。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    publish_buf = T.alloc_ub((cores * stride,), 'uint32')
                    for c in T.serial(cores):
                        for q in T.serial(stride):
                            publish_buf[c * stride + q] = T.uint32(0)
                            if q < experts:
                                publish_buf[c * stride + q] = T.cast(prefix[q], 'uint32')
                    copy_words(publish_buf, state, 0, workspace_word, cores * stride, cpu)
                    fence(cpu)
                    # P2-safe-gate：workspace仍批量发布；gate恢复独立32B槽及逐次完成等待。
                    # 保留原publish_buf容量，避免同时改变UB布局；接收核仍只清自己的槽。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    # F6.gate_publish：P2-safe-gate逐核等待；默认P1+P2只在整组末尾等待。
                    if variant == 2 or cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        # P1+P2：P2 workspace已完成；gate采用P1组尾完成等待。
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                else:
                    # P1：保留逐核小块copy，workspace组和gate组各等待一次完成。
                    # [AI] workspace每核align(E,8)个int32；保持32B行距及逐核地址覆盖。
                    workspace_word = T.alloc_var('int32', init=T.cast(
                        (o[F["workspace_address"]] - o[F["state_address"]]) // 4, 'int32'))
                    for q in T.serial(stride):
                        small[q] = T.cast(prefix[q], 'uint32')
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, workspace_word + c * stride, stride, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:stride], state[workspace_word + c * stride:workspace_word + c * stride + stride])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)
                    # gate是8个int32(1)，区别于计数/payload的float(1)位模式。
                    for i in T.serial(8):
                        small[i] = T.uint32(1)
                    if cpu:
                        for c in T.serial(cores):
                            copy_words(small, state, 0, GATE_WORD + c * 8, 8, cpu)
                    else:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                        for c in T.serial(cores):
                            T.copy(small[0:8], state[GATE_WORD + c * 8:GATE_WORD + c * 8 + 8])
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    fence(cpu)

@T.macro
def receive_batch_output(payload, output, assist, offset, destination, batch_count,
                         batch_data, batch_assist, capacity, event_id, cpu):
    # [AI] 当前A或B槽已经空闲。先完成MTE2读，再标量整理来源信息；
    # 两次输出共用一个MTE3→S完成事件，提交后暂不等待。调用者复用/退出时消费。
    read_receive_rows(payload, batch_data, offset, 120, batch_count * 2, capacity * 2, cpu)
    for row in T.serial(batch_count):
        for col in T.serial(3):
            batch_assist[row * 8 + col] = T.cast(batch_data[row * 240 + 128 + col], 'int32')
    if not cpu:
        T.set_flag('S', 'MTE3', 0)
        T.wait_flag('S', 'MTE3', 0)
    write_receive_rows(batch_data, output, 0, destination * 128,
                       240, 128, 128, batch_count, capacity, cpu)
    write_receive_rows(batch_assist, assist, 0, destination * 3,
                       8, 3, 3, batch_count, capacity, cpu)
    if not cpu:
        T.set_flag('MTE3', 'S', event_id)


@T.macro
def receive_output(state, payload, output, assist, expert_nums, core, rank, cores,
                   poll_limit, small, prefix, nums, diag, o, cpu, capacity, world_size, experts, stride):
    # [AI] ⑤ F7/F8/F9：全核等自己的gate；按receive_begin/end分到槽的核搬运payload。
    # [AI] 入参：state/payload是本rank GM通信窗口；output为uint32承载的BF16[T*4,256]容量，
    # assist为int32[T*4,3]容量；实际有效行由prefix决定。expert_nums为int64[2]专家计数。
    # small/prefix/nums/diag/o均为本核UB；poll_limit限制每批READY轮询，cpu仅用于串行行为验证。
    # 每条GM记录=2*(480B数据+32B READY)；压紧UB记录=960B，特征占前512B，随后12B来源信息。
    # [AI] A/B数据及assist独立占用UB；READY缓冲可在两批间复用，不覆盖数据缓冲。
    batch_data_a = T.alloc_ub((capacity * 240,), 'uint32')
    batch_data_b = T.alloc_ub((capacity * 240,), 'uint32')
    batch_assist_a = T.alloc_ub((capacity * 8,), 'int32')
    batch_assist_b = T.alloc_ub((capacity * 8,), 'int32')
    batch_flags = T.alloc_ub((capacity * 2 * 8,), 'uint32')
    ready = T.alloc_var('int32')
    ready = 0
    attempts = T.alloc_var('int32')
    attempts = 0
    # F7.layout_wait：检查本核gate的8个uint32均为1；Host提交不代表这里已开始。
    while ready == 0 and attempts < poll_limit:
        copy_words(state, small, GATE_WORD + core * 8, 0, 8, cpu)
        ready = 1
        for i in T.serial(8):
            if small[i] != T.uint32(1):
                ready = 0
        attempts = attempts + 1
    diag[2] = attempts
    if ready == 0:
        if diag[0] == 0:
            diag[0] = 2
    else:
        # F7.gate_clear：每核只清自己的32B gate，供下一轮复用。
        for i in T.serial(8):
            small[i] = T.uint32(0)
        copy_words(small, state, 0, GATE_WORD + core * 8, 8, cpu)
        if o[F["receive_tasks"]] > T.uint64(0):
            # F7.receive_plan：读取本核的prefix副本，确定输出起点/条数和payload桶。
            # core0还将四项prefix归并为两个本地专家的总接收数。
            diag[8] = T.cast(o[F["receive_tasks"]], "int32")
            copy_words(state, small, T.cast((o[F["workspace_address"]] - o[F["state_address"]]) // 4, "int32") + core * stride, 0, stride, cpu)
            for i in T.serial(stride):
                prefix[i] = T.cast(small[i], "int32")
            if core == 0:
                for local in T.serial(experts // world_size):
                    before_local = T.alloc_var('int32')
                    before_local = prefix[T.max(local * world_size - 1, 0)]
                    if local == 0:
                        before_local = 0
                    nums[local] = T.cast(prefix[(local + 1) * world_size - 1], 'int64') - T.cast(before_local, 'int64')
                copy_words(nums, expert_nums, 0, 0, experts // world_size, cpu)
            consumed_slots = T.alloc_ub((experts,), 'int32')
            for q in T.serial(experts):
                consumed_slots[q] = 0
            # [AI] F7.receive_plan：核可分到多个槽；先验证整段prefix，防止越界。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                previous = T.alloc_var('int32')
                previous = prefix[T.max(q - 1, 0)]
                if q == 0:
                    previous = 0
                if prefix[q] < previous or prefix[q] - previous > T.cast(o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32') or previous < 0 or prefix[q] > experts * T.cast(o[F['expert_window_bytes']] // o[F['record_bytes']], 'int32'):
                    if diag[0] == 0:
                        diag[0] = 5
            # [AI] F8.payload_loop：按local_expert×source槽循环，不能假定core就是槽编号。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                begin = T.alloc_var('int32')
                begin = prefix[T.max(q - 1, 0)]
                if q == 0:
                    begin = 0
                size = T.alloc_var('int32')
                size = prefix[q] - begin
                bucket = T.alloc_var('int32')
                bucket = ((q % world_size + rank) % world_size) * (experts // world_size) + q // world_size
                consumed = T.alloc_var('int32')
                consumed = 0
                # [AI] F8.payload_loop：容量由UB预算决定；A/B交替，尾批仅处理有效条数。
                # pending表示本槽已提交且尚未消费MTE3→S事件；空桶/失败前未用槽不等待。
                batch_index = T.alloc_var('int32')
                pending_a = T.alloc_var('int32')
                pending_b = T.alloc_var('int32')
                batch_index = 0
                pending_a = 0
                pending_b = 0
                while consumed < size and diag[0] == 0:
                    batch_count = T.alloc_var('int32')
                    batch_count = T.min(capacity, size - consumed)
                    offset = T.alloc_var('int32')
                    offset = bucket * T.cast(o[F["expert_window_bytes"]] // 4, "int32") + consumed * T.cast(o[F["record_bytes"]] // 4, "int32")
                    arrived = T.alloc_var('int32')
                    arrived = 0
                    polls = T.alloc_var('int32')
                    polls = 0
                    while arrived == 0 and polls < poll_limit:
                        read_receive_rows(payload, batch_flags, offset + 120, 8,
                                          batch_count * 2, capacity * 2, cpu)
                        arrived = 1
                        for row in T.serial(batch_count * 2):
                            if batch_flags[row * 8] != T.uint32(READY):
                                arrived = 0
                        polls = polls + 1
                    # [AI] 保留payload_polls的逐条检查口径：一次批轮询检查batch_count条的两槽。
                    diag[3] = diag[3] + polls * batch_count
                    if arrived == 0:
                        diag[0] = 3
                    else:
                        if batch_index % 2 == 0:
                            if not cpu:
                                if pending_a != 0:
                                    T.wait_flag('MTE3', 'S', 2)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_a, batch_assist_a,
                                                 capacity, 2, cpu)
                            pending_a = 1
                        else:
                            if not cpu:
                                if pending_b != 0:
                                    T.wait_flag('MTE3', 'S', 3)
                            receive_batch_output(payload, output, assist, offset, begin + consumed,
                                                 batch_count, batch_data_b, batch_assist_b,
                                                 capacity, 3, cpu)
                            pending_b = 1
                        batch_index = batch_index + 1
                        consumed = consumed + batch_count
                # [AI] 包括READY超限退出：排空先前已提交的A/B，再计成功消费/清flag。
                # 等待属于F8，不能将完成成本转移到F9制造计时改善。
                if not cpu:
                    if pending_a != 0:
                        T.wait_flag('MTE3', 'S', 2)
                    if pending_b != 0:
                        T.wait_flag('MTE3', 'S', 3)
                consumed_slots[q] = consumed
                diag[7] = diag[7] + consumed
                diag[10] = diag[10] + consumed * T.cast(o[F["record_bytes"]], "int32")
            # [AI] F9.payload_clear：F8排空之后才清所有已消费槽；失败槽原样保留。
            for q in T.serial(T.cast(o[F['receive_begin']], 'int32'), T.cast(o[F['receive_end']], 'int32')):
                bucket = T.alloc_var('int32')
                bucket = ((q % world_size + rank) % world_size) * (experts // world_size) + q // world_size
                # [AI] F9.payload_clear：每批跨步清2*N个32B尾槽，GM目的行距512B。
                # 仅清已完成输出的记录；失败批不消费/不清理，保留诊断现场。
                # [AI] 仅初始化本核清理DMA会读取的有效零槽，避免小batch清整块大容量UB。
                for i in T.serial(T.min(capacity, consumed_slots[q]) * 2 * 8):
                    batch_flags[i] = T.uint32(0)
                cleared = T.alloc_var('int32')
                cleared = 0
                while cleared < consumed_slots[q]:
                    clear_count = T.alloc_var('int32')
                    clear_count = T.min(capacity, consumed_slots[q] - cleared)
                    if not cpu:
                        T.set_flag('S', 'MTE3', 0)
                        T.wait_flag('S', 'MTE3', 0)
                    write_receive_rows(batch_flags, payload, 0,
                                       bucket * T.cast(o[F['expert_window_bytes']] // 4, 'int32')
                                       + cleared * T.cast(o[F['record_bytes']] // 4, 'int32') + 120,
                                       8, 128, 8, clear_count * 2, capacity * 2, cpu)
                    if not cpu:
                        T.set_flag('MTE3', 'S', 0)
                        T.wait_flag('MTE3', 'S', 0)
                    cleared = cleared + clear_count
        # F9.final_fence：本核收尾的MTE3排序，不是跨核/rank完成屏障。
        fence(cpu)

@T.macro
def dispatch_body(params, x, ids, peers, local_state, local_data, output, assist,
                  counts, expert_nums, diagnostics, core, rank, cores, poll_limit,
                  variant, tokens, receive_capacity, world_size, experts, stride):
    # [AI] peers=GM uint64[2*P]：state/data交错。地址由本rank Host通信映射提供。
    # 每核独立UB。P/E/T是本次编译的shape参数，不是固定rank名单。
    p = T.alloc_ub((16,), 'uint64')
    o = T.alloc_ub((64,), 'uint64')
    route = T.alloc_ub((tokens * 2,), 'int32')
    amounts = T.alloc_ub((experts,), 'uint32')
    record = T.alloc_ub((256,), 'uint32')
    feature = T.alloc_ub((128,), 'uint32')
    records = T.alloc_ub((experts * 8,), 'uint32')
    prefix = T.alloc_ub((stride,), 'int32')
    small = T.alloc_ub((stride,), 'uint32')
    nums = T.alloc_ub((experts // world_size,), 'int64')
    diag = T.alloc_ub((16,), 'int32')
    for i in T.serial(16):
        diag[i] = 0
    copy_words(params, p, 0, 0, 16, False)
    layout(p, o)
    copy_words(ids, route, 0, 0, tokens * 2, False)
    send_round(p, o)
    count_split(p, o, core)
    count_publish(route, peers, rank, small, amounts, diag, o, tokens * 2, False, world_size, experts)
    if T.cast(core, 'uint64') < o[F['send_cores']]:
        pack_send(x, route, peers, record, feature, core, rank, diag, o, tokens * 2, False, world_size, experts)
    else:
        status_split(p, o, core)
        count_prefix(local_state, counts, core, cores, poll_limit, records, prefix, small, diag, o,
                     False, variant, experts, stride)
    T.pipe_barrier('ALL')
    receive_split(p, o, core)
    receive_output(local_state, local_data, output, assist, expert_nums, core, rank, cores,
                   poll_limit, small, prefix, nums, diag, o, False, receive_capacity,
                   world_size, experts, stride)
    copy_words(diag, diagnostics, 0, core * 16, 16, False)


def make_kernel(rank, cores, *, poll_limit=100000, variant=3, tokens=4, world_size=2, experts=4):
    """[AI] 构造一个rank的单Dispatch PrimFunc，P由配置传入；不在设备端跨进程解引用裸指针。

    params:uint64[16]为本轮布局/magic；x:uint32[T*128]承载BF16[T,256]；
    ids:int32[T,2]为全局专家ID；peers:uint64[2*P]为本进程可访问的GM映射；
    local_state/local_data为本rank窗口；output/assist容量E*T、实际长度由counts决定；
    counts:int32[E]为inclusive prefix；expert_nums:int64[E/P]；diagnostics:int32[cores,16]。
    """
    validate_dispatch_config(world_size=world_size, experts=experts, rank=rank, cores=cores, tokens=tokens)
    if isinstance(poll_limit, bool) or not isinstance(poll_limit, int) or not 1 <= poll_limit <= 10000000:
        raise ValueError('poll_limit must be an integer in [1,10000000]')
    if type(variant) is not int or variant not in (0, 1, 2, 3):
        raise ValueError('variant must be baseline/P1/P2-safe-gate/P1+P2')
    if type(tokens) is not int or tokens not in (4, 16, 64, 256):
        raise ValueError('tokens must be 4, 16, 64, or 256')
    stride = workspace_stride_words(experts)
    receive_capacity = receive_ub_plan(tokens, cores, world_size, experts)['batch_capacity']
    @T.prim_func
    def dispatch(
        params: T.Tensor((16,), 'uint64'), x: T.Tensor((tokens * 128,), 'uint32'),
        ids: T.Tensor((tokens * 2,), 'int32'), peers: T.Tensor((world_size * 2,), 'uint64'),
        local_state: T.Tensor((STATE_WORDS,), 'uint32'),
        local_data: T.Tensor((experts * tokens * 256,), 'uint32'),
        output: T.Tensor((experts * tokens * 128,), 'uint32'),
        assist: T.Tensor((experts * tokens * 3,), 'int32'),
        counts: T.Tensor((experts,), 'int32'), expert_nums: T.Tensor((experts // world_size,), 'int64'),
        diagnostics: T.Tensor((cores * 16,), 'int32')):
        with T.Kernel(cores, threads=1, is_npu=True) as core:
            T.import_source(RECEIVE_COPY_SOURCE)
            with T.Scope('V'):
                dispatch_body(params, x, ids, peers, local_state, local_data,
                              output, assist, counts, expert_nums, diagnostics,
                              core, rank, cores, poll_limit, variant, tokens, receive_capacity,
                              world_size, experts, stride)
    return dispatch
