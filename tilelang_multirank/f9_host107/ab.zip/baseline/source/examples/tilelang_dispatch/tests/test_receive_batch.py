"""[AI] 真实接收宏CPU行为：尾批/空桶/不完整READY批/窗口清理；不验证MTE时序。"""
import importlib.util
import tempfile
import unittest

from .test_batch_kernel import compile_cpu


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class ReceiveBatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import tilelang as tl
        import tilelang.language as T
        from ..contract import STATE_WORDS
        from ..kernel import layout, receive_split, receive_output, receive_ub_plan

        capacity = receive_ub_plan(256, 56)['batch_capacity']
        cls.capacity = capacity
        @T.prim_func
        def receive(params: T.Tensor((16,), 'uint64'), state: T.Tensor((STATE_WORDS,), 'uint32'),
                    payload: T.Tensor((256 * 1024,), 'uint32'), output: T.Tensor((256 * 512,), 'uint32'),
                    assist: T.Tensor((256 * 12,), 'int32'), expert_nums: T.Tensor((2,), 'int64'),
                    diagnostics: T.Tensor((16,), 'int32')):
            with T.block('receive'):
                p = T.alloc_buffer((16,), 'uint64', scope='local')
                o = T.alloc_buffer((64,), 'uint64', scope='local')
                small = T.alloc_buffer((8,), 'uint32', scope='local')
                prefix = T.alloc_buffer((8,), 'int32', scope='local')
                nums = T.alloc_buffer((2,), 'int64', scope='local')
                diag = T.alloc_buffer((16,), 'int32', scope='local')
                for i in T.serial(16):
                    p[i] = params[i]
                    diag[i] = 0
                layout(p, o)
                # [AI] 保持core为TIR变量，与真实kernel一致，避免常量0使未执行分支生成负索引。
                core = T.alloc_var('int32')
                core = 0
                receive_split(p, o, core)
                receive_output(state, payload, output, assist, expert_nums, core, 0, 56, 3,
                               small, prefix, nums, diag, o, True, capacity, 2, 4, 8)
                for i in T.serial(16):
                    diagnostics[i] = diag[i]
        with tempfile.TemporaryDirectory() as directory:
            cls.module = compile_cpu(receive, directory, 'receive')

    def run_receive(self, size, missing=None):
        import numpy as np
        import tilelang as tl
        from ..contract import Config, F, GATE_WORD, READY, STATE_WORDS, reference

        config = Config(tokens=256, rank=0, block_dim=56)
        fields = reference(config)[0]
        workspace = (fields[F['workspace_address']] - fields[F['state_address']]) // 4
        state = np.zeros(STATE_WORDS, dtype=np.uint32)
        state[GATE_WORD:GATE_WORD + 8] = 1
        state[workspace:workspace + 4] = size
        # [AI] 在整个payload填充哨兵；检查跨步清flag没有误改数据、其他桶或尾批之外。
        payload = np.full(256 * 1024, 0xa5a5a5a5, dtype=np.uint32)
        features = []
        for token in range(size):
            feature = np.arange(128, dtype=np.uint32) + token * 256 + 0x3f803f80
            features.append(feature)
            offset = token * 256
            payload[offset:offset + 120] = feature[:120]
            payload[offset + 128:offset + 136] = feature[120:]
            payload[offset + 136:offset + 139] = (1, token, token % 2)
            payload[offset + 120:offset + 128] = READY
            payload[offset + 248:offset + 256] = READY
        if missing is not None:
            token, block = missing
            payload[token * 256 + block * 128 + 120] = 0
        before = payload.copy()
        array = tl.tvm.nd.array
        args = [array(np.array(config.words(), dtype=np.uint64)), array(state), array(payload),
                array(np.full(256 * 512, 0xa5a5a5a5, dtype=np.uint32)),
                array(np.full(256 * 12, -1515870811, dtype=np.int32)),
                array(np.zeros(2, dtype=np.int64)), array(np.zeros(16, dtype=np.int32))]
        self.module['receive'](*args)
        # [AI] 不完整的批整批不输出；此前成功批正常完成并清理，错误码3且没有重试掩盖失败。
        consumed = size if missing is None else missing[0] // self.capacity * self.capacity
        diag = args[6].numpy()
        self.assertEqual(int(diag[0]), 0 if missing is None else 3)
        self.assertEqual(int(diag[7]), consumed)
        self.assertEqual(int(diag[10]), consumed * 1024)
        if consumed:
            np.testing.assert_array_equal(args[3].numpy()[:consumed * 128],
                                          np.concatenate(features[:consumed]))
        np.testing.assert_array_equal(args[3].numpy()[consumed * 128:], 0xa5a5a5a5)
        want_assist = np.array([(1, t, t % 2) for t in range(consumed)], dtype=np.int32).reshape(-1)
        np.testing.assert_array_equal(args[4].numpy()[:consumed * 3], want_assist)
        np.testing.assert_array_equal(args[4].numpy()[consumed * 3:], -1515870811)
        for token in range(consumed):
            for block in range(2):
                offset = token * 256 + block * 128 + 120
                before[offset:offset + 8] = 0
        np.testing.assert_array_equal(args[2].numpy(), before)
        np.testing.assert_array_equal(args[1].numpy()[GATE_WORD:GATE_WORD + 8], 0)
        np.testing.assert_array_equal(args[5].numpy(), [size, 0])
        if missing is None:
            self.assertEqual(int(diag[3]), size)

    def test_empty_full_and_tail_batches(self):
        for size in (0, 1, self.capacity - 1, self.capacity, self.capacity + 1,
                     self.capacity * 2, self.capacity * 2 + 1, 256):
            with self.subTest(size=size):
                self.run_receive(size)

    def test_missing_either_flag_preserves_unconsumed_batch(self):
        for size, token in ((self.capacity, self.capacity - 1),
                            (self.capacity + 1, self.capacity),
                            (2 * self.capacity + 1, 2 * self.capacity)):
            for block in (0, 1):
                with self.subTest(size=size, token=token, block=block):
                    self.run_receive(size, (token, block))


@unittest.skipUnless(importlib.util.find_spec('tilelang'), 'Requires pinned TileLang backend')
class ReceiveBudgetTests(unittest.TestCase):
    def test_maximal_capacity_within_budget(self):
        from ..kernel import receive_ub_plan
        for tokens in (4, 16, 64, 256):
            for cores in (56, 64):
                with self.subTest(tokens=tokens, cores=cores):
                    p = receive_ub_plan(tokens, cores)
                    self.assertGreater(p['batch_capacity'], 0)
                    self.assertEqual(p['data_buffers'], 2)
                    self.assertLessEqual(p['planned_bytes'], p['ub_budget_bytes'])
                    self.assertGreater(p['planned_bytes'] + p['bytes_per_record'],
                                       p['ub_budget_bytes'])


if __name__ == '__main__':
    unittest.main()
