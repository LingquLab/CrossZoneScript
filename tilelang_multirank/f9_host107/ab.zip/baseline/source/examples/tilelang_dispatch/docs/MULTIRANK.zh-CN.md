# [AI] 可配置rank的Dispatch

本次修改让P由配置传入，两rank也使用通用peer地址表，不保留旧state0/state1旁路。
范围是同一A5主机上的peer内存通信、均匀分专家E/P、BF16、H256、Top-2、TP1、各rank相同T。
T保留4/16/64/256。P按原生参数上限1..128、E整除P、实际窗口/UB/DMA容量校验，不列2/4/6白名单。
这不是跨机组网、多机HCCL transport、mask或量化实现。

## 输入与布局

- P：rank数，rank编号0..P−1；E：全局专家数，L=E/P。
- `peers:uint64[2P]`由每rank Host生成，交错排列`state0,data0,state1,data1,...`。
  每项是**本进程通信映射内可访问的设备地址**，不能填其他进程的任意裸指针。
  轮次magic决定bank；每次launch独立保存表，直到stream执行/验收完成才释放。
- 全局专家g的目的rank为`g//L`、本地专家为`g%L`。
- 计数逻辑槽`q=local_expert*P+source_rank`，每槽32B，即使计数0也发布READY。
- 数据物理桶`b=((source_rank+destination_rank)%P)*L+local_expert`，每桶最多T条，记录仍1024B。
- 每核prefix副本占`align(E,8)`个32位字；UB/GM同一行距，避免E不是8倍数时跨核小块非对齐。
- 输出按本地专家、source、token、topk顺序排列；容量E*T行，有效长度为`counts[E−1]`。
  `counts:int32[E]`，`expert_nums:int64[L]`；零输出rank合法。

设备ABI v2：11个GM指针`params,x,ids,peers,local_state,local_data,output,assist,counts,expert_nums,diagnostics`，
随后`fftsAddr:uint64`与`profileGM`，AArch64共104B。旧112B设备ELF/Host不可混用。

## 五模块的改变

① F0/F1：P/E/L及workspace容量参与布局，专家路由仍是本rank的[T,2]。
② F2/F3：T<48按全核切分E个专家，T>=48末核统计全部E项；peer表选择目标状态窗口。
③ F4：去掉固定rank分支，按目标专家选择peer payload地址；保留现有标量打包算法。
④ F5/F6：末核等E个计数槽、生成E项前缀和；保留P1+P2的workspace批量完成和gate组尾等待。
⑤ F7/F8/F9：按E个接收槽分配任务，一个核可以处理多个槽；每槽A/B完成后记录消费数，
随后统一清理已消费槽。gate仍每核独立，不是全核barrier。

当前明确采用**一个末核计算prefix**，没有实现原生多cumsum核的性能分工。
当P/E增加时，它可能成为瓶颈；功能泛化不能等同原生性能。
容量不足直接拒绝：状态窗口、UB至少一条、int32偏移、单次DMA上限（workspace/count记录各≤65504B）。
更大的发布区需要另做DMA分段，不能静默越界。

## 配置入口

近期实际A5仍只用P2/E4和旧T16/64/256，X/ids字节保持一致。
以下P3是离线配置示例，**不是已完成的三卡设备验证或新增设备实验授权**：

```bash
python3 -m examples.tilelang_dispatch.hardware_fixture --world-size 3 --experts 9 --tokens 16 --cores 32 32 32 --output /tmp/fixture-p3
python3 -m examples.tilelang_dispatch.export --world-size 3 --experts 9 --tokens 16 --rank 0 --cores 32 --output /tmp/raw-p3/rank0
python3 -m examples.tilelang_dispatch.profile --source /tmp/raw-p3/rank0 --output /tmp/profiled-p3/rank0
# 对每个rank分别导出/适配，不混用不同P/E/T或核数的文件。
```

CMake显式传`TL_DISPATCH_WORLD_SIZE`、`TL_DISPATCH_EXPERTS`、`TL_DISPATCH_CORES_PER_RANK`，
导出路径保持rank0..rank(P−1)；配置核验metadata及104B ABI。
常规执行入口`run_native --devices ... --cores ...`要求长度均为P、设备唯一、启动前查卡。
非P2不能默认套用56/64；物理可用核数需实际设备证据。
Host barrier与HCCL root交换等待P个不同rank；前置AllReduce的INT32[1]输入各为1、SUM预期为P，
保持同stream AR→Dispatch，中间不加Host等待。

历史`tools/run_batch.py`保留原两rank suite/输入SHA/start-release限制；通用运行使用`run_native`，
不要删除旧历史约束来宣称多rank设备已获授权。四槽first-seen旧诊断仅P2/E4可用。
原始ticks仍未完成跨核/跨rank时钟校准，trace不能据此判断rank启动先后。

ABI2 的 F4 打点位于发送条件外，末核以外的发送角色核都应出现成对区间；
例如 T16/Top-2、56/64 核时，各有 55/63 个参与核，其中 32 核实际发送记录。
分析器须按 ABI 区分打点参与核与诊断中的实际工作量核，不能因无发送记录而拒绝完整区间，
也不能省略这些核的条件判断开销。历史 ABI1 保留原参与核规则。
缺失、未配对区间或末核出现 F4 仍须拒绝；合成 trace 回归只验证分析规则，不替代设备运行。

## 验证边界

真实TL宏CPU串行测试检查路由/计数/输出/清flag/复用，Ascend C导出检查固定后端兼容与UB。
CPU socket和桩头C++14检查Host协议/类型，不替代CANN编译、NPU peer可见性或硬事件测试。
两rank和多rank设备正确性、性能都必须绑定本候选ELF、输入SHA和独立实验回执。
