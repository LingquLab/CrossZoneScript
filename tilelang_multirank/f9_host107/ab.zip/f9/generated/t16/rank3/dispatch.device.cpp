
#include "kernel_operator.h"
namespace tl { namespace ascend {
template <typename T, uint32_t Width, uint32_t Capacity>
__aicore__ inline void copy_gm_to_ub_valid(AscendC::LocalTensor<T> dst,
    AscendC::GlobalTensor<T> src, uint32_t srcPitch, uint32_t rows,
    uint32_t width, T unusedPad) {
    static_assert(sizeof(T) == 4 && Width % 8 == 0, "Receive rows must be 32B aligned");
    AscendC::DataCopyParams params{static_cast<uint16_t>(rows),
        static_cast<uint16_t>(width / 8),
        static_cast<uint16_t>((srcPitch - width) / 8), 0};
    AscendC::DataCopy(dst, src, params);
}
// [AI] peer表是在本进程设备地址空间内有效的uint64地址，不是另一进程的裸指针。
// CopyCodegen把真实GM表作为dst、真实UB作为src传入；此桥接只绑定目标地址并提交对齐DMA。
__aicore__ inline void copy_ub_to_gm_peer(AscendC::GlobalTensor<uint64_t> peers,
    AscendC::LocalTensor<uint32_t> src, uint32_t slot, uint32_t wordOffset,
    uint32_t words) {
    AscendC::GlobalTensor<uint32_t> dst;
    dst.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue(slot)));
    AscendC::DataCopy(dst[wordOffset], src, words);
}
} }
#include "kernel_operator.h"
#include <tilexr/profiling.h>
#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void tilexr_tl_dispatch_r3_c64( GM_ADDR params_handle,  GM_ADDR x_handle,  GM_ADDR ids_handle,  GM_ADDR peers_handle,  GM_ADDR local_state_handle,  GM_ADDR local_data_handle,  GM_ADDR output_handle,  GM_ADDR assist_handle,  GM_ADDR counts_handle,  GM_ADDR expert_nums_handle,  GM_ADDR diagnostics_handle, uint64_t fftsAddr, GM_ADDR profileGM) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<uint64_t> params;
  params.SetGlobalBuffer((__gm__ uint64_t*)params_handle);
  AscendC::GlobalTensor<uint32_t> x;
  x.SetGlobalBuffer((__gm__ uint32_t*)x_handle);
  AscendC::GlobalTensor<int> ids;
  ids.SetGlobalBuffer((__gm__ int*)ids_handle);
  AscendC::GlobalTensor<uint64_t> peers;
  peers.SetGlobalBuffer((__gm__ uint64_t*)peers_handle);
  AscendC::GlobalTensor<uint32_t> local_state;
  local_state.SetGlobalBuffer((__gm__ uint32_t*)local_state_handle);
  AscendC::GlobalTensor<uint32_t> local_data;
  local_data.SetGlobalBuffer((__gm__ uint32_t*)local_data_handle);
  AscendC::GlobalTensor<uint32_t> output;
  output.SetGlobalBuffer((__gm__ uint32_t*)output_handle);
  AscendC::GlobalTensor<int> assist;
  assist.SetGlobalBuffer((__gm__ int*)assist_handle);
  AscendC::GlobalTensor<int> counts;
  counts.SetGlobalBuffer((__gm__ int*)counts_handle);
  AscendC::GlobalTensor<int64_t> expert_nums;
  expert_nums.SetGlobalBuffer((__gm__ int64_t*)expert_nums_handle);
  AscendC::GlobalTensor<int> diagnostics;
  diagnostics.SetGlobalBuffer((__gm__ int*)diagnostics_handle);

  // AIV适配：保留实际UB，生命周期到全部工作和Flush之后。
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;
  pipe.InitBuffer(ascend_ub, 193248);
  auto core = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    }
  auto diag = ascend_ub.GetWithOffset<int>(16, 0);
  auto p = ascend_ub.GetWithOffset<uint64_t>(16, 64);
  uint64_t experts = (uint64_t)0;
  uint64_t cores = (uint64_t)0;
  uint64_t cumsum = (uint64_t)0;
  uint64_t feature = (uint64_t)0;
  uint64_t workspace = (uint64_t)0;
  uint64_t state_address = (uint64_t)0;
  auto o = ascend_ub.GetWithOffset<uint64_t>(64, 192);
  auto route = ascend_ub.GetWithOffset<int>(32, 704);
  uint64_t worker = (uint64_t)0;
  uint64_t n = (uint64_t)0;
  uint64_t b = (uint64_t)0;
  uint64_t begin = (uint64_t)0;
  uint64_t size = (uint64_t)0;
  auto amounts = ascend_ub.GetWithOffset<uint32_t>(8, 832);
  auto small = ascend_ub.GetWithOffset<uint32_t>(8, 864);
  uint32_t amount = (uint32_t)0;
  int offset = 0;
  int route_index = 0;
  uint64_t worker_1 = (uint64_t)0;
  uint64_t n_1 = (uint64_t)0;
  uint64_t b_1 = (uint64_t)0;
  uint64_t begin_1 = (uint64_t)0;
  uint64_t size_1 = (uint64_t)0;
  int ready = 0;
  int attempts = 0;
  auto records = ascend_ub.GetWithOffset<uint32_t>(64, 2432);
  uint32_t total = (uint32_t)0;
  auto prefix = ascend_ub.GetWithOffset<int>(8, 2688);
  uint32_t running = (uint32_t)0;
  int workspace_word = 0;
  auto publish_buf = ascend_ub.GetWithOffset<uint32_t>(512, 2720);
  int expert = 0;
  int position = 0;
  auto feature_1 = ascend_ub.GetWithOffset<uint32_t>(128, 896);
  auto record = ascend_ub.GetWithOffset<uint32_t>(256, 1408);
  int target = 0;
  int bucket = 0;
  int offset_1 = 0;
  uint64_t worker_2 = (uint64_t)0;
  uint64_t n_2 = (uint64_t)0;
  uint64_t b_2 = (uint64_t)0;
  uint64_t begin_2 = (uint64_t)0;
  int ready_1 = 0;
  int attempts_1 = 0;
  auto nums = ascend_ub.GetWithOffset<int64_t>(2, 4768);
  auto consumed_slots = ascend_ub.GetWithOffset<int>(8, 4800);
  auto batch_flags = ascend_ub.GetWithOffset<uint32_t>(1472, 4832);
  int max_clean_records = 0;
  int clean_words = 0;
  int before_local = 0;
  int previous = 0;
  int begin_3 = 0;
  int size_2 = 0;
  int bucket_1 = 0;
  int consumed = 0;
  int batch_index = 0;
  int pending_a = 0;
  int pending_b = 0;
  int batch_count = 0;
  int offset_2 = 0;
  int arrived = 0;
  int polls = 0;
  auto batch_data_a = ascend_ub.GetWithOffset<uint32_t>(22080, 10720);
  auto batch_assist_a = ascend_ub.GetWithOffset<int>(736, 99040);
  auto batch_data_b = ascend_ub.GetWithOffset<uint32_t>(22080, 101984);
  auto batch_assist_b = ascend_ub.GetWithOffset<int>(736, 190304);
  int slot_records = 0;
  int bucket_2 = 0;
  int slot_records_1 = 0;
  int cleared = 0;
  int clear_count = 0;
  auto vid = AscendC::GetSubBlockIdx();
  // Recorder初始化不计入module.whole；一个AIV核唯一拥有一条lane。
  TileXR::Profiling::Recorder<64> recorder;
  if ASCEND_IS_AIV {
    if ASCEND_IS_AIV {
      // 【开始 ID=1】module.whole：单kernel内观测包络，含功能及harness，不含TPipe/Recorder准备、Flush和Destroy；不是ACL完整kernel时间
      recorder.RecordMarker<0, 1>();
      // 【开始 ID=1000】harness.diag_init：每核诊断UB清零
      recorder.RecordMarker<1, 1000>();
      for (int32_t i = 0; i < 16; ++i) {
        diag.SetValue(i, 0);
      }
      // 【结束 ID=1001】harness.diag_init：每核诊断UB清零
      recorder.RecordMarker<2, 1001>();
      // 【开始 ID=1010】harness.params_init：运行时参数GM→UB，含MTE2_S完成等待
      recorder.RecordMarker<3, 1010>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<uint64_t, 16>(p[0], params[0], 16, 1, 16, (uint64_t)0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      // 【结束 ID=1011】harness.params_init：运行时参数GM→UB，含MTE2_S完成等待
      recorder.RecordMarker<4, 1011>();
      // 【开始 ID=10】F0.layout：计算实际使用的状态/工作区地址、记录/专家窗口尺寸和核角色；不输出独立描述符
      recorder.RecordMarker<5, 10>();
      experts = p.GetValue(3);
      cores = p.GetValue(6);
      cumsum = (uint64_t)1;
      feature = (p.GetValue(1) * (uint64_t)2);
      feature = ((((feature + (uint64_t)31) / (uint64_t)32) + (uint64_t)15) / (uint64_t)15);
      feature = (feature * (uint64_t)512);
      workspace = ((cores * (((experts + (uint64_t)7) / (uint64_t)8) * (uint64_t)8)) * (uint64_t)4);
      state_address = ((p.GetValue(8) + ((p.GetValue(7) % (uint64_t)2) * (uint64_t)1073741824)) + (uint64_t)2097152);
      o.SetValue(5, experts);
      o.SetValue(6, cumsum);
      o.SetValue(7, (cores - cumsum));
      o.SetValue(8, cores);
      if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
        o.SetValue(8, cumsum);
      }
      o.SetValue(14, feature);
      o.SetValue(15, ((p.GetValue(10) / p.GetValue(4)) * feature));
      o.SetValue(22, state_address);
      o.SetValue(25, ((state_address + (uint64_t)786432) - workspace));
      // 【结束 ID=11】F0.layout：计算实际使用的状态/工作区地址、记录/专家窗口尺寸和核角色；不输出独立描述符
      recorder.RecordMarker<6, 11>();
      // 【开始 ID=100】F1.route_read：expertIds读入UB，含MTE2_S完成等待；无mask场景，不声称测了mask计算
      recorder.RecordMarker<7, 100>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<int, 32>(route[0], ids[0], 32, 1, 32, 0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      // 【结束 ID=101】F1.route_read：expertIds读入UB，含MTE2_S完成等待；无mask场景，不声称测了mask计算
      recorder.RecordMarker<8, 101>();
      // 【开始 ID=20】F0.send_round：发送轮数默认值与条件选择
      recorder.RecordMarker<9, 20>();
      o.SetValue(32, (uint64_t)1);
      // 【结束 ID=21】F0.send_round：发送轮数默认值与条件选择
      recorder.RecordMarker<10, 21>();
      // 【开始 ID=30】F0.count_split：T<48按全核划分E个计数任务；T>=48仅末核处理全部E项
      recorder.RecordMarker<11, 30>();
      o.SetValue(34, (uint64_t)0);
      o.SetValue(35, (uint64_t)0);
      o.SetValue(36, (uint64_t)0);
      if (((p.GetValue(0) / (uint64_t)48) < (uint64_t)1) || (o.GetValue(7) <= ((uint64_t)core))) {
        worker = ((uint64_t)core);
        if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
          worker = (worker - o.GetValue(7));
        }
        n = p.GetValue(3);
        b = o.GetValue(8);
        begin = (((n / b) * worker) + (worker < (n % b) ? worker : (n % b)));
        size = ((n / b) + ((uint64_t)(worker < (n % b))));
        o.SetValue(34, begin);
        o.SetValue(35, (begin + size));
        o.SetValue(36, size);
      }
      // 【结束 ID=31】F0.count_split：T<48按全核划分E个计数任务；T>=48仅末核处理全部E项
      recorder.RecordMarker<12, 31>();
      if ((uint64_t)0 < o.GetValue(36)) {
        // 【开始 ID=200】F2.expert_count：扫描本rank全部2T路由，统计分配到本核的全局专家；整个专家循环
        recorder.RecordMarker<13, 200>();
        for (int32_t expert_1 = ((int32_t)o.GetValue(34)); expert_1 < ((int32_t)o.GetValue(35)); ++expert_1) {
          amount = (uint32_t)0;
          for (int32_t i_1 = 0; i_1 < 32; ++i_1) {
            if (route.GetValue(i_1) == expert_1) {
              amount = (amount + (uint32_t)1);
            }
          }
          amounts.SetValue(((int64_t)expert_1), amount);
        }
        diag.SetValue(4, ((int32_t)o.GetValue(36)));
        // 【结束 ID=201】F2.expert_count：扫描本rank全部2T路由，统计分配到本核的全局专家；整个专家循环
        recorder.RecordMarker<14, 201>();
        // 【开始 ID=300】F3.count_publish：发布本核全部专家的32B状态记录，逐项完成等待；区间覆盖整个专家发布循环
        recorder.RecordMarker<15, 300>();
        for (int32_t expert_2 = ((int32_t)o.GetValue(34)); expert_2 < ((int32_t)o.GetValue(35)); ++expert_2) {
          for (int32_t i_2 = 0; i_2 < 8; ++i_2) {
            small.SetValue(i_2, (uint32_t)0);
          }
          small.SetValue(0, (uint32_t)1065353216);
          small.SetValue(1, amounts.GetValue(((int64_t)expert_2)));
          offset = (((expert_2 % 2) * 32) + 24);
          AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
          tl::ascend::copy_ub_to_gm_peer(peers[0], small[0], ((expert_2 / 2) * 2), offset, 8);
          AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          AscendC::PipeBarrier<PIPE_MTE3>();
        }
        // 【结束 ID=301】F3.count_publish：发布本核全部专家的32B状态记录，逐项完成等待；区间覆盖整个专家发布循环
        recorder.RecordMarker<16, 301>();
      }
      if (((uint64_t)core) < o.GetValue(7)) {
        // 【开始 ID=400】F4.pack_send：循环处理本核全部route任务：稳定位置、特征读取、payload/assist打包、peer发送及逐项MTE3完成等待；区间覆盖整个任务循环
        recorder.RecordMarker<17, 400>();
        if ((core < 32) && (o.GetValue(32) == (uint64_t)1)) {
          for (int32_t task = 0; task < ((31 / ((int32_t)o.GetValue(7))) + 1); ++task) {
            route_index = (core + (task * ((int32_t)o.GetValue(7))));
            if (route_index < 32) {
              expert = route.GetValue(route_index);
              if ((0 <= expert) && (expert < 8)) {
                position = 0;
                for (int32_t i_3 = 0; i_3 < route_index; ++i_3) {
                  if (route.GetValue(i_3) == expert) {
                    position = (position + 1);
                  }
                }
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                tl::ascend::copy_gm_to_ub<uint32_t, 128>(feature_1[0], x[((route_index / 2) * 128)], 2048, 1, 128, (uint32_t)0);
                AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                for (int32_t i_4 = 0; i_4 < 256; ++i_4) {
                  record.SetValue(i_4, (uint32_t)0);
                }
                for (int32_t i_5 = 0; i_5 < 128; ++i_5) {
                  record.SetValue((((i_5 / 120) * 128) + (i_5 % 120)), feature_1.GetValue(i_5));
                }
                record.SetValue(136, (uint32_t)3);
                record.SetValue(137, ((uint32_t)(route_index / 2)));
                record.SetValue(138, ((uint32_t)(route_index % 2)));
                for (int32_t block = 0; block < 2; ++block) {
                  for (int32_t i_6 = 0; i_6 < 8; ++i_6) {
                    record.SetValue((((block * 128) + i_6) + 120), (uint32_t)1065353216);
                  }
                }
                target = (expert / 2);
                bucket = ((((target + 3) % 4) * 2) + (expert % 2));
                offset_1 = ((bucket * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (position * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
                AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                tl::ascend::copy_ub_to_gm_peer(peers[0], record[0], ((target * 2) + 1), offset_1, 256);
                AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
                AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
                AscendC::PipeBarrier<PIPE_MTE3>();
                diag.SetValue(5, (diag.GetValue(5) + 1));
                diag.SetValue(9, (diag.GetValue(9) + ((int32_t)o.GetValue(14))));
              } else {
                diag.SetValue(0, 6);
              }
            }
          }
        }
        // 【结束 ID=401】F4.pack_send：循环处理本核全部route任务：稳定位置、特征读取、payload/assist打包、peer发送及逐项MTE3完成等待；区间覆盖整个任务循环
        recorder.RecordMarker<18, 401>();
      } else {
        // 【开始 ID=40】F0.status_split：末核计算状态任务，状态工作量由该结果记录
        recorder.RecordMarker<19, 40>();
        worker_1 = (((uint64_t)core) - o.GetValue(7));
        n_1 = o.GetValue(5);
        b_1 = o.GetValue(6);
        begin_1 = (((n_1 / b_1) * worker_1) + (worker_1 < (n_1 % b_1) ? worker_1 : (n_1 % b_1)));
        size_1 = ((n_1 / b_1) + ((uint64_t)(worker_1 < (n_1 % b_1))));
        o.SetValue(38, begin_1);
        o.SetValue(39, (begin_1 + size_1));
        o.SetValue(40, size_1);
        // 【结束 ID=41】F0.status_split：末核计算状态任务，状态工作量由该结果记录
        recorder.RecordMarker<20, 41>();
        if (core == 63) {
          // 【开始 ID=500】F5.wait_count：整个有界计数轮询，含每次GM→UB及MTE2_S完成等待；失败也有此区间
          recorder.RecordMarker<21, 500>();
          ready = 0;
          attempts = 0;
          while (1) {
            if (!(((ready == 0) && (attempts < 100000)))) { break; }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 64>(records[0], local_state[0], 262144, 1, 64, (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            ready = 1;
            for (int32_t q = ((int32_t)o.GetValue(38)); q < ((int32_t)o.GetValue(39)); ++q) {
              if (records.GetValue((((int64_t)q) * (int64_t)8)) != (uint32_t)1065353216) {
                ready = 0;
              }
            }
            attempts = (attempts + 1);
          }
          diag.SetValue(1, attempts);
          diag.SetValue(6, ((int32_t)o.GetValue(40)));
          // 【结束 ID=501】F5.wait_count：整个有界计数轮询，含每次GM→UB及MTE2_S完成等待；失败也有此区间
          recorder.RecordMarker<22, 501>();
          if (ready == 0) {
            diag.SetValue(0, 1);
          } else {
            // 【开始 ID=510】F5.consume_clear：消费计数、局部求和及清ready状态，含MTE3_S完成等待
            recorder.RecordMarker<23, 510>();
            total = (uint32_t)0;
            for (int32_t q_1 = ((int32_t)o.GetValue(38)); q_1 < ((int32_t)o.GetValue(39)); ++q_1) {
              total = (total + records.GetValue(((((int64_t)q_1) * (int64_t)8) + (int64_t)1)));
              records.SetValue((((int64_t)q_1) * (int64_t)8), (uint32_t)0);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 64>(local_state[0], records[0], 262144, 1, 64);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            // 【结束 ID=511】F5.consume_clear：消费计数、局部求和及清ready状态，含MTE3_S完成等待
            recorder.RecordMarker<24, 511>();
            // 【开始 ID=600】F6.prefix_publish：单cumsum记录发布/回读/清理、prefix计算、counts/workspace/gate发布；含本地copy完成等待，不是真实跨核cumsum等待
            recorder.RecordMarker<25, 600>();
            // 【开始 ID=620】F6.prepare：cumsum发布/回读/清理、prefix计算及counts写回完成；不含workspace/gate填充
            recorder.RecordMarker<26, 620>();
            for (int32_t i_7 = 0; i_7 < 8; ++i_7) {
              small.SetValue(i_7, (uint32_t)0);
            }
            small.SetValue(0, total);
            small.SetValue(1, (uint32_t)1065353216);
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 8>(local_state[222208], small[0], 262144, 1, 8);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::PipeBarrier<PIPE_MTE3>();
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], local_state[222208], 262144, 1, 8, (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            if (small.GetValue(1) != (uint32_t)1065353216) {
              diag.SetValue(0, 4);
            } else {
              for (int32_t q_2 = 0; q_2 < 8; ++q_2) {
                prefix.SetValue(q_2, 0);
              }
              running = (uint32_t)0;
              for (int32_t q_3 = 0; q_3 < 8; ++q_3) {
                running = (running + records.GetValue(((q_3 * 8) + 1)));
                prefix.SetValue(q_3, ((int32_t)running));
              }
              for (int32_t i_8 = 0; i_8 < 8; ++i_8) {
                small.SetValue(i_8, (uint32_t)0);
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8>(local_state[222208], small[0], 262144, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<int, 8>(counts[0], prefix[0], 8, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              // 【结束 ID=621】F6.prepare：cumsum发布/回读/清理、prefix计算及counts写回完成；不含workspace/gate填充
              recorder.RecordMarker<27, 621>();
              // 【开始 ID=630】F6.workspace_publish：workspace地址/UB准备、全部目标提交及本地MTE3完成等待和外围fence
              recorder.RecordMarker<28, 630>();
              workspace_word = ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4));
              for (int32_t c = 0; c < 64; ++c) {
                for (int32_t q_4 = 0; q_4 < 8; ++q_4) {
                  publish_buf.SetValue(((c * 8) + q_4), (uint32_t)0);
                  publish_buf.SetValue(((c * 8) + q_4), ((uint32_t)prefix.GetValue(q_4)));
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              int32_t condval;
              if (workspace_word <= 261632) {
                condval = 512;
              } else {
                int32_t condval_1;
                if (workspace_word < 262144) {
                  condval_1 = (262144 - workspace_word);
                } else {
                  condval_1 = 0;
                }
                condval = condval_1;
              }
              tl::ascend::copy_ub_to_gm<uint32_t, 512>(local_state[workspace_word], publish_buf[0], 262144, 1, condval);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::PipeBarrier<PIPE_MTE3>();
              // 【结束 ID=631】F6.workspace_publish：workspace地址/UB准备、全部目标提交及本地MTE3完成等待和外围fence
              recorder.RecordMarker<29, 631>();
              // 【开始 ID=640】F6.gate_publish：逐核32B gate提交，采用P1组尾MTE3_S完成等待；workspace已批量完成
              recorder.RecordMarker<30, 640>();
              for (int32_t i_9 = 0; i_9 < 8; ++i_9) {
                small.SetValue(i_9, (uint32_t)1);
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              for (int32_t c_1 = 0; c_1 < 64; ++c_1) {
                tl::ascend::copy_ub_to_gm<uint32_t, 8>(local_state[((c_1 * 8) + 224256)], small[0], 262144, 1, 8);
              }
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::PipeBarrier<PIPE_MTE3>();
              // 【结束 ID=641】F6.gate_publish：逐核32B gate提交，采用P1组尾MTE3_S完成等待；workspace已批量完成
              recorder.RecordMarker<31, 641>();
            }
            // 【结束 ID=601】F6.prefix_publish：单cumsum记录发布/回读/清理、prefix计算、counts/workspace/gate发布；含本地copy完成等待，不是真实跨核cumsum等待
            recorder.RecordMarker<32, 601>();
          }
        }
      }
      // 【开始 ID=1100】role_pipeline_barrier：角色分支后的核内PIPE_ALL指令，无跨核barrier；单列而不分摊到模块
      recorder.RecordMarker<33, 1100>();
      AscendC::PipeBarrier<PIPE_ALL>();
      // 【结束 ID=1101】role_pipeline_barrier：角色分支后的核内PIPE_ALL指令，无跨核barrier；单列而不分摊到模块
      recorder.RecordMarker<34, 1101>();
      // 【开始 ID=50】F0.receive_split：全部核计算接收状态任务，驱动接收核分支
      recorder.RecordMarker<35, 50>();
      worker_2 = ((uint64_t)core);
      n_2 = o.GetValue(5);
      b_2 = p.GetValue(6);
      begin_2 = (((n_2 / b_2) * worker_2) + (worker_2 < (n_2 % b_2) ? worker_2 : (n_2 % b_2)));
      n_2 = ((n_2 / b_2) + ((uint64_t)(worker_2 < (n_2 % b_2))));
      o.SetValue(42, begin_2);
      o.SetValue(43, (begin_2 + n_2));
      o.SetValue(44, n_2);
      // 【结束 ID=51】F0.receive_split：全部核计算接收状态任务，驱动接收核分支
      recorder.RecordMarker<36, 51>();
      // 【开始 ID=700】F7.layout_wait：整个有界gate轮询，含GM→UB及MTE2_S完成等待；失败也有此区间
      recorder.RecordMarker<37, 700>();
      ready_1 = 0;
      attempts_1 = 0;
      while (1) {
        if (!(((ready_1 == 0) && (attempts_1 < 100000)))) { break; }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
        tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], local_state[((core * 8) + 224256)], 262144, 1, 8, (uint32_t)0);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        ready_1 = 1;
        for (int32_t i_10 = 0; i_10 < 8; ++i_10) {
          if (small.GetValue(i_10) != (uint32_t)1) {
            ready_1 = 0;
          }
        }
        attempts_1 = (attempts_1 + 1);
      }
      diag.SetValue(2, attempts_1);
      // 【结束 ID=701】F7.layout_wait：整个有界gate轮询，含GM→UB及MTE2_S完成等待；失败也有此区间
      recorder.RecordMarker<38, 701>();
      if (ready_1 == 0) {
        if (diag.GetValue(0) == 0) {
          diag.SetValue(0, 2);
        }
      } else {
        // 【开始 ID=710】F7.gate_clear：清本核gate，含MTE3_S完成等待
        recorder.RecordMarker<39, 710>();
        for (int32_t i_11 = 0; i_11 < 8; ++i_11) {
          small.SetValue(i_11, (uint32_t)0);
        }
        AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
        tl::ascend::copy_ub_to_gm<uint32_t, 8>(local_state[((core * 8) + 224256)], small[0], 262144, 1, 8);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
        // 【结束 ID=711】F7.gate_clear：清本核gate，含MTE3_S完成等待
        recorder.RecordMarker<40, 711>();
        if ((uint64_t)0 < o.GetValue(44)) {
          // 【开始 ID=720】F7.receive_plan：读取本核32B补齐prefix副本、验证全部已分配槽；核0写L项专家数量
          recorder.RecordMarker<41, 720>();
          diag.SetValue(8, ((int32_t)o.GetValue(44)));
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval_2;
          if (-262136 <= ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 8))) {
            condval_2 = 8;
          } else {
            int32_t condval_3;
            if (-262144 < ((0 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 8))) {
              condval_3 = ((262144 - ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4))) - (core * 8));
            } else {
              condval_3 = 0;
            }
            condval_2 = condval_3;
          }
          tl::ascend::copy_gm_to_ub<uint32_t, 8>(small[0], local_state[((core * 8) + ((int32_t)((o.GetValue(25) - o.GetValue(22)) / (uint64_t)4)))], 262144, 1, condval_2, (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
          for (int32_t i_12 = 0; i_12 < 8; ++i_12) {
            prefix.SetValue(i_12, ((int32_t)small.GetValue(i_12)));
          }
          if (core == 0) {
            for (int32_t local = 0; local < 2; ++local) {
              before_local = prefix.GetValue((((local * 4) - 1) > 0 ? ((local * 4) - 1) : 0));
              if (local == 0) {
                before_local = 0;
              }
              nums.SetValue(local, (((int64_t)prefix.GetValue(((local * 4) + 3))) - ((int64_t)before_local)));
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int64_t, 2>(expert_nums[0], nums[0], 2, 1, 2);
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          }
          for (int32_t q_5 = 0; q_5 < 8; ++q_5) {
            consumed_slots.SetValue(q_5, 0);
          }
          for (int32_t q_6 = ((int32_t)o.GetValue(42)); q_6 < ((int32_t)o.GetValue(43)); ++q_6) {
            previous = prefix.GetValue(((((int64_t)q_6) - (int64_t)1) > (int64_t)0 ? (((int64_t)q_6) - (int64_t)1) : (int64_t)0));
            if (q_6 == 0) {
              previous = 0;
            }
            if ((((prefix.GetValue(((int64_t)q_6)) < previous) || (((int32_t)(o.GetValue(15) / o.GetValue(14))) < (prefix.GetValue(((int64_t)q_6)) - previous))) || (previous < 0)) || ((((int32_t)(o.GetValue(15) / o.GetValue(14))) * 8) < prefix.GetValue(((int64_t)q_6)))) {
              if (diag.GetValue(0) == 0) {
                diag.SetValue(0, 5);
              }
            }
          }
          // 【结束 ID=721】F7.receive_plan：读取本核32B补齐prefix副本、验证全部已分配槽；核0写L项专家数量
          recorder.RecordMarker<42, 721>();
          // 【开始 ID=800】F8.payload_loop：完整接收槽循环：批量跨READY搬运、A/B输出与每槽排空；包含全部完成等待
          recorder.RecordMarker<43, 800>();
          for (int32_t q_7 = ((int32_t)o.GetValue(42)); q_7 < ((int32_t)o.GetValue(43)); ++q_7) {
            begin_3 = prefix.GetValue(((((int64_t)q_7) - (int64_t)1) > (int64_t)0 ? (((int64_t)q_7) - (int64_t)1) : (int64_t)0));
            if (q_7 == 0) {
              begin_3 = 0;
            }
            size_2 = (prefix.GetValue(((int64_t)q_7)) - begin_3);
            bucket_1 = (((((q_7 % 4) + 3) % 4) * 2) + (q_7 / 4));
            consumed = 0;
            batch_index = 0;
            pending_a = 0;
            pending_b = 0;
            while (1) {
              if (!(((consumed < size_2) && (diag.GetValue(0) == 0)))) { break; }
              batch_count = (92 < (size_2 - consumed) ? 92 : (size_2 - consumed));
              offset_2 = ((bucket_1 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (consumed * ((int32_t)(o.GetValue(14) / (uint64_t)4))));
              arrived = 0;
              polls = 0;
              while (1) {
                if (!(((arrived == 0) && (polls < 100000)))) { break; }
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                tl::ascend::copy_gm_to_ub_valid<uint32_t, 8, 184>(batch_flags[0], local_data[(offset_2 + 120)], 128, (batch_count * 2), 8, (uint32_t)0);
                AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                arrived = 1;
                for (int32_t row = 0; row < (batch_count * 2); ++row) {
                  if (batch_flags.GetValue((((int64_t)row) * (int64_t)8)) != (uint32_t)1065353216) {
                    arrived = 0;
                  }
                }
                polls = (polls + 1);
              }
              diag.SetValue(3, (diag.GetValue(3) + (polls * batch_count)));
              if (arrived == 0) {
                diag.SetValue(0, 3);
              } else {
                if ((batch_index % 2) == 0) {
                  if (pending_a != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 184>(batch_data_a[0], local_data[offset_2], 128, (batch_count * 2), 120, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  for (int32_t row_1 = 0; row_1 < batch_count; ++row_1) {
                    for (int32_t col = 0; col < 3; ++col) {
                      batch_assist_a.SetValue(((((int64_t)row_1) * (int64_t)8) + ((int64_t)col)), ((int32_t)batch_data_a.GetValue((((((int64_t)row_1) * (int64_t)240) + ((int64_t)col)) + (int64_t)128))));
                    }
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 240, 92>(output[((begin_3 * 128) + (consumed * 128))], batch_data_a[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm<int32_t, 8, 92>(assist[((begin_3 * 3) + (consumed * 3))], batch_assist_a[0], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                  pending_a = 1;
                } else {
                  if (pending_b != 0) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  tl::ascend::copy_gm_to_ub_valid<uint32_t, 120, 184>(batch_data_b[0], local_data[offset_2], 128, (batch_count * 2), 120, (uint32_t)0);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  for (int32_t row_2 = 0; row_2 < batch_count; ++row_2) {
                    for (int32_t col_1 = 0; col_1 < 3; ++col_1) {
                      batch_assist_b.SetValue(((((int64_t)row_2) * (int64_t)8) + ((int64_t)col_1)), ((int32_t)batch_data_b.GetValue((((((int64_t)row_2) * (int64_t)240) + ((int64_t)col_1)) + (int64_t)128))));
                    }
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  tl::ascend::copy_ub_to_gm<uint32_t, 240, 92>(output[((begin_3 * 128) + (consumed * 128))], batch_data_b[0], 128, batch_count, 128);
                  tl::ascend::copy_ub_to_gm<int32_t, 8, 92>(assist[((begin_3 * 3) + (consumed * 3))], batch_assist_b[0], 3, batch_count, 3);
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                  pending_b = 1;
                }
                batch_index = (batch_index + 1);
                consumed = (consumed + batch_count);
              }
            }
            if (pending_a != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
            }
            if (pending_b != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
            }
            consumed_slots.SetValue(((int64_t)q_7), consumed);
            diag.SetValue(7, (diag.GetValue(7) + consumed));
            diag.SetValue(10, (diag.GetValue(10) + (consumed * ((int32_t)o.GetValue(14)))));
          }
          // 【结束 ID=801】F8.payload_loop：完整接收槽循环：批量跨READY搬运、A/B输出与每槽排空；包含全部完成等待
          recorder.RecordMarker<44, 801>();
          // 【开始 ID=900】F9.payload_clear：本核最大需求扫描、一次向量填零及按槽清已完成记录READY，含全部同步和逐批MTE3完成等待
          recorder.RecordMarker<45, 900>();
          max_clean_records = 0;
          for (int32_t q_8 = ((int32_t)o.GetValue(42)); q_8 < ((int32_t)o.GetValue(43)); ++q_8) {
            slot_records = consumed_slots.GetValue(((int64_t)q_8));
            max_clean_records = (max_clean_records > (92 < slot_records ? 92 : slot_records) ? max_clean_records : (92 < slot_records ? 92 : slot_records));
          }
          clean_words = (max_clean_records * 16);
          if (0 < clean_words) {
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            if (63 < clean_words) {
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[0], (uint32_t)0, (~(uint64_t)0), (clean_words / 64), 1, 8);
            }
            if (0 < (clean_words % 64)) {
              tl::ascend::Fill_experiment<uint32_t>(batch_flags[((clean_words / 64) * 64)], (uint32_t)0, (((uint64_t)1 << ((uint64_t)(clean_words % 64))) - (uint64_t)1), 1, 1, 8);
            }
            AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
          }
          for (int32_t q_9 = ((int32_t)o.GetValue(42)); q_9 < ((int32_t)o.GetValue(43)); ++q_9) {
            bucket_2 = (((((q_9 % 4) + 3) % 4) * 2) + (q_9 / 4));
            slot_records_1 = consumed_slots.GetValue(((int64_t)q_9));
            cleared = 0;
            while (1) {
              if (!((cleared < slot_records_1))) { break; }
              clear_count = (92 < (slot_records_1 - cleared) ? 92 : (slot_records_1 - cleared));
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8, 184>(local_data[(((bucket_2 * ((int32_t)(o.GetValue(15) / (uint64_t)4))) + (cleared * ((int32_t)(o.GetValue(14) / (uint64_t)4)))) + 120)], batch_flags[0], 128, (clear_count * 2), 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              cleared = (cleared + clear_count);
            }
          }
          // 【结束 ID=901】F9.payload_clear：本核最大需求扫描、一次向量填零及按槽清已完成记录READY，含全部同步和逐批MTE3完成等待
          recorder.RecordMarker<46, 901>();
        }
        // 【开始 ID=910】F9.final_fence：保留现有PIPE_MTE3 fence；输出完成等待已在F8内，不称原生异步输出尾等待
        recorder.RecordMarker<47, 910>();
        AscendC::PipeBarrier<PIPE_MTE3>();
        // 【结束 ID=911】F9.final_fence：保留现有PIPE_MTE3 fence；输出完成等待已在F8内，不称原生异步输出尾等待
        recorder.RecordMarker<48, 911>();
      }
      // 【开始 ID=1030】harness.diag_write：诊断写回GM，含MTE3_S完成等待
      recorder.RecordMarker<49, 1030>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
      tl::ascend::copy_ub_to_gm<int, 16>(diagnostics[(core * 16)], diag[0], 1024, 1, 16);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
      // 【结束 ID=1031】harness.diag_write：诊断写回GM，含MTE3_S完成等待
      recorder.RecordMarker<50, 1031>();
      // 【结束 ID=2】module.whole：单kernel内观测包络，含功能及harness，不含TPipe/Recorder准备、Flush和Destroy；不是ACL完整kernel时间
      recorder.RecordMarker<51, 2>();
      // Flush位于module.whole之外；profileGM来自当前launch的AclCapture。
      recorder.Flush(profileGM, static_cast<uint32_t>(core));
    }
  }
  pipe.Destroy();
}
