// clang-format off
#include "catlass/catlass.hpp"
#include "catlass/arch/arch.hpp"
// clang-format on

#include "catlass/detail/tag_to_layout.hpp"
#include "catlass/gemm/block/block_swizzle.hpp"
#include "catlass/gemm/tile/tile_copy.hpp"
#include "catlass/layout/layout.hpp"

#if defined(__has_include)
#if __has_include("version/cann_version.h")
#include "version/cann_version.h"
#endif
#endif

#include "shmem.h"
#include "tl_templates/ascend/reduce_2d_v2.h"

#define CUDART_INF_F 1.0f / 0.0f

typedef AscendC::int4b_t int4b_t;

namespace tl::ascend {
using namespace Catlass;
using namespace tla;
using namespace Catlass::Gemm::Tile;
using namespace Catlass::Gemm::Block;
using namespace AscendC;

using ArchTag = Arch::AtlasA2;
using LayoutGM = layout::RowMajor;

using LayoutL0A = layout::zZ;
using LayoutL0B = layout::nZ;
using LayoutL1 = layout::zN;
using LayoutL1T = layout::nZ;

constexpr int64_t UB_HALF_SIZE = 64;

template <typename T>
constexpr bool IsDuplicateSupported_v =
    std::is_same_v<T, int16_t> || std::is_same_v<T, uint16_t> ||
    std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t> ||
    std::is_same_v<T, int32_t> || std::is_same_v<T, uint32_t> ||
    std::is_same_v<T, float>;

// Bit width of a single element. Sub-byte types must report their packed bit
// width, NOT sizeof(): int4b_t has sizeof == 1 but only occupies 4 bits (two
// elements are nibble-packed into one byte, both in GM and in the on-chip
// fractal layouts), so any geometry derived from sizeof() is 2x off for int4.
template <typename T> CATLASS_DEVICE constexpr uint32_t ElementSizeBits() {
  if constexpr (std::is_same_v<T, int4b_t>) {
    return 4;
  } else {
    return sizeof(T) * 8;
  }
}

// Elements of T that fit in one 32-byte C0 block (64 for int4b_t).
template <typename T> CATLASS_DEVICE constexpr uint32_t EleNumPerC0() {
  return BYTE_PER_C0 * 8 / ElementSizeBits<T>();
}

// Elements of T that fit in one 512-byte fractal (1024 for int4b_t).
template <typename T> CATLASS_DEVICE constexpr uint32_t EleNumPerFractal() {
  return BYTE_PER_FRCATLASSAL * 8 / ElementSizeBits<T>();
}

// Exact byte footprint of n elements of T. n must cover whole bytes for
// sub-byte types (guaranteed for 32B-aligned tiles).
template <typename T>
CATLASS_DEVICE constexpr uint64_t EleNumToBytes(uint64_t n) {
  return n * ElementSizeBits<T>() / 8;
}

CATLASS_DEVICE void disable_dma_atomic_compat() {
#if defined(CANN_MAJOR) && CANN_MAJOR >= 9
  AscendC::DisableDmaAtomic();
#else
  AscendC::SetAtomicNone();
#endif
}

template <typename T, uint32_t dstM, uint32_t dstN>
CATLASS_DEVICE void
copy_gm_to_l1(LocalTensor<T> dstTensor, GlobalTensor<T> srcTensor,
              uint32_t realSrcN = 1, uint32_t realTailM = 0,
              uint32_t realTailN = 0, bool need_clear = true) {
  uint32_t tailM = realTailM == 0 ? dstM : realTailM;
  uint32_t tailN = realTailN == 0 ? dstN : realTailN;
  // Only the primary copy (dst offset 0, i.e. need_clear == true) is allowed to
  // zero-init the full L1 tile. Sub-region copies (need_clear == false, e.g.
  // the second DMA of a splice / vertical-merge pattern) must NOT clear,
  // otherwise they clobber data already written into the same NZ tile. The
  // full-tile clear is only correct when it targets the tile base, which the
  // codegen guarantees by passing need_clear = (dst_offset == 0).
  //
  // The clear must cover the zN FRACTAL extent, not just dstM*dstN elements:
  // the zN layout pads rows up to 16 and interleaves the padding holes inside
  // the tile (e.g. zN(K=200, N=128) stores each 16-column N band at a
  // roundUp16(K)*16 = 3328-element stride, leaving 8 unwritten K rows per
  // band). The GM copy only writes valid elements, and Mmad rounds its k
  // argument up to whole C0 fractals, so a gemm_v0 K-tail tile
  // (kSize % 16 != 0) multiplies whatever sits in those holes (issue #1341).
  // Zero-init them whenever the tile has fractal padding
  // (extent != dstM*dstN) or a partial tail copy.
  // Bit-width-based (not sizeof-based) so the extent math is also exact for
  // sub-byte dtypes (int4b_t: sizeof == 1 but 4 bits per element, see
  // ElementSizeBits).
  constexpr uint32_t ELE_PER_C0 = EleNumPerC0<T>();
  constexpr uint32_t C0_PER_FRACTAL = Catlass::C0_NUM_PER_FRCATLASSAL;
  const uint32_t paddedRows =
      (dstM + C0_PER_FRACTAL - 1) / C0_PER_FRACTAL * C0_PER_FRACTAL;
  const uint32_t fractalExtent =
      ((dstN + ELE_PER_C0 - 1) / ELE_PER_C0) * paddedRows * ELE_PER_C0;
  if (need_clear &&
      (tailM != dstM || tailN != dstN || fractalExtent != dstM * dstN)) {
    AscendC::InitConstValue(
        dstTensor, {1,
                    static_cast<uint16_t>(EleNumToBytes<T>(fractalExtent) /
                                          Catlass::BYTE_PER_C0),
                    0, 0});
    AscendC::PipeBarrier<PIPE_MTE2>();
  }
  if constexpr (std::is_same_v<T, int4b_t>) {
    // int4 GM -> L1 (Nd2Nz into the zN fractal layout), calling the AscendC
    // intrinsic directly: the generic TileCopyTla path derives its geometry
    // from sizeof(T) and has no int4 support. The CCE intrinsic behind this
    // DataCopy reinterprets int4b_t as int8_t (b8 path), so dValue /
    // srcDValue are BYTE counts (two nibbles per byte) while the destination
    // strides are in 32-byte C0 units and one C0 block holds 64 nibble
    // elements. GM rows must start at even element offsets, which nibble
    // packing (N even) guarantees.
    AscendC::Nd2NzParams intriParams;
    intriParams.ndNum = 1;
    intriParams.dValue = tailN / 2;
    intriParams.srcNdMatrixStride = 0;
    intriParams.dstNzC0Stride =
        ((dstM + 15) / 16) * 16; // roundUp16(dstM), in C0 units
    intriParams.dstNzMatrixStride = 0;
    if (realSrcN / 2 < STRIDE_LIMIT) {
      intriParams.nValue = tailM;
      intriParams.srcDValue = realSrcN / 2;
      intriParams.dstNzNStride = 1;
      AscendC::DataCopy(dstTensor, srcTensor, intriParams);
    } else {
      // Per-row fallback, mirroring the generic path (only reachable for GM
      // row pitches >= 128K nibbles).
      intriParams.nValue = 1;
      intriParams.srcDValue = 0;
      intriParams.dstNzNStride = 0;
      for (uint32_t i = 0; i < tailM; i++) {
        AscendC::DataCopy(dstTensor[i * EleNumPerC0<T>()],
                          srcTensor[i * realSrcN], intriParams);
      }
    }
    return;
  }
  auto layout = MakeLayoutFromTag(LayoutGM{tailM, realSrcN});
  auto src_LAYOUT = MakeLayoutTile(layout, tla::MakeShape(tailM, tailN));
  auto src = tla::MakeTensor<decltype(srcTensor), decltype(src_LAYOUT),
                             AscendC::TPosition::GM>(srcTensor, src_LAYOUT);

  using LayoutL1_ = Catlass::detail::TagToLayout_t<T, LayoutL1>;
  constexpr auto layoutInL1 = tla::MakeLayout<T, LayoutL1_>(dstM, dstN);
  auto dst = tla::MakeTensor<decltype(dstTensor), decltype(layoutInL1),
                             AscendC::TPosition::A1>(dstTensor, layoutInL1);

  TileCopyTla<ArchTag, decltype(src), decltype(dst)> tileCopier;
  tileCopier(dst, src);
}

template <typename T, uint32_t srcM, uint32_t srcN, bool transpose = false>
CATLASS_DEVICE void copy_l1_to_l0a(LocalTensor<T> dstTensor,
                                   LocalTensor<T> srcTensor, uint32_t dstM,
                                   uint32_t dstN) {
  if constexpr (std::is_same_v<T, int4b_t>) {
    // int4 (W4A4) L1(zN) -> L0A(zZ), calling the s4 load intrinsic directly
    // (the generic TileCopyTla path derives its geometry from sizeof(T) and
    // has no int4 support).
    static_assert(!transpose,
                  "int4 (W4A4) does not support transpose_A: the s4 L1->L0A "
                  "load has no transpose mode on this architecture");
    // s4 fractal geometry: 64 nibble elements per 32B C0 block, 1024 elements
    // (512B) per fractal; LoadData2DParams strides are in 512B fractal units.
    AscendC::LoadData2DParams loadDataParams;
    loadDataParams.startIndex = 0;
    // One repeat per K-C0 block (64 K elements); each repeat steps the source
    // by the zN N-block stride = roundUp16(M) x 64 elements = roundUp16(M)/16
    // fractals.
    loadDataParams.repeatTimes = (dstN + 63) / 64;
    loadDataParams.srcStride = ((dstM + 15) / 16 * 16) / 16;
    loadDataParams.sid = 0;
    loadDataParams.dstGap = 0;
    loadDataParams.ifTranspose = false;
    loadDataParams.addrMode = 0;
    // One LoadData per 16-row M band. Band stride: 512B (one fractal) in the
    // zN source; roundUp64(K) x 16 elements in the zZ destination (a 16-row
    // band spans the whole K extent).
    const uint32_t rowBlocks = (dstM + 15) / 16;
    const uint32_t dstBandStride = ((dstN + 63) / 64 * 64) * 16;
    for (uint32_t i = 0; i < rowBlocks; i++) {
      AscendC::LoadData(dstTensor[i * dstBandStride],
                        srcTensor[i * EleNumPerFractal<T>()], loadDataParams);
    }
    return;
  }
  using LayoutL1_ =
      std::conditional_t<transpose,
                         Catlass::detail::TagToLayout_t<T, LayoutL1T>,
                         Catlass::detail::TagToLayout_t<T, LayoutL1>>;
  constexpr auto layout = transpose ? tla::MakeLayout<T, LayoutL1_>(srcN, srcM)
                                    : tla::MakeLayout<T, LayoutL1_>(srcM, srcN);
  auto src_LAYOUT = MakeLayoutTile(layout, tla::MakeShape(dstM, dstN));
  auto src = MakeTensor<decltype(srcTensor), decltype(src_LAYOUT),
                        AscendC::TPosition::A1>(srcTensor, src_LAYOUT);

  using LayoutL0A_ = Catlass::detail::TagToLayout_t<T, LayoutL0A>;
  auto layoutAInL0 = tla::MakeLayout<T, LayoutL0A_>(dstM, dstN);
  auto dst = tla::MakeTensor<decltype(dstTensor), decltype(layoutAInL0),
                             AscendC::TPosition::A2>(dstTensor, layoutAInL0);
  TileCopyTla<ArchTag, decltype(src), decltype(dst)> tileCopier;
  tileCopier(dst, src);
}

template <typename T, uint32_t srcM, uint32_t srcN, bool transpose = false>
CATLASS_DEVICE void copy_l1_to_l0b(LocalTensor<T> dstTensor,
                                   LocalTensor<T> srcTensor, uint32_t dstM,
                                   uint32_t dstN) {
  if constexpr (std::is_same_v<T, int4b_t>) {
    // int4 (W4A4) L1(zN) -> L0B(nZ) via the s4 transposing load, calling the
    // AscendC intrinsic directly: the generic LoadData path dispatches to
    // load_cbuf_to_cb_s4 which hardcodes transpose OFF and silently drops the
    // ifTranspose flag, so B never receives the nZ layout mad_s4 expects.
    static_assert(!transpose,
                  "int4 (W4A4) does not support transpose_B: the s4 L1->L0B "
                  "transposing load requires a zN source layout");
    // s4 transposing-load semantics (measured on dav_c220 / Ascend 910B; the
    // generic LoadDataWithTranspose documents 512B-fractal units, but the s4
    // variant does NOT follow them):
    //   - one repeat moves a whole 64K x 64N nibble block (2048B): it reads
    //     the four consecutive 512B zN row-fractals of one K-64 band and
    //     writes 64 complete nZ N-columns (16 fractals) to L0B;
    //   - srcStride steps the source between repeats in 2048B blocks, so one
    //     N-C0 block (64 columns) needs srcStride = roundUp16(K) / 64, where
    //     K is the FULL L1 tile depth (template srcM) because the zN buffer
    //     is allocated for the whole tile;
    //   - dstGap advances the destination by (1 + dstGap) nZ N-fractals (16
    //     columns each), so 64 columns per repeat needs dstGap = 3.
    AscendC::LoadData2dTransposeParams loadDataParams;
    loadDataParams.startIndex = 0;
    loadDataParams.repeatTimes = (dstN + 63) / 64;
    loadDataParams.srcStride = ((srcM + 15) / 16 * 16) / 64;
    loadDataParams.dstGap = 3;
    loadDataParams.dstFracGap = 0;
    loadDataParams.addrMode = 0;
    // One LoadDataWithTranspose per K-C0 block (64 K elements). Block stride:
    // 2048B (4 fractals) in the zN source; roundUp16(N) x 64 elements in the
    // nZ destination (64 K rows spanning the whole N extent).
    const uint32_t kBlocks = (dstM + 63) / 64;
    const uint32_t dstKBlockStride = ((dstN + 15) / 16 * 16) * 64;
    const uint32_t srcKBlockStride = 4 * EleNumPerFractal<T>();
    for (uint32_t b = 0; b < kBlocks; b++) {
      AscendC::LoadDataWithTranspose(dstTensor[b * dstKBlockStride],
                                     srcTensor[b * srcKBlockStride],
                                     loadDataParams);
    }
    return;
  }
  using LayoutL1_ =
      std::conditional_t<transpose,
                         Catlass::detail::TagToLayout_t<T, LayoutL1T>,
                         Catlass::detail::TagToLayout_t<T, LayoutL1>>;
  constexpr auto layout = transpose ? tla::MakeLayout<T, LayoutL1_>(srcN, srcM)
                                    : tla::MakeLayout<T, LayoutL1_>(srcM, srcN);
  auto src_LAYOUT = MakeLayoutTile(layout, tla::MakeShape(dstM, dstN));
  auto src = MakeTensor<decltype(srcTensor), decltype(src_LAYOUT),
                        AscendC::TPosition::A1>(srcTensor, src_LAYOUT);

  using LayoutL0B_ = Catlass::detail::TagToLayout_t<T, LayoutL0B>;
  auto layoutBInL0 = tla::MakeLayout<T, LayoutL0B_>(dstM, dstN);
  auto dst = tla::MakeTensor<decltype(dstTensor), decltype(layoutBInL0),
                             AscendC::TPosition::B2>(dstTensor, layoutBInL0);

  TileCopyTla<ArchTag, decltype(src), decltype(dst)> tileCopier;
  tileCopier(dst, src);
}

template <typename T1, typename T2, uint32_t M, uint32_t N>
CATLASS_DEVICE void mma(LocalTensor<T1> const A, LocalTensor<T1> const B,
                        LocalTensor<T2> const C, bool init, uint32_t K,
                        uint32_t n_actual = N, uint8_t unitFlag = 0) {
  // n_actual: runtime number of output columns to compute (<= N). Defaults to
  // the compile-time N, so existing callers are byte-identical. Enables
  // variable-N gemm (e.g. QK over the actual window length), mirroring how K is
  // already a runtime arg.
  MmadParams mmadParams;
  mmadParams.m = M;
  mmadParams.n = n_actual;
  mmadParams.k = K;
  mmadParams.cmatrixInitVal = init;
  // MmadParams does not default-initialise cmatrixSource, and the hardware
  // reads it whenever cmatrixInitVal == false (an accumulating mma, C sourced
  // from L0C). A single-mma caller never notices, but a K-accumulating sequence
  // that also sets unitFlag reads the uninitialised field and hangs the cube.
  // false ("source from L0C") is what every accumulating caller already means.
  mmadParams.cmatrixSource = false;
  // unitFlag drives the hardware mma->fixpipe pipeline: 0b10 keeps the result
  // in L0C, 0b11 releases it to a paired fixpipe. That is what lets
  // fixpipe(tile i) overlap mma(tile i+1) across a two-slot L0C ping-pong,
  // without a software M_FIX/FIX_M handshake. Defaults to 0 (off), so every
  // existing caller is byte-for-byte unchanged.
  mmadParams.unitFlag = unitFlag;

  Mmad(C, A, B, mmadParams);

  constexpr uint32_t PIPE_M_BARRIER_THRESHOLD = 10;
  // if constexpr ((M / C0_NUM_PER_FRACTAL) * (N / C0_NUM_PER_FRACTAL) <
  //               PIPE_M_BARRIER_THRESHOLD) {
  //   PipeBarrier<PIPE_M>();
  // }
}

template <typename T1, typename T2, typename LayoutGM, uint32_t srcM,
          uint32_t srcN, bool enRelu = false>
CATLASS_DEVICE void
copy_l0c_to_gm(GlobalTensor<T2> dstTensor, LocalTensor<T1> srcTensor,
               uint32_t realDstN = 1, uint32_t realTailM = 0,
               uint32_t realTailN = 0, uint8_t unitFlag = 0) {
  uint32_t tailM = realTailM == 0 ? srcM : realTailM;
  uint32_t tailN = realTailN == 0 ? srcN : realTailN;
  auto layoutInL0C = tla::MakeLayoutL0C(srcM, srcN);
  auto src = tla::MakeTensor<decltype(srcTensor), decltype(layoutInL0C),
                             AscendC::TPosition::CO1>(srcTensor, layoutInL0C);
  LayoutGM gm{tailM, realDstN};
  auto layout = MakeLayoutFromTag(gm);
  auto dTensor = MakeTensor(dstTensor, layout, Arch::PositionGM{});
  auto layout_ = dTensor.layout();
  auto dst_LAYOUT = MakeLayoutTile(layout_, tla::MakeShape(tailM, tailN));
  auto dst = MakeTensor<decltype(dstTensor), decltype(dst_LAYOUT),
                        AscendC::TPosition::GM>(dstTensor, dst_LAYOUT);

  CopyL0CToGmTla<ArchTag, decltype(src), decltype(dst),
                 ScaleGranularity::NO_QUANT, enRelu>
      tileCopier;
  // unitFlag (default 0 = a standalone fixpipe) pairs with the Mmad unitFlag to
  // form the hardware mma->fixpipe pipeline; CopyL0CToGmTla already plumbs it
  // through to FixpipeParams.
  tileCopier(dst, src, unitFlag);
}

template <uint32_t M, uint32_t N, uint32_t K, uint32_t block_M,
          uint32_t block_N, uint32_t SwizzleOffset = 1,
          uint32_t SwizzleDirection = 0>
CATLASS_DEVICE auto thread_block_swizzle(uint64_t pid) {
  GemmCoord problem_shape = GemmCoord(M, N, K);
  MatrixCoord tile_shape = MatrixCoord(block_M, block_N);

  GemmIdentityBlockSwizzle swizzle =
      GemmIdentityBlockSwizzle<SwizzleOffset, SwizzleDirection>(problem_shape,
                                                                tile_shape);

  auto cols = swizzle.loopsMN.column();

  auto coord = swizzle.GetBlockCoord(pid);

  // return coord;
  return coord.m() * cols + coord.n();
}

// Generic valid-region transfers. Pitches/counts are elements of T. No
// unrequested rows are cleared. GM/UB transfers add no dependency waits;
// UB/UB scalar fallback synchronizes scalar/vector access. Callers own
// source/destination lifetime and explicit MTE pipeline synchronization.
// UB row pitches must be 32-byte aligned and fit the rounded copied row.
// The GM pitch is byte granular; thus (M,3) int32 assist output stays packed.
template <typename T>
CATLASS_DEVICE void copy_gm_to_ub_strided(LocalTensor<T> dst,
    GlobalTensor<T> src, uint32_t srcPitch, uint32_t dstPitch,
    uint32_t rows, uint32_t width) {
  if (rows == 0 || width == 0) return;
  constexpr uint32_t maxBytes = 65504;  // largest 32B multiple below uint16 max
  const uint32_t totalBytes = width * sizeof(T);
  const uint32_t srcPitchBytes = srcPitch * sizeof(T);
  const uint32_t dstPitchBytes = dstPitch * sizeof(T);
  for (uint32_t colBytes = 0; colBytes < totalBytes; colBytes += maxBytes) {
    const uint32_t bytes = totalBytes - colBytes > maxBytes ? maxBytes : totalBytes - colBytes;
    const uint32_t rounded = (bytes + 31) / 32 * 32;
    const uint32_t rowGroup = srcPitchBytes >= bytes && dstPitchBytes >= rounded ? 4095 : 1;
    for (uint32_t first = 0; first < rows; first += rowGroup) {
      const uint32_t count = rows - first > rowGroup ? rowGroup : rows - first;
      AscendC::DataCopyExtParams params{static_cast<uint16_t>(count), bytes,
          count > 1 ? srcPitchBytes - bytes : 0,
          count > 1 ? (dstPitchBytes - rounded) / 32 : 0, 0};
      AscendC::DataCopyPadExtParams<T> pad{false, 0, 0, T(0)};
      AscendC::DataCopyPad(dst[first * dstPitch + colBytes / sizeof(T)],
          src[first * srcPitch + colBytes / sizeof(T)], params, pad);
    }
  }
}

template <typename T>
CATLASS_DEVICE void copy_ub_to_gm_strided(GlobalTensor<T> dst,
    LocalTensor<T> src, uint32_t srcPitch, uint32_t dstPitch,
    uint32_t rows, uint32_t width) {
  if (rows == 0 || width == 0) return;
  constexpr uint32_t maxBytes = 65504;
  const uint32_t totalBytes = width * sizeof(T);
  const uint32_t srcPitchBytes = srcPitch * sizeof(T);
  const uint32_t dstPitchBytes = dstPitch * sizeof(T);
  for (uint32_t colBytes = 0; colBytes < totalBytes; colBytes += maxBytes) {
    const uint32_t bytes = totalBytes - colBytes > maxBytes ? maxBytes : totalBytes - colBytes;
    const uint32_t rounded = (bytes + 31) / 32 * 32;
    const uint32_t rowGroup = srcPitchBytes >= rounded && dstPitchBytes >= bytes ? 4095 : 1;
    for (uint32_t first = 0; first < rows; first += rowGroup) {
      const uint32_t count = rows - first > rowGroup ? rowGroup : rows - first;
      AscendC::DataCopyExtParams params{static_cast<uint16_t>(count), bytes,
          count > 1 ? (srcPitchBytes - rounded) / 32 : 0,
          count > 1 ? dstPitchBytes - bytes : 0, 0};
      AscendC::DataCopyPad(dst[first * dstPitch + colBytes / sizeof(T)],
          src[first * srcPitch + colBytes / sizeof(T)], params);
    }
  }
}

template <typename T>
CATLASS_DEVICE void copy_ub_to_ub_strided(LocalTensor<T> dst,
    LocalTensor<T> src, uint32_t srcPitch, uint32_t dstPitch,
    uint32_t rows, uint32_t width) {
  if (rows == 0 || width == 0) return;
  // Vector Copy uses 256-byte repeats and 32-byte repeat strides. A bit view
  // avoids treating uint32 payload words as unsupported arithmetic operands.
  // Unaligned/non-vector element sizes retain correct scalar buffer semantics.
  if constexpr (sizeof(T) == 4 || sizeof(T) == 2) {
    using CopyType = std::conditional_t<sizeof(T) == 4, int32_t, int16_t>;
    auto d = dst.template ReinterpretCast<CopyType>();
    auto s = src.template ReinterpretCast<CopyType>();
    constexpr uint32_t vectorElements = 256 / sizeof(T);
    const uint32_t srcBlocks = srcPitch * sizeof(T) / 32;
    const uint32_t dstBlocks = dstPitch * sizeof(T) / 32;
    if (rows == 1 || (srcPitch * sizeof(T) % 32 == 0 &&
        dstPitch * sizeof(T) % 32 == 0 && srcBlocks <= 255 && dstBlocks <= 255)) {
      for (uint32_t col = 0; col < width; col += vectorElements) {
        const uint64_t mask = width - col > vectorElements ? vectorElements : width - col;
        for (uint32_t first = 0; first < rows; first += 255) {
          const uint8_t count = static_cast<uint8_t>(rows - first > 255 ? 255 : rows - first);
          AscendC::Copy(d[first * dstPitch + col], s[first * srcPitch + col], mask, count,
              {1, 1, static_cast<uint8_t>(rows == 1 ? 0 : dstBlocks),
               static_cast<uint8_t>(rows == 1 ? 0 : srcBlocks)});
        }
      }
      return;
    }
  }
  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
  for (uint32_t row = 0; row < rows; ++row) {
    for (uint32_t col = 0; col < width; ++col) {
      dst.SetValue(row * dstPitch + col, src.GetValue(row * srcPitch + col));
    }
  }
  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
}

template <typename T, uint32_t dstN, uint32_t dstM = 1>
CATLASS_DEVICE void
copy_gm_to_ub(LocalTensor<T> dstTensor, GlobalTensor<T> srcTensor,
              uint32_t realSrcN = 1, uint32_t maskShapeM = dstM,
              uint32_t maskShapeN = dstN, T padValue = T(0)) {
  // Hybrid scheme: the UB gap ([maskShapeN, dstN) / [maskShapeM, dstM)) is
  // filled with ``padValue`` via Duplicate so that downstream reduce /
  // broadcast / compare / select ops (which still read the full tile) observe a
  // defined value. AscendTailMaskPropagation additionally rewrites unary /
  // binary / scalar ops to tail_* helpers that compute only over the valid
  // region, so the pad value in the gap is preserved (not corrupted by
  // elementwise ops) and reaches the unreduced readers intact.
  bool isPad = true;
  uint32_t rightPadding = 1;
  if (maskShapeN == dstN || EleNumToBytes<T>(maskShapeN) % 32 == 0) {
    isPad = false;
    rightPadding = 0;
  }
  if (maskShapeM != dstM || maskShapeN != dstN) {
    if constexpr (IsDuplicateSupported_v<T>) {
      SetFlag<HardEvent::MTE2_V>(0);
      WaitFlag<HardEvent::MTE2_V>(0);
      SetFlag<HardEvent::MTE3_V>(0);
      WaitFlag<HardEvent::MTE3_V>(0);
      AscendC::Duplicate<T>(dstTensor, padValue, dstM * dstN);
      SetFlag<HardEvent::V_MTE2>(0);
      WaitFlag<HardEvent::V_MTE2>(0);
    }
  }
  AscendC::DataCopyExtParams dataCopyParams(
      maskShapeM, EleNumToBytes<T>(maskShapeN),
      EleNumToBytes<T>(realSrcN - maskShapeN),
      EleNumToBytes<T>(dstN - maskShapeN) / 32, 0);
  AscendC::DataCopyPadExtParams<T> padParams(isPad, 0, rightPadding, padValue);
  AscendC::DataCopyPad(dstTensor, srcTensor, dataCopyParams, padParams);
}

template <typename T, uint32_t srcN, uint32_t srcM = 1>
CATLASS_DEVICE void
copy_ub_to_gm(GlobalTensor<T> dstTensor, LocalTensor<T> srcTensor,
              uint32_t realdstN = 1, uint32_t maskShapeM = srcM,
              uint32_t maskShapeN = srcN) {
  // MTE3 (UB -> GM) copy semantics (dav-c220 / dav-c310):
  //  * per burst the UB source advances ceil(blockLen / 32) + srcStride
  //    whole 32B blocks - the "narrow UB rows sit in 32B slots" convention
  //    (MTE-filled buffers and the packed-mask helpers write rows on 32B
  //    boundaries);
  //  * the GM-side stride is byte granular - destination addresses need no
  //    alignment;
  //  * blockLen is a 16-bit field (max 65535), blockCount a 12-bit field
  //    (max 4095).
  // A compact sub-32B-pitch multi-row source (e.g. a V-pipe (M, 1) fp32
  // keepdim reduce result, issue #1682) breaks that slot stepping; when
  // both sides are packed the copy is one contiguous slab, emitted as a
  // single flat burst.
  // bisheng's cross-pipe dependency sync only covers straight-line code: a
  // GM scalar store beside a DataCopyPad (notably in a sibling branch) or a
  // runtime branch around the call makes it miscompile and deadlock the MTE3
  // queue. So the DataCopyPad below stays straight-line and unconditional,
  // and what the engine cannot express aborts explicitly instead of
  // silently corrupting.
  // Byte math uses EleNumToBytes<T>() (bit-width exact) so sub-byte dtypes
  // (int4: two elements per byte) count real bytes instead of sizeof(T)
  // (which is 1 for the packed int4b_t); for all non sub-byte dtypes the
  // values are identical to sizeof(T) math.
  constexpr uint32_t kBlockBytes = 32;
  const uint32_t blockLen = EleNumToBytes<T>(maskShapeN);
  const uint32_t srcPitch = EleNumToBytes<T>(srcN);
  const uint32_t dstPitch = EleNumToBytes<T>(realdstN);
  if (blockLen == 0 || maskShapeM == 0) {
    return;
  }

  const bool packed = srcN == maskShapeN && realdstN == maskShapeN;
  const uint64_t total = static_cast<uint64_t>(maskShapeM) * blockLen;
  const bool flat = packed && total <= 65535;
  // A srcPitch >= 32B that is not a 32B multiple (e.g. a compact (M, 10)
  // fp32 source, 40B rows) can be read by neither DMA form: no srcStride
  // makes the multi-burst step such a pitch, and per-row single bursts
  // would need 32B-aligned sources (device: MTE ADDR_MISALIGN); a scalar
  // fallback is barred by the bisheng constraint above. Only the
  // single-burst forms (one row, or both sides packed) are correct - abort
  // the rest via trap(), since ASCENDC_ASSERT compiles to nothing in a
  // real device build.
  if constexpr (srcPitch % kBlockBytes != 0 && srcPitch >= kBlockBytes) {
    if (!(maskShapeM == 1 || flat)) {
      trap();
    }
  }
  // Flat form (both sides packed): one burst covers the whole slab.
  // Everything else keeps the classic multi-burst.
  uint32_t blockCount = maskShapeM;
  uint32_t burstLen = blockLen;
  uint32_t srcStride = (srcPitch - blockLen) / kBlockBytes;
  uint32_t dstStride = dstPitch - blockLen;
  if (flat) {
    blockCount = 1;
    burstLen = static_cast<uint32_t>(total);
    srcStride = 0;
    dstStride = 0;
  }
  AscendC::DataCopyExtParams dataCopyParams(blockCount, burstLen, srcStride,
                                            dstStride, 0);
  AscendC::DataCopyPad(dstTensor, srcTensor, dataCopyParams);
}

template <typename T, uint32_t srcN, uint32_t srcM = 1>
CATLASS_DEVICE void
atomic_add_ub_to_gm(GlobalTensor<T> dstTensor, LocalTensor<T> srcTensor,
                    uint32_t realdstN = 1, uint32_t maskShapeM = srcM,
                    uint32_t maskShapeN = srcN) {
  AscendC::SetAtomicAdd<T>();
  copy_ub_to_gm<T, srcN, srcM>(dstTensor, srcTensor, realdstN, maskShapeM,
                               maskShapeN);
  disable_dma_atomic_compat();
}

template <typename T1, typename T2, typename LayoutGM, uint32_t srcM,
          uint32_t srcN, bool enRelu = false>
CATLASS_DEVICE void
atomic_add_l0c_to_gm(GlobalTensor<T2> dstTensor, LocalTensor<T1> srcTensor,
                     uint32_t realDstN = 1, uint32_t realTailM = 0,
                     uint32_t realTailN = 0) {
  AscendC::SetAtomicAdd<T2>();
  copy_l0c_to_gm<T1, T2, LayoutGM, srcM, srcN, enRelu>(
      dstTensor, srcTensor, realDstN, realTailM, realTailN);
  disable_dma_atomic_compat();
}

template <typename T1, typename T2, uint32_t len>
CATLASS_DEVICE void copy_ub_to_ub(LocalTensor<T1> dstTensor,
                                  LocalTensor<T2> srcTensor) {
  if constexpr (std::is_same_v<T1, T2>) {
    AscendC::DataCopy(dstTensor, srcTensor, len);
  } else {
    if constexpr ((std::is_same_v<T1, float> && std::is_same_v<T2, half>) ||
                  (std::is_same_v<T1, float> &&
                   std::is_same_v<T2, bfloat16_t>) ||
                  (std::is_same_v<T1, float> && std::is_same_v<T2, int16_t>) ||
                  (std::is_same_v<T1, half> && std::is_same_v<T2, int8_t>) ||
                  (std::is_same_v<T1, int16_t> &&
                   std::is_same_v<T2, int32_t>)) {
      AscendC::Cast(dstTensor, srcTensor, AscendC::RoundMode::CAST_NONE, len);
    } else {
      AscendC::Cast(dstTensor, srcTensor, AscendC::RoundMode::CAST_RINT, len);
    }
  }
}

template <typename T1, typename T2, uint32_t len>
CATLASS_DEVICE void
copy_ub_to_ub(LocalTensor<T1> dstTensor, LocalTensor<T2> srcTensor,
              uint32_t src_rows, uint32_t src_cols, uint32_t src_stride,
              uint32_t dst_rows, uint32_t dst_cols, uint32_t dst_stride) {
  if (src_cols == src_stride && dst_cols == dst_stride) {
    copy_ub_to_ub<T1, T2, len>(dstTensor, srcTensor);
  } else {
    for (uint32_t i = 0; i < src_rows; i++) {
      if constexpr (std::is_same_v<T1, T2>) {
        AscendC::DataCopy(dstTensor[i * dst_stride], srcTensor[i * src_stride],
                          src_cols);
      } else {
        if constexpr ((std::is_same_v<T1, float> && std::is_same_v<T2, half>) ||
                      (std::is_same_v<T1, float> &&
                       std::is_same_v<T2, bfloat16_t>) ||
                      (std::is_same_v<T1, float> &&
                       std::is_same_v<T2, int16_t>) ||
                      (std::is_same_v<T1, half> &&
                       std::is_same_v<T2, int8_t>) ||
                      (std::is_same_v<T1, int16_t> &&
                       std::is_same_v<T2, int32_t>)) {
          AscendC::Cast(dstTensor[i * dst_stride], srcTensor[i * src_stride],
                        AscendC::RoundMode::CAST_NONE, src_cols);
        } else {
          AscendC::Cast(dstTensor[i * dst_stride], srcTensor[i * src_stride],
                        AscendC::RoundMode::CAST_RINT, src_cols);
        }
      }
    }
  }
}

template <typename T, uint32_t M, uint32_t N>
CATLASS_DEVICE void copy_ub_to_l1(LocalTensor<T> dstTensor,
                                  LocalTensor<T> srcTensor) {
  static_assert(std::is_same_v<T, half>, "only support half");
  static_assert(M % 16 == 0, "M must be the multiple of 16");

  AscendC::DataCopyExtParams dataCopyParams(M, N * sizeof(T), 0, 0, 0);

  AscendC::Nd2NzParams nd2nzParams;
  nd2nzParams.ndNum = 1;
  nd2nzParams.nValue = M;
  nd2nzParams.dValue = N;
  nd2nzParams.srcNdMatrixStride = 0;
  nd2nzParams.srcDValue = N;
  nd2nzParams.dstNzC0Stride = M;
  nd2nzParams.dstNzNStride = 1;
  nd2nzParams.dstNzMatrixStride = 0;

  AscendC::DataCopyPad(dstTensor, srcTensor, dataCopyParams, nd2nzParams);
}

template <typename T, uint32_t Len>
CATLASS_DEVICE void tile_add(LocalTensor<T> const &ubIn0,
                             LocalTensor<T> const &ubIn1,
                             LocalTensor<T> const &ubOut) {
  AscendC::Add(ubOut, ubIn0, ubIn1, Len);
}

template <typename T, uint32_t Len, uint32_t op>
CATLASS_DEVICE void elementwise_binary(LocalTensor<T> const &ubIn0,
                                       LocalTensor<T> const &ubIn1,
                                       LocalTensor<T> const &ubOut) {
  // AscendC::Elementwise(ubOut, ubIn0, ubIn1, op, Len);
  if constexpr (op == 0) {
    AscendC::Add(ubOut, ubIn0, ubIn1, Len);
  } else if constexpr (op == 1) {
    AscendC::Sub(ubOut, ubIn0, ubIn1, Len);
  } else if constexpr (op == 2) {
    AscendC::Mul(ubOut, ubIn0, ubIn1, Len);
  } else if constexpr (op == 3) {
    AscendC::Div(ubOut, ubIn0, ubIn1, Len);
  }
}

template <typename T>
CATLASS_DEVICE void shmem_put_nbi(const GlobalTensor<T> &output,
                                  const GlobalTensor<T> &input, size_t nelems,
                                  size_t newPe) {
  AscendC::TPipe pipe;
  uint32_t ub_size = UB_HALF_SIZE * 2 + 64;
  AscendC::TBuf<AscendC::TPosition::VECIN> ub_buf;
  pipe.InitBuffer(ub_buf, ub_size);
  auto ub_tensor = ub_buf.Get<T>();
  pipe.Destroy();
  __gm__ T *outputPtr = const_cast<__gm__ T *>(output.GetPhyAddr());
  __gm__ T *inputPtr = const_cast<__gm__ T *>(input.GetPhyAddr());
  __ubuf__ T *buf = reinterpret_cast<__ubuf__ T *>(ub_tensor.GetPhyAddr());
  aclshmemx_mte_put_nbi(outputPtr, inputPtr, buf, ub_size, nelems, newPe,
                        EVENT_ID0);
}

template <typename T>
CATLASS_DEVICE void shmem_ub_put_nbi(const LocalTensor<T> &ubTensor,
                                     const GlobalTensor<T> &output,
                                     size_t nelems, int newPe, int strelem) {
  aclshmemx_mte_put_nbi(const_cast<__gm__ T *>(output.GetPhyAddr() + strelem),
                        reinterpret_cast<__ubuf__ T *>(ubTensor.GetPhyAddr()),
                        nelems, newPe, EVENT_ID0);
}

template <typename T>
CATLASS_DEVICE void shmem_get_nbi(const GlobalTensor<T> &output,
                                  const GlobalTensor<T> &input, size_t nelems,
                                  size_t newPe) {
  AscendC::TPipe pipe;
  uint32_t ub_size = UB_HALF_SIZE * 2 + 64;
  AscendC::TBuf<AscendC::TPosition::VECIN> ub_buf;
  pipe.InitBuffer(ub_buf, ub_size);
  auto ub_tensor = ub_buf.Get<T>();
  pipe.Destroy();
  __gm__ T *outputPtr = const_cast<__gm__ T *>(output.GetPhyAddr());
  __gm__ T *inputPtr = const_cast<__gm__ T *>(input.GetPhyAddr());
  __ubuf__ T *buf = reinterpret_cast<__ubuf__ T *>(ub_tensor.GetPhyAddr());
  aclshmemx_mte_get_nbi(outputPtr, inputPtr, buf, ub_size, nelems, newPe,
                        EVENT_ID0);
}

template <typename T>
CATLASS_DEVICE void shmem_ub_get_nbi(const LocalTensor<T> &output,
                                     const GlobalTensor<T> &input,
                                     size_t nelems, size_t newPe) {
  aclshmemx_mte_get_nbi(reinterpret_cast<__ubuf__ T *>(output.GetPhyAddr()),
                        const_cast<__gm__ T *>(input.GetPhyAddr()), nelems,
                        newPe, EVENT_ID0);
}

template <typename T, uint32_t Len, uint32_t op>
CATLASS_DEVICE void elementwise_unary(LocalTensor<T> const &ubIn,
                                      LocalTensor<T> const &ubOut) {
  // AscendC::Elementwise(ubOut, ubIn0, ubIn1, op, Len);
  if constexpr (op == 0) {
    // TODO: Check layout, Len only has bug.
    AscendC::Exp(ubOut, ubIn, Len);
  }
}

template <typename dst, typename src, const char round_mode[], uint32_t Len>
CATLASS_DEVICE void cast(LocalTensor<dst> const &ubOut,
                         LocalTensor<src> const &ubIn) {
  AscendC::Cast(ubOut, ubIn, round_mode, Len);
}

// template <typename T, uint32_t Len>
// CATLASS_DEVICE void fill(LocalTensor<T> const &ubOut, T value) {
//   AscendC::Duplicate(ubOut, value, Len);
// }

template <typename T>
CATLASS_DEVICE void
reduce_sum_half(LocalTensor<T> const &dstTensor,
                LocalTensor<T> const &srcTensor, const int32_t mask,
                const int32_t repeatTime, const int32_t srcRepStride) {
  AscendC::WholeReduceSum<T>(dstTensor, srcTensor, mask, repeatTime, 1, 1,
                             srcRepStride);
}

// Row-reduce a narrow column range of a wider tile.
//
// AscendC's Reduce* takes a {M, N} shape and reads the source as a CONTIGUOUS
// M x N block, so it cannot express "N columns out of each row of a wider
// buffer": for a [M, 512] tile and a logical width of 64 it reads elements
// [0, M*64), which is row 0's first eight chunks, not the first 64 columns of
// each of the M rows. WholeReduce* instead takes an explicit per-repeat source
// stride, so one repeat per row with srcRepStride set to the PHYSICAL row width
// reduces the intended region. One repeat covers at most 256 bytes, which is
// what bounds the usable width.
template <typename T, bool isSetMask = true>
CATLASS_DEVICE void
reduce_max_narrow(LocalTensor<T> const &dstTensor,
                  LocalTensor<T> const &srcTensor, const int32_t mask,
                  const int32_t repeatTime, const int32_t srcRepStride) {
  AscendC::WholeReduceMax<T, isSetMask>(dstTensor, srcTensor, mask, repeatTime,
                                        1, 1, srcRepStride,
                                        AscendC::ReduceOrder::ORDER_ONLY_VALUE);
}

template <typename T, bool isSetMask = true>
CATLASS_DEVICE void
reduce_min_narrow(LocalTensor<T> const &dstTensor,
                  LocalTensor<T> const &srcTensor, const int32_t mask,
                  const int32_t repeatTime, const int32_t srcRepStride) {
  AscendC::WholeReduceMin<T, isSetMask>(dstTensor, srcTensor, mask, repeatTime,
                                        1, 1, srcRepStride,
                                        AscendC::ReduceOrder::ORDER_ONLY_VALUE);
}

template <typename T, bool isSetMask = true>
CATLASS_DEVICE void
reduce_sum_narrow(LocalTensor<T> const &dstTensor,
                  LocalTensor<T> const &srcTensor, const int32_t mask,
                  const int32_t repeatTime, const int32_t srcRepStride) {
  AscendC::WholeReduceSum<T, isSetMask>(dstTensor, srcTensor, mask, repeatTime,
                                        1, 1, srcRepStride);
}

template <typename T, uint32_t M, uint32_t N, int32_t dim>
CATLASS_DEVICE void
reduce_sum(LocalTensor<T> const &dstTensor, LocalTensor<T> const &srcTensor,
           LocalTensor<uint8_t> const &sharedTmpBuffer, bool clear = true) {
  uint32_t shape[] = {M, N};
  if (clear) {
    if constexpr (dim == -1) {
      AscendC::ReduceSum<T, AscendC::Pattern::Reduce::AR>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    } else {
      AscendC::ReduceSum<T, AscendC::Pattern::Reduce::RA>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    }
    return;
  }

  constexpr uint32_t kReduceResultLen = dim == -1 ? M : N;
  // ReduceSum appears to use scratch in a way that can interfere with a local
  // UB backup on real_shape/slice paths, so keep the old dst in scalar locals
  // before forcing clear=true and merging manually.
  T dstBackup[kReduceResultLen];
  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    dstBackup[i] = dstTensor.GetValue(i);
  }

  if constexpr (dim == -1) {
    AscendC::ReduceSum<T, AscendC::Pattern::Reduce::AR>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  } else {
    AscendC::ReduceSum<T, AscendC::Pattern::Reduce::RA>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  }

  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    T reducedValue = dstTensor.GetValue(i);
    dstTensor.SetValue(i, static_cast<T>(reducedValue + dstBackup[i]));
  }
}

template <typename T>
CATLASS_DEVICE T reduce_scalar_max_safe(T lhsValue, T rhsValue) {
  // Bisheng/AICore does not allow scalar half/bfloat16 comparisons inside
  // device code, so the clear=false fallback compares through float.
  if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
    return static_cast<float>(lhsValue) > static_cast<float>(rhsValue)
               ? lhsValue
               : rhsValue;
  } else {
    return lhsValue > rhsValue ? lhsValue : rhsValue;
  }
}

template <typename T, uint32_t M, uint32_t N, int32_t dim>
CATLASS_DEVICE void
reduce_max(LocalTensor<T> const &dstTensor, LocalTensor<T> const &srcTensor,
           LocalTensor<uint8_t> const &sharedTmpBuffer, bool clear = true) {
  uint32_t shape[] = {M, N};
  if (clear) {
    if constexpr (dim == -1) {
      AscendC::ReduceMax<T, AscendC::Pattern::Reduce::AR>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    } else {
      AscendC::ReduceMax<T, AscendC::Pattern::Reduce::RA>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    }
    return;
  }

  // AscendC::ReduceMax(..., clear=false) does not reliably preserve the
  // upstream "merge old dst with reduced value" contract on real_shape/slice
  // paths, so we make the merge explicit here.
  constexpr uint32_t kReduceResultLen = dim == -1 ? M : N;
  T dstBackup[kReduceResultLen];
  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    dstBackup[i] = dstTensor.GetValue(i);
  }

  if constexpr (dim == -1) {
    AscendC::ReduceMax<T, AscendC::Pattern::Reduce::AR>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  } else {
    AscendC::ReduceMax<T, AscendC::Pattern::Reduce::RA>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  }

  // Keep the merge explicit instead of relying on an in-place vector max,
  // because aliasing dst with one input can produce unstable results here.
  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    T reducedValue = dstTensor.GetValue(i);
    T backupValue = dstBackup[i];
    dstTensor.SetValue(i, reduce_scalar_max_safe(reducedValue, backupValue));
  }
}

template <typename T>
CATLASS_DEVICE T reduce_scalar_min_safe(T lhsValue, T rhsValue) {
  // Bisheng/AICore does not allow scalar half/bfloat16 comparisons inside
  // device code, so the clear=false fallback compares through float.
  if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
    return static_cast<float>(lhsValue) < static_cast<float>(rhsValue)
               ? lhsValue
               : rhsValue;
  } else {
    return lhsValue < rhsValue ? lhsValue : rhsValue;
  }
}

template <typename T, uint32_t M, uint32_t N, int32_t dim>
CATLASS_DEVICE void
reduce_min(LocalTensor<T> const &dstTensor, LocalTensor<T> const &srcTensor,
           LocalTensor<uint8_t> const &sharedTmpBuffer, bool clear = true) {
  uint32_t shape[] = {M, N};
  if (clear) {
    if constexpr (dim == -1) {
      AscendC::ReduceMin<T, AscendC::Pattern::Reduce::AR>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    } else {
      AscendC::ReduceMin<T, AscendC::Pattern::Reduce::RA>(
          dstTensor, srcTensor, sharedTmpBuffer, shape, true);
    }
    return;
  }

  // AscendC::ReduceMin(..., clear=false) does not reliably preserve the
  // upstream "merge old dst with reduced value" contract on real_shape/slice
  // paths, so we make the merge explicit here.
  constexpr uint32_t kReduceResultLen = dim == -1 ? M : N;
  T dstBackup[kReduceResultLen];
  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    dstBackup[i] = dstTensor.GetValue(i);
  }

  if constexpr (dim == -1) {
    AscendC::ReduceMin<T, AscendC::Pattern::Reduce::AR>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  } else {
    AscendC::ReduceMin<T, AscendC::Pattern::Reduce::RA>(
        dstTensor, srcTensor, sharedTmpBuffer, shape, true);
  }

  // Keep the merge explicit instead of relying on an in-place vector min,
  // because aliasing dst with one input can produce unstable results here.
  for (uint32_t i = 0; i < kReduceResultLen; ++i) {
    T reducedValue = dstTensor.GetValue(i);
    T backupValue = dstBackup[i];
    dstTensor.SetValue(i, reduce_scalar_min_safe(reducedValue, backupValue));
  }
}

// Expose the helper's Vector pipe to BiSheng automatic synchronization.
#pragma begin_pipe(V)
template <typename T, reduce2d_v2::Reduce2DKind Kind, bool Clear, uint32_t M,
          uint32_t N, int32_t Dim, uint32_t PhysicalRow, bool AllowRepeatZero>
CATLASS_DEVICE void reduce_2d(LocalTensor<T> const &dstTensor,
                              LocalTensor<T> const &srcTensor,
                              LocalTensor<T> const &sharedTmpBuffer) {
  static_assert(std::is_same_v<T, float> && Dim == -1,
                "Reduce2D v2 only supports fp32 row reduction");
  reduce2d_v2::Reduce2D<T, Kind, Clear, M, N, PhysicalRow, AllowRepeatZero>(
      dstTensor, srcTensor, sharedTmpBuffer);
}
#pragma end_pipe

// ===================== Tail-aware vector helpers =========================
// AscendTailMaskPropagation rewrites vector ops on tail UB tiles to these
// helpers. A tail tile carries a valid rectangle [validRow, validCol] laid out
// with a physical row pitch of physCol (the allocated tile width). We choose
// the cheapest correct execution:
//   - full rows (validCol == physCol): one contiguous count call;
//   - narrow tail (validCol <= elements-per-256B-repeat): native mask + repeat,
//     one repeat per row with the repeat stride derived from physCol;
//   - otherwise: per-row contiguous fallback (skips only the gap rows).
// Masking does not make a single repeat cheaper; the saving comes from issuing
// fewer 256B repeats (fewer rows and/or fewer whole column blocks).

enum class TailVecUnOp { Exp, Ln, Abs, Reciprocal, Sqrt, Rsqrt, Relu };
enum class TailVecBinOp { Add, Sub, Mul, Div, Max, Min };
enum class TailVecScalarOp { Adds, Muls, Maxs, Mins };

template <typename T> struct TailIsFloatLike {
  static constexpr bool value = std::is_same_v<T, float> ||
                                std::is_same_v<T, half> ||
                                std::is_same_v<T, bfloat16_t>;
};

// ---- binary ----
template <typename T>
CATLASS_DEVICE void TailApplyBinCount(TailVecBinOp op, LocalTensor<T> d,
                                      LocalTensor<T> s0, LocalTensor<T> s1,
                                      int32_t n) {
  switch (op) {
  case TailVecBinOp::Add:
    AscendC::Add(d, s0, s1, n);
    break;
  case TailVecBinOp::Sub:
    AscendC::Sub(d, s0, s1, n);
    break;
  case TailVecBinOp::Mul:
    AscendC::Mul(d, s0, s1, n);
    break;
  case TailVecBinOp::Div:
    AscendC::Div(d, s0, s1, n);
    break;
  case TailVecBinOp::Max:
    AscendC::Max(d, s0, s1, n);
    break;
  case TailVecBinOp::Min:
    AscendC::Min(d, s0, s1, n);
    break;
  }
}

template <typename T>
CATLASS_DEVICE void TailApplyBinMask(TailVecBinOp op, LocalTensor<T> d,
                                     LocalTensor<T> s0, LocalTensor<T> s1,
                                     uint64_t mask, uint8_t repeat,
                                     const AscendC::BinaryRepeatParams &rp) {
  switch (op) {
  case TailVecBinOp::Add:
    AscendC::Add(d, s0, s1, mask, repeat, rp);
    break;
  case TailVecBinOp::Sub:
    AscendC::Sub(d, s0, s1, mask, repeat, rp);
    break;
  case TailVecBinOp::Mul:
    AscendC::Mul(d, s0, s1, mask, repeat, rp);
    break;
  case TailVecBinOp::Div:
    AscendC::Div(d, s0, s1, mask, repeat, rp);
    break;
  case TailVecBinOp::Max:
    AscendC::Max(d, s0, s1, mask, repeat, rp);
    break;
  case TailVecBinOp::Min:
    AscendC::Min(d, s0, s1, mask, repeat, rp);
    break;
  }
}

template <typename T>
CATLASS_DEVICE void tail_binary(TailVecBinOp op, LocalTensor<T> dst,
                                LocalTensor<T> src0, LocalTensor<T> src1,
                                uint32_t validRow, uint32_t validCol,
                                uint32_t physCol) {
  if (validRow == 0 || validCol == 0)
    return;
  if (validCol == physCol) {
    TailApplyBinCount<T>(op, dst, src0, src1,
                         static_cast<int32_t>(validRow * physCol));
    return;
  }
  constexpr uint32_t vl = 256 / sizeof(T);
  constexpr uint32_t blk = 32 / sizeof(T);
  uint32_t repStride = physCol / blk;
  if (validCol <= vl && validRow <= 255 && (physCol % blk == 0) &&
      repStride <= 255) {
    AscendC::BinaryRepeatParams rp;
    rp.dstBlkStride = 1;
    rp.src0BlkStride = 1;
    rp.src1BlkStride = 1;
    rp.dstRepStride = repStride;
    rp.src0RepStride = repStride;
    rp.src1RepStride = repStride;
    TailApplyBinMask<T>(op, dst, src0, src1, static_cast<uint64_t>(validCol),
                        static_cast<uint8_t>(validRow), rp);
    return;
  }
  for (uint32_t r = 0; r < validRow; ++r) {
    TailApplyBinCount<T>(op, dst[r * physCol], src0[r * physCol],
                         src1[r * physCol], static_cast<int32_t>(validCol));
  }
}

// ---- unary ----
template <typename T>
CATLASS_DEVICE void TailApplyUnCount(TailVecUnOp op, LocalTensor<T> d,
                                     LocalTensor<T> s, int32_t n) {
  if constexpr (TailIsFloatLike<T>::value) {
    switch (op) {
    case TailVecUnOp::Exp:
      AscendC::Exp(d, s, n);
      break;
    case TailVecUnOp::Ln:
      AscendC::Ln(d, s, n);
      break;
    case TailVecUnOp::Abs:
      AscendC::Abs(d, s, n);
      break;
    case TailVecUnOp::Reciprocal:
      AscendC::Reciprocal(d, s, n);
      break;
    case TailVecUnOp::Sqrt:
      AscendC::Sqrt(d, s, n);
      break;
    case TailVecUnOp::Rsqrt:
      AscendC::Rsqrt(d, s, n);
      break;
    case TailVecUnOp::Relu:
      AscendC::Relu(d, s, n);
      break;
    }
  } else {
    switch (op) {
    case TailVecUnOp::Abs:
      AscendC::Abs(d, s, n);
      break;
    default:
      break;
    }
  }
}

template <typename T>
CATLASS_DEVICE void TailApplyUnMask(TailVecUnOp op, LocalTensor<T> d,
                                    LocalTensor<T> s, uint64_t mask,
                                    uint8_t repeat,
                                    const AscendC::UnaryRepeatParams &rp) {
  if constexpr (TailIsFloatLike<T>::value) {
    switch (op) {
    case TailVecUnOp::Exp:
      AscendC::Exp(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Ln:
      AscendC::Ln(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Abs:
      AscendC::Abs(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Reciprocal:
      AscendC::Reciprocal(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Sqrt:
      AscendC::Sqrt(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Rsqrt:
      AscendC::Rsqrt(d, s, mask, repeat, rp);
      break;
    case TailVecUnOp::Relu:
      AscendC::Relu(d, s, mask, repeat, rp);
      break;
    }
  } else {
    switch (op) {
    case TailVecUnOp::Abs:
      AscendC::Abs(d, s, mask, repeat, rp);
      break;
    default:
      break;
    }
  }
}

template <typename T>
CATLASS_DEVICE void tail_unary(TailVecUnOp op, LocalTensor<T> dst,
                               LocalTensor<T> src, uint32_t validRow,
                               uint32_t validCol, uint32_t physCol) {
  if (validRow == 0 || validCol == 0)
    return;
  if (validCol == physCol) {
    TailApplyUnCount<T>(op, dst, src, static_cast<int32_t>(validRow * physCol));
    return;
  }
  constexpr uint32_t vl = 256 / sizeof(T);
  constexpr uint32_t blk = 32 / sizeof(T);
  uint32_t repStride = physCol / blk;
  if (validCol <= vl && validRow <= 255 && (physCol % blk == 0) &&
      repStride <= 255) {
    AscendC::UnaryRepeatParams rp;
    rp.dstBlkStride = 1;
    rp.srcBlkStride = 1;
    rp.dstRepStride = repStride;
    rp.srcRepStride = repStride;
    TailApplyUnMask<T>(op, dst, src, static_cast<uint64_t>(validCol),
                       static_cast<uint8_t>(validRow), rp);
    return;
  }
  for (uint32_t r = 0; r < validRow; ++r) {
    TailApplyUnCount<T>(op, dst[r * physCol], src[r * physCol],
                        static_cast<int32_t>(validCol));
  }
}

// ---- scalar ----
template <typename T>
CATLASS_DEVICE void TailApplyScalarCount(TailVecScalarOp op, LocalTensor<T> d,
                                         LocalTensor<T> s, T v, int32_t n) {
  switch (op) {
  case TailVecScalarOp::Adds:
    AscendC::Adds(d, s, v, n);
    break;
  case TailVecScalarOp::Muls:
    AscendC::Muls(d, s, v, n);
    break;
  case TailVecScalarOp::Maxs:
    AscendC::Maxs(d, s, v, n);
    break;
  case TailVecScalarOp::Mins:
    AscendC::Mins(d, s, v, n);
    break;
  }
}

template <typename T>
CATLASS_DEVICE void TailApplyScalarMask(TailVecScalarOp op, LocalTensor<T> d,
                                        LocalTensor<T> s, T v, uint64_t mask,
                                        uint8_t repeat,
                                        const AscendC::UnaryRepeatParams &rp) {
  switch (op) {
  case TailVecScalarOp::Adds:
    AscendC::Adds(d, s, v, mask, repeat, rp);
    break;
  case TailVecScalarOp::Muls:
    AscendC::Muls(d, s, v, mask, repeat, rp);
    break;
  case TailVecScalarOp::Maxs:
    AscendC::Maxs(d, s, v, mask, repeat, rp);
    break;
  case TailVecScalarOp::Mins:
    AscendC::Mins(d, s, v, mask, repeat, rp);
    break;
  }
}

template <typename T>
CATLASS_DEVICE void tail_scalar(TailVecScalarOp op, LocalTensor<T> dst,
                                LocalTensor<T> src, T scalar, uint32_t validRow,
                                uint32_t validCol, uint32_t physCol) {
  if (validRow == 0 || validCol == 0)
    return;
  if (validCol == physCol) {
    TailApplyScalarCount<T>(op, dst, src, scalar,
                            static_cast<int32_t>(validRow * physCol));
    return;
  }
  constexpr uint32_t vl = 256 / sizeof(T);
  constexpr uint32_t blk = 32 / sizeof(T);
  uint32_t repStride = physCol / blk;
  if (validCol <= vl && validRow <= 255 && (physCol % blk == 0) &&
      repStride <= 255) {
    AscendC::UnaryRepeatParams rp;
    rp.dstBlkStride = 1;
    rp.srcBlkStride = 1;
    rp.dstRepStride = repStride;
    rp.srcRepStride = repStride;
    TailApplyScalarMask<T>(op, dst, src, scalar,
                           static_cast<uint64_t>(validCol),
                           static_cast<uint8_t>(validRow), rp);
    return;
  }
  for (uint32_t r = 0; r < validRow; ++r) {
    TailApplyScalarCount<T>(op, dst[r * physCol], src[r * physCol], scalar,
                            static_cast<int32_t>(validCol));
  }
}

// ---- compare / select ----------------------------------------------------
// Compare and Select use a packed uint8 predicate.  Although the logical row
// contains only ceil(physCol / 8) bytes, AscendC vector/MTE instructions start
// every UB row on a 32-byte data-block boundary.  Memory planning widens
// the predicate's backing allocation accordingly; the public Buffer shape and
// GM representation remain densely packed.
template <typename T>
CATLASS_DEVICE bool tail_compare_value(T lhs, T rhs, AscendC::CMPMODE mode) {
  // Bisheng rejects scalar half/bfloat16 comparison instructions in AICore
  // functions.  Promote only the scalar control path; values written by
  // select remain in their original dtype.
  if constexpr (std::is_same_v<T, half> || std::is_same_v<T, bfloat16_t>) {
    return tail_compare_value(static_cast<float>(lhs), static_cast<float>(rhs),
                              mode);
  } else {
    switch (mode) {
    case AscendC::CMPMODE::EQ:
      return lhs == rhs;
    case AscendC::CMPMODE::NE:
      return lhs != rhs;
    case AscendC::CMPMODE::GT:
      return lhs > rhs;
    case AscendC::CMPMODE::GE:
      return lhs >= rhs;
    case AscendC::CMPMODE::LT:
      return lhs < rhs;
    case AscendC::CMPMODE::LE:
      return lhs <= rhs;
    default:
      return false;
    }
  }
}

template <typename T>
CATLASS_DEVICE void
tail_compare(LocalTensor<uint8_t> dst, LocalTensor<T> src0, LocalTensor<T> src1,
             AscendC::CMPMODE mode, uint32_t validRow, uint32_t validCol,
             uint32_t physRow, uint32_t physCol, uint32_t storageCol) {
  (void)storageCol;
  if (validRow == 0 || validCol == 0)
    return;
  constexpr uint32_t maskRowStride = 32;
  dst.SetSize(physRow * maskRowStride);
  AscendC::PipeBarrier<PIPE_ALL>();
  for (uint32_t r = 0; r < validRow; ++r) {
    for (uint32_t byte = 0; byte < (validCol + 7U) / 8U; ++byte) {
      uint8_t packed = 0;
      for (uint32_t bit = 0; bit < 8U; ++bit) {
        uint32_t c = byte * 8U + bit;
        if (c < validCol &&
            tail_compare_value(src0.GetValue(r * physCol + c),
                               src1.GetValue(r * physCol + c), mode)) {
          packed |= static_cast<uint8_t>(1U << bit);
        }
      }
      dst.SetValue(r * maskRowStride + byte, packed);
    }
  }
  AscendC::PipeBarrier<PIPE_ALL>();
}

template <typename T>
CATLASS_DEVICE void
tail_compare_scalar(LocalTensor<uint8_t> dst, LocalTensor<T> src, T scalar,
                    AscendC::CMPMODE mode, uint32_t validRow, uint32_t validCol,
                    uint32_t physRow, uint32_t physCol, uint32_t storageCol) {
  (void)storageCol;
  if (validRow == 0 || validCol == 0)
    return;
  constexpr uint32_t maskRowStride = 32;
  dst.SetSize(physRow * maskRowStride);
  AscendC::PipeBarrier<PIPE_ALL>();
  for (uint32_t r = 0; r < validRow; ++r) {
    for (uint32_t byte = 0; byte < (validCol + 7U) / 8U; ++byte) {
      uint8_t packed = 0;
      for (uint32_t bit = 0; bit < 8U; ++bit) {
        uint32_t c = byte * 8U + bit;
        if (c < validCol &&
            tail_compare_value(src.GetValue(r * physCol + c), scalar, mode)) {
          packed |= static_cast<uint8_t>(1U << bit);
        }
      }
      dst.SetValue(r * maskRowStride + byte, packed);
    }
  }
  AscendC::PipeBarrier<PIPE_ALL>();
}

template <typename T>
CATLASS_DEVICE void
tail_select(LocalTensor<T> dst, LocalTensor<uint8_t> selMask,
            LocalTensor<T> src0, LocalTensor<T> src1, AscendC::SELMODE mode,
            uint32_t validRow, uint32_t validCol, uint32_t physRow,
            uint32_t physCol, uint32_t storageCol) {
  (void)storageCol;
  if (validRow == 0 || validCol == 0)
    return;
  constexpr uint32_t maskRowStride = 32;
  selMask.SetSize(physRow * maskRowStride);
  AscendC::PipeBarrier<PIPE_ALL>();
  for (uint32_t r = 0; r < validRow; ++r) {
    for (uint32_t c = 0; c < validCol; ++c) {
      uint8_t packed = selMask.GetValue(r * maskRowStride + c / 8U);
      bool take_src0 = (packed & static_cast<uint8_t>(1U << (c & 7U))) != 0;
      uint32_t index = r * physCol + c;
      dst.SetValue(index,
                   take_src0 ? src0.GetValue(index) : src1.GetValue(index));
    }
  }
  AscendC::PipeBarrier<PIPE_ALL>();
}

template <typename T>
CATLASS_DEVICE void
tail_select_scalar(LocalTensor<T> dst, LocalTensor<uint8_t> selMask,
                   LocalTensor<T> src, T scalar, AscendC::SELMODE mode,
                   uint32_t validRow, uint32_t validCol, uint32_t physRow,
                   uint32_t physCol, uint32_t storageCol) {
  (void)storageCol;
  if (validRow == 0 || validCol == 0)
    return;
  constexpr uint32_t maskRowStride = 32;
  selMask.SetSize(physRow * maskRowStride);
  AscendC::PipeBarrier<PIPE_ALL>();
  for (uint32_t r = 0; r < validRow; ++r) {
    for (uint32_t c = 0; c < validCol; ++c) {
      uint8_t packed = selMask.GetValue(r * maskRowStride + c / 8U);
      bool take_src = (packed & static_cast<uint8_t>(1U << (c & 7U))) != 0;
      uint32_t index = r * physCol + c;
      dst.SetValue(index, take_src ? src.GetValue(index) : scalar);
    }
  }
  AscendC::PipeBarrier<PIPE_ALL>();
}

// ---- broadcast -----------------------------------------------------------
template <typename T>
CATLASS_DEVICE void
tail_broadcast(LocalTensor<T> dst, LocalTensor<T> src, int axis,
               uint32_t validRow, uint32_t validCol, uint32_t srcValidRow,
               uint32_t srcValidCol, uint32_t dstPhysCol, uint32_t srcPhysCol) {
  if (validRow == 0 || validCol == 0)
    return;
  if (axis == 1) {
    uint32_t rows = validRow < srcValidRow ? validRow : srcValidRow;
    constexpr uint32_t elemsPerBlock = 32 / sizeof(T);
    uint32_t srcRowStride =
        ((srcPhysCol + elemsPerBlock - 1) / elemsPerBlock) * elemsPerBlock;
    AscendC::PipeBarrier<PIPE_ALL>();
    for (uint32_t r = 0; r < rows; ++r) {
      T scalar = src.GetValue(r * srcRowStride);
      // Keep both full and tail rows on the vector path.  SetValue is a
      // scalar-pipeline store and is not a sound producer for the following
      // MTE3 copy on device; Duplicate supports an arbitrary element count and
      // therefore writes exactly the valid prefix of every physical row.
      AscendC::Duplicate(dst[r * dstPhysCol], scalar,
                         static_cast<int32_t>(validCol));
    }
    AscendC::PipeBarrier<PIPE_ALL>();
    return;
  }
  uint32_t cols = validCol < srcValidCol ? validCol : srcValidCol;
  for (uint32_t r = 0; r < validRow; ++r) {
    AscendC::Adds(dst[r * dstPhysCol], src, static_cast<T>(0),
                  static_cast<int32_t>(cols));
  }
}

// ---- reduce ----
// The propagation pass emits this helper only for axis 0/-2: reduce down the
// valid rows into out[0..validCol). The validated contract consumes no tmp and
// always arrives normalized as dim == 0, clear == true.
template <typename T>
CATLASS_DEVICE void tail_reduce_sum(LocalTensor<T> out, LocalTensor<T> src,
                                    int dim, uint32_t validRow,
                                    uint32_t validCol, uint32_t physCol,
                                    bool clear) {
  (void)dim;
  (void)clear;
  if (validRow == 0 || validCol == 0)
    return;
  // Multiplication by one preserves signed zero while initializing the first
  // row; Adds(..., 0) may canonicalize -0.0 on device.
  AscendC::Muls(out, src, static_cast<T>(1), static_cast<int32_t>(validCol));
  for (uint32_t r = 1; r < validRow; ++r) {
    AscendC::Add(out, out, src[r * physCol], static_cast<int32_t>(validCol));
  }
}

template <typename T>
CATLASS_DEVICE void tail_reduce_max(LocalTensor<T> out, LocalTensor<T> src,
                                    int dim, uint32_t validRow,
                                    uint32_t validCol, uint32_t physCol,
                                    bool clear) {
  (void)dim;
  (void)clear;
  if (validRow == 0 || validCol == 0)
    return;
  AscendC::Muls(out, src, static_cast<T>(1), static_cast<int32_t>(validCol));
  for (uint32_t r = 1; r < validRow; ++r) {
    AscendC::Max(out, out, src[r * physCol], static_cast<int32_t>(validCol));
  }
}

template <typename T>
CATLASS_DEVICE void tail_reduce_min(LocalTensor<T> out, LocalTensor<T> src,
                                    int dim, uint32_t validRow,
                                    uint32_t validCol, uint32_t physCol,
                                    bool clear) {
  (void)dim;
  (void)clear;
  if (validRow == 0 || validCol == 0)
    return;
  AscendC::Muls(out, src, static_cast<T>(1), static_cast<int32_t>(validCol));
  for (uint32_t r = 1; r < validRow; ++r) {
    AscendC::Min(out, out, src[r * physCol], static_cast<int32_t>(validCol));
  }
}

static constexpr uint32_t L0AB_EVENT = 0;

template <typename T1, typename T2, uint32_t M, uint32_t N, uint32_t K,
          bool transpose_A = false, bool transpose_B = false,
          uint32_t kL0Size = 128>
CATLASS_DEVICE void
gemm_v0(LocalTensor<T1> const &A, LocalTensor<T1> const &B,
        LocalTensor<T2> const &C, // this must be located in l0c
        AscendC::TBuf<AscendC::TPosition::A2> &l0a_,
        AscendC::TBuf<AscendC::TPosition::B2> &l0b_, bool clear,
        uint32_t n_actual = N) {
  // n_actual: runtime output-column count (<= N), only honoured on the
  // transpose_B (QK) path -- computes/loads just the real window columns
  // instead of the full template N. Defaults to N, so all existing callers are
  // byte-identical. Physical L0B/L0C layout and the template N/K stay
  // compile-time; only "how many columns are actually computed" changes (dual
  // to the runtime K already threaded through mma).
  static_assert(kL0Size % 16 == 0, "kL0Size must be a multiple of 16");
  // int4 (W4A4) fractal alignment: the s4 load intrinsics and mad_s4 consume
  // K/N in whole 64-element C0 blocks (64 nibbles per 32B block), while the
  // buffer planning, L0A/L0B ping-pong slot sizes and the zN offset strides
  // above all use the unrounded template sizes. A K/N/kL0Size that is a
  // multiple of 16 but not of 64 (e.g. 96) would load/accumulate a rounded-up
  // 128 elements over a 96-planned slot -- silent garbage or slot overwrite.
  // Reject at compile time until tail-block zero-fill support (cf. the int8
  // kL0Tail handling) is added for int4.
  if constexpr (std::is_same_v<T1, int4b_t>) {
    static_assert(K % 64 == 0,
                  "gemm_v0 int4 (W4A4) requires K to be a multiple of 64 "
                  "(one s4 C0 block; tail blocks are not zero-filled yet)");
    static_assert(N % 64 == 0,
                  "gemm_v0 int4 (W4A4) requires N to be a multiple of 64 "
                  "(one s4 C0 block; tail blocks are not zero-filled yet)");
    static_assert(kL0Size % 64 == 0,
                  "gemm_v0 int4 (W4A4) requires kL0Size to be a multiple of "
                  "64 (one s4 C0 block)");
  }
  // Elements per C0 block (32 bytes). Equals 16 only for half; for int8 it is
  // 32, for int4b_t it is 64 (two nibbles per byte), for float it is 8. The
  // fractal (zN/zZ/nZ) K-stride used below to step between L0 K-tiles is
  // ELE_NUM_PER_C0 * kL0Size, so hardcoding 16 breaks int8 (and any dtype
  // where sizeof(T1) != 2) once kL0split > 1. Must be bit-width based:
  // sizeof(AscendC::int4b_t) == 1 even though an element is 4 bits.
  constexpr uint32_t ELE_NUM_PER_C0 = EleNumPerC0<T1>();
  constexpr uint32_t kL0split = (K + kL0Size - 1) / kL0Size;
  auto l0a = l0a_.Get<T1>();
  auto l0b = l0b_.Get<T1>();
  uint32_t kL0Tail = K - (kL0split - 1) * kL0Size;
  bool initflag = false;

  // Mmad consumes K in whole C0 blocks: a tail mma with k = kL0Tail actually
  // accumulates ceil(kL0Tail / ELE_NUM_PER_C0) * ELE_NUM_PER_C0 K-slots. The
  // L1 zN layout only pads K up to a multiple of 16 rows, so for int8
  // (ELE_NUM_PER_C0 == 32) a tail with kL0Tail % 32 in [1, 16] reads 16 L0B
  // K-slots that neither the GM->L1 copy nor the L1->L0B copy ever wrote
  // (stale L0B garbage -> silently wrong results). Reject that combination at
  // compile time; 16/8-bit types never trip this (their C0 rounding never
  // exceeds the 16-row fractal padding).
  static_assert(
      ELE_NUM_PER_C0 <= 16 ||
          ((K - (kL0split - 1) * kL0Size) % ELE_NUM_PER_C0 == 0) ||
          ((K - (kL0split - 1) * kL0Size) % ELE_NUM_PER_C0 > 16),
      "gemm_v0: int8 K-tail must be 16-element aligned (kL0Tail % 32 in "
      "[1,16] is unsupported: the mma consumes whole 32-element C0 blocks "
      "but the L1 fractal layout only pads K to 16 rows, leaving L0B "
      "K-slots unwritten). Split K differently or pad K to the needed "
      "alignment.");

  // The tail guard above is not enough: EVERY K-tile is consumed with a
  // C0-rounded k (a full tile with kSize = kL0Size uses ceil(kL0Size/C0)*C0
  // slots), and its L1->L0B source offset steps by ELE_NUM_PER_C0 * kL0Size.
  // When kL0Size is not C0-aligned (e.g. int8 kL0Size = 48: mma consumes 64
  // slots while the L1 zN layout only provides roundUp16(48) = 48 rows), the
  // first tile already reads unwritten L0B slots and the tile offsets drift
  // from the C0-rounded spans. Require kL0Size itself to be C0-aligned
  // whenever the K axis is split at the L0 level.
  static_assert(
      ELE_NUM_PER_C0 <= 16 || kL0split == 1 || (kL0Size % ELE_NUM_PER_C0) == 0,
      "gemm_v0: kL0Size must be a multiple of the C0 element count "
      "(32 for int8) when K is split into multiple L0 tiles. A non-C0-aligned "
      "kL0Size makes every mma consume more K-slots than the L1 fractal "
      "layout provides and desynchronizes the L0 ping-pong bases.");

  // ---- N tiling -----------------------------------------------------------
  // The B operand tile loaded into L0B is (kL0Size x nTile); L0B holds 64KB,
  // and with the kL0 ping-pong the per-slot budget is 32KB. So a single mma
  // over the whole N (l0b slot = N*kL0Size) overflows L0B once N is large
  // (e.g. the PV matmul's N = headDim = 512 -> 512*128*2 = 128KB). Tile N into
  // nTile columns just like the Ascend C reference (N_SPLIT_SIZE = 128): each
  // tile loads its own (kL0Size x nTile) B sub-block and writes its own column
  // band of the L0C accumulator. Only the non-transpose-B path is tiled; the
  // transpose-B callers (e.g. QK with N = block_I <= 128) already fit, so they
  // keep nTile == N (a single pass, byte-for-byte the original behaviour) and
  // need no L1 column-offset formula. Compatibility: any existing caller with
  // N <= nMaxByL0B (transpose or not) sees nL0split == 1 and identical codegen.
  //
  // Sub-tile offsets come straight from the catlass tla fractal layouts:
  //   L0C column n0  ->  n0 * roundUp16(M)   (tla::MakeLayoutL0C N1 stride)
  //   L1 zN B col n0 ->  n0 * roundUp16(K)   (tla::MakeLayout<zN>  C1 stride)
  // both of which are consistent with the original K-offset
  // B[kL0Idx*ELE_NUM_PER_C0*kL0Size] (zN K-row stride) already used below.
  constexpr uint32_t nMaxByL0B =
      (32u * 1024u * 8 / ElementSizeBits<T1>()) / kL0Size;
  constexpr uint32_t nTile = (transpose_B || N <= nMaxByL0B) ? N : nMaxByL0B;
  static_assert(transpose_B || (N % nTile == 0),
                "gemm_v0 N-tiling requires N divisible by the N tile size");
  constexpr uint32_t nL0split = N / nTile;
  // L0A and L0B are each 64KB. The kL0/N ping-pong uses two slots only when
  // there is more than one (N-tile, K-tile) step; a single step uses one slot
  // and may occupy the whole 64KB -- which is why a transpose-B caller with a
  // single K-tile and N up to 64KB/(kL0Size*sizeof(T)) fits (e.g. fp32 N=128 =
  // 64KB). So the per-slot budget is 64KB for a single step, 32KB once the
  // ping-pong actually alternates.
  constexpr uint32_t kNumSteps = ((K + kL0Size - 1) / kL0Size) * nL0split;
  constexpr uint32_t kL0Budget = (64u * 1024u) / (kNumSteps > 1 ? 2u : 1u);
  // The B tile in L0B is (kL0Size x nTile) -- only the transpose-B path keeps
  // nTile == N, so a large-N transpose-B caller could overflow its L0B slot.
  static_assert(EleNumToBytes<T1>(nTile * kL0Size) <= kL0Budget,
                "gemm_v0: the (kL0Size x nTile) B tile does not fit its L0B "
                "ping-pong slot");
  // M is not tiled, so a large M would overflow its L0A slot.
  static_assert(EleNumToBytes<T1>(M * kL0Size) <= kL0Budget,
                "gemm_v0: the (M x kL0Size) A tile does not fit its L0A "
                "ping-pong slot");
  // L0C is caller-allocated (the `C` operand) and holds the full (M x N)
  // accumulator: roundUp16(M) * N * sizeof(T2). It must fit the target's L0C
  // (A2/A3 128KB, A5 256KB) -- e.g. M=128, N=512, fp32 needs 256KB and only
  // fits A5. Unlike the L0A/L0B guards above this can't be a static_assert
  // here: L0C capacity is device-dependent, whereas L0A/L0B are 64KB on both
  // archs (which is why those two use a literal budget). This device-side
  // template has no arch macro or L0C-size constant to branch on
  // (ASCEND_*_L0C_SIZE live in the host codegen), so a literal guard would
  // reject a valid A5 caller or silently pass on A2/A3. The constraint is
  // therefore documented here; the caller sizes its L0C tile accordingly.
  constexpr uint32_t mRound = ((M + 15u) / 16u) * 16u;
  constexpr uint32_t kRound = ((K + 15u) / 16u) * 16u;

  // ---- Pipelined main loop. Prime/drain the L0A/L0B ping-pong buffers ONCE
  // and let the ping-pong run continuously across the WHOLE (N-tile, K-tile)
  // sequence (flattened by tileIdx). Each tile's L1->L0 load goes into the
  // free buffer while the previous tile's mma runs, so N-tiles overlap with K
  // exactly like the Ascend C matmul pipeline -- a per-N-tile drain (the first
  // N-tiling version) instead serialised the tiles. For nL0split == 1 (every
  // pre-existing caller, and the QK transpose-B path) tileIdx == kL0Idx, so
  // this is byte-for-byte the original K ping-pong.
  SetFlag<HardEvent::MTE2_MTE1>(L0AB_EVENT);
  WaitFlag<HardEvent::MTE2_MTE1>(L0AB_EVENT);
  SetFlag<HardEvent::FIX_M>(L0AB_EVENT);
  WaitFlag<HardEvent::FIX_M>(L0AB_EVENT);

  SetFlag<HardEvent::M_MTE1>(L0AB_EVENT);
  SetFlag<HardEvent::M_MTE1>(L0AB_EVENT + 1);

  uint32_t tileIdx = 0;
  for (uint32_t nL0Idx = 0; nL0Idx < nL0split; nL0Idx++) {
    // Non-transpose B is zN in L1: its column n0 lives at n0 * roundUp16(K)
    // (the zN C1 stride), so this N-tile's B sub-block starts at
    // nL0Idx*nTile*kRound. This column-offset formula is correct only for a zN
    // B_L1; a different B layout would need a different per-column stride here.
    uint32_t bNOffset = transpose_B ? 0u : (nL0Idx * nTile * kRound);
    uint32_t cNOffset = nL0Idx * nTile * mRound;

    for (uint32_t kL0Idx = 0; kL0Idx < kL0split; kL0Idx++) {
      // clear THIS N-tile's C column band on its first K-tile (each band is an
      // independent accumulation over K).
      initflag = (clear && (kL0Idx == 0));
      uint32_t kSize = (kL0Idx == kL0split - 1) ? kL0Tail : kL0Size;
      uint32_t pp = (tileIdx & 1);

      uint32_t l0a_base = pp * (M * kL0Size);
      uint32_t l0b_base = pp * (nTile * kL0Size);

      WaitFlag<HardEvent::M_MTE1>(L0AB_EVENT + pp);
      if constexpr (!transpose_A) {
        tl::ascend::copy_l1_to_l0a<T1, M, K>(l0a[l0a_base],
                                             A[kL0Idx * M * kL0Size], M, kSize);
      } else {
        tl::ascend::copy_l1_to_l0a<T1, K, M, true>(
            l0a[l0a_base], A[kL0Idx * ELE_NUM_PER_C0 * kL0Size], M, kSize);
      }
      if constexpr (!transpose_B) {
        tl::ascend::copy_l1_to_l0b<T1, K, N>(
            l0b[l0b_base], B[bNOffset + kL0Idx * ELE_NUM_PER_C0 * kL0Size],
            kSize, nTile);
      } else {
        // transpose_B (QK): load only the n_actual real output columns; the
        // [n_actual:N] columns stay unloaded (masked downstream). n_actual
        // defaults to N (full width) -> byte-identical for non-window callers.
        tl::ascend::copy_l1_to_l0b<T1, N, K, true>(
            l0b[l0b_base], B[kL0Idx * N * kL0Size], kSize, n_actual);
      }
      SetFlag<HardEvent::MTE1_M>(L0AB_EVENT + pp);
      WaitFlag<HardEvent::MTE1_M>(L0AB_EVENT + pp);
      PipeBarrier<PIPE_M>();
      // transpose_B (QK) computes only n_actual columns (window width); the
      // non-transpose path keeps the full template N (nTile per N-tile).
      tl::ascend::mma<T1, T2, M, nTile>(l0a[l0a_base], l0b[l0b_base],
                                        C[cNOffset], initflag, kSize,
                                        transpose_B ? n_actual : nTile);
      SetFlag<HardEvent::M_MTE1>(L0AB_EVENT + pp);
      tileIdx++;
    }
  }
  WaitFlag<HardEvent::M_MTE1>(L0AB_EVENT);
  WaitFlag<HardEvent::M_MTE1>(L0AB_EVENT + 1);

  SetFlag<HardEvent::MTE1_MTE2>(L0AB_EVENT);
  WaitFlag<HardEvent::MTE1_MTE2>(L0AB_EVENT);
  SetFlag<HardEvent::M_FIX>(L0AB_EVENT);
  WaitFlag<HardEvent::M_FIX>(L0AB_EVENT);
}

// 2-way merge sort
template <typename T>
CATLASS_DEVICE void
MergeSort(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
          const LocalTensor<T> &src1, uint32_t blockLen0, uint32_t blockLen1) {
  AscendC::MrgSort4Info params;
  params.elementLengths[0] = blockLen0;
  params.elementLengths[1] = blockLen1;
  params.elementLengths[2] = 0;
  params.elementLengths[3] = 0;
  params.ifExhaustedSuspension = false;
  params.validBit = 3;

  AscendC::MrgSortSrcList<T> srcList;
  srcList.src1 = src0;
  srcList.src2 = src1;
  srcList.src3 = src0;
  srcList.src4 = src0;

  AscendC::MrgSort<T>(dst, srcList, params);
  PipeBarrier<PIPE_V>();
}

// 3-way merge sort
template <typename T>
CATLASS_DEVICE void
MergeSort(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
          const LocalTensor<T> &src1, const LocalTensor<T> &src2,
          uint32_t blockLen0, uint32_t blockLen1, uint32_t blockLen2) {
  AscendC::MrgSort4Info params;
  params.elementLengths[0] = blockLen0;
  params.elementLengths[1] = blockLen1;
  params.elementLengths[2] = blockLen2;
  params.elementLengths[3] = 0;
  params.ifExhaustedSuspension = false;
  params.validBit = 7;

  AscendC::MrgSortSrcList<T> srcList;
  srcList.src1 = src0;
  srcList.src2 = src1;
  srcList.src3 = src2;
  srcList.src4 = src0;

  AscendC::MrgSort<T>(dst, srcList, params);
  PipeBarrier<PIPE_V>();
}

// 4-way merge sort
template <typename T>
CATLASS_DEVICE void
MergeSort(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
          const LocalTensor<T> &src1, const LocalTensor<T> &src2,
          const LocalTensor<T> &src3, uint32_t blockLen0, uint32_t blockLen1,
          uint32_t blockLen2, uint32_t blockLen3) {
  AscendC::MrgSort4Info params;
  params.elementLengths[0] = blockLen0;
  params.elementLengths[1] = blockLen1;
  params.elementLengths[2] = blockLen2;
  params.elementLengths[3] = blockLen3;
  params.ifExhaustedSuspension = false;
  params.validBit = 15;

  AscendC::MrgSortSrcList<T> srcList;
  srcList.src1 = src0;
  srcList.src2 = src1;
  srcList.src3 = src2;
  srcList.src4 = src3;

  AscendC::MrgSort<T>(dst, srcList, params);
  PipeBarrier<PIPE_V>();
}

template <typename T>
CATLASS_DEVICE void GatherMask(const LocalTensor<T> &dst,
                               const LocalTensor<T> &sortedTensor,
                               uint8_t src1Pattern) {
  uint32_t eleNum = sortedTensor.GetSize();
  GatherMaskParams gatherMaskParams;
  gatherMaskParams.repeatTimes = Ceil(eleNum * sizeof(T), 256);
  gatherMaskParams.src0BlockStride = 1;
  gatherMaskParams.src0RepeatStride = 8;
  gatherMaskParams.src1RepeatStride = 0;
  uint64_t rsvdCnt = 0; // 用于保存筛选后保留下来的元素个数
  GatherMask(dst, sortedTensor, src1Pattern, false, static_cast<uint32_t>(0),
             gatherMaskParams, rsvdCnt);
  PipeBarrier<PIPE_V>();
}

template <typename T, typename U>
CATLASS_DEVICE void GatherMask(const LocalTensor<T> &dst,
                               const LocalTensor<T> &sortedTensor,
                               const LocalTensor<U> &src1Pattern) {
  uint32_t eleNum = sortedTensor.GetSize();
  GatherMaskParams gatherMaskParams;
  gatherMaskParams.repeatTimes = Ceil(eleNum * sizeof(T), 256);
  gatherMaskParams.src0BlockStride = 1;
  gatherMaskParams.src0RepeatStride = 8;
  gatherMaskParams.src1RepeatStride = 0;
  uint64_t rsvdCnt = 0; // 用于保存筛选后保留下来的元素个数
  GatherMask(dst, sortedTensor, src1Pattern, false, static_cast<uint32_t>(0),
             gatherMaskParams, rsvdCnt);
}

template <typename T>
CATLASS_DEVICE void Gather(const LocalTensor<T> &dst,
                           const LocalTensor<T> &sortedTensor,
                           const LocalTensor<uint32_t> &src1Pattern) {

  int32_t count = src1Pattern.GetSize();
  int32_t scalarValue = sizeof(T);
  LocalTensor<int32_t> offset = const_cast<LocalTensor<uint32_t> &>(src1Pattern)
                                    .template ReinterpretCast<int32_t>();
  AscendC::Muls(offset, offset, scalarValue, count);
  AscendC::Gather(dst, sortedTensor,
                  offset.template ReinterpretCast<uint32_t>(),
                  static_cast<uint32_t>(0), static_cast<uint32_t>(count));
}

template <typename T>
CATLASS_DEVICE void
Gatherb(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
        const LocalTensor<uint32_t> &offset, uint8_t repeat_time,
        uint8_t dst_blk_stride, uint8_t dst_rep_stride) {
  GatherRepeatParams gatherRepeatParams;
  gatherRepeatParams.dstBlkStride = dst_blk_stride;
  gatherRepeatParams.dstRepStride = dst_rep_stride;
  Gatherb(dst.template ReinterpretCast<uint32_t>(),
          src0.template ReinterpretCast<uint32_t>(),
          offset.template ReinterpretCast<uint32_t>(), repeat_time,
          gatherRepeatParams);
  PipeBarrier<PIPE_V>();
}

template <typename T>
CATLASS_DEVICE void InitSortBuf(const LocalTensor<T> &src, int64_t eleNum,
                                int64_t rsv = 0) {
  constexpr int32_t NEG_INF = 0xFF800000;
  constexpr uint8_t VEC_REPEAT_MAX = 255;
  constexpr uint8_t B32_VEC_ELM_NUM = 64;
  uint64_t mask1[2] = {0x5555555555555555, 0};
  uint64_t mask0[2] = {0xaaaaaaaaaaaaaaaa, 0};
  int64_t repeatNum = eleNum / B32_VEC_ELM_NUM;
  int64_t forLoop = repeatNum / VEC_REPEAT_MAX;
  int64_t forRemain = repeatNum % VEC_REPEAT_MAX;
  for (int i = 0; i < forLoop; i++) {
    Duplicate(src.template ReinterpretCast<int32_t>(), NEG_INF, mask1,
              VEC_REPEAT_MAX, 1, 8);
    Duplicate(src.template ReinterpretCast<int32_t>(), -1, mask0,
              VEC_REPEAT_MAX, 1, 8);
  }
  if (forRemain > 0) {
    Duplicate(src.template ReinterpretCast<int32_t>()[forLoop * VEC_REPEAT_MAX *
                                                      B32_VEC_ELM_NUM],
              NEG_INF, mask1, forRemain, 1, 8);
    Duplicate(src.template ReinterpretCast<int32_t>()[forLoop * VEC_REPEAT_MAX *
                                                      B32_VEC_ELM_NUM],
              -1, mask0, forRemain, 1, 8);
  }
  PipeBarrier<PIPE_V>();
}

template <typename T>
CATLASS_DEVICE void brcb(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
                         const uint8_t repeatTime, const uint16_t dstBlkStride,
                         const uint16_t dstRepStride) {
  AscendC::BrcbRepeatParams repeatParams(dstBlkStride, dstRepStride);
  AscendC::Brcb<T>(dst, src0, repeatTime, repeatParams);
}

template <typename T>
CATLASS_DEVICE void
mul_mask(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
         const LocalTensor<T> &src1, const uint64_t mask0, const uint64_t mask1,
         const uint8_t repeatTime, const uint8_t dstBlkStride,
         const uint8_t src0BlkStride, const uint8_t src1BlkStride,
         const uint8_t dstRepStride, const uint8_t src0RepStride,
         const uint8_t src1RepStride) {
  uint64_t mask[2] = {mask0, mask1};
  AscendC::BinaryRepeatParams params(dstBlkStride, src0BlkStride, src1BlkStride,
                                     dstRepStride, src0RepStride,
                                     src1RepStride);
  AscendC::Mul<T, false>(dst, src0, src1, mask, repeatTime, params);
}

template <typename T>
CATLASS_DEVICE void
sub_mask(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
         const LocalTensor<T> &src1, const uint64_t mask0, const uint64_t mask1,
         const uint8_t repeatTime, const uint8_t dstBlkStride,
         const uint8_t src0BlkStride, const uint8_t src1BlkStride,
         const uint8_t dstRepStride, const uint8_t src0RepStride,
         const uint8_t src1RepStride) {
  uint64_t mask[2] = {mask0, mask1};
  AscendC::BinaryRepeatParams params(dstBlkStride, src0BlkStride, src1BlkStride,
                                     dstRepStride, src0RepStride,
                                     src1RepStride);
  AscendC::Sub<T, false>(dst, src0, src1, mask, repeatTime, params);
}

template <typename T>
CATLASS_DEVICE void
div_mask(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
         const LocalTensor<T> &src1, const uint64_t mask0, const uint64_t mask1,
         const uint8_t repeatTime, const uint8_t dstBlkStride,
         const uint8_t src0BlkStride, const uint8_t src1BlkStride,
         const uint8_t dstRepStride, const uint8_t src0RepStride,
         const uint8_t src1RepStride) {
  uint64_t mask[2] = {mask0, mask1};
  AscendC::BinaryRepeatParams params(dstBlkStride, src0BlkStride, src1BlkStride,
                                     dstRepStride, src0RepStride,
                                     src1RepStride);
  AscendC::Div<T, false>(dst, src0, src1, mask, repeatTime, params);
}

// Strided masked exp for the narrow online-softmax window: exp only the `mask`
// valid columns of each row, striding `srcRepStride`/`dstRepStride` 32B-blocks
// between rows so one call touches just the [0:tw] window of a wider,
// physically-strided score buffer (no compaction). Unary mirror of sub_mask;
// ExpExperimentCodegen derives repeatTime/rep_stride from the buffer's physical
// column count, and callers loop 64-column (fp32) chunks over the valid window.
template <typename T>
CATLASS_DEVICE void
exp_mask(const LocalTensor<T> &dst, const LocalTensor<T> &src,
         const uint64_t mask0, const uint64_t mask1, const uint8_t repeatTime,
         const uint8_t dstBlkStride, const uint8_t srcBlkStride,
         const uint8_t dstRepStride, const uint8_t srcRepStride) {
  uint64_t mask[2] = {mask0, mask1};
  AscendC::UnaryRepeatParams params(dstBlkStride, srcBlkStride, dstRepStride,
                                    srcRepStride);
  AscendC::Exp<T, false>(dst, src, mask, repeatTime, params);
}

template <typename T1, typename T2, typename LayOutL1, typename LayoutGM,
          uint32_t M, uint32_t N, uint32_t K, uint32_t baseM, uint32_t baseN,
          uint32_t baseK, bool init, bool is_transpose_A = false,
          bool is_transpose_B = false, bool enable_relu = false>
CATLASS_DEVICE void gemmL1(LocalTensor<T1> A, LocalTensor<T1> B,
                           GlobalTensor<T1> C, LocalTensor<T1> A2,
                           LocalTensor<T1> B2, LocalTensor<T2> C2) {
  for (uint32_t loopM = 0; loopM < M / baseM; loopM++) {
    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(0);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE1>(0);

    copy_l1_to_l0a<T1, M, K, baseM, baseK>(A2, A[loopM * baseM * 16]);

    for (uint32_t loopN = 0; loopN < N / baseN; loopN++) {
      copy_l1_to_l0b<T1, K, N, baseK, baseN>(B2, B[loopN * baseN * K]);

      AscendC::SetFlag<AscendC::HardEvent::MTE1_M>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE1_M>(0);

      mma<T1, T2, baseM, baseN, baseK, init>(A2, B2, C2);

      AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(0);
      AscendC::SetFlag<AscendC::HardEvent::M_MTE2>(0);
      AscendC::SetFlag<AscendC::HardEvent::M_FIX>(0);
      AscendC::WaitFlag<AscendC::HardEvent::M_FIX>(0);

      copy_l0c_to_gm<T1, T2, LayoutGM, baseM, baseN, M, N>(
          C[loopM * baseM * N + loopN * baseN], C2, enable_relu);

      AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(0);
      AscendC::WaitFlag<AscendC::HardEvent::M_MTE2>(0);
    }
    AscendC::PipeBarrier<PIPE_ALL>();
  }
}

template <typename T, int32_t dim, int32_t axis, bool isReuseSource = false>
CATLASS_DEVICE void
Broadcast(const LocalTensor<T> &dst, const LocalTensor<T> &src,
          LocalTensor<uint8_t> sharedTmpBuffer, const uint32_t dstShape[dim],
          const uint32_t srcShape[dim]) {
  AscendC::Broadcast<T, dim, axis, isReuseSource>(dst, src, dstShape, srcShape,
                                                  sharedTmpBuffer);
}

template <typename T, int32_t dim, int32_t axis, bool isReuseSource = false,
          bool isSetMask = true>
CATLASS_DEVICE void
Broadcast(const LocalTensor<T> &dst, const LocalTensor<T> &src,
          const uint32_t dstShape[dim], const uint32_t srcShape[dim]) {
  uint32_t dstSize = 1;
  uint32_t srcSize = 1;
  for (int32_t i = 0; i < dim; ++i) {
    dstSize *= dstShape[i];
    srcSize *= srcShape[i];
  }
  if (srcSize == dstSize) {
    if constexpr (isSetMask) {
      AscendC::Muls(dst, src, static_cast<T>(1), dstSize);
    } else {
      AscendC::Muls<T, false>(dst, src, static_cast<T>(1),
                              AscendC::MASK_PLACEHOLDER, 1,
                              AscendC::UnaryRepeatParams());
    }
    return;
  }
  ASCENDC_ASSERT((srcSize == 1), {
    KERNEL_LOG(KERNEL_ERROR,
               "Workspace-free Broadcast only supports equal or scalar shapes");
  });
  if constexpr (isSetMask) {
    AscendC::Duplicate(dst, src.GetValue(0), dstSize);
  } else {
    AscendC::Duplicate<T, false>(dst, src.GetValue(0),
                                 AscendC::MASK_PLACEHOLDER, 1, 1, 8);
  }
}

template <typename T>
CATLASS_DEVICE void Fill(const LocalTensor<T> &dst, const T &scalarValue,
                         const int32_t &count) {
  AscendC::Duplicate<T>(dst, scalarValue, count);
}

template <typename T>
CATLASS_DEVICE void ArithProgression(const LocalTensor<T> &dst,
                                     const T firstValue, const T diffValue,
                                     const int32_t count) {
  AscendC::ArithProgression<T>(dst, firstValue, diffValue, count);
}

template <typename T>
CATLASS_DEVICE void Sort(const LocalTensor<T> &dst, const LocalTensor<T> &src,
                         const LocalTensor<T> &tmp, const int32_t repeatTimes,
                         const int32_t actualCount) {
  if constexpr (sizeof(T) == 2) {
    // B16 (half): MrgSort requires >= 256 bytes per source, but Sort32 only
    // produces 128 bytes per block for B16. Work around by sorting in float.
    //
    // Layout in tmp (N = alignedCount, as float elements via ReinterpretCast):
    //   ftmp[0 .. N*2-1]    = Sort32 output + merge ping-pong buffer A
    //   ftmp[N*2 .. N*4-1]  = Sort<float>'s dst (merge ping-pong buffer B)
    //     - before Sort32: indices at [N*2..N*3), float_src at [N*3..N*4)
    //     - after  Sort32: entire region free for merge
    // Total: 4N float elements = 8N half elements.
    uint32_t N = repeatTimes * 32;

    auto ftmp = tmp.template ReinterpretCast<float>();
    auto float_src = ftmp[N * 3];

    // Cast half → float
    AscendC::Cast(float_src, src, AscendC::RoundMode::CAST_NONE, N);

    // Sort<float> guarantees result in dst (= ftmp[N*2])
    Sort<float>(ftmp[N * 2], float_src, ftmp, repeatTimes, actualCount);

    // Cast float result → half (2*N elements: interleaved [value, index] pairs)
    AscendC::Cast(dst, ftmp[N * 2], AscendC::RoundMode::CAST_RINT, N * 2);
    PipeBarrier<PIPE_V>();
    return;
  }

  constexpr uint32_t blockSize = 32;
  uint32_t alignedCount = repeatTimes * blockSize;
  uint32_t padCount = alignedCount - actualCount;
  uint32_t blockNum = repeatTimes;

  // Generate ascending indices as float values (0.0, 1.0, 2.0, ...) in dst
  // (temporary storage — overwritten by merge later). This allows tmp to
  // be only alignedCount*2 elements instead of alignedCount*4, because dst
  // (which is 2*alignedCount for interleaved output) doubles as the second
  // merge ping-pong buffer.
  AscendC::ArithProgression<T>(dst, T(0), T(1), alignedCount);
  PipeBarrier<PIPE_V>();
  LocalTensor<uint32_t> indices = dst.template ReinterpretCast<uint32_t>();

  // Pad src in-place with -inf for unused positions
  if (padCount > 0) {
    T negInf = -CUDART_INF_F;
    constexpr uint32_t elemPerBlock =
        32 / sizeof(T); // 16 for half, 8 for float
    uint32_t alignedActual = (actualCount / elemPerBlock) * elemPerBlock;
    uint32_t inBlockOffset = actualCount - alignedActual;

    if (inBlockOffset == 0) {
      // actualCount is already 32-byte aligned, simple Duplicate
      AscendC::Duplicate<T>(src[actualCount], negInf, padCount);
    } else {
      // Non-aligned: split into aligned bulk fill + masked partial block
      uint32_t nextAligned = alignedActual + elemPerBlock;
      // Fill full aligned blocks after the partial one
      if (nextAligned < alignedCount) {
        AscendC::Duplicate<T>(src[nextAligned], negInf,
                              alignedCount - nextAligned);
      }
      // Fill partial block using mask to preserve valid elements before
      // actualCount
      uint64_t mask0 = 0;
      for (uint32_t i = inBlockOffset; i < elemPerBlock; i++) {
        mask0 |= (1ULL << i);
      }
      uint64_t masks[2] = {mask0, 0};
      AscendC::Duplicate(src[alignedActual], negInf, masks, (uint8_t)1,
                         (uint16_t)1, (uint8_t)0);
    }
    PipeBarrier<PIPE_V>();
  }

  // Sort32: each 32-element block → tmp[0..alignedCount*2-1] (bufA)
  AscendC::Sort32(tmp, src, indices, repeatTimes);
  PipeBarrier<PIPE_V>();

  // Merge ping-pong between tmp[0..2N-1] and dst[0..2N-1].
  // tmp only needs alignedCount*2 elements (Sort32 output size).

  if (blockNum > 1) {
    uint32_t fullSegSize = blockSize;
    uint32_t lastSegSize = blockSize;
    uint32_t numSegs = blockNum;
    bool readFromTmp = true; // Sort32 output is in tmp

    while (numSegs > 1) {
      uint32_t newNumSegs = 0;
      uint32_t inOffset = 0;
      uint32_t outOffset = 0;

      for (uint32_t g = 0; g < numSegs; g += 4) {
        uint32_t groupCount = numSegs - g;
        if (groupCount > 4) {
          groupCount = 4;
        }
        uint32_t len0 = (g == numSegs - 1) ? lastSegSize : fullSegSize;
        uint32_t len1 = 0, len2 = 0, len3 = 0;
        uint32_t totalElems = len0;
        if (groupCount > 1) {
          len1 = (g + 1 == numSegs - 1) ? lastSegSize : fullSegSize;
          totalElems += len1;
        }
        if (groupCount > 2) {
          len2 = (g + 2 == numSegs - 1) ? lastSegSize : fullSegSize;
          totalElems += len2;
        }
        if (groupCount > 3) {
          len3 = (g + 3 == numSegs - 1) ? lastSegSize : fullSegSize;
          totalElems += len3;
        }

        if (groupCount == 1) {
          if (readFromTmp) {
            AscendC::DataCopy(dst[outOffset], tmp[inOffset], len0 * 2);
          } else {
            AscendC::DataCopy(tmp[outOffset], dst[inOffset], len0 * 2);
          }
        } else {
          AscendC::MrgSort4Info params;
          params.elementLengths[0] = len0;
          params.elementLengths[1] = len1;
          params.elementLengths[2] = groupCount > 2 ? len2 : 0;
          params.elementLengths[3] = groupCount > 3 ? len3 : 0;
          params.ifExhaustedSuspension = false;
          params.validBit = (1 << groupCount) - 1;

          uint32_t off0 = inOffset;
          uint32_t off1 = off0 + len0 * 2;
          uint32_t off2 = off1 + len1 * 2;
          uint32_t off3 = off2 + len2 * 2;

          AscendC::MrgSortSrcList<T> srcList;
          if (readFromTmp) {
            srcList.src1 = tmp[off0];
            srcList.src2 = tmp[off1];
            srcList.src3 = groupCount > 2 ? tmp[off2] : tmp[off0];
            srcList.src4 = groupCount > 3 ? tmp[off3] : tmp[off0];
            AscendC::MrgSort<T>(dst[outOffset], srcList, params);
          } else {
            srcList.src1 = dst[off0];
            srcList.src2 = dst[off1];
            srcList.src3 = groupCount > 2 ? dst[off2] : dst[off0];
            srcList.src4 = groupCount > 3 ? dst[off3] : dst[off0];
            AscendC::MrgSort<T>(tmp[outOffset], srcList, params);
          }
        }

        inOffset += totalElems * 2;
        outOffset += totalElems * 2;
        newNumSegs++;
      }

      PipeBarrier<PIPE_V>();

      uint32_t lastGroupStart = ((numSegs - 1) / 4) * 4;
      uint32_t lastGroupCount = numSegs - lastGroupStart;
      uint32_t newLastSegSize = 0;
      for (uint32_t i = 0; i < lastGroupCount; i++) {
        newLastSegSize +=
            (lastGroupStart + i == numSegs - 1) ? lastSegSize : fullSegSize;
      }

      fullSegSize = (newNumSegs > 1) ? 4 * fullSegSize : newLastSegSize;
      lastSegSize = newLastSegSize;
      numSegs = newNumSegs;
      readFromTmp = !readFromTmp;
    }

    // readFromTmp=true means last round wrote to tmp → result in tmp
    if (readFromTmp) {
      AscendC::DataCopy(dst, tmp, alignedCount * 2);
    }
  } else {
    // Single block: Sort32 output is in tmp, copy to dst
    AscendC::DataCopy(dst, tmp, alignedCount * 2);
  }
}

template <typename T>
CATLASS_DEVICE void ClampMax(const LocalTensor<T> &dst,
                             const LocalTensor<T> &buffer,
                             const LocalTensor<uint8_t> &tmp,
                             const T scalarValue, const int32_t count) {
  AscendC::ClampMax<T>(dst, buffer, tmp, scalarValue, count);
}

template <typename T>
CATLASS_DEVICE void TopK(const LocalTensor<T> &dst, const LocalTensor<T> &src,
                         const LocalTensor<T> &tmp, const int32_t K,
                         const int32_t repeatTimes, const int32_t actualCount) {
  // Use tmp as the full-size sort destination (2 * alignedCount elements).
  // Sort writes its result into tmp's first region; we then copy the top-K
  // portion into dst.
  uint32_t alignedCount = repeatTimes * 32;
  // sortDst needs 2 * alignedCount elements; reuse the tail of tmp.
  // Layout of tmp: [0 .. 2*alignedCount-1] = sortDst, [2*alignedCount ..] =
  // sortTmp
  auto sortDst = tmp;
  auto sortTmp = tmp[alignedCount * 2];
  Sort<T>(sortDst, src, sortTmp, repeatTimes, actualCount);
  PipeBarrier<PIPE_V>();
  // Copy 2*K elements (interleaved value-index pairs) from sorted result to
  // dst. DataCopy requires the byte count to be a multiple of 32 bytes, so
  // round up.
  uint32_t topkElems = 2 * K;
  constexpr uint32_t elemsPerBlock = 32 / sizeof(T);
  uint32_t alignedTopk =
      ((topkElems + elemsPerBlock - 1) / elemsPerBlock) * elemsPerBlock;
  AscendC::DataCopy(dst, sortDst, alignedTopk);
}

template <typename T>
CATLASS_DEVICE void ClampMin(const LocalTensor<T> &dst,
                             const LocalTensor<T> &buffer,
                             const LocalTensor<uint8_t> &tmp,
                             const T scalarValue, const int32_t count) {
  AscendC::ClampMin<T>(dst, buffer, tmp, scalarValue, count);
}

template <typename T>
CATLASS_DEVICE void
Clamp(const LocalTensor<T> &dst, const LocalTensor<T> &buffer,
      const LocalTensor<uint8_t> &tmp, const T minScalarValue,
      const T maxScalarValue, const int32_t count) {
  AscendC::ClampMin<T>(dst, buffer, tmp, minScalarValue, count);
  AscendC::ClampMax<T>(dst, dst, tmp, maxScalarValue, count);
}

template <typename T, typename U>
CATLASS_DEVICE void
GatherMask_experiment(const LocalTensor<T> &dst, const LocalTensor<T> &src0,
                      const LocalTensor<U> &src1Pattern, const bool reduceMode,
                      const uint32_t mask, const uint32_t src0BlockStride,
                      const uint32_t repeatTimes, uint32_t src0RepeatStride,
                      const uint32_t src1RepeatStride, uint64_t rsvdCnt) {
  GatherMaskParams gatherMaskParams;
  gatherMaskParams.repeatTimes = repeatTimes;
  gatherMaskParams.src0BlockStride = src0BlockStride;
  gatherMaskParams.src0RepeatStride = src0RepeatStride;
  gatherMaskParams.src1RepeatStride = src1RepeatStride;
  GatherMask(dst, src0, src1Pattern, reduceMode, mask, gatherMaskParams,
             rsvdCnt);
}

template <typename T>
CATLASS_DEVICE void
Fill_experiment(const LocalTensor<T> &dst, const T &scalarValue, uint64_t mask0,
                const uint8_t repeatTime, const uint16_t dstBlockStride,
                const uint8_t dstRepeatStride) {
  uint64_t mask[2] = {mask0, 0};
  AscendC::Duplicate(dst, scalarValue, mask, repeatTime, dstBlockStride,
                     dstRepeatStride);
}

template <typename T>
CATLASS_DEVICE void
Sum_experiment(const LocalTensor<T> &dst, const LocalTensor<T> &src,
               const uint32_t outter, const uint32_t inner, const uint32_t n) {
  SumParams sumParams;
  sumParams.outter = outter;
  sumParams.inner = inner;
  sumParams.n = n;
  AscendC::Sum(dst, src, sumParams);
}

template <typename T, uint32_t H, uint32_t W>
CATLASS_DEVICE void transpose_block(LocalTensor<T> const &dst,
                                    LocalTensor<T> const &src) {
  constexpr uint32_t blockSize = 32 / sizeof(T);
  constexpr uint32_t highBlock = H / 16;
  constexpr uint32_t repeat = W / blockSize;

  TransDataTo5HDParams params;
  params.dstHighHalf = false;
  params.srcHighHalf = false;
  params.repeatTimes = repeat;
  params.dstRepStride = repeat > 1 ? H : 0;
  params.srcRepStride = repeat > 1 ? 1 : 0;

  __ubuf__ T *dstList[16];
  __ubuf__ T *srcList[16];

  for (uint32_t i = 0; i < highBlock; i++) {
    if constexpr (sizeof(T) == 2) {
      for (int32_t m = 0; m < 16; m++)
        dstList[m] = (__ubuf__ T *)dst[i * 16 + H * m].GetPhyAddr();
      for (int32_t n = 0; n < 16; n++)
        srcList[n] = (__ubuf__ T *)src[i * W * 16 + W * n].GetPhyAddr();
      AscendC::TransDataTo5HDImpl<T>(dstList, srcList, params);
    } else if constexpr (sizeof(T) == 4) {
      for (int32_t m = 0; m < 16; m = m + 2) {
        dstList[m] = (__ubuf__ T *)dst[i * 16 + H * (m / 2)].GetPhyAddr();
        dstList[m + 1] =
            (__ubuf__ T *)dst[i * 16 + H * (m / 2) + blockSize].GetPhyAddr();
      }
      for (int32_t n = 0; n < 16; n++)
        srcList[n] = (__ubuf__ T *)src[i * W * 16 + W * n].GetPhyAddr();
      AscendC::TransDataTo5HDImpl<T>(dstList, srcList, params);
    }
  }
  AscendC::PipeBarrier<PIPE_V>();
}

template <typename T, uint32_t FullM = 16, uint32_t FullN = 16>
CATLASS_DEVICE void transpose(LocalTensor<T> const &dst,
                              LocalTensor<T> const &src) {
  if constexpr (FullM == 16 && FullN == 16 && sizeof(T) == 2 &&
                !std::is_same_v<T, bfloat16_t>) {
    AscendC::Transpose(dst, src);
    return;
  }

  if constexpr (FullM % 16 == 0 && FullN % 16 == 0 &&
                (sizeof(T) == 2 || sizeof(T) == 4) &&
                !std::is_same_v<T, bfloat16_t>) {
    transpose_block<T, FullM, FullN>(dst, src);
  } else {
    for (uint32_t i = 0; i < FullM; i++)
      for (uint32_t j = 0; j < FullN; j++)
        dst.SetValue(j * FullM + i, src.GetValue(i * FullN + j));
  }
}

} // namespace tl::ascend
