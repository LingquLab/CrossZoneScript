#include <tilexr/profiling.h>
#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void tilexr_tl_dispatch_runtime_c64_profile( GM_ADDR params_handle,  GM_ADDR x_handle,  GM_ADDR ids_handle,  GM_ADDR mask_handle,  GM_ADDR peers_handle,  GM_ADDR state_handle,  GM_ADDR payload_handle,  GM_ADDR output_handle,  GM_ADDR assist_handle,  GM_ADDR counts_handle,  GM_ADDR expert_nums_handle,  GM_ADDR diagnostics_handle, uint64_t fftsAddr, GM_ADDR profileGM) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<uint64_t> params;
  params.SetGlobalBuffer((__gm__ uint64_t*)params_handle);
  AscendC::GlobalTensor<uint16_t> x;
  x.SetGlobalBuffer((__gm__ uint16_t*)x_handle);
  AscendC::GlobalTensor<int> ids;
  ids.SetGlobalBuffer((__gm__ int*)ids_handle);
  AscendC::GlobalTensor<uint8_t> mask;
  mask.SetGlobalBuffer((__gm__ uint8_t*)mask_handle);
  AscendC::GlobalTensor<uint64_t> peers;
  peers.SetGlobalBuffer((__gm__ uint64_t*)peers_handle);
  AscendC::GlobalTensor<uint32_t> state;
  state.SetGlobalBuffer((__gm__ uint32_t*)state_handle);
  AscendC::GlobalTensor<uint32_t> payload;
  payload.SetGlobalBuffer((__gm__ uint32_t*)payload_handle);
  AscendC::GlobalTensor<uint16_t> output;
  output.SetGlobalBuffer((__gm__ uint16_t*)output_handle);
  AscendC::GlobalTensor<int> assist;
  assist.SetGlobalBuffer((__gm__ int*)assist_handle);
  AscendC::GlobalTensor<int> counts;
  counts.SetGlobalBuffer((__gm__ int*)counts_handle);
  AscendC::GlobalTensor<int64_t> expert_nums;
  expert_nums.SetGlobalBuffer((__gm__ int64_t*)expert_nums_handle);
  AscendC::GlobalTensor<int> diagnostics;
  diagnostics.SetGlobalBuffer((__gm__ int*)diagnostics_handle);

  // [AI] 纯AIV仅分配实际UB，全部搬运完成后销毁。
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;
  pipe.InitBuffer(ascend_ub, 189472);
  TileXR::Profiling::Recorder<32> recorder;
  auto core = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    }
  auto diag = ascend_ub.GetWithOffset<int>(16, 0);
  auto p = ascend_ub.GetWithOffset<uint64_t>(32, 64);
  auto route = ascend_ub.GetWithOffset<int>(768, 320);
  auto active = ascend_ub.GetWithOffset<uint8_t>(128, 3392);
  auto data_b = ascend_ub.GetWithOffset<uint32_t>(18000, 3520);
  int8_t precompute = (signed char)0;
  int workers = 0;
  int worker = 0;
  auto records = ascend_ub.GetWithOffset<uint32_t>(3072, 75520);
  auto data_a = ascend_ub.GetWithOffset<uint32_t>(18000, 87808);
  int polls = 0;
  uint32_t ready = (uint32_t)0;
  auto record = ascend_ub.GetWithOffset<uint32_t>(3840, 159808);
  int issued = 0;
  int producers = 0;
  int ready_1 = 0;
  int polls_1 = 0;
  uint32_t running = (uint32_t)0;
  auto prefix = ascend_ub.GetWithOffset<int>(384, 175168);
  int first = 0;
  int producers_1 = 0;
  int ready_2 = 0;
  int polls_2 = 0;
  auto nums = ascend_ub.GetWithOffset<int64_t>(384, 176704);
  int valid_slots = 0;
  auto consumed_slots = ascend_ub.GetWithOffset<int>(1152, 179776);
  auto flags = ascend_ub.GetWithOffset<uint32_t>(1272, 184384);
  int remaining = 0;
  int cursor = 0;
  int batch_index = 0;
  int pending_a = 0;
  int pending_b = 0;
  int start = 0;
  int arrived = 0;
  int clean_rows = 0;
  int position = 0;
  uint32_t bits = (uint32_t)0;
  int population = 0;
  uint32_t wanted = (uint32_t)0;
  uint32_t wanted_1 = (uint32_t)0;
  int before = 0;
  int start_1 = 0;
  uint32_t wanted_2 = (uint32_t)0;
  int cleared = 0;
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    if ASCEND_IS_AIV {
      for (int32_t i = 0; i < 16; ++i) {
        diag.SetValue(i, 0);
      }
      recorder.RecordMarker<0, 1>();
      AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
      tl::ascend::copy_gm_to_ub<uint64_t, 32>(p[0], params[0], 32, 1, 32, (uint64_t)0);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
      if (((((((((((((((((((p.GetValue(11) != (uint64_t)3) || (p.GetValue(6) != (uint64_t)64)) || (p.GetValue(0) == (uint64_t)0)) || ((uint64_t)128 < p.GetValue(0))) || (p.GetValue(1) == (uint64_t)0)) || ((uint64_t)7168 < p.GetValue(1))) || (p.GetValue(2) == (uint64_t)0)) || ((uint64_t)6 < p.GetValue(2))) || (p.GetValue(3) == (uint64_t)0)) || ((uint64_t)384 < p.GetValue(3))) || (p.GetValue(4) == (uint64_t)0)) || ((uint64_t)64 < p.GetValue(4))) || (p.GetValue(4) <= p.GetValue(5))) || ((p.GetValue(3) % (p.GetValue(4) > (uint64_t)1 ? p.GetValue(4) : (uint64_t)1)) != (uint64_t)0)) || ((uint64_t)1 < p.GetValue(12))) || ((uint64_t)1 < p.GetValue(13))) || ((uint64_t)1 < p.GetValue(14))) || (p.GetValue(15) != (((p.GetValue(1) + (uint64_t)15) / (uint64_t)16) * (uint64_t)8))) || (p.GetValue(16) != ((p.GetValue(15) + (uint64_t)127) / (uint64_t)120))) {
        diag.SetValue(0, 8);
      } else {
        recorder.RecordMarker<1, 10>();
        int32_t count = ((int32_t)(p.GetValue(0) * p.GetValue(2)));
        int32_t experts = ((int32_t)p.GetValue(3));
        int32_t world = ((int32_t)p.GetValue(4));
        int32_t rank = ((int32_t)p.GetValue(5));
        int32_t cores = ((int32_t)p.GetValue(6));
        int32_t hidden = ((int32_t)p.GetValue(1));
        int32_t assist_word = ((int32_t)p.GetValue(15));
        int32_t blocks = ((int32_t)p.GetValue(16));
        recorder.RecordMarker<2, 11>();
        recorder.RecordMarker<3, 100>();
        AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
        tl::ascend::copy_gm_to_ub<int, 768>(route[0], ids[0], 768, 1, ((count <= 768) ? count : 768), 0);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        if (p.GetValue(12) != (uint64_t)0) {
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval;
          if (((int32_t)p.GetValue(0)) <= 128) {
            condval = ((int32_t)p.GetValue(0));
          } else {
            condval = 128;
          }
          tl::ascend::copy_gm_to_ub<uint8_t, 128>(active[0], mask[0], 128, 1, condval, (uchar)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
        }
        auto values = data_b[0].ReinterpretCast<int>();
        auto clamped = data_b[768].ReinterpretCast<int>();
        auto predicate = data_b[1536].ReinterpretCast<uint8_t>();
        auto bits_1 = data_b[0].ReinterpretCast<float>();
        auto invalid_bits = data_b[768].ReinterpretCast<float>();
        AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
        AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
        tl::ascend::Fill<int>(values[0], -1, 768);
        AscendC::PipeBarrier<PIPE_V>();
        tl::ascend::copy_ub_to_ub_strided<int>(values[0], route[0], 768, 768, 1, count);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Mins(clamped[0], values[0], (experts - 1), 768);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Maxs(clamped[0], clamped[0], -1, 768);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Compare(predicate[0], values[0], clamped[0], AscendC::CMPMODE::EQ, 768);
        AscendC::PipeBarrier<PIPE_V>();
        tl::ascend::Fill<int>(clamped[0], -1, 768);
        AscendC::PipeBarrier<PIPE_V>();
AscendC::Select(bits_1[0], predicate[0], bits_1[0], invalid_bits[0], AscendC::SELMODE::VSEL_TENSOR_TENSOR_MODE, 768);
        AscendC::PipeBarrier<PIPE_V>();
        tl::ascend::copy_ub_to_ub_strided<int>(route[0], values[0], 768, 768, 1, count);
        AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
        AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
        if (p.GetValue(12) != (uint64_t)0) {
          for (int32_t token = 0; token < ((int32_t)p.GetValue(0)); ++token) {
            if (active.GetValue(token) == (uchar)0) {
              for (int32_t choice = 0; choice < ((int32_t)p.GetValue(2)); ++choice) {
                route.SetValue(((((int64_t)token) * ((int64_t)p.GetValue(2))) + ((int64_t)choice)), -1);
              }
            }
          }
        }
        recorder.RecordMarker<4, 101>();
        precompute = (signed char)0;
        precompute = ((signed char)((((world == 64) && (experts == 384)) && (p.GetValue(0) == (uint64_t)128)) && ((p.GetValue(2) == (uint64_t)6) || (p.GetValue(2) == (uint64_t)8))));
        workers = cores;
        worker = core;
        if ((uint64_t)1 <= (p.GetValue(0) / (uint64_t)48)) {
          workers = (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)));
          worker = (((8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2))) + core) - cores);
        }
        if (((p.GetValue(0) / (uint64_t)48) < (uint64_t)1) || ((cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))) <= core)) {
          int32_t begin = ((worker < (experts % workers) ? worker : (experts % workers)) + ((experts / workers) * worker));
          int32_t end = ((begin + (experts / workers)) + ((int32_t)(worker < (experts % workers))));
          if (begin < end) {
            recorder.RecordMarker<5, 200>();
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::Fill<uint32_t>(records[0], (uint32_t)0, (experts * 8));
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            for (int32_t expert = begin; expert < end; ++expert) {
              records.SetValue((((int64_t)expert) * (int64_t)8), (uint32_t)1065353216);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::Fill<uint32_t>(data_b[0], (uint32_t)0, experts);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            if (((bool)precompute) && (worker == 0)) {
              for (int32_t i_1 = 0; i_1 < count; ++i_1) {
                int32_t expert_1 = route.GetValue(i_1);
                if (0 <= expert_1) {
                  data_a.SetValue(i_1, data_b.GetValue(((int64_t)expert_1)));
                  data_b.SetValue(((int64_t)expert_1), (data_b.GetValue(((int64_t)expert_1)) + (uint32_t)1));
                } else {
                  data_a.SetValue(i_1, (uint32_t)0);
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 18000>(state[16384], data_a[0], 262144, 1, ((count <= 245760) ? count : 245760));
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill<uint32_t>(data_a[0], (uint32_t)1, ((cores * 8) - ((8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2))) * 8)));
              AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 18000>(state[17408], data_a[0], 262144, 1, (((cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))) <= 30592) ? ((cores * 8) - ((8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2))) * 8)) : 244736));
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            } else {
              for (int32_t i_2 = 0; i_2 < count; ++i_2) {
                int32_t expert_2 = route.GetValue(i_2);
                if ((begin <= expert_2) && (expert_2 < end)) {
                  data_b.SetValue(((int64_t)expert_2), (data_b.GetValue(((int64_t)expert_2)) + (uint32_t)1));
                }
              }
            }
            for (int32_t expert_3 = begin; expert_3 < end; ++expert_3) {
              records.SetValue(((((int64_t)expert_3) * (int64_t)8) + (int64_t)1), data_b.GetValue(((int64_t)expert_3)));
            }
            recorder.RecordMarker<6, 201>();
            recorder.RecordMarker<7, 300>();
            for (int32_t target = 0; target < world; ++target) {
              if (((begin < ((target + 1) * (experts / world))) && ((target * (experts / world)) < end)) && ((target * (experts / world)) < ((target + 1) * (experts / world)))) {
                AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                AscendC::GlobalTensor<uint32_t> peer;
                peer.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue((((int64_t)target) * (int64_t)2))));
                auto source = records[((begin > (target * (experts / world)) ? begin : (target * (experts / world))) * 8)].ReinterpretCast<uint32_t>();
                auto target_rows = peer[(((((begin > (target * (experts / world)) ? begin : (target * (experts / world))) % (experts / world)) * world) * 8) + (rank * 8))].ReinterpretCast<uint32_t>();
                tl::ascend::copy_ub_to_gm_strided<uint32_t>(target_rows[0], source[0], 8, (world * 8), ((end < ((target + 1) * (experts / world)) ? end : ((target + 1) * (experts / world))) - (begin > (target * (experts / world)) ? begin : (target * (experts / world)))), 8);
                diag.SetValue(4, (((end < ((target + 1) * (experts / world)) ? end : ((target + 1) * (experts / world))) + diag.GetValue(4)) - (begin > (target * (experts / world)) ? begin : (target * (experts / world)))));
              }
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            recorder.RecordMarker<8, 301>();
          }
        }
        if (core < (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2))))) {
          recorder.RecordMarker<9, 400>();
          if ((bool)precompute) {
            polls = 0;
            ready = (uint32_t)0;
            while (1) {
              if (!(((ready != (uint32_t)1) && (polls < 100000)))) { break; }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
              tl::ascend::copy_gm_to_ub<uint32_t, 8>(record[0], state[((core * 8) + 17408)], 262144, 1, 8, (uint32_t)0);
              AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
              ready = record.GetValue(0);
              polls = (polls + 1);
            }
            if (ready == (uint32_t)1) {
              AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
              tl::ascend::copy_gm_to_ub_strided<uint32_t>(data_b[0], state[16384], 262144, 18000, 1, count);
              AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill<uint32_t>(record[0], (uint32_t)0, 8);
              AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<uint32_t, 8>(state[((core * 8) + 17408)], record[0], 262144, 1, 8);
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            } else {
              diag.SetValue(0, 9);
            }
          }
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill<uint32_t>(data_a[0], (uint32_t)1065353216, (((2 < (1125 / (blocks * 8)) ? 2 : (1125 / (blocks * 8))) * blocks) * 128));
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill<uint32_t>(record[0], (uint32_t)0, (blocks * 120));
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          issued = 0;
          for (int32_t task = 0; task < ((((count + cores) - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))) - 1) / (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2))))); ++task) {
            if (((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) < count) && (diag.GetValue(0) != 9)) {
              int32_t token_1 = ((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) / ((int32_t)p.GetValue(2)));
              int32_t expert_4 = route.GetValue((((int64_t)core) + (((int64_t)task) * (((int64_t)cores) - ((int64_t)8 < (((((int64_t)experts) + (int64_t)15) / (int64_t)16) < (((int64_t)cores) / (int64_t)2) ? ((((int64_t)experts) + (int64_t)15) / (int64_t)16) : (((int64_t)cores) / (int64_t)2)) ? (int64_t)8 : (((((int64_t)experts) + (int64_t)15) / (int64_t)16) < (((int64_t)cores) / (int64_t)2) ? ((((int64_t)experts) + (int64_t)15) / (int64_t)16) : (((int64_t)cores) / (int64_t)2)))))));
              if (0 <= expert_4) {
                position = 0;
                if ((bool)precompute) {
                  position = ((int32_t)data_b.GetValue((((int64_t)core) + (((int64_t)task) * (((int64_t)cores) - ((int64_t)8 < (((((int64_t)experts) + (int64_t)15) / (int64_t)16) < (((int64_t)cores) / (int64_t)2) ? ((((int64_t)experts) + (int64_t)15) / (int64_t)16) : (((int64_t)cores) / (int64_t)2)) ? (int64_t)8 : (((((int64_t)experts) + (int64_t)15) / (int64_t)16) < (((int64_t)cores) / (int64_t)2) ? ((((int64_t)experts) + (int64_t)15) / (int64_t)16) : (((int64_t)cores) / (int64_t)2))))))));
                } else {
                  auto values_1 = data_b[0].ReinterpretCast<int>();
                  auto predicate_1 = data_b[768].ReinterpretCast<uint8_t>();
                  auto packed = data_b[768].ReinterpretCast<uint32_t>();
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  tl::ascend::Fill<int>(values_1[0], -1, 768);
                  AscendC::PipeBarrier<PIPE_V>();
                  tl::ascend::copy_ub_to_ub_strided<int>(values_1[0], route[0], 768, 768, 1, (core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))));
                  AscendC::PipeBarrier<PIPE_V>();
                  AscendC::CompareScalar(predicate_1[0], values_1[0], expert_4, AscendC::CMPMODE::EQ, 768);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                  position = 0;
                  for (int32_t word = 0; word < (((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) + 31) / 32); ++word) {
                    bits = packed.GetValue(((int64_t)word));
                    if ((((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) / 32) - word) < 1) {
                      bits = (bits & (((uint32_t)1 << ((uint32_t)((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) - (word * 32)))) - (uint32_t)1));
                    }
                    population = 0;
                    bits = (bits - ((bits >> (uint32_t)1) & (uint32_t)1431655765));
                    bits = ((bits & (uint32_t)858993459) + ((bits >> (uint32_t)2) & (uint32_t)858993459));
                    bits = ((bits + (bits >> (uint32_t)4)) & (uint32_t)252645135);
                    population = ((int32_t)((bits * (uint32_t)16843009) >> (uint32_t)24));
                    position = (position + population);
                  }
                }
                if (((int32_t)p.GetValue(0)) <= position) {
                  diag.SetValue(0, 7);
                } else {
                  int32_t slot = (issued % (2 < (1125 / (blocks * 8)) ? 2 : (1125 / (blocks * 8))));
                  if ((2 <= issued) || ((1125 / (blocks * 8)) <= issued)) {
                    AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>((slot + 2));
                  }
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                  auto feature = record[0].ReinterpretCast<uint16_t>();
                  tl::ascend::copy_gm_to_ub_strided<uint16_t>(feature[0], x[(token_1 * hidden)], 917504, 7680, 1, hidden);
                  AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                  if (0 < (hidden % 2)) {
                    record.SetValue((hidden / 2), (record.GetValue((hidden / 2)) & (uint32_t)65535));
                  }
                  for (int32_t j = ((hidden + 1) / 2); j < assist_word; ++j) {
                    record.SetValue(((int64_t)j), (uint32_t)0);
                  }
                  record.SetValue(((int64_t)assist_word), ((uint32_t)rank));
                  record.SetValue((((int64_t)assist_word) + (int64_t)1), ((uint32_t)token_1));
                  record.SetValue((((int64_t)assist_word) + (int64_t)2), ((uint32_t)((core + (task * (cores - (8 < (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)) ? 8 : (((experts + 15) / 16) < (cores / 2) ? ((experts + 15) / 16) : (cores / 2)))))) % ((int32_t)p.GetValue(2)))));
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  auto compact = record[0].ReinterpretCast<uint32_t>();
                  auto packed_1 = data_a[((slot * blocks) * 128)].ReinterpretCast<uint32_t>();
                  tl::ascend::copy_ub_to_ub_strided<uint32_t>(packed_1[0], compact[0], 120, 128, blocks, 120);
                  AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
                  int32_t offset = ((((((((rank + (expert_4 / (experts / world))) % world) * (experts / world)) + (expert_4 % (experts / world))) * ((int32_t)p.GetValue(0))) + position) * blocks) * 128);
                  AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                  AscendC::GlobalTensor<uint32_t> peer_1;
                  peer_1.SetGlobalBuffer(reinterpret_cast<__gm__ uint32_t *>(peers.GetValue((((((int64_t)expert_4) / (((int64_t)experts) / ((int64_t)world))) * (int64_t)2) + (int64_t)1))));
                  tl::ascend::copy_ub_to_gm<uint32_t, 18000>(peer_1[offset], data_a[((slot * blocks) * 128)], 188743680, 1, ((((blocks * 128) + offset) <= 188743680) ? (blocks * 128) : ((offset < 188743680) ? (188743680 - offset) : 0)));
                  AscendC::SetFlag<AscendC::HardEvent::MTE3_S>((slot + 2));
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                  issued = (issued + 1);
                  diag.SetValue(5, (diag.GetValue(5) + 1));
                  diag.SetValue(9, ((blocks * 512) + diag.GetValue(9)));
                }
              }
            }
          }
          for (int32_t slot_1 = 0; slot_1 < (2 < (1125 / (blocks * 8)) ? 2 : (1125 / (blocks * 8))); ++slot_1) {
            if (slot_1 < issued) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>((slot_1 + 2));
            }
          }
          recorder.RecordMarker<10, 401>();
        }
        int32_t experts_1 = ((int32_t)p.GetValue(3));
        int32_t cores_1 = ((int32_t)p.GetValue(6));
        producers = (8 < (((experts_1 + 15) / 16) < (cores_1 / 2) ? ((experts_1 + 15) / 16) : (cores_1 / 2)) ? 8 : (((experts_1 + 15) / 16) < (cores_1 / 2) ? ((experts_1 + 15) / 16) : (cores_1 / 2)));
        if ((cores_1 - producers) <= core) {
          int32_t worker_1 = ((core + producers) - cores_1);
          int32_t begin_1 = (((worker_1 < (((experts_1 + 7) / 8) % producers) ? worker_1 : (((experts_1 + 7) / 8) % producers)) * 8) + (((((experts_1 + 7) / 8) / producers) * worker_1) * 8));
          int32_t stop = ((((((experts_1 + 7) / 8) / producers) * 8) + (((int32_t)(worker_1 < (((experts_1 + 7) / 8) % producers))) * 8)) + begin_1);
          recorder.RecordMarker<11, 500>();
          ready_1 = 0;
          polls_1 = 0;
          while (1) {
            if (!(((ready_1 == 0) && (polls_1 < 100000)))) { break; }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 3072>(records[0], state[0], 262144, 1, ((experts_1 <= 32768) ? (experts_1 * 8) : 262144), (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            ready_1 = 1;
            auto predicate_2 = data_a[64].ReinterpretCast<uint8_t>();
            auto packed_2 = data_a[64].ReinterpretCast<uint32_t>();
            for (int32_t chunk = 0; chunk < ((experts_1 + 7) / 8); ++chunk) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              auto values_2 = data_a[0].ReinterpretCast<uint32_t>();
              auto signed_values = data_a[0].ReinterpretCast<int>();
              tl::ascend::Fill<uint32_t>(values_2[0], (uint32_t)1065353216, 64);
              AscendC::PipeBarrier<PIPE_V>();
              tl::ascend::copy_ub_to_ub_strided<uint32_t>(values_2[0], records[(chunk * 64)], 3072, 64, 1, ((8 < (experts_1 - (chunk * 8)) ? 8 : (experts_1 - (chunk * 8))) * 8));
              AscendC::PipeBarrier<PIPE_V>();
              AscendC::CompareScalar(predicate_2[0], signed_values[0], 1065353216, AscendC::CMPMODE::EQ, 64);
              AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
              for (int32_t word_1 = 0; word_1 < 2; ++word_1) {
                if (0 < ((8 < (experts_1 - (chunk * 8)) ? 8 : (experts_1 - (chunk * 8))) - (word_1 * 4))) {
                  wanted = (uint32_t)4294967295;
                  wanted = ((uint32_t)16843009 >> ((uint32_t)(32 - ((4 < ((8 < (experts_1 - (chunk * 8)) ? 8 : (experts_1 - (chunk * 8))) - (word_1 * 4)) ? 4 : ((8 < (experts_1 - (chunk * 8)) ? 8 : (experts_1 - (chunk * 8))) - (word_1 * 4))) * 8))));
                  if ((packed_2.GetValue(word_1) & wanted) != wanted) {
                    ready_1 = 0;
                  }
                }
              }
            }
            polls_1 = (polls_1 + 1);
          }
          diag.SetValue(1, polls_1);
          recorder.RecordMarker<12, 501>();
          if (ready_1 == 0) {
            diag.SetValue(0, 1);
          } else {
            recorder.RecordMarker<13, 600>();
            running = (uint32_t)0;
            for (int32_t q = begin_1; q < stop; ++q) {
              prefix.SetValue(((int64_t)q), 0);
            }
            for (int32_t q_1 = 0; q_1 < (stop < experts_1 ? stop : experts_1); ++q_1) {
              running = (running + records.GetValue(((((int64_t)q_1) * (int64_t)8) + (int64_t)1)));
              if (begin_1 <= q_1) {
                prefix.SetValue(q_1, ((int32_t)running));
              }
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<int, 384>(counts[begin_1], prefix[begin_1], 384, 1, (((stop <= 384) || (experts_1 <= 384)) ? ((stop < experts_1 ? stop : experts_1) - begin_1) : ((begin_1 < 384) ? (384 - begin_1) : 0)));
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            auto prefix_words = prefix[0].ReinterpretCast<uint32_t>();
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            for (int32_t c = 0; c < cores_1; ++c) {
              tl::ascend::copy_ub_to_gm<uint32_t, 384>(state[(((((c * ((experts_1 + 7) / 8)) * 8) + begin_1) + 196608) - ((cores_1 * ((experts_1 + 7) / 8)) * 8))], prefix_words[begin_1], 262144, 1, (((stop - begin_1) <= (((((cores_1 * ((experts_1 + 7) / 8)) * 8) + 65536) - begin_1) - ((c * ((experts_1 + 7) / 8)) * 8))) ? (stop - begin_1) : ((-65536 < ((((cores_1 * ((experts_1 + 7) / 8)) * 8) - begin_1) - ((c * ((experts_1 + 7) / 8)) * 8))) ? (((((cores_1 * ((experts_1 + 7) / 8)) * 8) + 65536) - begin_1) - ((c * ((experts_1 + 7) / 8)) * 8)) : 0)));
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            tl::ascend::Fill<uint32_t>(data_a[0], (uint32_t)1, ((2250 < cores_1 ? 2250 : cores_1) * 8));
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            first = 0;
            while (1) {
              if (!((first < cores_1))) { break; }
              int32_t n = (2250 < (cores_1 - first) ? 2250 : (cores_1 - first));
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              auto source_1 = data_a[0].ReinterpretCast<uint32_t>();
              auto target_1 = state[((((first * producers) * 8) + (worker_1 * 8)) + 224256)].ReinterpretCast<uint32_t>();
              tl::ascend::copy_ub_to_gm_strided<uint32_t>(target_1[0], source_1[0], 8, (producers * 8), n, 8);
              first = (first + n);
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            recorder.RecordMarker<14, 601>();
          }
        }
        AscendC::PipeBarrier<PIPE_ALL>();
        recorder.RecordMarker<15, 700>();
        int32_t experts_2 = ((int32_t)p.GetValue(3));
        int32_t world_1 = ((int32_t)p.GetValue(4));
        int32_t rank_1 = ((int32_t)p.GetValue(5));
        int32_t cores_2 = ((int32_t)p.GetValue(6));
        int32_t tokens = ((int32_t)p.GetValue(0));
        int32_t blocks_1 = ((int32_t)p.GetValue(16));
        producers_1 = (8 < (((experts_2 + 15) / 16) < (cores_2 / 2) ? ((experts_2 + 15) / 16) : (cores_2 / 2)) ? 8 : (((experts_2 + 15) / 16) < (cores_2 / 2) ? ((experts_2 + 15) / 16) : (cores_2 / 2)));
        ready_2 = 0;
        polls_2 = 0;
        recorder.RecordMarker<16, 704>();
        while (1) {
          if (!(((ready_2 == 0) && (polls_2 < 100000)))) { break; }
          AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
          int32_t condval_1;
          if (0 <= ((4736 - producers_1) - (core * producers_1))) {
            condval_1 = (producers_1 * 8);
          } else {
            int32_t condval_2;
            if ((core * producers_1) < 4736) {
              condval_2 = (37888 - ((core * producers_1) * 8));
            } else {
              condval_2 = 0;
            }
            condval_1 = condval_2;
          }
          tl::ascend::copy_gm_to_ub<uint32_t, 3072>(records[0], state[(((core * producers_1) * 8) + 224256)], 262144, 1, condval_1, (uint32_t)0);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
          ready_2 = 1;
          auto predicate_3 = data_b[64].ReinterpretCast<uint8_t>();
          auto packed_3 = data_b[64].ReinterpretCast<uint32_t>();
          for (int32_t chunk_1 = 0; chunk_1 < ((producers_1 + 7) / 8); ++chunk_1) {
            int32_t rows = (64 < ((producers_1 * 8) - (chunk_1 * 64)) ? 64 : ((producers_1 * 8) - (chunk_1 * 64)));
            AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
            auto values_3 = data_b[0].ReinterpretCast<uint32_t>();
            auto signed_values_1 = data_b[0].ReinterpretCast<int>();
            tl::ascend::Fill<uint32_t>(values_3[0], (uint32_t)1, 64);
            AscendC::PipeBarrier<PIPE_V>();
            tl::ascend::copy_ub_to_ub_strided<uint32_t>(values_3[0], records[(chunk_1 * 64)], 3072, 64, 1, rows);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::CompareScalar(predicate_3[0], signed_values_1[0], 1, AscendC::CMPMODE::EQ, 64);
            AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
            for (int32_t word_2 = 0; word_2 < 2; ++word_2) {
              if (0 < (rows - (word_2 * 32))) {
                wanted_1 = (uint32_t)4294967295;
                if (((rows / 32) - word_2) < 1) {
                  wanted_1 = (((uint32_t)1 << ((uint32_t)(rows - (word_2 * 32)))) - (uint32_t)1);
                }
                if ((packed_3.GetValue(word_2) & wanted_1) != wanted_1) {
                  ready_2 = 0;
                }
              }
            }
          }
          polls_2 = (polls_2 + 1);
        }
        recorder.RecordMarker<17, 705>();
        diag.SetValue(2, polls_2);
        if (ready_2 == 0) {
          diag.SetValue(0, 2);
        } else {
          recorder.RecordMarker<18, 706>();
          AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
          tl::ascend::Fill<uint32_t>(records[0], (uint32_t)0, (producers_1 * 8));
          AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
          AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
          AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
          int32_t condval_3;
          if (0 <= ((4736 - producers_1) - (core * producers_1))) {
            condval_3 = (producers_1 * 8);
          } else {
            int32_t condval_4;
            if ((core * producers_1) < 4736) {
              condval_4 = (37888 - ((core * producers_1) * 8));
            } else {
              condval_4 = 0;
            }
            condval_3 = condval_4;
          }
          tl::ascend::copy_ub_to_gm<uint32_t, 3072>(state[(((core * producers_1) * 8) + 224256)], records[0], 262144, 1, condval_3);
          AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
          recorder.RecordMarker<19, 707>();
          if (core == 0) {
            recorder.RecordMarker<20, 708>();
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            tl::ascend::copy_gm_to_ub<uint32_t, 3072>(records[0], state[0], 262144, 1, ((experts_2 <= 32768) ? (experts_2 * 8) : 262144), (uint32_t)0);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            for (int32_t q_2 = 0; q_2 < experts_2; ++q_2) {
              records.SetValue((((int64_t)q_2) * (int64_t)8), (uint32_t)0);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
            tl::ascend::copy_ub_to_gm<uint32_t, 3072>(state[0], records[0], 262144, 1, ((experts_2 <= 32768) ? (experts_2 * 8) : 262144));
            AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            recorder.RecordMarker<21, 709>();
          }
          recorder.RecordMarker<22, 701>();
          if (((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)) < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2))))) {
            recorder.RecordMarker<23, 702>();
            AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
            AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
            auto prefix_words_1 = prefix[0].ReinterpretCast<uint32_t>();
            tl::ascend::copy_gm_to_ub_strided<uint32_t>(prefix_words_1[0], state[(((((experts_2 + 7) / 8) * (core - cores_2)) * 8) + 196608)], 262144, 384, 1, (((experts_2 + 7) / 8) * 8));
            AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
            if (core == 0) {
              for (int32_t local = 0; local < (experts_2 / world_1); ++local) {
                before = 0;
                if (0 < local) {
                  before = prefix.GetValue(((((int64_t)local) * ((int64_t)world_1)) - (int64_t)1));
                }
                nums.SetValue(((int64_t)local), ((int64_t)prefix.GetValue((((((int64_t)local) + (int64_t)1) * ((int64_t)world_1)) - (int64_t)1))));
                if (p.GetValue(13) == (uint64_t)1) {
                  nums.SetValue(((int64_t)local), (nums.GetValue(((int64_t)local)) - ((int64_t)before)));
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              tl::ascend::copy_ub_to_gm<int64_t, 384>(expert_nums[0], nums[0], 384, 1, (((experts_2 / world_1) <= 384) ? (experts_2 / world_1) : 384));
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            }
            valid_slots = 0;
            for (int32_t q_3 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_3 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_3) {
              consumed_slots.SetValue(((int64_t)q_3), 0);
              consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_3)), 0);
              start_1 = 0;
              if (0 < q_3) {
                start_1 = prefix.GetValue((((int64_t)q_3) - (int64_t)1));
              }
              int32_t size = (prefix.GetValue(((int64_t)q_3)) - start_1);
              if ((((size < 0) || (tokens < size)) || (start_1 < 0)) || ((experts_2 * tokens) < prefix.GetValue(((int64_t)q_3)))) {
                diag.SetValue(0, 5);
              }
              if (0 < size) {
                consumed_slots.SetValue(((((int64_t)experts_2) * (int64_t)2) + ((int64_t)valid_slots)), q_3);
                valid_slots = (valid_slots + 1);
              }
            }
            recorder.RecordMarker<24, 703>();
            recorder.RecordMarker<25, 800>();
            if ((0 < valid_slots) && (diag.GetValue(0) == 0)) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill<uint32_t>(flags[0], (uint32_t)0, 1256);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
            }
            remaining = valid_slots;
            cursor = 0;
            batch_index = 0;
            pending_a = 0;
            pending_b = 0;
            while (1) {
              if (!(((0 < remaining) && (diag.GetValue(0) == 0)))) { break; }
              int32_t q_4 = consumed_slots.GetValue(((((int64_t)experts_2) * (int64_t)2) + ((int64_t)cursor)));
              start = 0;
              if (0 < q_4) {
                start = prefix.GetValue((q_4 - 1));
              }
              int32_t size_1 = (prefix.GetValue(((int64_t)q_4)) - start);
              int32_t consumed = consumed_slots.GetValue(((int64_t)q_4));
              if (consumed < size_1) {
                arrived = 0;
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                auto source_2 = payload[((((((((((q_4 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_4 / world_1)) * tokens) + consumed) * blocks_1) * 128) + 120)].ReinterpretCast<uint32_t>();
                auto target_2 = flags[0].ReinterpretCast<uint32_t>();
                tl::ascend::copy_gm_to_ub_strided<uint32_t>(target_2[0], source_2[0], 128, 8, ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1), 8);
                AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(0);
                AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(0);
                arrived = 1;
                auto predicate_4 = flags[1256].ReinterpretCast<uint8_t>();
                auto packed_4 = flags[1256].ReinterpretCast<uint32_t>();
                for (int32_t chunk_2 = 0; chunk_2 < ((((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) + 7) / 8); ++chunk_2) {
                  AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
                  auto values_4 = flags[(chunk_2 * 64)].ReinterpretCast<int>();
                  AscendC::CompareScalar(predicate_4[0], values_4[0], 1065353216, AscendC::CMPMODE::EQ, 64);
                  AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
                  AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
                  for (int32_t word_3 = 0; word_3 < 2; ++word_3) {
                    if (0 < ((8 < (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8)) ? 8 : (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8))) - (word_3 * 4))) {
                      wanted_2 = (uint32_t)4294967295;
                      wanted_2 = ((uint32_t)16843009 >> ((uint32_t)(32 - ((4 < ((8 < (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8)) ? 8 : (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8))) - (word_3 * 4)) ? 4 : ((8 < (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8)) ? 8 : (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) - (chunk_2 * 8))) - (word_3 * 4))) * 8))));
                      if ((packed_4.GetValue(word_3) & wanted_2) != wanted_2) {
                        arrived = 0;
                      }
                    }
                  }
                }
                consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_4)), (consumed_slots.GetValue((((int64_t)experts_2) + ((int64_t)q_4))) + 1));
                diag.SetValue(3, ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) + diag.GetValue(3)));
                if (arrived != 0) {
                  if ((batch_index % 2) == 0) {
                    if (pending_a != 0) {
                      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
                    }
                    int32_t output_rows_s0 = ((int32_t)p.GetValue(1));
                    int32_t aw = ((int32_t)p.GetValue(15));
                    int32_t blocks_2 = ((int32_t)p.GetValue(16));
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                    auto source_3 = payload[(((((((((q_4 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_4 / world_1)) * tokens) + consumed) * blocks_1) * 128)].ReinterpretCast<uint32_t>();
                    auto compact_1 = data_a[0].ReinterpretCast<uint32_t>();
                    tl::ascend::copy_gm_to_ub_strided<uint32_t>(compact_1[0], source_3[0], 128, 120, ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_2), 120);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(2);
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                    auto feature_1 = data_a[0].ReinterpretCast<uint16_t>();
                    auto feature_rows = feature_1[0].ReinterpretCast<uint16_t>();
                    auto output_rows = output[((start + consumed) * output_rows_s0)].ReinterpretCast<uint16_t>();
                    tl::ascend::copy_ub_to_gm_strided<uint16_t>(output_rows[0], feature_rows[0], (blocks_2 * 240), output_rows_s0, (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)), output_rows_s0);
                    auto assist_words = data_a[0].ReinterpretCast<int>();
                    auto assist_rows = assist_words[aw].ReinterpretCast<int>();
                    auto output_assist = assist[((start * 3) + (consumed * 3))].ReinterpretCast<int>();
                    tl::ascend::copy_ub_to_gm_strided<int>(output_assist[0], assist_rows[0], (blocks_2 * 120), 3, (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)), 3);
                    AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(2);
                    pending_a = 1;
                  } else {
                    if (pending_b != 0) {
                      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
                    }
                    int32_t output_rows_s0_1 = ((int32_t)p.GetValue(1));
                    int32_t aw_1 = ((int32_t)p.GetValue(15));
                    int32_t blocks_3 = ((int32_t)p.GetValue(16));
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE2>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE2>(0);
                    auto source_4 = payload[(((((((((q_4 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_4 / world_1)) * tokens) + consumed) * blocks_1) * 128)].ReinterpretCast<uint32_t>();
                    auto compact_2 = data_b[0].ReinterpretCast<uint32_t>();
                    tl::ascend::copy_gm_to_ub_strided<uint32_t>(compact_2[0], source_4[0], 128, 120, ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_3), 120);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(3);
                    AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
                    AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
                    auto feature_2 = data_b[0].ReinterpretCast<uint16_t>();
                    auto feature_rows_1 = feature_2[0].ReinterpretCast<uint16_t>();
                    auto output_rows_1 = output[((start + consumed) * output_rows_s0_1)].ReinterpretCast<uint16_t>();
                    tl::ascend::copy_ub_to_gm_strided<uint16_t>(output_rows_1[0], feature_rows_1[0], (blocks_3 * 240), output_rows_s0_1, (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)), output_rows_s0_1);
                    auto assist_words_1 = data_b[0].ReinterpretCast<int>();
                    auto assist_rows_1 = assist_words_1[aw_1].ReinterpretCast<int>();
                    auto output_assist_1 = assist[((start * 3) + (consumed * 3))].ReinterpretCast<int>();
                    tl::ascend::copy_ub_to_gm_strided<int>(output_assist_1[0], assist_rows_1[0], (blocks_3 * 120), 3, (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)), 3);
                    AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(3);
                    pending_b = 1;
                  }
                  batch_index = (batch_index + 1);
                  consumed_slots.SetValue(((int64_t)q_4), ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) + consumed) < size_1 ? (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) + consumed) : size_1));
                  consumed_slots.SetValue((((int64_t)experts_2) + ((int64_t)q_4)), 0);
                  diag.SetValue(7, ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) + diag.GetValue(7)));
                  diag.SetValue(10, ((((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (size_1 - consumed) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (size_1 - consumed)) * blocks_1) * 512) + diag.GetValue(10)));
                  if (((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) + consumed) < size_1 ? (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) + consumed) : size_1) == size_1) {
                    remaining = (remaining - 1);
                    cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
                  }
                } else {
                  if (100000 <= consumed_slots.GetValue((((int64_t)experts_2) + ((int64_t)q_4)))) {
                    diag.SetValue(0, 3);
                  }
                  cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
                }
              } else {
                cursor = ((cursor + 1) % (valid_slots > 1 ? valid_slots : 1));
              }
            }
            if (pending_a != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(2);
            }
            if (pending_b != 0) {
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(3);
            }
            recorder.RecordMarker<26, 801>();
            recorder.RecordMarker<27, 900>();
            clean_rows = 0;
            for (int32_t q_5 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_5 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_5) {
              clean_rows = (clean_rows > ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < consumed_slots.GetValue(((int64_t)q_5)) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : consumed_slots.GetValue(((int64_t)q_5))) * blocks_1) ? clean_rows : ((((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < consumed_slots.GetValue(((int64_t)q_5)) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : consumed_slots.GetValue(((int64_t)q_5))) * blocks_1));
            }
            if (0 < clean_rows) {
              AscendC::SetFlag<AscendC::HardEvent::S_V>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_V>(0);
              tl::ascend::Fill<uint32_t>(flags[0], (uint32_t)0, (clean_rows * 8));
              AscendC::SetFlag<AscendC::HardEvent::V_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_S>(0);
              AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(0);
              AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
              AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
              for (int32_t q_6 = ((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + ((experts_2 / cores_2) * core)); q_6 < ((((core < (experts_2 % cores_2) ? core : (experts_2 % cores_2)) + (experts_2 / cores_2)) + ((int32_t)(core < (experts_2 % cores_2)))) + ((experts_2 / cores_2) * core)); ++q_6) {
                cleared = 0;
                while (1) {
                  if (!((cleared < consumed_slots.GetValue(((int64_t)q_6))))) { break; }
                  int32_t n_1 = (((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) < (consumed_slots.GetValue(((int64_t)q_6)) - cleared) ? ((150 / blocks_1) < (4095 / blocks_1) ? (150 / blocks_1) : (4095 / blocks_1)) : (consumed_slots.GetValue(((int64_t)q_6)) - cleared));
                  int32_t offset_1 = ((((((((((q_6 % world_1) + rank_1) % world_1) * (experts_2 / world_1)) + (q_6 / world_1)) * tokens) + cleared) * blocks_1) * 128) + 120);
                  auto source_5 = flags[0].ReinterpretCast<uint32_t>();
                  auto target_3 = payload[offset_1].ReinterpretCast<uint32_t>();
                  tl::ascend::copy_ub_to_gm_strided<uint32_t>(target_3[0], source_5[0], 8, 128, (n_1 * blocks_1), 8);
                  cleared = (cleared + n_1);
                }
              }
              AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
              AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
            }
            recorder.RecordMarker<28, 901>();
          }
        }
      }
      AscendC::SetFlag<AscendC::HardEvent::S_MTE3>(0);
      AscendC::WaitFlag<AscendC::HardEvent::S_MTE3>(0);
      tl::ascend::copy_ub_to_gm<int, 16>(diagnostics[(core * 16)], diag[0], 1024, 1, 16);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_S>(0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_S>(0);
      recorder.RecordMarker<29, 2>();
    }
  }
  recorder.Flush(profileGM, static_cast<uint32_t>(AscendC::GetBlockIdx()));
  pipe.Destroy();
}
