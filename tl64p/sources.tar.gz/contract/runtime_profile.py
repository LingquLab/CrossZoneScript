"""[AI] ABI3真实导出→版本化TileXR打点源码/映射；离线操作，不编译或启动设备。"""
import argparse
import hashlib
import json
from pathlib import Path

from .runtime_contract import RUNTIME_ABI
from .runtime_device import ARGS, MARKER_BOUNDARY, MARKER_EVENTS, device_source


STAGES = {
    1: ('module.whole', 2), 10: ('F0.send_layout', 11),
    100: ('F1.route_read', 101), 200: ('F2.expert_count', 201),
    300: ('F3.count_publish', 301), 400: ('F4.pack_send', 401),
    500: ('F5.wait_count', 501), 600: ('F6.prefix_publish', 601),
    700: ('F7.layout_wait', 701), 702: ('F7.receive_plan', 703),
    704: ('F7.gate_poll', 705), 706: ('F7.gate_clear', 707),
    708: ('F7.count_clear', 709), 800: ('F8.payload_loop', 801),
    900: ('F9.payload_clear', 901),
}
EVENTS = {event: (name, edge) for begin, (name, end) in STAGES.items()
          for event, edge in ((begin, 'begin'), (end, 'end'))}
_BOUNDARY = MARKER_BOUNDARY
assert set(EVENTS) == MARKER_EVENTS


def sha(data):
    return hashlib.sha256(data).hexdigest()


def instrument(raw, metadata):
    """[AI] 先复用ABI3签名/SHA/UB门禁，仅替换TL明确导出的诊断槽边界写入。

    30个槽位对应循环外包络；条件未执行的核不生成该阶段事件。
    Recorder构造/Flush均不计入whole。F8保留所有输出排空，F9保留清理排空。
    不根据数据相关行号猜区间，也不沿用ABI2的52槽或104B profile签名。
    """
    device, details = device_source(raw, metadata, preserve_markers=True)
    calls = list(_BOUNDARY.finditer(device))
    event_ids = [int(call['event']) for call in calls]
    if len(event_ids) != len(EVENTS) or set(event_ids) != set(EVENTS):
        raise ValueError('ABI3 boundary stores missing, duplicated or unknown')
    slots = {event: index for index, event in enumerate(event_ids)}
    device = _BOUNDARY.sub(lambda m: f'recorder.RecordMarker<{slots[int(m["event"])]}, {m["event"]}>();', device)
    original_entry = details['entry']
    entry = original_entry + '_profile'
    signature = 'void ' + original_entry + '('
    if device.count(signature) != 1 or device.count('uint64_t fftsAddr) {') != 1:
        raise ValueError('ABI3 profiling signature boundary differs')
    device = device.replace(signature, 'void ' + entry + '(', 1)
    device = device.replace('uint64_t fftsAddr) {', 'uint64_t fftsAddr, GM_ADDR profileGM) {', 1)
    device = '#include <tilexr/profiling.h>\n' + device
    begin = '  pipe.InitBuffer(ascend_ub, ' + str(details['ub_bytes']) + ');'
    if device.count(begin) != 1 or device.count('  pipe.Destroy();') != 1:
        raise ValueError('ABI3 profiling TPipe boundary differs')
    device = device.replace(begin, begin + '\n  TileXR::Profiling::Recorder<32> recorder;', 1)
    # [AI] GetBlockIdx与纯AIV一核一lane；Host capture必须分配cores条独占lane。
    device = device.replace('  pipe.Destroy();',
                            '  recorder.Flush(profileGM, static_cast<uint32_t>(AscendC::GetBlockIdx()));\n'
                            '  pipe.Destroy();', 1)
    mapping = dict(schema='tilelang_dispatch_runtime_profile.v1', abi_version=RUNTIME_ABI,
                   entry=entry, args=ARGS + ['profileGM'], args_bytes_aarch64=112,
                   recorder_capacity=32, required_define='TILEXR_ENABLE_PROFILING=1',
                   event_slots=[dict(slot=slots[event], id=event, stage=EVENTS[event][0],
                                     edge=EVENTS[event][1]) for event in event_ids],
                   cores=metadata['cores'], capacity_limits=metadata['capacity_limits'],
                   receive_ub_plan=metadata['receive_ub_plan'], ub_bytes=details['ub_bytes'],
                   clock=dict(unit='raw_tick', cycles_per_us=None, alignment='NOT_VERIFIED',
                              rank='runtime descriptor word 5', whole='earliest/latest observed boundary'),
                   participation='Only executed begin/end pairs; never treat absent F8/F9 as zero-cost work',
                   exclusions=['Recorder constructor', 'Recorder Flush', 'TPipe setup/destroy',
                               'Host/ACL launch', 'pre-AllReduce'],
                   whole_boundary='Observed kernel business envelope, not full msprof device task',
                   device_compile='NOT_RUN', device_execution='NOT_RUN',
                   recorder_storage='Target compiler register/stack/UB effects NOT_VERIFIED',
                   raw_sha256=sha(raw.encode()), device_sha256=sha(device.encode()))
    return device, mapping


def adapt(source_dir, output_dir):
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    metadata_bytes = (source_dir / 'export.json').read_bytes()
    metadata = json.loads(metadata_bytes)
    root = Path(__file__).resolve().parents[2]
    for relative, expected in metadata['source_hashes'].items():
        source = (root / relative).resolve()
        if not source.is_relative_to(root) or sha(source.read_bytes()) != expected:
            raise ValueError('Runtime source provenance mismatch: ' + relative)
    raw = (source_dir / 'dispatch.raw.cpp').read_text()
    device, mapping = instrument(raw, metadata)
    mapping['source_export_sha256'] = sha(metadata_bytes)
    mapping['adapter_sha256'] = sha(Path(__file__).read_bytes())
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / 'dispatch.profile.cpp').write_text(device)
    (output_dir / 'runtime-profile.json').write_text(json.dumps(mapping, indent=2) + '\n')
    (output_dir / 'export.json').write_bytes(metadata_bytes)
    return mapping


def summarize_lanes(lanes):
    """[AI] 对单capture的原始Recorder事件按实际参与核统计，不建立跨核/跨rank时间轴。

    输入每条lane为{core, timestamps:[uint64], event_ids:[uint32]}。
    未执行阶段不混入均值分母；⑤聚合须调用方按接收/非接收核另分组。
    输出只保留ticks，最慢核记录真实core，绝不把不同阶段max相加。
    """
    collected = {name: [] for name, _ in STAGES.values()}
    seen_cores = set()
    by_core = {}
    for lane in lanes:
        core = lane['core']
        if type(core) is not int or core < 0 or core in seen_cores:
            raise ValueError('Invalid or duplicate logical core')
        seen_cores.add(core)
        stamps, ids = lane['timestamps'], lane['event_ids']
        if (len(stamps) != len(ids) or len(set(ids)) != len(ids) or
                any(type(event) is not int or event not in EVENTS for event in ids)):
            raise ValueError('Invalid or duplicate runtime marker events')
        values = dict(zip(ids, stamps))
        if any(type(tick) is not int or not 0 <= tick < 2**64 for tick in stamps):
            raise ValueError('Runtime timestamps must be uint64 raw ticks')
        if 1 not in values or 2 not in values:
            raise ValueError('Missing runtime whole envelope')
        durations = {}
        for begin, (name, end) in STAGES.items():
            if (begin in values) != (end in values):
                raise ValueError('Incomplete runtime stage pair: ' + name)
            if begin in values:
                duration = values[end] - values[begin]
                if duration < 0:
                    raise ValueError('Negative runtime interval')
                if values[begin] < values[1] or values[end] > values[2]:
                    raise ValueError('Runtime interval outside whole envelope')
                collected[name].append((core, duration))
                durations[name] = duration
        # [AI] 704–709是layout_wait内部细分，不得再次加到模块⑤，且必须落在父包络内。
        for begin in (704, 706, 708):
            end = STAGES[begin][1]
            if begin in values and (700 not in values or
                                   values[begin] < values[700] or values[end] > values[701]):
                raise ValueError('Runtime F7 substage outside layout_wait envelope')
        by_core[core] = durations
    # [AI] 同核逐阶段相加后才求模块mean/max；不同核均值/最大值从不直接相加。
    modules = {
        'module.public_prepare': ('F0.send_layout', 'F1.route_read'),
        'module.count_publish': ('F2.expert_count', 'F3.count_publish'),
        'module.pack_send': ('F4.pack_send',),
        'module.layout_prefix': ('F5.wait_count', 'F6.prefix_publish'),
        'module.receive_output': ('F7.layout_wait', 'F7.receive_plan', 'F8.payload_loop', 'F9.payload_clear'),
    }
    for name, components in modules.items():
        collected[name] = [(core, sum(stages.get(part, 0) for part in components))
                           for core, stages in by_core.items() if any(part in stages for part in components)]
    for cohort, receives in (('receivers', True), ('non_receivers', False)):
        collected['module.receive_output.' + cohort] = [
            (core, ticks) for core, ticks in collected['module.receive_output']
            if ('F8.payload_loop' in by_core[core]) == receives]
    result = {}
    for name, pairs in collected.items():
        result[name] = dict(status='EXECUTED' if pairs else 'NOT_EXECUTED',
                            cores=[core for core, _ in pairs], participants=len(pairs),
                            mean_ticks=sum(t for _, t in pairs) / len(pairs) if pairs else None,
                            max_ticks=max((t for _, t in pairs), default=None),
                            slowest_cores=[core for core, t in pairs if t == max(v for _, v in pairs)])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = adapt(args.source, args.output)
    print(json.dumps({key: result[key] for key in ('entry', 'args_bytes_aarch64', 'device_compile')}))


if __name__ == '__main__':
    main()
