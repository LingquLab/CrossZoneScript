"""[AI] ABI3原样导出→纯AIV编译输入；不插桩、不编译、不启动设备。"""
import argparse
import hashlib
import json
from pathlib import Path
import re

from .runtime_contract import RuntimeLimits, RUNTIME_ABI

ARGS = ['params', 'x', 'ids', 'mask', 'peers', 'state', 'payload', 'output',
        'assist', 'counts', 'expert_nums', 'diagnostics', 'fftsAddr_unused_u64']
ELEMENT_BYTES = {'uint8_t': 1, 'uint16_t': 2, 'uint32_t': 4, 'uint64_t': 8,
                 'int': 4, 'int32_t': 4, 'int64_t': 8, 'float': 4, 'half': 2, 'bfloat16_t': 2}
# [AI] 源码边界是普通TL诊断槽写入；raw移除，profile仅替换这些已知写入。
MARKER_EVENTS = frozenset((1, 2, 10, 11, 100, 101, 200, 201, 300, 301,
                           400, 401, 500, 501, 600, 601, 700, 701, 702, 703,
                           704, 705, 706, 707, 708, 709, 800, 801, 900, 901))
MARKER_BOUNDARY = re.compile(r'(?P<diag>\w+)\.SetValue\(\s*15,\s*'
                             r'(?:\((?:u?int32_t|int)\)\s*)?(?P<event>\d+)\s*\);')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def device_source(raw, metadata, *, preserve_markers=False):
    """[AI] 适配启动外壳和TPipe生命周期；只移除已核对的TL观测占位写入。

    容量/核数取自真实导出。拒绝未知签名、边界缺失、UB重叠或预算超限；
    不把ABI3的104B启动参数与历史ABI2的104B打点参数混用。
    """
    if metadata.get('abi_version') != RUNTIME_ABI or metadata.get('export_mode') != 'runtime':
        raise ValueError('Requires runtime ABI3 export')
    limits = RuntimeLimits(**metadata['capacity_limits'])
    plan = limits.ub_plan(metadata['cores'])
    if metadata['receive_ub_plan'] != plan:
        raise ValueError('Runtime capacity plan differs from export metadata')
    modules = metadata.get('modules', [])
    if len(modules) != 1 or modules[0]['module'] != 'dispatch' or sha(raw.encode()) != modules[0]['source_sha256']:
        raise ValueError('Runtime raw source SHA mismatch')
    boundary = '\nvoid dispatch_runtime_kernel_tiling() {\n'
    if raw.count(boundary) != 1:
        raise ValueError('Unexpected runtime Host wrapper boundary')
    device = raw.split(boundary)[0].rstrip()
    expected_args = ', '.join('GM_ADDR ' + name + '_handle' for name in ARGS[:-1]) + ', uint64_t fftsAddr'
    signature = re.search(r'void dispatch_runtime_kernel\(([^)]+)\)', device)
    if signature is None or ' '.join(signature[1].split()) != expected_args:
        raise ValueError('Unexpected ABI3 kernel argument signature')
    allocations = []
    for match in re.finditer(r'auto (\w+) = ascend_ub.GetWithOffset<(\w+)>\((\d+), (\d+)\);', device):
        name, dtype, count, offset = match.groups()
        if dtype not in ELEMENT_BYTES:
            raise ValueError('Unknown runtime UB dtype: ' + dtype)
        size = int(count) * ELEMENT_BYTES[dtype]
        allocations.append(dict(name=name, dtype=dtype, elements=int(count), offset=int(offset), bytes=size))
    if not allocations or any(row['offset'] % 32 or row['bytes'] <= 0 for row in allocations):
        raise ValueError('Unexpected runtime UB allocations/alignment')
    expected = limits.ub_buffers(metadata['cores'])
    by_name = {row['name']: row for row in allocations}
    if len(by_name) != len(allocations):
        raise ValueError('Duplicate runtime UB allocation name')
    roots = []
    for name, shape in expected.items():
        row = by_name.get(name)
        actual_dtype = ('int32' if row and row['dtype'] == 'int' else
                        row['dtype'].removesuffix('_t') if row else None)
        if row is None or actual_dtype != shape['dtype'] or row['elements'] != shape['elements']:
            raise ValueError('Runtime UB root contract mismatch: ' + name)
        roots.append(row)
    ordered = sorted(roots, key=lambda row: row['offset'])
    if any(a['offset'] + a['bytes'] > b['offset'] for a, b in zip(ordered, ordered[1:])):
        raise ValueError('Runtime UB root allocations overlap')
    # [AI] 编译器显式别名只能落在一个已知根缓冲内；不按GetWithOffset行数猜分配数。
    for row in allocations:
        if row['name'] not in expected:
            owners = [root for root in roots if root['offset'] <= row['offset'] and
                      row['offset'] + row['bytes'] <= root['offset'] + root['bytes']]
            if len(owners) != 1:
                raise ValueError('Unowned runtime UB allocation: ' + row['name'])
            row['alias_of'] = owners[0]['name']
    ub_bytes = max(row['offset'] + row['bytes'] for row in roots)
    if ub_bytes > plan['planned_bytes'] or ub_bytes > plan['ub_budget_bytes']:
        raise ValueError('Actual runtime UB exceeds declared budget')
    calls = list(MARKER_BOUNDARY.finditer(device))
    event_ids = [int(call['event']) for call in calls]
    diag_buffers = {row['name'] for row in allocations
                    if row['dtype'] in ('int', 'int32_t') and row['elements'] == 16}
    if (len(event_ids) != len(MARKER_EVENTS) or set(event_ids) != MARKER_EVENTS or
            len({call['diag'] for call in calls}) != 1 or
            any(call['diag'] not in diag_buffers for call in calls)):
        raise ValueError('Runtime TL marker stores missing, duplicated or unknown')
    if not preserve_markers:
        device = MARKER_BOUNDARY.sub('', device)
    begin = device.index('  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;')
    end = device.index('  pipe.Destroy();', begin) + len('  pipe.Destroy();')
    if device.count('pipe.Destroy();') != 1:
        raise ValueError('Unexpected runtime TPipe lifecycle')
    device = (device[:begin] + '  // [AI] 纯AIV仅分配实际UB，全部搬运完成后销毁。\n'
              '  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub;\n'
              f'  pipe.InitBuffer(ascend_ub, {ub_bytes});' + device[end:])
    task = 'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_1);'
    if device.count(task) != 1 or not device.endswith('}'):
        raise ValueError('Unexpected runtime task type/kernel boundary')
    entry = 'tilexr_tl_dispatch_runtime_c' + str(metadata['cores'])
    device = device.replace(task, 'KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);')
    device = device.replace('void dispatch_runtime_kernel(', 'void ' + entry + '(', 1)
    device = device.replace('#include <runtime/rt_ffts.h>\n', '')
    device = device[:-1] + '  pipe.Destroy();\n}\n'
    return device, dict(entry=entry, args=ARGS, args_bytes_aarch64=104,
                        ub_bytes=ub_bytes, allocations=allocations, ub_roots=expected,
                        marker_events=event_ids, marker_stores_preserved=preserve_markers)


def adapt(source_dir, output_dir):
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    metadata = json.loads((source_dir / 'export.json').read_text())
    root = Path(__file__).resolve().parents[2]
    for relative, expected in metadata['source_hashes'].items():
        source = root / relative
        if not source.resolve().is_relative_to(root) or sha(source.read_bytes()) != expected:
            raise ValueError('Runtime source provenance mismatch: ' + relative)
    raw = (source_dir / 'dispatch.raw.cpp').read_bytes()
    device, details = device_source(raw.decode(), metadata)
    result = dict(schema='tilelang_dispatch_runtime_device.v1', abi_version=RUNTIME_ABI,
                  cores=metadata['cores'], capacity_limits=metadata['capacity_limits'], **details,
                  instrumentation='NONE', device_compile='NOT_RUN', device_execution='NOT_RUN',
                  profiling='RAW_ONLY; use runtime_profile.py for the separate 112B profiling ABI',
                  source_export_sha256=sha((source_dir / 'export.json').read_bytes()),
                  adapter_sha256=sha(Path(__file__).read_bytes()),
                  raw_sha256=sha(raw), device_sha256=sha(device.encode()))
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / 'dispatch.device.cpp').write_text(device)
    (output_dir / 'export.json').write_bytes((source_dir / 'export.json').read_bytes())
    (output_dir / 'runtime-device.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    result = adapt(args.source, args.output)
    print(json.dumps({key: result[key] for key in ('entry', 'abi_version', 'ub_bytes', 'device_compile')}))


if __name__ == '__main__':
    main()
