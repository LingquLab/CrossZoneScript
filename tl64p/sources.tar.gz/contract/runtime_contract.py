"""[AI] 通用非量化入口的容量合同；同一导出在上限内接受运行时P/E/T/H/K/rank。

容量上限决定静态UB和张量声明，不是测试用例白名单。完整Memory功能的覆盖
状态见docs/REPLACEMENT.md；量化/共享专家在相应设备路径完成前显式拒绝。
"""
from dataclasses import dataclass
from .layout_reference import align_up, Config, reference, DFX_OFFSET, STATE_BYTES, CUMSUM_FLAG_OFFSET

RUNTIME_ABI = 3
PARAM_WORDS = 32
# [AI] 协议窗口单位为 uint32 word；gate 位于原生 cumsum 标志区。
STATE_WORDS = STATE_BYTES // 4
GATE_WORD = CUMSUM_FLAG_OFFSET // 4
READY = 0x3F800000
# [AI] 64P序号表在计数槽之后，最多1024个uint32。后接每发送核一行gate。
# 该形状384个计数槽仅12 KiB，前缀workspace即使200核也从468 KiB开始。
SEND_POSITION_WORD = (64 << 10) // 4
SEND_POSITION_GATE_WORD = SEND_POSITION_WORD + 128 * 8


@dataclass(frozen=True)
class RuntimeLimits:
    max_tokens: int = 256
    max_hidden: int = 1024
    max_top_k: int = 4
    max_experts: int = 16
    max_world_size: int = 8

    def __post_init__(self):
        if any(type(x) is not int or x <= 0 for x in vars(self).values()):
            raise ValueError('Capacity bounds must be positive integers')
        if self.max_world_size > 128:
            raise ValueError('Invalid rank/route capacity')

    @property
    def record_blocks(self):
        return (align_up(self.max_hidden * 2, 32) + 32 + 479) // 480

    @property
    def record_words(self):
        return self.record_blocks * 128

    @property
    def payload_words(self):
        return self.max_experts * self.max_tokens * self.record_words

    @property
    def cpu_window_words(self):
        return max(STATE_BYTES // 4, self.payload_words)

    def ub_buffers(self, cores):
        """[AI] 唯一kernel常驻UB根缓冲合同；位视图不另分配或计入预算。"""
        plan = self.ub_plan(cores)
        shapes = {
            'p': ('uint64', PARAM_WORDS),
            'route': ('int32', self.max_tokens * self.max_top_k),
            'active': ('uint8', self.max_tokens),
            'record': ('uint32', self.record_words),
            'records': ('uint32', self.max_experts * 8),
            'prefix': ('int32', align_up(self.max_experts, 8)),
            'consumed_slots': ('int32', self.max_experts * 3),
            'nums': ('int64', self.max_experts),
            'diag': ('int32', 16),
            'data_a': ('uint32', plan['batch_capacity'] * self.record_blocks * 120),
            'data_b': ('uint32', plan['batch_capacity'] * self.record_blocks * 120),
            'flags': ('uint32', plan['max_ready_rows'] * 8 + 72),
        }
        return {name: dict(dtype=dtype, elements=elements)
                for name, (dtype, elements) in shapes.items()}

    def ub_plan(self, cores):
        if type(cores) is not int or not 2 <= cores <= 200:
            raise ValueError('Invalid launch core count')
        # [AI] 与runtime_body的分配逐项对应；常驻区不重叠；A/B分别在F4/F6及接收阶段显式复用。
        sizes = (PARAM_WORDS * 8, self.max_tokens * self.max_top_k * 4,
                 self.max_tokens, self.record_words * 4,
                 self.max_experts * 32,
                 align_up(self.max_experts, 8) * 4, self.max_experts * 12,
                 self.max_experts * 8, 64)
        common = sum(align_up(s, 32) for s in sizes)
        # [AI] A/B各B*max_blocks*480，flags每块32B，另224B保护+64B结果。
        per = self.record_blocks * (2 * 480 + 32)
        capacity = min((190 * 1024 - common - 288) // per,
                       4095 // self.record_blocks)
        # [AI] READY初始化按偶数行容量；奇数行补32B也必须计入预算。
        while capacity > 0 and common + capacity * per + 288 + (capacity * self.record_blocks % 2) * 32 > 190 * 1024:
            capacity -= 1
        ready_rows = align_up(capacity * self.record_blocks, 2)
        planned = common + capacity * self.record_blocks * 960 + ready_rows * 32 + 288
        arena_words = capacity * self.record_blocks * 120
        padded_routes = align_up(self.max_tokens * self.max_top_k, 64)
        count_scratch = max(72, 2 * padded_routes + align_up((padded_routes + 31) // 32, 8))
        if (capacity < 1 or planned > 190 * 1024 or self.record_words * 4 > 65504
                or arena_words < max(self.record_words, count_scratch, align_up(self.max_experts, 8))):
            raise ValueError('Runtime capacity does not fit A5 UB/DMA; select a smaller class')
        if max(self.payload_words, self.max_experts * self.max_tokens * self.max_hidden,
               self.max_experts * self.max_tokens * 3, self.max_experts * 32) >= 2**31:
            raise ValueError('Runtime int32 address capacity exceeded')
        return dict(common_bytes=common, batch_capacity=capacity,
                    max_ready_rows=ready_rows,
                    planned_bytes=planned, ub_budget_bytes=190 * 1024)


@dataclass(frozen=True)
class RuntimeConfig:
    tokens: int = 256
    hidden: int = 256
    top_k: int = 2
    experts: int = 4
    world_size: int = 2
    rank: int = 0
    cores: int = 64
    magic: int = 1
    dtype: str = 'bf16'
    token_mask: bool = False
    expert_nums_type: int = 1
    quant_mode: int = 0
    shared_experts: int = 0
    shared_ranks: int = 0

    def layout(self, limits):
        if type(self.token_mask) is not bool or type(self.expert_nums_type) is not int:
            raise ValueError('mask must be bool and expert_nums_type must be int')
        shape = ('tokens', 'hidden', 'top_k', 'experts', 'world_size')
        if any(type(getattr(self, k)) is not int or
               not 1 <= getattr(self, k) <= getattr(limits, 'max_' + k) for k in shape):
            raise ValueError('Shape exceeds the compiled capacity class')
        if self.dtype not in ('bf16', 'fp16') or self.expert_nums_type not in (0, 1):
            raise ValueError('Invalid input dtype/expert output mode')
        if self.quant_mode or self.shared_experts or self.shared_ranks:
            raise NotImplementedError('Runtime device path currently supports non-quantized MoE experts only')
        cfg = Config(tokens=self.tokens, hidden=self.hidden, top_k=self.top_k,
                     experts=self.experts, world_size=self.world_size, rank=self.rank,
                     block_dim=self.cores, magic=self.magic)
        # [AI] 原生已知非量化布局及窗口容量；TL使用对齐分段prefix，UB按实际TL分配。
        rows = reference(cfg, single_cumsum=True, native_capacity=False, restrict_top_k=False)
        del rows
        plan = limits.ub_plan(self.cores)
        feature_bytes = self.hidden * 2
        aligned = align_up(feature_bytes, 32)
        blocks = (aligned + 32 + 479) // 480
        stride = align_up(self.experts, 8)
        workspace = self.cores * stride * 4
        if self.experts * 32 > 65504 or self.experts * 32 + workspace > DFX_OFFSET:
            raise ValueError('Runtime status/workspace overlap')
        return dict(feature_bytes=feature_bytes, aligned_feature_bytes=aligned,
                    record_blocks=blocks, record_words=blocks * 128,
                    packed_words=blocks * 120, expert_window_words=self.tokens * blocks * 128,
                    workspace_word=(DFX_OFFSET - workspace) // 4, workspace_stride=stride,
                    output_capacity_rows=self.experts * self.tokens, **plan)

    def words(self, limits):
        layout = self.layout(limits)
        # [AI] 保留旧描述符前11项的意义；12/13是mask及count/prefix模式，14为输入dtype。
        return [self.tokens, self.hidden, self.top_k, self.experts, self.world_size,
                self.rank, self.cores, self.magic, 0x100000000, 2**31,
                self.tokens * self.world_size, RUNTIME_ABI, int(self.token_mask),
                self.expert_nums_type, int(self.dtype == 'fp16'),
                layout['aligned_feature_bytes'] // 4, layout['record_blocks']] + [0] * (PARAM_WORDS - 17)


def runtime_strategy(config, limits):
    """[AI] Host可观测工作分工；与TL表达式同单位，不更改运行时描述符。"""
    layout = config.layout(limits)
    producers = min(8, (config.experts + 15) // 16, config.cores // 2)
    arena_words = layout['batch_capacity'] * limits.record_blocks * 120
    actual_batch = min(arena_words // layout['packed_words'],
                       layout['max_ready_rows'] // layout['record_blocks'],
                       4095 // layout['record_blocks'])
    return dict(prefix_producers=producers,
                count_workers=config.cores if config.tokens < 48 else producers,
                payload_workers=config.cores - producers,
                receive_workers=min(config.experts, config.cores),
                actual_batch_capacity=actual_batch,
                sender_buffers=min(2, arena_words // layout['record_words']),
                gate_bytes=config.cores * producers * 32,
                prefix_policy='aligned_disjoint_slices_independent_carry')


def select_capacity(config, candidates):
    """[AI] 从已编译容量档选择有效批量最大者；同档P/E/T/H/K保持运行时能力。

    返回清单下标，便于Host关联其固定ELF/符号；这里不编译、不JIT，不按rank专化。
    相同批量优先较少常驻UB，然后保持清单顺序。找不到即拒绝，不裁剪输入。
    """
    best = None
    for index, limits in enumerate(candidates):
        try:
            layout = config.layout(limits)
            strategy = runtime_strategy(config, limits)
        except (ValueError, NotImplementedError):
            continue
        score = (strategy['actual_batch_capacity'], -layout['common_bytes'], -index)
        if best is None or score > best[0]:
            best = score, index
    if best is None:
        raise ValueError('No compiled runtime capacity accepts this configuration')
    return best[1]
