#ifndef TILEXR_TILELANG_DISPATCH_RUNTIME_ABI_H
#define TILEXR_TILELANG_DISPATCH_RUNTIME_ABI_H

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>
#include <vector>

namespace tilexr {
namespace tilelang_dispatch {

// [AI] ABI3是12个GM指针+1个保留u64；参数字节数碰巧与历史ABI2相同，字段不兼容。
// params必须指向MakeRuntimeDescriptor产生、已完成H2D的256B描述符。
// peers为本rank当前轮的[P,2] uint64映射；所有窗口/输出寿命由调用方保持到stream完成。
struct RuntimeLaunchArgs {
    void *params, *x, *ids, *mask, *peers, *state, *payload, *output;
    void *assist, *counts, *expert_nums, *diagnostics;
    std::uint64_t ffts_addr_unused = 0;
};
struct RuntimeProfileLaunchArgs {
    RuntimeLaunchArgs runtime;
    // [AI] 当前launch独享的TileXR DeviceView GM地址，不是裸时间戳数组。
    void *profile_gm;
};
static_assert(std::is_standard_layout<RuntimeLaunchArgs>::value, "ABI3 requires standard layout");
static_assert(sizeof(void*) == 8 && sizeof(RuntimeLaunchArgs) == 104, "ABI3 requires 64-bit Host");
static_assert(offsetof(RuntimeLaunchArgs, diagnostics) == 88 &&
              offsetof(RuntimeLaunchArgs, ffts_addr_unused) == 96, "ABI3 field offsets differ");
static_assert(offsetof(RuntimeProfileLaunchArgs, profile_gm) == 104 &&
              sizeof(RuntimeProfileLaunchArgs) == 112, "ABI3 profiling requires 112B");

// [AI] ABI3仅描述非量化MoE Host参数；不注册内核、不分配窗口、不启动设备。
constexpr std::uint64_t kRuntimeAbi = 3;
constexpr std::size_t kParamWords = 32;
using RuntimeDescriptor = std::array<std::uint64_t, kParamWords>;
static_assert(sizeof(RuntimeDescriptor) == 256, "ABI3 descriptor must occupy 256 bytes");

struct RuntimeLimits {
    std::uint64_t max_tokens = 256, max_hidden = 1024, max_top_k = 4;
    std::uint64_t max_experts = 16, max_world_size = 8;
};

struct RuntimeConfig {
    std::uint64_t tokens = 256, hidden = 256, top_k = 2, experts = 4, world_size = 2;
    std::uint64_t rank = 0, cores = 64, magic = 1;
    // [AI] dtype=0为BF16、1为FP16；两者只搬运uint16位模式，不执行数值转换。
    std::uint64_t dtype = 0, token_mask = 0, expert_nums_type = 1;
    std::uint64_t quant_mode = 0, shared_experts = 0, shared_ranks = 0;
};

struct RuntimeLayout {
    std::uint64_t feature_bytes, aligned_feature_bytes, record_blocks, record_words;
    std::uint64_t packed_words, expert_window_words, workspace_word, workspace_stride;
    std::uint64_t output_capacity_rows;
    std::uint64_t common_bytes, batch_capacity, max_ready_rows, planned_bytes, ub_budget_bytes;
};

namespace detail {
// [AI] 输入来自Host，先检查uint64运算，再检查设备int32/原生uint32边界。
inline std::uint64_t Add(std::uint64_t a, std::uint64_t b) {
    if (a > std::numeric_limits<std::uint64_t>::max() - b)
        throw std::invalid_argument("Runtime integer overflow");
    return a + b;
}
inline std::uint64_t Mul(std::uint64_t a, std::uint64_t b) {
    if (b && a > std::numeric_limits<std::uint64_t>::max() / b)
        throw std::invalid_argument("Runtime integer overflow");
    return a * b;
}
inline std::uint64_t Align(std::uint64_t n, std::uint64_t alignment) {
    return Mul(Add(n, alignment - 1) / alignment, alignment);
}
inline std::uint64_t Blocks(std::uint64_t hidden) {
    return Add(Align(Mul(hidden, 2), 32), 511) / 480;
}
inline RuntimeLayout Capacity(const RuntimeLimits& l, std::uint64_t cores) {
    constexpr std::uint64_t budget = 190 * 1024;
    if (!l.max_tokens || !l.max_hidden || !l.max_top_k || !l.max_experts ||
        !l.max_world_size || l.max_world_size > 128 ||
        cores < 2 || cores > 200)
        throw std::invalid_argument("Invalid runtime capacity/core count");
    const auto blocks = Blocks(l.max_hidden);
    const auto words = Mul(blocks, 128);
    const std::uint64_t sizes[] = {
        kParamWords * 8, Mul(Mul(l.max_tokens, l.max_top_k), 4), l.max_tokens,
        Mul(words, 4), Mul(l.max_experts, 32),
        Mul(Align(l.max_experts, 8), 4), Mul(l.max_experts, 12), Mul(l.max_experts, 8), 64};
    std::uint64_t common = 0;
    for (auto size : sizes) common = Add(common, Align(size, 32));
    if (Add(common, 288) >= budget || Mul(words, 4) > 65504)
        throw std::invalid_argument("Runtime capacity exceeds A5 UB/DMA");
    const auto per = Mul(blocks, 992);
    auto capacity = std::min((budget - common - 288) / per, 4095 / blocks);
    while (capacity && Add(Add(common, Mul(capacity, per)),
                           288 + (Mul(capacity, blocks) % 2) * 32) > budget) --capacity;
    const auto rows = Align(Mul(capacity, blocks), 2);
    const auto planned = Add(Add(common, Mul(Mul(capacity, blocks), 960)), Add(Mul(rows, 32), 288));
    const auto routes = Mul(l.max_tokens, l.max_top_k);
    const auto padded_routes = Align(routes, 64);
    const auto count_scratch = std::max<std::uint64_t>(72, Add(Mul(padded_routes, 2), Align(Add(padded_routes, 31) / 32, 8)));
    const auto arena_words = Mul(Mul(capacity, blocks), 120);
    if (!capacity || planned > budget || arena_words < std::max(words, std::max(count_scratch, Align(l.max_experts, 8))))
        throw std::invalid_argument("Runtime capacity exceeds A5 UB/DMA");
    const auto slots = Mul(l.max_experts, l.max_tokens);
    if (Mul(slots, words) >= (1ULL << 31) || Mul(slots, l.max_hidden) >= (1ULL << 31) ||
        Mul(slots, 3) >= (1ULL << 31) || Mul(l.max_experts, 32) >= (1ULL << 31))
        throw std::invalid_argument("Runtime int32 address capacity exceeded");
    RuntimeLayout result{};
    result.common_bytes = common;
    result.batch_capacity = capacity;
    result.max_ready_rows = rows;
    result.planned_bytes = planned;
    result.ub_budget_bytes = budget;
    return result;
}
}  // namespace detail

inline RuntimeLayout MakeRuntimeLayout(const RuntimeConfig& c, const RuntimeLimits& l) {
    using detail::Add;
    using detail::Mul;
    using detail::Align;
    if (!c.tokens || c.tokens > l.max_tokens || !c.hidden || c.hidden > l.max_hidden ||
        !c.top_k || c.top_k > l.max_top_k || !c.experts || c.experts > l.max_experts ||
        !c.world_size || c.world_size > l.max_world_size || c.world_size > 128 ||
        c.rank >= c.world_size || c.cores < 2 || c.cores > 200 ||
        c.experts % c.world_size || c.magic >= (1ULL << 63) ||
        c.dtype > 1 || c.token_mask > 1 || c.expert_nums_type > 1)
        throw std::invalid_argument("Invalid runtime shape, rank or mode");
    if (c.quant_mode || c.shared_experts || c.shared_ranks)
        throw std::invalid_argument("Runtime quantization/shared experts are unsupported");
    auto r = detail::Capacity(l, c.cores);
    r.feature_bytes = Mul(c.hidden, 2);
    if (Mul(Mul(c.tokens, c.top_k), 4) >= (1ULL << 32) ||
        Mul(c.tokens, c.world_size) >= (1ULL << 32) ||
        r.feature_bytes >= (1ULL << 32) || c.experts >= (1ULL << 32))
        throw std::invalid_argument("Native uint32 shape arithmetic overflow");
    r.aligned_feature_bytes = Align(r.feature_bytes, 32);
    r.record_blocks = detail::Blocks(c.hidden);
    r.record_words = Mul(r.record_blocks, 128);
    r.packed_words = Mul(r.record_blocks, 120);
    r.expert_window_words = Mul(c.tokens, r.record_words);
    r.workspace_stride = Align(c.experts, 8);
    const auto workspace = Mul(Mul(c.cores, r.workspace_stride), 4);
    constexpr std::uint64_t dfx = 768 * 1024;
    if (Mul(c.experts, 32) > 65504 || Add(Mul(c.experts, 32), workspace) > dfx)
        throw std::invalid_argument("Runtime status/workspace capacity exceeded");
    r.workspace_word = (dfx - workspace) / 4;
    r.output_capacity_rows = Mul(c.experts, c.tokens);
    const auto combine = Mul(Mul(Mul(c.tokens, c.top_k), Add(r.feature_bytes, 479) / 480), 512);
    const auto dispatch = Mul(Mul(c.experts, r.expert_window_words), 4);
    constexpr std::uint64_t round_payload = (1022ULL << 20) - (1ULL << 20);
    if (Add(combine, dispatch) > round_payload || r.record_blocks > 255)
        throw std::invalid_argument("Native round window/record capacity exceeded");
    return r;
}

inline RuntimeDescriptor MakeRuntimeDescriptor(const RuntimeConfig& c, const RuntimeLimits& l) {
    const auto r = MakeRuntimeLayout(c, l);
    // [AI] 8/9保留Python参考的算术地址/窗口常量；真实peer映射由独立peers张量提供。
    RuntimeDescriptor words{};
    words[0] = c.tokens; words[1] = c.hidden; words[2] = c.top_k;
    words[3] = c.experts; words[4] = c.world_size; words[5] = c.rank;
    words[6] = c.cores; words[7] = c.magic; words[8] = 0x100000000ULL;
    words[9] = 1ULL << 31; words[10] = c.tokens * c.world_size; words[11] = kRuntimeAbi;
    words[12] = c.token_mask; words[13] = c.expert_nums_type; words[14] = c.dtype;
    words[15] = r.aligned_feature_bytes / 4; words[16] = r.record_blocks;
    return words;
}

inline void ValidateRuntimeDescriptor(const RuntimeDescriptor& words, const RuntimeLimits& limits) {
    RuntimeConfig c;
    c.tokens = words[0]; c.hidden = words[1]; c.top_k = words[2];
    c.experts = words[3]; c.world_size = words[4]; c.rank = words[5];
    c.cores = words[6]; c.magic = words[7]; c.token_mask = words[12];
    c.expert_nums_type = words[13]; c.dtype = words[14];
    if (words != MakeRuntimeDescriptor(c, limits))
        throw std::invalid_argument("Invalid ABI3 descriptor fields or reserved words");
}

// [AI] 与TL同一策略：小E单prefix，大E至多8个，全部片段32B对齐。
struct RuntimeStrategy {
    std::uint64_t prefix_producers, count_workers, payload_workers, receive_workers;
    std::uint64_t actual_batch_capacity, sender_buffers, gate_bytes;
};
inline RuntimeStrategy MakeRuntimeStrategy(const RuntimeConfig& c, const RuntimeLimits& l) {
    const auto r = MakeRuntimeLayout(c, l);
    const auto producers = std::min<std::uint64_t>(8, std::min((c.experts + 15) / 16, c.cores / 2));
    const auto arena = r.batch_capacity * detail::Blocks(l.max_hidden) * 120;
    const auto batch = std::min(arena / r.packed_words,
        std::min(r.max_ready_rows / r.record_blocks, 4095 / r.record_blocks));
    return {producers, c.tokens < 48 ? c.cores : producers, c.cores - producers,
        std::min(c.experts, c.cores), batch,
        std::min<std::uint64_t>(2, arena / r.record_words), c.cores * producers * 32};
}
inline std::size_t SelectRuntimeCapacity(const RuntimeConfig& c, const std::vector<RuntimeLimits>& candidates) {
    std::size_t best = candidates.size();
    std::uint64_t bestBatch = 0, bestCommon = std::numeric_limits<std::uint64_t>::max();
    for (std::size_t i = 0; i < candidates.size(); ++i) {
        try {
            const auto r = MakeRuntimeLayout(c, candidates[i]);
            const auto strategy = MakeRuntimeStrategy(c, candidates[i]);
            if (best == candidates.size() || strategy.actual_batch_capacity > bestBatch ||
                (strategy.actual_batch_capacity == bestBatch && r.common_bytes < bestCommon)) {
                best = i; bestBatch = strategy.actual_batch_capacity; bestCommon = r.common_bytes;
            }
        } catch (const std::invalid_argument&) { /* Capacity does not accept this input. */ }
    }
    if (best == candidates.size()) throw std::invalid_argument("No compiled runtime capacity accepts this configuration");
    return best;
}

}  // namespace tilelang_dispatch
}  // namespace tilexr
#endif
