#!/usr/bin/env python3
# Copyright (c) 2026 TileXR Project.
"""Run a prepared native case with SST, reconstruct exports and invoke its checker.

All objects, model files, environment scripts and checker identities are pinned.
This Linux execution entry never invokes a build or fixture preparation action.
"""

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
from pathlib import Path, PurePosixPath

if __package__:
    from .exports import export_actual, verify_guards
else:
    from exports import export_actual, verify_guards


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_files(root, files):
    for name, expected in files.items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Manifest path escapes the case")
        path = root / name
        if not path.resolve().is_relative_to(root.resolve()) or sha(path) != expected:
            raise ValueError("Case file changed: " + name)


def run(case, fixture, checker, environment, threads=8, timeout=1800):
    case, fixture, checker = (
        Path(case).resolve(),
        Path(fixture).resolve(),
        Path(checker).resolve(),
    )
    manifest = json.loads((case / "case-manifest.json").read_text())
    required = {
        "kernel/inter_server_send.o",
        "workload.yml",
        "export-layout.json",
        "test_UBusSim.py",
    }
    if (
        not required.issubset(manifest["files"])
        or manifest["entry"] != "tilexr_ep_ht_inter_server_send_kernel"
    ):
        raise ValueError("Native kernel and model files must be pinned")
    verify_files(case, manifest["files"])
    if sha(case / "kernel/inter_server_send.o") != manifest["kernel_sha256"]:
        raise ValueError("Blue object hash differs from case identity")
    layout = json.loads((case / "export-layout.json").read_text())
    if any(not row.get("guards") for row in layout["ranks"]):
        raise ValueError("Explicit per-rank guard exports are required")
    for key in ("sst_bin", "env_script", "decoder_library"):
        if sha(environment[key]) != environment[key + "_sha256"]:
            raise ValueError("SST environment identity changed: " + key)
    for path, expected in environment.get("runtime_files", {}).items():
        if sha(path) != expected:
            raise ValueError("SST model dependency changed: " + path)
    if sha(checker) != manifest["checker_sha256"]:
        raise ValueError("Candidate checker changed")
    verify_files(fixture, manifest["fixture_files"])
    if not threads > 0 or not timeout > 0:
        raise ValueError("Threads and timeout must be positive")
    # An existing run may have effects; require a fresh prepared case.
    record_path = case / "run.json"
    with record_path.open("x") as stream:
        json.dump(
            {
                "status": "reserved_not_started",
                "candidate_commit": manifest["candidate_commit"],
            },
            stream,
        )
    argv = [environment["sst_bin"], "-n", str(threads), str(case / "test_UBusSim.py")]
    command = [
        "bash",
        "-c",
        'set -e; source "$1"; shift; exec "$@"',
        "bash",
        environment["env_script"],
        *argv,
    ]
    record = {
        "status": "running",
        "candidate_commit": manifest["candidate_commit"],
        "command": argv,
        "timeout_seconds": timeout,
        "kernel_sha256": manifest["kernel_sha256"],
    }
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    with (case / "sim.log").open("wb") as log:
        try:
            child = subprocess.Popen(
                command,
                cwd=case,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        except OSError as error:
            record.update(status="start_failed", error=str(error))
            record_path.write_text(json.dumps(record, indent=2) + "\n")
            raise
        record["pid"] = child.pid
        record_path.write_text(json.dumps(record, indent=2) + "\n")

        def interrupt(signum, frame):
            raise KeyboardInterrupt

        previous = signal.signal(signal.SIGTERM, interrupt)
        try:
            code = child.wait(timeout=timeout)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
            record.update(
                status="timed_out"
                if isinstance(error, subprocess.TimeoutExpired)
                else "interrupted"
            )
            record_path.write_text(json.dumps(record, indent=2) + "\n")
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            record["returncode"] = child.returncode
            record_path.write_text(json.dumps(record, indent=2) + "\n")
            raise
        finally:
            signal.signal(signal.SIGTERM, previous)
    record["returncode"] = code
    try:
        if code:
            raise ValueError("SST exited nonzero")
        record["guards"] = verify_guards(
            layout, case / "bin", environment["decoder_library"]
        )
        actual = case / "actual"
        export_actual(layout, case / "bin", actual, environment["decoder_library"])
        check_command = [
            sys.executable,
            str(checker),
            "check",
            "--output",
            str(fixture),
            "--actual",
            str(actual),
        ]
        with (case / "check.log").open("wb") as log:
            checked = subprocess.run(
                check_command,
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=120,
                check=False,
            )
        if checked.returncode:
            raise ValueError("Native payload/readiness/status checker failed")
        verify_files(case, manifest["files"])
        verify_files(fixture, manifest["fixture_files"])
        record["status"] = "sst_and_checker_passed"
    except Exception as error:
        record.update(status="failed", error=str(error))
        raise
    finally:
        record_path.write_text(json.dumps(record, indent=2) + "\n")
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--environment", type=Path, required=True)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--timeout", type=int, default=1800)
    args = parser.parse_args()
    result = run(
        args.case,
        args.fixture,
        args.checker,
        json.loads(args.environment.read_text()),
        args.threads,
        args.timeout,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
