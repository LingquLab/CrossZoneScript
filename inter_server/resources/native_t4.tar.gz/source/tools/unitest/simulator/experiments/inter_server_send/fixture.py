# Copyright (c) 2026 TileXR Project.
# Generate standalone HT route/data fixtures and check actual exported payload/readiness.
"""Small EP64 InterServerSend fixtures, with no Torch/Notify dependency.

Generate: python tools/unitest/simulator/experiments/inter_server_send/fixture.py prepare --output /tmp/inter-send --tokens 4
Check:   python tools/unitest/simulator/experiments/inter_server_send/fixture.py check --output /tmp/inter-send --actual /tmp/received
The native C++ planner supplies the exact tiling ABI and SO/owner schedule.
"""

import argparse
from array import array
import json
from pathlib import Path
import struct
import subprocess
import sys

WORLD, TOPK = 64, 6
ROOT = Path(__file__).resolve().parents[5]


def chunk_id(token, tokens):
    first, splits = min(tokens, 256), min(tokens, 256, 4)
    return token * splits // first if token < first else token // 256 + splits - 1


def make_routes(tokens):
    """One gateway per token/server; alternate DIRECT and two-secondary runs."""
    routes = [[] for _ in range(WORLD)]
    for source in range(WORLD):
        for token in range(tokens):
            if (source + token) % 7 == 0:
                continue  # Sparse tokens and empty ranges.
            servers = {(source // 8 + 1) % 8, (source // 8 + 2 + token % 6) % 8}
            for server in sorted(servers):
                gateway = server * 8 + source % 8
                routes[gateway].append(
                    (source, token, (source + token + server) % 2 == 0)
                )
    return routes


def bf16_row(gateway, source, token, hidden):
    # Finite BF16 bit patterns distinguish route identity and element positions.
    base = 0x3F00 + (gateway * 67 + source * 13 + token * 17) % 512
    return [base + element % 13 for element in range(hidden)]


def build_arrays(tokens, hidden):
    if not 1 <= tokens <= 16384 or not 0 < hidden <= 7168 or hidden % 16:
        raise ValueError("Require T=1..16384 and H=16..7168, multiple of 16")
    routes = make_routes(tokens)
    rows = max(1, max(map(len, routes)))
    chunks = (tokens + 255) // 256 + min(tokens, 256, 4) - 1
    result = []
    golden = [array("H", [0]) * (tokens * 8 * hidden) for _ in range(WORLD)]
    for gateway, tasks in enumerate(routes):
        data = array("H", [0xBF80]) * (rows * hidden)
        partial = array("H", [0xC000]) * (rows * hidden)
        forward = array("i", [-1]) * (WORLD * tokens * TOPK * 6)
        counts = array("i", [0]) * WORLD
        ranges = array("i", [0]) * (WORLD * chunks * 2)
        for source in range(WORLD):
            source_tasks = [
                (row, t, reduced)
                for row, (s, t, reduced) in enumerate(tasks)
                if s == source
            ]
            index = 0
            for chunk in range(chunks):
                begin = index
                for row, token, reduced in source_tasks:
                    if chunk_id(token, tokens) != chunk:
                        continue
                    words = array("H", bf16_row(gateway, source, token, hidden))
                    (partial if reduced else data)[
                        row * hidden : (row + 1) * hidden
                    ] = words
                    run_size = 2 if reduced else 1
                    end = index + run_size
                    for secondary in range(run_size):
                        record = [
                            end,
                            token,
                            row,
                            gateway if reduced else -1,
                            row,
                            secondary if reduced else -1,
                        ]
                        start = (source * tokens * TOPK + index) * 6
                        forward[start : start + 6] = array("i", record)
                        index += 1
                    slot = (token * 8 + gateway // 8) * hidden
                    golden[source][slot : slot + hidden] = words
                offset = (source * chunks + chunk) * 2
                ranges[offset : offset + 2] = array("i", [begin, index])
            counts[source] = index
        result.append(
            dict(
                input=data,
                partial=partial,
                forward=forward,
                counts=counts,
                ranges=ranges,
            )
        )
    return dict(
        tokens=tokens,
        hidden=hidden,
        rows=rows,
        chunks=chunks,
        ranks=result,
        golden=golden,
    )


def write_array(path, values):
    copy = values[:]
    if sys.byteorder != "little":
        copy.byteswap()
    path.write_bytes(copy.tobytes())


def prepare(output, tokens, hidden):
    fixture = build_arrays(tokens, hidden)
    output.mkdir(parents=True, exist_ok=True)
    probe = output / "plan-probe"
    subprocess.run(
        [
            "c++",
            "-std=c++14",
            "-O2",
            "-I",
            str(ROOT / "include"),
            "-I",
            str(ROOT / "src/ep/combine_ht"),
            str(Path(__file__).with_name("plan_probe.cpp")),
            "-o",
            str(probe),
        ],
        check=True,
    )
    completed = [bytearray(WORLD * fixture["chunks"] * 2 * 512) for _ in range(WORLD)]
    for rank, arrays in enumerate(fixture["ranks"]):
        directory = output / f"rank{rank:02d}"
        directory.mkdir(exist_ok=True)
        for name, values in arrays.items():
            write_array(directory / f"{name}.bin", values)
        write_array(directory / "golden-returned.bin", fixture["golden"][rank])
        subprocess.run(
            [
                str(probe),
                str(rank),
                str(tokens),
                str(hidden),
                str(fixture["rows"]),
                str(directory / "tiling.bin"),
                str(directory / "plan.json"),
            ],
            check=True,
        )
        plan = json.loads((directory / "plan.json").read_text())
        for peer, chunk, _owner in plan["so"]:
            for lane in range(2):
                struct.pack_into(
                    "<Q",
                    completed[peer],
                    ((rank * fixture["chunks"] + chunk) * 2 + lane) * 512,
                    2026,
                )
    for rank, flags in enumerate(completed):
        (output / f"rank{rank:02d}" / "golden-completed.bin").write_bytes(flags)
    manifest = {name: fixture[name] for name in ("tokens", "hidden", "rows", "chunks")}
    manifest.update(
        world=64,
        topk=6,
        row_bytes=hidden * 2,
        return_slots=8,
        entry="tilexr_ep_ht_inter_server_send_kernel",
        block_dim=16,
        ready_epoch=fixture["chunks"],
        magic=2026,
        validation="generated_not_simulated",
    )
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def check(output, actual):
    manifest = json.loads((output / "manifest.json").read_text())
    for rank in range(WORLD):
        directory, received = output / f"rank{rank:02d}", actual / f"rank{rank:02d}"
        kernel_status = (received / "status.bin").read_bytes()
        if len(kernel_status) != 16 * 32 or any(
            struct.unpack_from("<I", kernel_status, i * 32)[0] for i in range(16)
        ):
            raise ValueError(f"rank{rank}: kernel status failed or export size differs")
        expected = (directory / "golden-returned.bin").read_bytes()
        payload = (received / "returned.bin").read_bytes()
        if payload != expected:
            raise ValueError(f"rank{rank}: returned payload/untouched slots differ")
        expected = (directory / "golden-completed.bin").read_bytes()
        flags = (received / "completed.bin").read_bytes()
        if len(flags) != len(expected):
            raise ValueError(f"rank{rank}: completion export size differs")
        # Check readiness word0; other words may contain legitimate credit checkpoints.
        for at in range(0, len(flags), 512):
            if flags[at : at + 8] != expected[at : at + 8]:
                raise ValueError(f"rank{rank}: readiness differs at slot {at // 512}")
    return dict(
        status="payload_readiness_and_status_verified",
        world=manifest["world"],
        tokens=manifest["tokens"],
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "check"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tokens", type=int, default=4)
    parser.add_argument("--hidden", type=int, default=256)
    parser.add_argument("--actual", type=Path)
    args = parser.parse_args()
    if args.action == "check" and args.actual is None:
        parser.error("check requires --actual")
    print(
        json.dumps(
            prepare(args.output, args.tokens, args.hidden)
            if args.action == "prepare"
            else check(args.output, args.actual),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
