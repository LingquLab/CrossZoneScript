# Copyright (c) 2026 TileXR Project.
"""Run the pinned installed SST platform model with the native case configuration.

Only platform construction is reused. The workload names the native HT entry and
its blue-built object; no AllToAll generation or validation runs here.
"""

import ast
import json
import sys
from pathlib import Path


def launch(case):
    snapshot = json.loads((case / "environment.snapshot.json").read_text())
    sys.path.insert(0, snapshot["settings"]["simulator_root"])
    source = case / "installed_model.py"
    tree = ast.parse(source.read_text())
    guard = ast.dump(ast.parse('if __name__ == "__main__": pass').body[0].test)
    if (
        not tree.body
        or not isinstance(tree.body[-1], ast.If)
        or ast.dump(tree.body[-1].test) != guard
    ):
        raise ValueError("Installed platform model has an unexpected main guard")
    main = tree.body.pop()
    namespace = {
        "__name__": "tilexr_platform_model",
        "__file__": snapshot["resources"]["installed_model.py"]["path"],
    }
    exec(compile(tree, str(source), "exec"), namespace)  # noqa: S102 -- Pinned installed model AST.
    namespace.update(__name__="__main__", __file__=str(case / "test_UBusSim.py"))
    tree.body = main.body
    exec(compile(tree, str(source), "exec"), namespace)  # noqa: S102 -- Pinned installed model AST.


if __name__ == "__main__":
    launch(Path(__file__).resolve().parent)
