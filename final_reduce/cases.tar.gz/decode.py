from pathlib import Path

V310_DECODER_SHA256 = "6d4cd3b729177646ca1c43d57971e5266a946405b6f820f3d0d914114b7ccfce"


def read_addressed(path, address, size):
    if address < 0 or size <= 0:
        raise ValueError("Need a nonempty chip-local output range")
    result, seen = bytearray(size), bytearray(size)
    with Path(path).open("rb") as stream:
        while True:
            record = stream.read(520)
            if not record:
                break
            if len(record) != 520:
                raise ValueError("Truncated addressed-512 dump: " + str(path))
            base = int.from_bytes(record[:8], "little")
            left, right = max(address, base), min(address + size, base + 512)
            for current in range(left, right):
                index, value = current - address, record[8 + current - base]
                if seen[index] and result[index] != value:
                    raise ValueError("Conflicting dump records: " + str(path))
                result[index], seen[index] = value, 1
    if not all(seen):
        raise ValueError("Missing dump bytes: " + str(path))
    return bytes(result)


def reconstruct_die_output(paths, address, size):
    if len(paths) != 2 or size <= 0 or address < 0:
        raise ValueError("Need two Die dumps and a nonempty chip-local range")
    copies = [read_addressed(path, address, size) for path in paths]
    result, offset = bytearray(size), 0
    while offset < size:
        current = address + offset
        die = ((current >> 9) ^ (current >> 16) ^ (current >> 23)) & 1
        count = min(size - offset, 512 - current % 512)
        result[offset : offset + count] = copies[die][offset : offset + count]
        offset += count
    return bytes(result)


